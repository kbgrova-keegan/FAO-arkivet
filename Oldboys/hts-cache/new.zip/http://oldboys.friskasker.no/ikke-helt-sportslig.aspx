
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">

	<head>

		<title>Ikke helt sportslig  - Frisk Asker Oldboys</title>
		
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
		<meta http-equiv="imagetoolbar" CONTENT="no">
		<meta name="keywords" content="" />
		<meta name="description" content="" />
		
		<meta name="title" content="Ikke helt sportslig - Frisk Asker Oldboys" />
		<meta name="URL" content="http://oldboys.friskasker.no" />
		<meta name="language" content="Norsk" />
		<meta name="author" content="Terje Dahl" />
		<meta name="copyright" content="Frisk Asker Oldboys" />
		<meta name="reply-to" content="terjda@online.no" />
		<meta name="verify-v1" content="BxVdMcZ0uoa2KVw8RB+FBg3715LgSDXNG+RYp0gHpAI=" />

		<link type="text/css" href="/css/client.css" rel="stylesheet" />
		<link type="text/css" href="/css/default.css" rel="stylesheet" />
		<link type="text/css" href="/css/weatherCSS.css" rel="stylesheet" />

		<script type="text/javascript" src="/js/jquery.js"></script>
		<script type="text/javascript" src="/js/ufo.js"></script>
		<script type="text/javascript" src="/js/friskasker.js"></script>
		<!--script type='text/javascript' src='http://www.rdmtech.no/js/jquery.js?ver=1.2.6'></script-->
		<!--script type='text/javascript' src='http://www.rdmtech.no/js/jquery.cross-slide.js?ver=2.6'></script-->

		<!--[if IE 6]>
		<link type="text/css" href="/css/ie60.css" rel="stylesheet" />			
		<![endif]-->
		<!-- TradeDoubler site verification 1588386 --> 

	<script type='text/javascript'>
		jQuery(function($) {$(document).ready(function() {
			$('#container2').crossSlide(
				{sleep: 2, fade: 1},
				[{src: 'http://oldboys.friskasker.no/media/26561/bg-fao1.jpg'},{src: 'http://oldboys.friskasker.no/media/26566/bg-fao2.jpg'},{src: 'http://oldboys.friskasker.no/media/26571/bg-fao3.jpg'},{src: 'http://oldboys.friskasker.no/media/26576/bg-fao4.jpg'}]
			);
		});});
	</script>
	
<script type="text/javascript">
var _polldaddy = [] || _polldaddy;

_polldaddy.push( {
    type: 'slider',
    title: 'FAO-spillemodellen, skjønner du den?',
    body: 'Ta testen og bidra til å øke sjansen for sportslig utvikling av FAO!',
    button: 'Get Started &raquo;',
    domain: 'risengaj96.polldaddy.com/s/',
    id: 'fao-spillemodellen',
    placeholder: 'pd1438692132734'
} );

jQuery(function(d,c,j){$if(!document.getElementById(j)){var pd=d.createElement(c),s;pd.id=j;pd.src=('https:'==document.location.protocol)?'https://polldaddy.com/survey.js':'http://i0.poll.fm/survey.js';s=document.getElementsByTagName(c)[0];s.parentNode.insertBefore(pd,s);}}(document,'script','pd-embed'));
</script>

	
	</head>
	
	<body>
      
        <div id="container">&nbsp;
        
            <div id="header">&nbsp;
            
                <div id="logo"><a href="/"><img src="/media/26597/logos.gif" alt="Logo" /></a></div>
                <div id="rss"><a href="/data/rss/nyheter.xml">Motta RSS strøm</a></div>
		<!--div id="sitemap"><a href="/sitemap.aspx">Sitemap</a></div-->
		<div id="topknapp">
		<iframe width="280" height="160" src="https://www.youtube.com/embed/15KEqzCTrwI" frameborder="0" allowfullscreen></iframe>
		</div>
		
                

            </div>
            
            <div id="body">&nbsp;
            
                <div id="left">&nbsp;

                    <div id="date">mandag 15. april</div>
                	
                    <div class="leftnav"><a href="/">Hjem</a><br /><a href="/arkiv.aspx">Arkiv</a><br /><a href="/tabeller--terminlister.aspx">Tabeller &amp; terminlister</a><br /><a href="/kampreferat.aspx">Kampreferat</a><br /><a href="/fotballfilosofi.aspx">Fotballfilosofi</a><br /><a href="/ikke-helt-sportslig.aspx" class="current">Ikke helt sportslig</a><br /></div>
		
                    <div class="box" id="contactbox"><div class="header">Frisk Asker</div><div class="body"><a href="/frisk-asker/laget.aspx">Laget</a><br /><a href="/frisk-asker/kontakt.aspx">Kontakt</a><br /><a href="/frisk-asker/dommerhjoernet.aspx">Dommerhjørnet</a><br /><a href="https://teams.s2s.net/11225/no/" target="_new">Treningstider</a></div><div class="footer"><!----></div></div>

<!--		     <iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/standard/Verdana/14/bold/230/1&rn=84" frameborder="0" scrolling="no" width="230" height="500"></iframe>
-->
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&banner=1&system=no_no/5212/1/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/standard/Verdana/14/bold/230/1&rn=94" frameborder="0" scrolling="no" width="230" height="214"></iframe>

		     <iframe src="http://www.s2s.net/todays_skill_external.php?ccc=no" scrolling="no" width="200" height="330" frameborder="0"></iframe>
<!--
		     <div id="login">&nbsp;
                   
                    <form id="loginform" action="#">&nbsp;
                      
                        <input id="username" type="text" value="brukernavn" />
                        <input id="password" type="text" value="passord" />
                        <img src="/img/login.gif" alt="login" />
                        <a href="#">glemt passord?</a>    
                        
                    </form>
                    
                    </div>
-->
		    <div id="search">

			Artikkelsøk:<br />
			<div id="xsltsearch" xmlns:ps="urn:percipientstudios-com:xslt"><form action="/soek.aspx?" method="post" class="xsltsearch_form"><input name="search" type="text" class="input" value=""></input> <input type="submit" value="Search" class="submit" /></form></div>
		    </div>

                </div>
                
                <div id="center">
		
                    
<div class="content">

	<h1>Ikke helt sportslig</h1>
	<p><b>Generelle betraktninger fra bakrommet</b></p><br/>



	<div class="newsitem"><h2>FAOs sommerkrim</h2><p><img src="/umbraco/imagegen.ashx?image=/media/115768/forside.png&amp;width=80" alt="Bilde" align="left" />FAO-dramatikk i 7 episoder</p><a class="readmore" href="/ikke-helt-sportslig/faos-sommerkrim.aspx">Les mer ...</a></div><div class="newsitem"><h2>Åpent brev</h2><p><img src="/umbraco/imagegen.ashx?image=/media/117231/hestk.png&amp;width=80" alt="Bilde" align="left" />Kjære fru Hapalahti</p><a class="readmore" href="/ikke-helt-sportslig/aapent-brev.aspx">Les mer ...</a></div><div class="newsitem"><h2>Frykt ikke, jeg kommer med et bud!</h2><p><img src="/umbraco/imagegen.ashx?image=/media/105571/messias.jpg&amp;width=80" alt="Bilde" align="left" />Lukk opp din hjertedør, og slipp solen inn!</p><a class="readmore" href="/ikke-helt-sportslig/frykt-ikke,-jeg-kommer-med-et-bud!.aspx">Les mer ...</a></div><div class="newsitem"><h2>Sannhetens time</h2><p><img src="/umbraco/imagegen.ashx?image=/media/104375/cave.jpg&amp;width=80" alt="Bilde" align="left" />Us and them</p><a class="readmore" href="/ikke-helt-sportslig/sannhetens-time.aspx">Les mer ...</a></div><div class="newsitem"><h2>Lagbygging</h2><p><img src="/umbraco/imagegen.ashx?image=/media/100269/boy.jpg&amp;width=80" alt="Bilde" align="left" />En sjørøvercapt'n, av den gode, gamle sorten</p><a class="readmore" href="/ikke-helt-sportslig/lagbygging.aspx">Les mer ...</a></div><div class="newsitem"><h2>Størst av alt er kjærligheten</h2><p><img src="/umbraco/imagegen.ashx?image=/media/100365/hjerte-i-solnedgang.jpg&amp;width=80" alt="Bilde" align="left" />A love story</p><a class="readmore" href="/ikke-helt-sportslig/stoerst-av-alt-er-kjaerligheten.aspx">Les mer ...</a></div><div class="newsitem"><h2>Hvem er Frisk Asker Oldboys?</h2><p><img src="/umbraco/imagegen.ashx?image=/media/92198/funny-philosophy.jpg&amp;width=80" alt="Bilde" align="left" />FAO har blitt stilt spørsmålet som så mange andre har stilt seg før.</p><a class="readmore" href="/ikke-helt-sportslig/hvem-er-frisk-asker-oldboys.aspx">Les mer ...</a></div><div class="newsitem"><h2>Aldersbestemt fotball - et spørsmål om idrettsglede</h2><p><img src="/umbraco/imagegen.ashx?image=/media/92691/lagbilde2 - rekke.jpg&amp;width=80" alt="Bilde" align="left" />En verdivurdering i Frisk Asker Oldboys</p><a class="readmore" href="/ikke-helt-sportslig/aldersbestemt-fotball---et-spoersmaal-om-idrettsglede.aspx">Les mer ...</a></div><div class="newsitem"><h2>A dream of an unmerited</h2><p><img src="/umbraco/imagegen.ashx?image=/media/93253/keegan.jpg&amp;width=80" alt="Bilde" align="left" />I have a dream</p><a class="readmore" href="/ikke-helt-sportslig/a-dream-of-an-unmerited.aspx">Les mer ...</a></div><div class="newsitem"><h2>No country for old men</h2><p><img src="/umbraco/imagegen.ashx?image=/media/67556/old.jpg&amp;width=80" alt="Bilde" align="left" />FAOs påskekrim</p><a class="readmore" href="/ikke-helt-sportslig/no-country-for-old-men.aspx">Les mer ...</a></div><div class="newsitem"><h2>No country for old men Part II</h2><p><img src="/umbraco/imagegen.ashx?image=/media/67633/fa-mafia.png&amp;width=80" alt="Bilde" align="left" />FAOs påskekrim - andre og siste episode</p><a class="readmore" href="/ikke-helt-sportslig/no-country-for-old-men-part-ii.aspx">Les mer ...</a></div><div class="newsitem"><h2>Påskekrim</h2><p><img src="/umbraco/imagegen.ashx?image=/media/58144/myra.jpg&amp;width=80" alt="Bilde" align="left" />Her følger både en krimfortelling og en påskenøtt på én gang – til trøst for gjenglemte fjellturister.</p><a class="readmore" href="/ikke-helt-sportslig/paaskekrim.aspx">Les mer ...</a></div><div class="newsitem"><h2>Påskekrim - del 2</h2><p><img src="/umbraco/imagegen.ashx?image=/media/58708/kakelys.bmp.jpg&amp;width=80" alt="Bilde" align="left" />Mordet på myra - siste episode av årets påskekrim</p><a class="readmore" href="/ikke-helt-sportslig/paaskekrim---del-2.aspx">Les mer ...</a></div><div class="newsitem"><h2>I avskjedens stund, en hyllest til lagmoralen på hjemmebane</h2><p><img src="/umbraco/imagegen.ashx?image=/media/58960/kiss.jpg&amp;width=80" alt="Bilde" align="left" />Oldboysspillere er familiekjære ektemenn, det er noe alle vet. 
Deres søknader om dispensasjon til the upcoming big event:  den årlige treningsleiren -  sitter langt inne. </p><a class="readmore" href="/ikke-helt-sportslig/i-avskjedens-stund,-en-hyllest-til-lagmoralen-paa-hjemmebane.aspx">Les mer ...</a></div><div class="newsitem"><h2>Heder og ære</h2><p><img src="/umbraco/imagegen.ashx?image=/media/59204/bilde3.png&amp;width=80" alt="Bilde" align="left" />I ærefullt ettermæle ordets glans vil aldri dø (Håvamål)
</p><a class="readmore" href="/ikke-helt-sportslig/heder-og-aere.aspx">Les mer ...</a></div><div class="newsitem"><h2>MiB (Meglere in Black)</h2><p><img src="/umbraco/imagegen.ashx?image=/media/61405/men-in-black.jpg&amp;width=80" alt="Bilde" align="left" />Med Askers skoleelever som ekstatiske tapere i skolestreiken, tar FAO ansvar og inviterer til historietime fra Nord-Irland.</p><a class="readmore" href="/ikke-helt-sportslig/mib-(meglere-in-black).aspx">Les mer ...</a></div><div class="newsitem"><h2>MiB II</h2><p><img src="/umbraco/imagegen.ashx?image=/media/61566/2370_krokryggen_la.jpg&amp;width=80" alt="Bilde" align="left" />   </p><a class="readmore" href="/ikke-helt-sportslig/mib-ii.aspx">Les mer ...</a></div><div class="newsitem"><h2>FAO på Norway Cup</h2><p><img src="/umbraco/imagegen.ashx?image=/media/50981/nc-logo.jpg&amp;width=80" alt="Bilde" align="left" />Salige er de saktmodige</p><a class="readmore" href="/ikke-helt-sportslig/fao-paa-norway-cup.aspx">Les mer ...</a></div><div class="newsitem"><h2>Dommer'n bestemmer</h2><p><img src="/umbraco/imagegen.ashx?image=/media/133297/gods hand_thumb.jpg&amp;width=80" alt="Bilde" align="left" />Da jeg traff Peter                                                                                                                    </p><a class="readmore" href="/ikke-helt-sportslig/dommer'n-bestemmer.aspx">Les mer ...</a></div><div class="newsitem"><h2>Fortellinger fra virkeligheten: En tur i svømmehallen - del 1</h2><p><img src="/umbraco/imagegen.ashx?image=/media/33700/badstue.jpg&amp;width=80" alt="Bilde" align="left" />Redaksjonen har prioritert å gjøre plass til en utenomsportslig fortelling, på grunn av det moderate aktivitetsnivået her på Oldboyssiden nå utenfor sesong.
Og dagens tema er: Selvinnsikt. 
</p><a class="readmore" href="/ikke-helt-sportslig/fortellinger-fra-virkeligheten-en-tur-i-svoemmehallen---del-1.aspx">Les mer ...</a></div><div class="newsitem"><h2>En tur i svømmehallen - del 2</h2><p><img src="/umbraco/imagegen.ashx?image=/media/34630/ludvik.jpg&amp;width=80" alt="Bilde" align="left" />Den elleville historien fra Risenga svømmehall fortsetter mot sitt intense anti-klimaks.</p><a class="readmore" href="/ikke-helt-sportslig/en-tur-i-svoemmehallen---del-2.aspx">Les mer ...</a></div><div class="newsitem"><h2>En tur i svømmehallen - 3. og siste del</h2><p><img src="/umbraco/imagegen.ashx?image=/media/34686/selfimage.jpg&amp;width=80" alt="Bilde" align="left" />I badstueoppgjøret mellom FAO og Polski Sauna Wyborowa har bortelaget tatt føringen. Spørsmålet er ikke lenger om vi kan vinne, men om vi kan komme fra det uten varige mén. 
Advarsel: No happy ending. 
</p><a class="readmore" href="/ikke-helt-sportslig/en-tur-i-svoemmehallen---3-og-siste-del.aspx">Les mer ...</a></div><div class="newsitem"><h2>Dramatisk hendelse på Bleiker</h2><p><img src="/umbraco/imagegen.ashx?image=/media/12957/gulfisken.jpg&amp;width=80" alt="Bilde" align="left" />Det har kommet redaksjonen for øre at en av våre spillere har hatt en sterk opplevelse denne uken, men vedkommende ønsker å være anonym for å ha sjansen til å bevare den nødvendige respekten på banen, hvilket naturligvis etterkommes.</p><a class="readmore" href="/ikke-helt-sportslig/dramatisk-hendelse-paa-bleiker.aspx">Les mer ...</a></div><div class="newsitem"><h2>Noen fakta om fisk</h2><p>2. episode i den utrolige gullfiskhistorien</p><a class="readmore" href="/ikke-helt-sportslig/noen-fakta-om-fisk.aspx">Les mer ...</a></div><div class="newsitem"><h2>A fishy theory</h2><p>I 3. og siste episode avsløres den ville gullfiskhistoriens etterlengtede slutt. </p><a class="readmore" href="/ikke-helt-sportslig/a-fishy-theory.aspx">Les mer ...</a></div>

</div>




                </div>
                
		 <div id="right">

<font color="red" size="4">Lagbilde</font><br/>


<!--a href="http://oldboys.friskasker.no/media/116678/formkurve.png" border=0><img src="/media/116678/formkurve.png" width="280" alt="Formkurve" /></a-->
<!--iframe src="http://free.timeanddate.com/countdown/i5t3zil3/n187/cf113/cm0/cu4/ct0/cs0/ca0/cr0/ss0/cac000/cpc000/pc00e60b/tc000/fs100/szw320/szh135/tatFAO%20h%C3%B8stsesong%20starter%20om../tac000/tptTime%20since%20Event%20started%20in/tpc000/mac000/mpc000/iso2017-08-14T21:00:00" allowTransparency="true" frameborder="0" width="320" height="135"></iframe-->
	<!--iframe frameborder="0" width="512" height="600" scrolling="auto" allowtransparency="true" src="https://risengaj96.polldaddy.com/s/fao-plassering-pr-lag-2018?iframe=1"><a href="https://risengaj96.polldaddy.com/s/fao-plassering-pr-lag-2018">View Survey</a></iframe-->
<br/>
<!-- FORMkurve iframe width="508" height="371" seamless frameborder="0" scrolling="no" src="https://docs.google.com/spreadsheets/d/1wL8AGtLu517MG4vlWG2DIat7LmhdKaJdXz4nDVsxc74/pubchart?oid=1826601090&amp;format=interactive"></iframe-->

<!-- iphone
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/iphone/Verdana/14/bold/250/1&rn=7" frameborder="0" scrolling="no" width="250" height="500"></iframe>
-->
	<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/iphone/Verdana/14/bold/280/1&rn=83" frameborder="0" scrolling="no" width="280" height="500"></iframe>
<!--
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/21/ae82202846179cbfa34c266edf916f37&colours=FF8C00/CCCCCC/FFF/4/standard/Comic+Sans+Serif/16/bold/280/1&rn=22" frameborder="0" scrolling="no" width="280" height="500"></iframe>
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/members&bits=25/21/ae82202846179cbfa34c266edf916f37&colours=FF8C00/CCCCCC/FFF/4/standard/Comic+Sans+Serif/16/bold/280/1&rn=50" frameborder="0" scrolling="no" width="280" height="500"></iframe>
-->
<!-- iframe src="https://www.s2s.net/export_content.php?team_id=1101&system=no_no/1032/2/one/activities&bits=25/21/68565729bae64238443339aae6dcf62c&colours=FF6600/000099/FFF/0/iphone/Verdana/12/bold/280/0" frameborder="0" scrolling="no" width="280" height="500"></iframe -->

<br/><br/>
<a href="http://www.forstehjelpsgrossisten.no/products/is-pose-stor-14-x-21-cm-i-kartong-av-24-stk" border="0" target="_new"><img src="/umbraco/imagegen.ashx?image=/media/114144/forstehjelpsgrossistem.png&width=280"></a>
<br/>
<div style="text-align: left; width:280px;">Stolt sponsor av Frisk Asker Oldboys!</div>

                                        
                </div>

            </div>
            
        </div>
	<div id="bottomad"><!-- Bunnbanner -->
<!--
<script type="text/javascript">
var uri = 'http://impno.tradedoubler.com/imp?type(js)g(17626798)a(1588386)' + new String (Math.random()).substring (2, 11);
document.write('<sc'+'ript type="text/javascript" src="'+uri+'" charset=""></sc'+'ript>');
</script>
-->
<a href="http://www.google.com" target="_blank">.</a>
<a href="http://www.google.com/search?q=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://www.yahoo.com" target="_blank">.</a>
<a href="http://search.yahoo.com/search?p=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://search.aol.co.uk" target="_blank">.</a>
<a href="http://search.aol.co.uk/aol/search?query=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://uk.ask.com" target="_blank">.</a>
<a href="http://uk.ask.com/web?q=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://search.live.com" target="_blank">.</a>
<a href="http://search.live.com/results.aspx?q=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://search.lycos.co.uk" target="_blank">.</a>
<a href="http://search.lycos.co.uk/cgi-bin/pursuit?SITE=uk&query=frisk+asker+oldboys" target="_blank">.</a>

	</div>

<script type="text/javascript">
var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
</script>
<script type="text/javascript">
var pageTracker = _gat._getTracker("UA-2025203-1");
pageTracker._initData();
pageTracker._trackPageview();
</script></body>
</html>
