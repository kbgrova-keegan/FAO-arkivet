
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">

	<head>

		<title>Episode 7: Avgjørelsen  - Frisk Asker Oldboys</title>
		
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
		<meta http-equiv="imagetoolbar" CONTENT="no">
		<meta name="keywords" content="" />
		<meta name="description" content="
Syvende og siste episode i FAOs forrykende sommerkrim
" />
		
		<meta name="title" content="Episode 7: Avgjørelsen - Frisk Asker Oldboys" />
		<meta name="URL" content="http://oldboys.friskasker.no" />
		<meta name="language" content="Norsk" />
		<meta name="author" content="Terje Dahl" />
		<meta name="copyright" content="Frisk Asker Oldboys" />
		<meta name="reply-to" content="terjda@online.no" />
		<meta name="verify-v1" content="BxVdMcZ0uoa2KVw8RB+FBg3715LgSDXNG+RYp0gHpAI=" />

		<link type="text/css" href="/css/client.css" rel="stylesheet" />
		<link type="text/css" href="/css/default.css" rel="stylesheet" />
		<link type="text/css" href="/css/weatherCSS.css" rel="stylesheet" />

		<script type="text/javascript" src="/js/jquery.js"></script>
		<script type="text/javascript" src="/js/ufo.js"></script>
		<script type="text/javascript" src="/js/friskasker.js"></script>
		<!--script type='text/javascript' src='http://www.rdmtech.no/js/jquery.js?ver=1.2.6'></script-->
		<!--script type='text/javascript' src='http://www.rdmtech.no/js/jquery.cross-slide.js?ver=2.6'></script-->

		<!--[if IE 6]>
		<link type="text/css" href="/css/ie60.css" rel="stylesheet" />			
		<![endif]-->
		<!-- TradeDoubler site verification 1588386 --> 

	<script type='text/javascript'>
		jQuery(function($) {$(document).ready(function() {
			$('#container2').crossSlide(
				{sleep: 2, fade: 1},
				[{src: 'http://oldboys.friskasker.no/media/26561/bg-fao1.jpg'},{src: 'http://oldboys.friskasker.no/media/26566/bg-fao2.jpg'},{src: 'http://oldboys.friskasker.no/media/26571/bg-fao3.jpg'},{src: 'http://oldboys.friskasker.no/media/26576/bg-fao4.jpg'}]
			);
		});});
	</script>
	
<script type="text/javascript">
var _polldaddy = [] || _polldaddy;

_polldaddy.push( {
    type: 'slider',
    title: 'FAO-spillemodellen, skjønner du den?',
    body: 'Ta testen og bidra til å øke sjansen for sportslig utvikling av FAO!',
    button: 'Get Started &raquo;',
    domain: 'risengaj96.polldaddy.com/s/',
    id: 'fao-spillemodellen',
    placeholder: 'pd1438692132734'
} );

jQuery(function(d,c,j){$if(!document.getElementById(j)){var pd=d.createElement(c),s;pd.id=j;pd.src=('https:'==document.location.protocol)?'https://polldaddy.com/survey.js':'http://i0.poll.fm/survey.js';s=document.getElementsByTagName(c)[0];s.parentNode.insertBefore(pd,s);}}(document,'script','pd-embed'));
</script>

	
	</head>
	
	<body>
      
        <div id="container">&nbsp;
        
            <div id="header">&nbsp;
            
                <div id="logo"><a href="/"><img src="/media/26597/logos.gif" alt="Logo" /></a></div>
                <div id="rss"><a href="/data/rss/nyheter.xml">Motta RSS strøm</a></div>
		<!--div id="sitemap"><a href="/sitemap.aspx">Sitemap</a></div-->
		<div id="topknapp">
		<iframe width="280" height="160" src="https://www.youtube.com/embed/15KEqzCTrwI" frameborder="0" allowfullscreen></iframe>
		</div>
		
                

            </div>
            
            <div id="body">&nbsp;
            
                <div id="left">&nbsp;

                    <div id="date">mandag 15. april</div>
                	
                    <div class="leftnav"><a href="/">Hjem</a><br /><a href="/arkiv.aspx">Arkiv</a><br /><a href="/tabeller--terminlister.aspx">Tabeller &amp; terminlister</a><br /><a href="/kampreferat.aspx">Kampreferat</a><br /><a href="/fotballfilosofi.aspx">Fotballfilosofi</a><br /><a href="/ikke-helt-sportslig.aspx">Ikke helt sportslig</a><br /></div>
		
                    <div class="box" id="contactbox"><div class="header">Frisk Asker</div><div class="body"><a href="/frisk-asker/laget.aspx">Laget</a><br /><a href="/frisk-asker/kontakt.aspx">Kontakt</a><br /><a href="/frisk-asker/dommerhjoernet.aspx">Dommerhjørnet</a><br /><a href="https://teams.s2s.net/11225/no/" target="_new">Treningstider</a></div><div class="footer"><!----></div></div>

<!--		     <iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/standard/Verdana/14/bold/230/1&rn=84" frameborder="0" scrolling="no" width="230" height="500"></iframe>
-->
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&banner=1&system=no_no/5212/1/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/standard/Verdana/14/bold/230/1&rn=94" frameborder="0" scrolling="no" width="230" height="214"></iframe>

		     <iframe src="http://www.s2s.net/todays_skill_external.php?ccc=no" scrolling="no" width="200" height="330" frameborder="0"></iframe>
<!--
		     <div id="login">&nbsp;
                   
                    <form id="loginform" action="#">&nbsp;
                      
                        <input id="username" type="text" value="brukernavn" />
                        <input id="password" type="text" value="passord" />
                        <img src="/img/login.gif" alt="login" />
                        <a href="#">glemt passord?</a>    
                        
                    </form>
                    
                    </div>
-->
		    <div id="search">

			Artikkelsøk:<br />
			<div id="xsltsearch" xmlns:ps="urn:percipientstudios-com:xslt"><form action="/soek.aspx?" method="post" class="xsltsearch_form"><input name="search" type="text" class="input" value=""></input> <input type="submit" value="Search" class="submit" /></form></div>
		    </div>

                </div>
                
                <div id="center">
		
                    
<div class="content">

	<!--h1>Episode 7: Avgjørelsen</h1-->
	<!--p><b><p>Syvende og siste episode i FAOs forrykende sommerkrim</p></b></p><br/-->

	<h1>Episode 7: Avgjørelsen</h1><div class="meta">07.07.16 17:48 - </div><div class="abstract"><img src="/umbraco/imagegen.ashx?image=/media/115223/episode 7.png&amp;width=80" alt="" align="left" />
<p>Syvende og siste episode i FAOs forrykende sommerkrim</p>
</div>
<p>&nbsp;</p>

<p>&nbsp;</p>

<p><strong>Avgjørelsen</strong><br />
<br />
 «Her kommer de!»<br />
 Troppssjefen for beredskapstroppen sto og så ut av sprekken i
teltduken på partyteltet. Han sto med nattkikkert og kunne se
infrarøde konturer av tre personer inne i bygget.<br />
 «Flott», sa Brøyn.<br />
 Nå var endelig tiden kommet. På fersk gjerning! Her skulle det bli
solide represalier fra storsamfunnet, ja.<br />
 «Gjør dere klare», sa han og dro kikkerten ut av hendene på
troppssjefen.<br />
 Hele beredskapstroppen hadde reist seg, og rigget seg klare.<br />
 Brøyn satte nattkikkerten til øynene.<br />
 Han så bevegelser innerst i lokalet, så så han konturene av tre
personer.<br />
 «He he, rett i garnet. Rett i garnet. Med hele byttet.»<br />
 Han stirret i kikkerten.<br />
 Så skrudde han på linsen, først til venstre, så til høyre.<br />
 «Men i svarte…», mumlet han.<br />
 Troppssjefen hadde funnet frem en annen kikkert, og sto også og
stirret.<br />
 «Nå kommer den første av dem!», hvisket han.<br />
 «Vent», sa den eldste etterforskeren. «Inspektør Brøyn, han bærer
ikke på noe», sa han med trykk på hvert av ordene.<br />
 «Jeg ser det», sa Brøyn<br />
 Så kom det to skikkelser til.<br />
 «La oss sette i gang!» sa troppssjefen.<br />
 «Ikke før sjefen sier det!» sa etterforskeren, og la en arm på
skulderen til troppssjefen.<br />
 «Brøyn, ingen av dem bærer på noe», sa han.<br />
 Brøyn så bort på statsadvokaten.<br />
 Statsadvokaten satt også og så, og han holdt seg over munnen med
hånden.<br />
 Han så lenge på Brøyn med en oppgitt mine. Så viftet han med
hånden, bøyde hodet, og gned hånden i fjeset.<br />
 Brøyn så bort på troppssjefen.<br />
 Så stirret han bort på de tre skikkelsene som gikk ned
trappa.<br />
 «OK», sa han. «La dem gå.»<br />
 «Hva? Hva mener du? Vi kan ta dem nå!» sa troppssjefen.<br />
 «For hva?» freste Brøyn. «Hva har du tenkt å ta dem for? Å bryte
seg inn? De har ikke stjålet noe. Forstår du? De vil bli stilt opp
for en pinglete dommerjævel, som ikke vil blåse i fløyta i det hele
tatt, knapt gi dem tilsnakk, og så er de tilbake igjen i neste
kamp. Ikke faen.»<br />
 Brøyn lukket øynene.<br />
 Troppssjefen hevet stemmen. «Jeg nekter å ta imot den kjeften jeg
kommer til å få av sjefen min, for at du lar dem gå. Nå slipper de
jo unna!», sa han.<br />
 «Det er akkurat det de gjør, de slipper unna», sa Brøyn. «Dette er
<em>min</em> operasjon, <em>jeg</em> har den taktiske kommandoen,
som er en høyere rang enn din, og <em>ja</em>, de vil slippe unna,
og <em>du</em> vil la dem gjøre det.» Han slang kikkerten i bakken.
«Helvete!»<br />
<br />
 De tre skikkelsene ruslet over parkeringsplassen. Den ene satte
seg inn i en bil, startet opp, og kjørte av sted. Den andre låste
opp en sykkel, tok en slurk av vannflaska i flaskeholderen, og
syklet etter. Den tredje slentret samme vei, mens han sparket til
småstein her og der. Så var de borte.<br />
<br />
 Inspektør Brøyn dro teltduken til side og gikk ut av teltet.<br />
 Beredskapstroppen gikk også ut, og de sto der alle og så på
hverandre.<br />
 Inspektør Brøyn snudde seg sakte rundt.<br />
 Han sto åndsfraværende med den ødelagte kikkerten og slo den mot
låret.<br />
 Så svingte han kikkerten i en bue med armen og slang den over til
troppssjefen, som fanget den i hendene.<br />
 Brøyn sukket. «Tilbake til kontorpulten», sa han og gikk.<br />
<br />
<br />
 *<br />
<br />
 SMS-korrspondanse:<br />
 <em>Kasserer Reodor:&nbsp; Det ser ut som at du kan legge inn
synderne i app'ene igjen.<br />
 Turbo:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
OK. Det var jo hyggelig.<br />
 Kasserer Reodor: Jepp. Alle betalte med DnB Vipps på lørdag
kveld.<br />
 Turbo:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
Utført! Alle er nå lagt til igjen.<br />
 Kasserer Reodor: Good. Litt merkelig egentlig. Alle
vipps-transaksjonene ble gjort innenfor det samme minuttet midt på
natta på lørdag.<br />
 Turbo:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
Strange. Kanskje de hacka seg inn på DnBs vipps-server, he he
;-)<br />
 Kasserer Reodor:&nbsp; :-) Ikke utenkelig. For de har betalt
forskudd for de neste 10 årene også.<br />
 Turbo:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
Fantastisk. Flotte karer.</em><br />
<br />
 *<br />
<br />
 Sunny satte seg ned på stolen med et fornøyd ansiktsuttrykk.<br />
 Festmiddagen var utsøkt.<br />
 Han var nettopp ferdig med talen, med velfortjent skryt av
spillerne for deres heltemodige innsats.<br />
 Han så utover bordet. Nederst ved enden satt Bønna, Mads og Moa,
og småkjeklet om ett eller annet. De hadde ikke hørt et ord av det
han hadde sagt. Ved siden av dem satt Trond-2 og tastet på
mobiltelefonen, han drev og meldte med en eller annen berte.<br />
 Bortenfor satt Happi og glippet med øya, med stinne kinn.
Forspist. Hadde forsynt seg 6 ganger.<br />
 Ved siden av ham satt Alex og sov.<br />
 Sunny smilte for seg selv, og reiste seg fra stolen igjen. Han
gikk bort til vinduet og så ut. Naboen hadde endelig pakket ned
partyteltet.<br />
 Han snudde seg og ble stående og se på banden sin.<br />
 Some bunch, tenkte han.<br />
 Han tok glasset sitt og tok en slurk. Happi hevet glasset sitt og
skålte med ham, før han satte det skeivt ned på bordet, så glasset
veltet.<br />
<br />
 Hvordan ville det vært, om han hadde hatt en ekte bande?<br />
 Hvordan ville det vært, om han hadde hatt ambisjoner?<br />
 Om han hadde satt seg mål?<br />
 Sunny så på dem der de satt.<br />
 Mads møtte blikket hans, smilte, og reiste glasset. De skålte.
Mads tok glasset på styrten.<br />
<br />
 Vel, det ville han aldri få vite.<br />
 Det er ikke mye til bande, okay, tenkte han.<br />
 Men det er <em>min</em> bande.<br />
 Og vi er de vi er.<br />
 Hverken mer eller mindre.<br />
 Det gjør det jo bare desto mer spennende på veien.<br />
<br />
</p>

<p>&nbsp;</p>

<h2>The End</h2>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p><em>Etterord:</em></p>

<p>På Frisk Asker Oldboys pleier vi ikke å ha etterord.<br />
 Vi bare rusler hjem, over parkeringsplassen.<br />
 <em>Hvis</em> noen skulle komme til å si noe, så sier de uansett
bare det samme som de også sa <em>før</em> kampen.<br />
 Så da kan vi heller like godt gjenta forordet:</p>

<p><em>Sunny's Seven</em> er en historie basert på virkelige
hendelser. Bare lagt inn i en action-kontekst. Enhver likhet med
virkelige personer er tilsiktet og langt fra tilfeldig.</p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p><br />
 Rulletekst:<br />
<br />
 In order of apperance:<br />
<br />
 Etterforsker d.y……………………&nbsp;&nbsp; &nbsp;Amir<br />
 Etterforsker d.e……………………&nbsp;&nbsp; &nbsp;Kikki<br />
 Statsadvokaten…………… ………&nbsp;&nbsp; Reodor<br />
 Sunny………………………...........&nbsp;&nbsp; &nbsp;Himself<br />
 Alex…………………………...........&nbsp;&nbsp; &nbsp;Himself<br />
 Moa………………………………....&nbsp;&nbsp; &nbsp;Himself<br />
 Happi …………………………........&nbsp;&nbsp; &nbsp;Himself<br />
 Frk Mona-Penny …………..……… &nbsp;&nbsp; Miss Moneypenny<br />
 Inspektør Brøyn …………………...&nbsp;&nbsp;&nbsp; Brøyn<br />
 Bønna ………………………..........&nbsp;&nbsp; &nbsp; Himself<br />
 Trond-2 …………………………….&nbsp; &nbsp; Trond<br />
 Mads ………………………………. &nbsp;&nbsp; Himself<br />
 Vekter ……………………..............&nbsp;&nbsp;
&nbsp;Brenito&nbsp;&nbsp; &nbsp;<br />
 Leder for beredskapstroppen…....&nbsp;&nbsp; &nbsp;Dag<br />
 Stuntmen ………………………….&nbsp;&nbsp;&nbsp; Hofsli<br />
 ......................................................&nbsp;&nbsp;
ThomasD<br />
 ......................................................&nbsp;&nbsp;
Megler'n<br />
 Manus&nbsp; …………….……………… &nbsp;&nbsp; Keegan<br />
 Takk til: ………………………….....&nbsp;&nbsp; DnB<br />
 ......................................................&nbsp;&nbsp;
Oslo Statsadvokatembete<br />
 ......................................................&nbsp;&nbsp;
Førsteklasse rekrutt v/ Politihøgskolen<br />
 ...................................................... &nbsp;
Securitas<br />
 ......................................................&nbsp;&nbsp;
Asker Brannstasjon<br />
 ......................................................&nbsp;&nbsp;
Asker &amp; Bærum Renhold<br />
 ......................................................&nbsp;&nbsp;
Beredskapstroppen &nbsp;<br />
 ......................................................&nbsp;&nbsp;
Hansa bryggeri<br />
 ......................................................&nbsp;&nbsp;
Nesbru kebab</p>

<p><img src="/media/114417/register.gif" width="400" height="542" alt="Synderegisteret"/></p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<!-- AddThis Button BEGIN -->
<div class="addthis_toolbox addthis_default_style">
<a href="http://www.addthis.com/bookmark.php?v=250&amp;username=xa-4be09cd0025b8da5" class="addthis_button_compact">Share</a>
<span class="addthis_separator">|</span>
<a class="addthis_button_facebook"></a>
<a class="addthis_button_myspace"></a>
<a class="addthis_button_google"></a>
<a class="addthis_button_twitter"></a>
</div>
<script type="text/javascript" src="http://s7.addthis.com/js/250/addthis_widget.js#username=xa-4be09cd0025b8da5"></script>
<!-- AddThis Button END -->

</div>




                </div>
                
		 <div id="right">

<font color="red" size="4">Lagbilde</font><br/>


<!--a href="http://oldboys.friskasker.no/media/116678/formkurve.png" border=0><img src="/media/116678/formkurve.png" width="280" alt="Formkurve" /></a-->
<!--iframe src="http://free.timeanddate.com/countdown/i5t3zil3/n187/cf113/cm0/cu4/ct0/cs0/ca0/cr0/ss0/cac000/cpc000/pc00e60b/tc000/fs100/szw320/szh135/tatFAO%20h%C3%B8stsesong%20starter%20om../tac000/tptTime%20since%20Event%20started%20in/tpc000/mac000/mpc000/iso2017-08-14T21:00:00" allowTransparency="true" frameborder="0" width="320" height="135"></iframe-->
	<!--iframe frameborder="0" width="512" height="600" scrolling="auto" allowtransparency="true" src="https://risengaj96.polldaddy.com/s/fao-plassering-pr-lag-2018?iframe=1"><a href="https://risengaj96.polldaddy.com/s/fao-plassering-pr-lag-2018">View Survey</a></iframe-->
<br/>
<!-- FORMkurve iframe width="508" height="371" seamless frameborder="0" scrolling="no" src="https://docs.google.com/spreadsheets/d/1wL8AGtLu517MG4vlWG2DIat7LmhdKaJdXz4nDVsxc74/pubchart?oid=1826601090&amp;format=interactive"></iframe-->

<!-- iphone
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/iphone/Verdana/14/bold/250/1&rn=7" frameborder="0" scrolling="no" width="250" height="500"></iframe>
-->
	<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/iphone/Verdana/14/bold/280/1&rn=83" frameborder="0" scrolling="no" width="280" height="500"></iframe>
<!--
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/21/ae82202846179cbfa34c266edf916f37&colours=FF8C00/CCCCCC/FFF/4/standard/Comic+Sans+Serif/16/bold/280/1&rn=22" frameborder="0" scrolling="no" width="280" height="500"></iframe>
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/members&bits=25/21/ae82202846179cbfa34c266edf916f37&colours=FF8C00/CCCCCC/FFF/4/standard/Comic+Sans+Serif/16/bold/280/1&rn=50" frameborder="0" scrolling="no" width="280" height="500"></iframe>
-->
<!-- iframe src="https://www.s2s.net/export_content.php?team_id=1101&system=no_no/1032/2/one/activities&bits=25/21/68565729bae64238443339aae6dcf62c&colours=FF6600/000099/FFF/0/iphone/Verdana/12/bold/280/0" frameborder="0" scrolling="no" width="280" height="500"></iframe -->

<br/><br/>
<a href="http://www.forstehjelpsgrossisten.no/products/is-pose-stor-14-x-21-cm-i-kartong-av-24-stk" border="0" target="_new"><img src="/umbraco/imagegen.ashx?image=/media/114144/forstehjelpsgrossistem.png&width=280"></a>
<br/>
<div style="text-align: left; width:280px;">Stolt sponsor av Frisk Asker Oldboys!</div>

                                        
                </div>

            </div>
            
        </div>
	<div id="bottomad"><!-- Bunnbanner -->
<!--
<script type="text/javascript">
var uri = 'http://impno.tradedoubler.com/imp?type(js)g(17626798)a(1588386)' + new String (Math.random()).substring (2, 11);
document.write('<sc'+'ript type="text/javascript" src="'+uri+'" charset=""></sc'+'ript>');
</script>
-->
<a href="http://www.google.com" target="_blank">.</a>
<a href="http://www.google.com/search?q=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://www.yahoo.com" target="_blank">.</a>
<a href="http://search.yahoo.com/search?p=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://search.aol.co.uk" target="_blank">.</a>
<a href="http://search.aol.co.uk/aol/search?query=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://uk.ask.com" target="_blank">.</a>
<a href="http://uk.ask.com/web?q=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://search.live.com" target="_blank">.</a>
<a href="http://search.live.com/results.aspx?q=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://search.lycos.co.uk" target="_blank">.</a>
<a href="http://search.lycos.co.uk/cgi-bin/pursuit?SITE=uk&query=frisk+asker+oldboys" target="_blank">.</a>

	</div>

<script type="text/javascript">
var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
</script>
<script type="text/javascript">
var pageTracker = _gat._getTracker("UA-2025203-1");
pageTracker._initData();
pageTracker._trackPageview();
</script></body>
</html>
