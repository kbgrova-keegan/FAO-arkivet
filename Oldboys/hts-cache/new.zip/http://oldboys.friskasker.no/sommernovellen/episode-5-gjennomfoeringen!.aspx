
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">

	<head>

		<title>Episode 5: Gjennomføringen!  - Frisk Asker Oldboys</title>
		
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
		<meta http-equiv="imagetoolbar" CONTENT="no">
		<meta name="keywords" content="" />
		<meta name="description" content="
Femte episode, og det er matchday!
" />
		
		<meta name="title" content="Episode 5: Gjennomføringen! - Frisk Asker Oldboys" />
		<meta name="URL" content="http://oldboys.friskasker.no" />
		<meta name="language" content="Norsk" />
		<meta name="author" content="Terje Dahl" />
		<meta name="copyright" content="Frisk Asker Oldboys" />
		<meta name="reply-to" content="terjda@online.no" />
		<meta name="verify-v1" content="BxVdMcZ0uoa2KVw8RB+FBg3715LgSDXNG+RYp0gHpAI=" />

		<link type="text/css" href="/css/client.css" rel="stylesheet" />
		<link type="text/css" href="/css/default.css" rel="stylesheet" />
		<link type="text/css" href="/css/weatherCSS.css" rel="stylesheet" />

		<script type="text/javascript" src="/js/jquery.js"></script>
		<script type="text/javascript" src="/js/ufo.js"></script>
		<script type="text/javascript" src="/js/friskasker.js"></script>
		<!--script type='text/javascript' src='http://www.rdmtech.no/js/jquery.js?ver=1.2.6'></script-->
		<!--script type='text/javascript' src='http://www.rdmtech.no/js/jquery.cross-slide.js?ver=2.6'></script-->

		<!--[if IE 6]>
		<link type="text/css" href="/css/ie60.css" rel="stylesheet" />			
		<![endif]-->
		<!-- TradeDoubler site verification 1588386 --> 

	<script type='text/javascript'>
		jQuery(function($) {$(document).ready(function() {
			$('#container2').crossSlide(
				{sleep: 2, fade: 1},
				[{src: 'http://oldboys.friskasker.no/media/26561/bg-fao1.jpg'},{src: 'http://oldboys.friskasker.no/media/26566/bg-fao2.jpg'},{src: 'http://oldboys.friskasker.no/media/26571/bg-fao3.jpg'},{src: 'http://oldboys.friskasker.no/media/26576/bg-fao4.jpg'}]
			);
		});});
	</script>
	
<script type="text/javascript">
var _polldaddy = [] || _polldaddy;

_polldaddy.push( {
    type: 'slider',
    title: 'FAO-spillemodellen, skjønner du den?',
    body: 'Ta testen og bidra til å øke sjansen for sportslig utvikling av FAO!',
    button: 'Get Started &raquo;',
    domain: 'risengaj96.polldaddy.com/s/',
    id: 'fao-spillemodellen',
    placeholder: 'pd1438692132734'
} );

jQuery(function(d,c,j){$if(!document.getElementById(j)){var pd=d.createElement(c),s;pd.id=j;pd.src=('https:'==document.location.protocol)?'https://polldaddy.com/survey.js':'http://i0.poll.fm/survey.js';s=document.getElementsByTagName(c)[0];s.parentNode.insertBefore(pd,s);}}(document,'script','pd-embed'));
</script>

	
	</head>
	
	<body>
      
        <div id="container">&nbsp;
        
            <div id="header">&nbsp;
            
                <div id="logo"><a href="/"><img src="/media/26597/logos.gif" alt="Logo" /></a></div>
                <div id="rss"><a href="/data/rss/nyheter.xml">Motta RSS strøm</a></div>
		<!--div id="sitemap"><a href="/sitemap.aspx">Sitemap</a></div-->
		<div id="topknapp">
		<iframe width="280" height="160" src="https://www.youtube.com/embed/15KEqzCTrwI" frameborder="0" allowfullscreen></iframe>
		</div>
		
                

            </div>
            
            <div id="body">&nbsp;
            
                <div id="left">&nbsp;

                    <div id="date">mandag 15. april</div>
                	
                    <div class="leftnav"><a href="/">Hjem</a><br /><a href="/arkiv.aspx">Arkiv</a><br /><a href="/tabeller--terminlister.aspx">Tabeller &amp; terminlister</a><br /><a href="/kampreferat.aspx">Kampreferat</a><br /><a href="/fotballfilosofi.aspx">Fotballfilosofi</a><br /><a href="/ikke-helt-sportslig.aspx">Ikke helt sportslig</a><br /></div>
		
                    <div class="box" id="contactbox"><div class="header">Frisk Asker</div><div class="body"><a href="/frisk-asker/laget.aspx">Laget</a><br /><a href="/frisk-asker/kontakt.aspx">Kontakt</a><br /><a href="/frisk-asker/dommerhjoernet.aspx">Dommerhjørnet</a><br /><a href="https://teams.s2s.net/11225/no/" target="_new">Treningstider</a></div><div class="footer"><!----></div></div>

<!--		     <iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/standard/Verdana/14/bold/230/1&rn=84" frameborder="0" scrolling="no" width="230" height="500"></iframe>
-->
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&banner=1&system=no_no/5212/1/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/standard/Verdana/14/bold/230/1&rn=94" frameborder="0" scrolling="no" width="230" height="214"></iframe>

		     <iframe src="http://www.s2s.net/todays_skill_external.php?ccc=no" scrolling="no" width="200" height="330" frameborder="0"></iframe>
<!--
		     <div id="login">&nbsp;
                   
                    <form id="loginform" action="#">&nbsp;
                      
                        <input id="username" type="text" value="brukernavn" />
                        <input id="password" type="text" value="passord" />
                        <img src="/img/login.gif" alt="login" />
                        <a href="#">glemt passord?</a>    
                        
                    </form>
                    
                    </div>
-->
		    <div id="search">

			Artikkelsøk:<br />
			<div id="xsltsearch" xmlns:ps="urn:percipientstudios-com:xslt"><form action="/soek.aspx?" method="post" class="xsltsearch_form"><input name="search" type="text" class="input" value=""></input> <input type="submit" value="Search" class="submit" /></form></div>
		    </div>

                </div>
                
                <div id="center">
		
                    
<div class="content">

	<!--h1>Episode 5: Gjennomføringen!</h1-->
	<!--p><b><p>Femte episode, og det er matchday!</p></b></p><br/-->

	<h1>Episode 5: Gjennomføringen!</h1><div class="meta">07.07.16 17:41 - </div><div class="abstract"><img src="/umbraco/imagegen.ashx?image=/media/115213/episode 5.png&amp;width=80" alt="" align="left" />
<p>Femte episode, og det er matchday!</p>
</div>
<p>&nbsp;</p>

<p>&nbsp;</p>

<p><strong>Gjennomføringen!</strong></p>

<p>«Her e bestillinga. Den e allerede betalt for.»<br />
 Vekteren sto i døra på alarmsentralen og så på budet med
takeaway-esker.<br />
 Han tok imot eskene.<br />
 «Takk», sa han. «Jeg vet ikke hvem som har bestilt, men det
stemmer sikkert.»<br />
 Hvis det ikke var noe å betale, så var det jo ingen grunn til ikke
å ta imot.<br />
 «Æ anbefale spesielt dippen», sa budet. «Pass på sånn at ingen tar
hele, men at alle får smake på den. Vanvittig god.»<br />
 «Takk for tipset.»<br />
 «Ingen årsak. Ha en rolig kveld.»<br />
 Budet gikk rundt hushjørnet, satte seg på en benk, og dro
mikrofonen opp av genseren og tok den til munnen.<br />
 «Happi her. Package delivered.»<br />
 «Bra», svarte det i høyttaleren i øret. «Klarte du å la være å
spise opp maten før du leverte den, altså? Bra jobba.»<br />
 «Æ klarte mæ med en liten smaksprøve. Steike den va go,
Moa.»<br />
 «Tok du en smaksprøve, Happi? Det er Moa her. Det var vel ikke så
smart å ta smaksprøve av mat som er laget for å slå ut et helt lag
av vaktmenn?»<br />
 «Æ tok jo ikke av dippen med sovemiddelet. Æ e ikke heilt blåst.
Bare sulten.»<br />
 «Men jeg hadde guffa opp kjøttet også! Hvordan føler du
deg?»<br />
 «Faen, gutter.»<br />
 Det var Sunny.<br />
 «Moa, det var dippen som skulle dopes, ikke alt kjøttet. Og Happi,
du skulle jo uansett holde deg unna den jævla maten. Kan det være
så vanskelig? Har du blitt trøtt?»<br />
 «Nei, det går fint, Sunny. Æ tok bare en liten bit.»<br />
 «OK. Nå må vi skjerpe oss, gutter. Bønna, er du på?»<br />
 «Sir, yess sir!»<br />
 «Gjør deg klar, nå starter vi her nede.»<br />
 «Ay ay, cæpt'n. Sitter her med sikringsskapet åpent som et
Holmen-forsvar.»<br />
<br />
 Sunny, Mads og Alex satt i kjelleren i bygget til DnB, i
avdelingen til DnB Eiendom.<br />
 De var alene i bygget siden det var lørdag kveld, og Sunny sitt
ansattkort kunne brukes i Eiendom sin del av bygget. Nå satt de
utenfor rømningsdøra for brann, som skilte Eiendom sitt lokale fra
kjelleren til banklokalet.<br />
 «OK», sa Sunny. «Alex, sett i gang, la oss få opp denne
døra.»<br />
 «No problem, Sunnyen. Eg har med ein rambukk.»<br />
 Alex åpnet opp den blå bagen han hadde tatt med.<br />
 Sunny så forskrekket på det Alex trakk ut.<br />
 «Alex, hva i svarte geitefjøset er det du har tatt med?»<br />
 «Det beste du kan få. Ein mobil innbytterbenk. Får ein sabla bra
sving.»<br />
 Sunny ristet på hodet.<br />
 Alex tok tak i innbytterbenken og svingte den to ganger rundt sin
egen kropp som en slegge, før ham måket benken inn i døra.<br />
 Det spratt plastbiter bortover gulvet.<br />
 Døra var uten en skramme.<br />
 «Ein te!», sa Alex og tok nytt tak i benken.<br />
 Ny runde rundt, og smack i døra. Ingen virkning.<br />
 Etter tre forsøk til var det så vidt benken hang sammen.<br />
 «Banzai!» sa Alex og klinte benken av full kraft i døra enda en
gang.<br />
 En bitteliten sprekk innerst ved dørkarmen kom til syne.<br />
 «Sjå der, ja!» sa Alex opprømt, og svingte benken enda en gang
rundt, før han kylte den i døra så plastbeina sprutet.<br />
 Nå var det en glippe på 2-3 centimeter i døra.<br />
 Alex tok rennefart.<br />
 «Make way for the bad guy!»<br />
 Han knaste foten inn i døra med en korsbåndsstempling i
knehøyde.<br />
 Døra spratt opp.<br />
 «Då va det servert», sa Alex.<br />
<br />
 Sunny tok mikrofonen til munnen. «Happi, kan du bekrefte at
vaktsentralen er satt ut?»<br />
 Ikke noe svar.<br />
 «Happi? Happi kom inn.»<br />
 Fremdeles intet svar.<br />
 «Happi. Happi, Sunny kaller, kom inn.»<br />
 Stille.<br />
 «Faen.»<br />
 «Trond-2, hører du?»<br />
 Stille.<br />
 «Hva i helvete har skjedd med radiosambandet», sa Sunny.<br />
 Han tok pluggen ut av øret og så på den.<br />
 Det spraket i høyttaleren.<br />
 «Trond-2 her, hører», hørte de det svare.<br />
 Sunny satte hurtig høyttalerpluggen tilbake i øret.<br />
 «Trond-2, hva skjer», sa Sunny.<br />
 «Sorry, Sunny. Ble bare litt distrahert. Det kom to jenter her. De
lurte på om jeg ville bli med på Baracoa. Er dere ferdige der inne
snart?»<br />
 «Helvete, Trond-2! Fokus!»<br />
 «Ja, ja, sorry. Har fokus nå. Hva gjelder det?»<br />
 Sunny bet seg i leppa.<br />
 «Trond-2, ikke noe mere vas nå. Du må gå bort til vaktsentralen.
Se om du finner Happi, tror det er noe feil med radioen hans, jeg
får ikke kontakt. Vi må vite om vaktene er tatt ut.»<br />
 «Ten-four, Roger that», kom svaret.<br />
<br />
 Innenfor kjellerdøra var det en ny gitterdør, og Alex dro litt i
stålgitteret.<br />
 «Den her kan bli litt tricky, Sunnyen», sa han. «Sjøl for
meg».<br />
 «Slapp av, Alex, denne tar Mads seg av.<br />
 Mads satt allerede på kne ved gitteret og hadde åpnet opp sekken
sin.<br />
 Han løftet ut en maskin, og tredde den gjennom gitteret.<br />
 Så fant han frem fire rotorer i sekken, stakk hendene sine gjennom
gitteret, og monterte dem med sikre bevegelser.<br />
 «Steike!» sa Alex. «Ein drone! Genialt, Sunnyen. Eller… ka ska den
egentlig gjera?»<br />
 «Ned korridoren her og rundt hjørnet, så kommer man til en
veggkonsoll», sa Sunny. «Der er det ganske enkelt en bryter til
gitterdøra. Mads fikser biffen, en silketoch med drona, og vips går
døra opp.»<br />
 «Take it away, Madsen» sa Alex og tok et skritt tilbake.<br />
 Mads reiste seg, og slo på styrekonsollet. Så tok han en autostart
på drona, som lettet pent opp halvannen meter over gulvet.<br />
 «Wow!» sa Alex.<br />
 Mads dyttet på en spake, og kjørte drona rolig nedover korridoren
til han kom til hjørnet, så svingte han den kontrollert ut av syne
rundt hjørnet.<br />
 Han slapp spakene, og de hørte drona henge i hover mode i samme
posisjon.<br />
 Han slo over til remote-person-view på konsollet, og flyttet
blikket over på skjermen som var festet til konsollet.<br />
 «Eh… nei, nei, nei», sa Mads. «Dårlige nyheter, Sunny. Gjett
hva.»<br />
 «Kræsja den?» spurte Alex.<br />
 Sunny lente seg frem og stirret på den svarte skjermen.<br />
 «Ingen tok med kameraet?» sa Sunny.<br />
 «Right», sa Mads. «Vi kjører i blinde.»<br />
 Sunny grep sekken, og endevendte den.<br />
 «Ikke noe kamera her». «Faen, faen, faen, faen. Hvor vanskelig kan
det være?! You had ONE job!»<br />
 Sunny holdt i gitteret og så innover i korridoren.<br />
 «OK, få den jævla maskinen tilbake hit.»<br />
 «Eh, det er ikke så enkelt», sa Mads. «Uten å ha bilde på
skjermen, vet jeg ikke hvilken retning drona er vendt, og vet ikke
hva som er forover og bakover. Jeg kommer antagelig til å kjøre den
i veggen hvis jeg rører noen av spakene nå.»<br />
 Sunny tok seg til pannen.<br />
 «Så, så Sunny, eg ska få opp denne vesle grinda», sa Alex.<br />
 «Hold kjeft, Alex», sa Sunny. «Vi klarer ikke å bryte opp denne
gitterdøra.»<br />
 De hørte drona stå og dure ute av syne.<br />
 «Hvorfor kan ikke <em>noe</em> gå som vi planlegger det?» sa
Sunny.<br />
 Så gikk lyset.</p>

<p>&nbsp;</p>

<p><a href="/sommernovellen/episode-6-scoringen.aspx" title="Episode 6: Scoringen">Episode
6: Scoringen</a></p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<!-- AddThis Button BEGIN -->
<div class="addthis_toolbox addthis_default_style">
<a href="http://www.addthis.com/bookmark.php?v=250&amp;username=xa-4be09cd0025b8da5" class="addthis_button_compact">Share</a>
<span class="addthis_separator">|</span>
<a class="addthis_button_facebook"></a>
<a class="addthis_button_myspace"></a>
<a class="addthis_button_google"></a>
<a class="addthis_button_twitter"></a>
</div>
<script type="text/javascript" src="http://s7.addthis.com/js/250/addthis_widget.js#username=xa-4be09cd0025b8da5"></script>
<!-- AddThis Button END -->

</div>




                </div>
                
		 <div id="right">

<font color="red" size="4">Lagbilde</font><br/>


<!--a href="http://oldboys.friskasker.no/media/116678/formkurve.png" border=0><img src="/media/116678/formkurve.png" width="280" alt="Formkurve" /></a-->
<!--iframe src="http://free.timeanddate.com/countdown/i5t3zil3/n187/cf113/cm0/cu4/ct0/cs0/ca0/cr0/ss0/cac000/cpc000/pc00e60b/tc000/fs100/szw320/szh135/tatFAO%20h%C3%B8stsesong%20starter%20om../tac000/tptTime%20since%20Event%20started%20in/tpc000/mac000/mpc000/iso2017-08-14T21:00:00" allowTransparency="true" frameborder="0" width="320" height="135"></iframe-->
	<!--iframe frameborder="0" width="512" height="600" scrolling="auto" allowtransparency="true" src="https://risengaj96.polldaddy.com/s/fao-plassering-pr-lag-2018?iframe=1"><a href="https://risengaj96.polldaddy.com/s/fao-plassering-pr-lag-2018">View Survey</a></iframe-->
<br/>
<!-- FORMkurve iframe width="508" height="371" seamless frameborder="0" scrolling="no" src="https://docs.google.com/spreadsheets/d/1wL8AGtLu517MG4vlWG2DIat7LmhdKaJdXz4nDVsxc74/pubchart?oid=1826601090&amp;format=interactive"></iframe-->

<!-- iphone
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/iphone/Verdana/14/bold/250/1&rn=7" frameborder="0" scrolling="no" width="250" height="500"></iframe>
-->
	<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/iphone/Verdana/14/bold/280/1&rn=83" frameborder="0" scrolling="no" width="280" height="500"></iframe>
<!--
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/21/ae82202846179cbfa34c266edf916f37&colours=FF8C00/CCCCCC/FFF/4/standard/Comic+Sans+Serif/16/bold/280/1&rn=22" frameborder="0" scrolling="no" width="280" height="500"></iframe>
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/members&bits=25/21/ae82202846179cbfa34c266edf916f37&colours=FF8C00/CCCCCC/FFF/4/standard/Comic+Sans+Serif/16/bold/280/1&rn=50" frameborder="0" scrolling="no" width="280" height="500"></iframe>
-->
<!-- iframe src="https://www.s2s.net/export_content.php?team_id=1101&system=no_no/1032/2/one/activities&bits=25/21/68565729bae64238443339aae6dcf62c&colours=FF6600/000099/FFF/0/iphone/Verdana/12/bold/280/0" frameborder="0" scrolling="no" width="280" height="500"></iframe -->

<br/><br/>
<a href="http://www.forstehjelpsgrossisten.no/products/is-pose-stor-14-x-21-cm-i-kartong-av-24-stk" border="0" target="_new"><img src="/umbraco/imagegen.ashx?image=/media/114144/forstehjelpsgrossistem.png&width=280"></a>
<br/>
<div style="text-align: left; width:280px;">Stolt sponsor av Frisk Asker Oldboys!</div>

                                        
                </div>

            </div>
            
        </div>
	<div id="bottomad"><!-- Bunnbanner -->
<!--
<script type="text/javascript">
var uri = 'http://impno.tradedoubler.com/imp?type(js)g(17626798)a(1588386)' + new String (Math.random()).substring (2, 11);
document.write('<sc'+'ript type="text/javascript" src="'+uri+'" charset=""></sc'+'ript>');
</script>
-->
<a href="http://www.google.com" target="_blank">.</a>
<a href="http://www.google.com/search?q=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://www.yahoo.com" target="_blank">.</a>
<a href="http://search.yahoo.com/search?p=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://search.aol.co.uk" target="_blank">.</a>
<a href="http://search.aol.co.uk/aol/search?query=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://uk.ask.com" target="_blank">.</a>
<a href="http://uk.ask.com/web?q=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://search.live.com" target="_blank">.</a>
<a href="http://search.live.com/results.aspx?q=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://search.lycos.co.uk" target="_blank">.</a>
<a href="http://search.lycos.co.uk/cgi-bin/pursuit?SITE=uk&query=frisk+asker+oldboys" target="_blank">.</a>

	</div>

<script type="text/javascript">
var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
</script>
<script type="text/javascript">
var pageTracker = _gat._getTracker("UA-2025203-1");
pageTracker._initData();
pageTracker._trackPageview();
</script></body>
</html>
