
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">

	<head>

		<title>Episode 6: Scoringen  - Frisk Asker Oldboys</title>
		
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
		<meta http-equiv="imagetoolbar" CONTENT="no">
		<meta name="keywords" content="" />
		<meta name="description" content="
Sjette og nest siste episode!
" />
		
		<meta name="title" content="Episode 6: Scoringen - Frisk Asker Oldboys" />
		<meta name="URL" content="http://oldboys.friskasker.no" />
		<meta name="language" content="Norsk" />
		<meta name="author" content="Terje Dahl" />
		<meta name="copyright" content="Frisk Asker Oldboys" />
		<meta name="reply-to" content="terjda@online.no" />
		<meta name="verify-v1" content="BxVdMcZ0uoa2KVw8RB+FBg3715LgSDXNG+RYp0gHpAI=" />

		<link type="text/css" href="/css/client.css" rel="stylesheet" />
		<link type="text/css" href="/css/default.css" rel="stylesheet" />
		<link type="text/css" href="/css/weatherCSS.css" rel="stylesheet" />

		<script type="text/javascript" src="/js/jquery.js"></script>
		<script type="text/javascript" src="/js/ufo.js"></script>
		<script type="text/javascript" src="/js/friskasker.js"></script>
		<!--script type='text/javascript' src='http://www.rdmtech.no/js/jquery.js?ver=1.2.6'></script-->
		<!--script type='text/javascript' src='http://www.rdmtech.no/js/jquery.cross-slide.js?ver=2.6'></script-->

		<!--[if IE 6]>
		<link type="text/css" href="/css/ie60.css" rel="stylesheet" />			
		<![endif]-->
		<!-- TradeDoubler site verification 1588386 --> 

	<script type='text/javascript'>
		jQuery(function($) {$(document).ready(function() {
			$('#container2').crossSlide(
				{sleep: 2, fade: 1},
				[{src: 'http://oldboys.friskasker.no/media/26561/bg-fao1.jpg'},{src: 'http://oldboys.friskasker.no/media/26566/bg-fao2.jpg'},{src: 'http://oldboys.friskasker.no/media/26571/bg-fao3.jpg'},{src: 'http://oldboys.friskasker.no/media/26576/bg-fao4.jpg'}]
			);
		});});
	</script>
	
<script type="text/javascript">
var _polldaddy = [] || _polldaddy;

_polldaddy.push( {
    type: 'slider',
    title: 'FAO-spillemodellen, skjønner du den?',
    body: 'Ta testen og bidra til å øke sjansen for sportslig utvikling av FAO!',
    button: 'Get Started &raquo;',
    domain: 'risengaj96.polldaddy.com/s/',
    id: 'fao-spillemodellen',
    placeholder: 'pd1438692132734'
} );

jQuery(function(d,c,j){$if(!document.getElementById(j)){var pd=d.createElement(c),s;pd.id=j;pd.src=('https:'==document.location.protocol)?'https://polldaddy.com/survey.js':'http://i0.poll.fm/survey.js';s=document.getElementsByTagName(c)[0];s.parentNode.insertBefore(pd,s);}}(document,'script','pd-embed'));
</script>

	
	</head>
	
	<body>
      
        <div id="container">&nbsp;
        
            <div id="header">&nbsp;
            
                <div id="logo"><a href="/"><img src="/media/26597/logos.gif" alt="Logo" /></a></div>
                <div id="rss"><a href="/data/rss/nyheter.xml">Motta RSS strøm</a></div>
		<!--div id="sitemap"><a href="/sitemap.aspx">Sitemap</a></div-->
		<div id="topknapp">
		<iframe width="280" height="160" src="https://www.youtube.com/embed/15KEqzCTrwI" frameborder="0" allowfullscreen></iframe>
		</div>
		
                

            </div>
            
            <div id="body">&nbsp;
            
                <div id="left">&nbsp;

                    <div id="date">mandag 15. april</div>
                	
                    <div class="leftnav"><a href="/">Hjem</a><br /><a href="/arkiv.aspx">Arkiv</a><br /><a href="/tabeller--terminlister.aspx">Tabeller &amp; terminlister</a><br /><a href="/kampreferat.aspx">Kampreferat</a><br /><a href="/fotballfilosofi.aspx">Fotballfilosofi</a><br /><a href="/ikke-helt-sportslig.aspx">Ikke helt sportslig</a><br /></div>
		
                    <div class="box" id="contactbox"><div class="header">Frisk Asker</div><div class="body"><a href="/frisk-asker/laget.aspx">Laget</a><br /><a href="/frisk-asker/kontakt.aspx">Kontakt</a><br /><a href="/frisk-asker/dommerhjoernet.aspx">Dommerhjørnet</a><br /><a href="https://teams.s2s.net/11225/no/" target="_new">Treningstider</a></div><div class="footer"><!----></div></div>

<!--		     <iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/standard/Verdana/14/bold/230/1&rn=84" frameborder="0" scrolling="no" width="230" height="500"></iframe>
-->
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&banner=1&system=no_no/5212/1/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/standard/Verdana/14/bold/230/1&rn=94" frameborder="0" scrolling="no" width="230" height="214"></iframe>

		     <iframe src="http://www.s2s.net/todays_skill_external.php?ccc=no" scrolling="no" width="200" height="330" frameborder="0"></iframe>
<!--
		     <div id="login">&nbsp;
                   
                    <form id="loginform" action="#">&nbsp;
                      
                        <input id="username" type="text" value="brukernavn" />
                        <input id="password" type="text" value="passord" />
                        <img src="/img/login.gif" alt="login" />
                        <a href="#">glemt passord?</a>    
                        
                    </form>
                    
                    </div>
-->
		    <div id="search">

			Artikkelsøk:<br />
			<div id="xsltsearch" xmlns:ps="urn:percipientstudios-com:xslt"><form action="/soek.aspx?" method="post" class="xsltsearch_form"><input name="search" type="text" class="input" value=""></input> <input type="submit" value="Search" class="submit" /></form></div>
		    </div>

                </div>
                
                <div id="center">
		
                    
<div class="content">

	<!--h1>Episode 6: Scoringen</h1-->
	<!--p><b><p>Sjette og nest siste episode!</p></b></p><br/-->

	<h1>Episode 6: Scoringen</h1><div class="meta">07.07.16 17:42 - </div><div class="abstract"><img src="/umbraco/imagegen.ashx?image=/media/115218/episode 6.png&amp;width=80" alt="" align="left" />
<p>Sjette og nest siste episode!</p>
</div>
<p>&nbsp;</p>

<p>&nbsp;</p>

<p><strong>Scoringen</strong><br />
<br />
 Inspektør Brøyn satt i partyteltet sammen med de to etterforskerne
og statsadvokaten. De hadde rigget opp teltet på torget utenfor
banklokalet.<br />
 10 mann fra beredskapstroppen satt stille på benkene rundt de fire
sammenleggbare bordene.<br />
 «Nå har de tatt lyset!» sa troppssjefen, som satt og så ut av en
sprekk i teltduken. «Skal si disse gutta vet hva de driver
med.»<br />
 Inspektør Brøyn hadde ikke tatt noen sjanser. Han hadde tatt med
en helt tropp, og de satt nå og ventet, klare til å ta banden på
fersk gjerning når de kom ut med byttet.<br />
 «Hvis du går for maksimal strafferamme, så må du ta dem etter at
de faktisk har stjålet noe. Ellers kan du jo ta dem tidligere, men
da er overtredelsen bare innbrudd og skade på eiendom», hadde
statsadvokaten sagt.<br />
 «Har du først fått utdelt par i ess, så går du for hele potten»,
hadde Brøyn svart.<br />
<br />
 Skade på eiendom. Særlig. Nei, her skulle ingen vise kortene før
alle sjetongene lå på bordet. Og så rett i kasjotten! Orden
gjenopprettet, og de usportslige forvist. Med max karantenetid! O'
salige fryd.<br />
<br />
<br />
 Sunny tok frem mobilen for å slå på lommelyktfunksjonen.<br />
 Det var stummende mørkt, bortsett fra refleksen på veggen nederst
i korridoren, fra de blinkende lysene fra drona som hang bakom
hjørnet.<br />
 Sunny grep mikrofonen. «Bønna, kom inn. Var det du som slo av
lyset?»<br />
 Det skrapet i høyttaleren.<br />
 «Sorry, Sunny. Jeg kom i skade for å kortslutte en kurs
her.»<br />
 «Men herre Jeremias, da!» Sunny rev seg i håret.<br />
 «Hvor mye er det mulig å rote til?»<br />
 Mads prøvde å rygge drona rundt hjørnet, men kjørte den i stedet
sidelengs inn i brannslukningsapparatet på veggen. To av rotorene
splintret, og drona deiset i gulvet med et brak.<br />
 «Hallo. Hallo. Trond-2 her». Det knitret i radioen.<br />
 «Kom inn, Trond-2» sa Sunny. Stemmen hadde mistet
entusiasmen.<br />
 «Jeg har funnet Happi. Han ligger her og sover på en benk.»<br />
 «Swell», sa Sunny. Han ség ned på gulvet, lente ryggen mot veggen,
og la ansiktet i hendene.<br />
 «Tenk om jeg hadde spilt på et ordentlig lag.»<br />
<br />
 «Sunny», sa Mads, og satte seg ved siden av ham. «Jeg må fortelle
deg…, jeg tror, når du kjefter på medspillerne, så kan de bli
usikre.»<br />
 Sunny så på ham.<br />
 «Kødder du? Usikre?» Sunny klarte ikke å holde tilbake en
latter.<br />
 «Ja», sa Mads. «Du må heller skryte av oss. Vise at du tror på
oss.»<br />
 Sunny så ut som han hadde ramlet ned fra månen.<br />
 Han lente seg frem, og så på Mads.<br />
 «Mads, la meg fortelle <em>deg</em> en ting. Denne banden her gjør
<em>meg</em> usikker. Jævlig, forbanna, inni helvete usikker. Så
usikker at jeg snart har revet av meg alt helvetes håret.» Sunny
lente seg fremover og bøyde nakken.<br />
 «Kan du se at jeg har begynt å få måne? Hvor tror du den kommer
fra?»<br />
 «Sorry, Sunny», sa Mads.<br />
 Sunny dyttet til ham. Mads kom ut av balanse og støttet seg til
gitterdøra. Den gled opp.<br />
 «Men i huleste...» Sunny dyttet døra helt opp. «Døra er jo
åpen!»<br />
 Han dro opp mikrofonen. «Bønna, du er et geni! Du har kortslutta
gitterdøra! Nå rører du faen meg ingenting! Hører du? Sitt
fullstendig stille, ikke ta på en ting!»<br />
 «Den er grei, Sunny!», kom svaret. «Men dere får henge i, ikke
spør meg hvordan jeg gjorde det, men jeg har mørklagt halve Asker
sentrum!»<br />
 Mads og Sunny jogget ned korridoren, til døra med skiltet
<em>Serverrom</em>.<br />
 Sunny dro mikrofonen opp til munnen. «Trond-2, kom inn».<br />
 «Trond-2 hører.»<br />
 «Trond-2, vi har kommet oss inn! Glem Happi nå. Du må gå bort til
vaktsentralen og sjekke om det er stille der. Vi går løs på den
siste døra nå.»<br />
 «Det har jeg alt gjort, Sunny. Det er stille som i graven. Jeg
ringte på døra, ingen svarer. Moas elefantdressing har wipet dem
ut.»<br />
 «Bra jobba!»<br />
 «Alex, får du opp døra her? Alex?»<br />
 Mads var gått tilbake til gitterdøra i den andre enden av
korridoren.<br />
 «Alex har sovna».<br />
 Sunny kom løpende, og klasket Alex i fleisen.<br />
 «Alex!»<br />
 «Sunnyen. Ka som står på?»<br />
 Sunny dro ham på bena.<br />
 «Vi er inne! Kom og få opp den siste døra!»<br />
 «Skal bli, Sunnyen. No problem. Stol på Alex.»<br />
 «Jeg stoler på deg, Alex! Jeg stoler på deg! Bare kom igjen, vi
har dårlig tid.»<br />
 De kjappet seg tilbake til døra til serverrommet.<br />
 Alex ga den en prøvende skuldertakling.<br />
 Han så seg rundt, og gikk bort til brannslukningsapparatet og
røsket det løs fra veggen.<br />
 Han holdt det som en torpedo, tok en lang sving bakover og klinte
apparatet i døra, ved siden av låsen.<br />
 Han mistet apparatet i gulvet, mens døra var like hel.<br />
 Alex plukket opp igjen apparatet og tok sats på nytt.<br />
 Han tok fart to meter fra døra, med apparatet i strake armer bak
kroppen, spente musklene og kylte apparatet inn i døra. Han hadde i
farten snudd apparatet feil vei, så han knallet det inn i døra med
toppen først.<br />
 Med et øredøvende smell eksploderte toppen av metallbeholderen, og
Alex ble kastet bakover i smellen. Han dro med seg både Sunny og
Mads i fallet, og de ramlet sammen i en haug på gulvet.<br />
 Som en fontene, sprutet hele innholdet av brannslukningsapparatet
ut i lufta. Et brannslukningsapparat inneholder veldig mye
brannslukningspulver. Taket over dem ble hvitt, veggen ble hvit, og
de selv lå i en pøl av hvitt pulver.<br />
 Alex var halvt svimeslått, men Sunny kom til seg selv og satte seg
opp.<br />
 «Herregud», sa han.<br />
 Han så på de to andre, som fortumlet kavet rundt i det hvite
pulveret.<br />
 «Se på døra!» ropte Mads.<br />
 De så på døra.<br />
 Den sto på vidt gap.<br />
 Sunny så på Mads.<br />
 Han så ut som en nedsnødd Himalaya-sherpa.<br />
 Men Sunny kjente igjen det digre gliset der inne bak alt
skummet.<br />
 Sunny måtte smile. Så begynte han å le. Først noen korte støt, så
en rungende, hysterisk latter.<br />
 Mads begynte også å le, og Alex begynte å le, de satt der på
gulvet og lo som sinnsyke gærninger, fullstendig nedsnødd.<br />
 Det knitret i radioen.<br />
 «Trond-2 her, Sunny kom inn.»<br />
 Sunny hikstet mens han fomlet frem mikofonen.<br />
 «Kom inn Trond-2», sa Sunny.<br />
 «Alarmen uler noe grønjævlig inne på vaktsentralen. Dere må henge
i. Selv om vaktene er slått ut, så kommer noen snart til å høre
det.»<br />
 Sunny kom seg på bena.<br />
 «Mottatt.»<br />
 «Kom igjen Mads», sa han. «Jeg stoler på deg. Jeg tror på deg. Jeg
er sikker på at du klarer det. Nå har vi kommet så langt, det er
bare ett hinder igjen, og det klarer du. Men heng i.»<br />
 «Skal bli, kaptein!»<br />
 Mads forserte hurtig inn i rommet, og bort til datamaskinen i
kroken. Han dro opp mobilen og koblet den raskt til serveren med en
ledning.<br />
 «Hvordan ser det ut», sa Sunny.<br />
 «Easy», svarte Mads. «De har ingen databrannmur her, naturlig nok.
For herfra er det ingen som skal logge seg på.»<br />
 Han tastet med raske fingre på mobilen.<br />
 «Barneskirenn», sa han og gliste.<br />
 «Vips, vips og vips. Voila» Han dro ut ledningen og puttet den
sammen med mobilen i lomma.<br />
 «OK», sa Sunny, «la oss komme oss ut.»<br />
 Ute i korridoren sto Alex utenfor en annen dør.
<em>Bankavdelingen</em> sto det på skiltet.<br />
 «Gutter, sjå ka eg fann», sa Alex og klappet på døra.<br />
 «Nei, Alex», sa Sunny. «Det der er ikke for oss. Vi er ferdige med
oppdraget vårt her.»<br />
 «Men Sunny», sa Alex, «tenk på ka som ligg her inne då. Eg får opp
døra, no problem.»<br />
 «Alex, kom igjen, nå skal vi ut. Stol på meg. Bak den døra er det
ikke bare en ny dør. Det er et <em>hvelv</em>. Det er ikke noe for
oss. Vi er et breddelag.»<br />
 Alex klappa to klapp på døra.<br />
 «Som du vil, Sunnyen. Men steike det hadde vært artig og
prøvd.»<br />
 Det knitret i radioen igjen.<br />
 «Sunny! Sunny! Det er Trond-2!» Stemmen var stressa.<br />
 De begynte å løpe bortover korridoren mens Sunny svarte.<br />
 «Kom inn, Trond-2.»<br />
 «Sunny, dere må komme dere ut! Vaktene har våkna til live på
vaktsentralen!»</p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p><a href="/sommernovellen/episode-7-avgjoerelsen.aspx"
title="Episode 7: Avgjørelsen">Episode 7: Avgjørelsen</a></p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<!-- AddThis Button BEGIN -->
<div class="addthis_toolbox addthis_default_style">
<a href="http://www.addthis.com/bookmark.php?v=250&amp;username=xa-4be09cd0025b8da5" class="addthis_button_compact">Share</a>
<span class="addthis_separator">|</span>
<a class="addthis_button_facebook"></a>
<a class="addthis_button_myspace"></a>
<a class="addthis_button_google"></a>
<a class="addthis_button_twitter"></a>
</div>
<script type="text/javascript" src="http://s7.addthis.com/js/250/addthis_widget.js#username=xa-4be09cd0025b8da5"></script>
<!-- AddThis Button END -->

</div>




                </div>
                
		 <div id="right">

<font color="red" size="4">Lagbilde</font><br/>


<!--a href="http://oldboys.friskasker.no/media/116678/formkurve.png" border=0><img src="/media/116678/formkurve.png" width="280" alt="Formkurve" /></a-->
<!--iframe src="http://free.timeanddate.com/countdown/i5t3zil3/n187/cf113/cm0/cu4/ct0/cs0/ca0/cr0/ss0/cac000/cpc000/pc00e60b/tc000/fs100/szw320/szh135/tatFAO%20h%C3%B8stsesong%20starter%20om../tac000/tptTime%20since%20Event%20started%20in/tpc000/mac000/mpc000/iso2017-08-14T21:00:00" allowTransparency="true" frameborder="0" width="320" height="135"></iframe-->
	<!--iframe frameborder="0" width="512" height="600" scrolling="auto" allowtransparency="true" src="https://risengaj96.polldaddy.com/s/fao-plassering-pr-lag-2018?iframe=1"><a href="https://risengaj96.polldaddy.com/s/fao-plassering-pr-lag-2018">View Survey</a></iframe-->
<br/>
<!-- FORMkurve iframe width="508" height="371" seamless frameborder="0" scrolling="no" src="https://docs.google.com/spreadsheets/d/1wL8AGtLu517MG4vlWG2DIat7LmhdKaJdXz4nDVsxc74/pubchart?oid=1826601090&amp;format=interactive"></iframe-->

<!-- iphone
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/iphone/Verdana/14/bold/250/1&rn=7" frameborder="0" scrolling="no" width="250" height="500"></iframe>
-->
	<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/iphone/Verdana/14/bold/280/1&rn=83" frameborder="0" scrolling="no" width="280" height="500"></iframe>
<!--
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/21/ae82202846179cbfa34c266edf916f37&colours=FF8C00/CCCCCC/FFF/4/standard/Comic+Sans+Serif/16/bold/280/1&rn=22" frameborder="0" scrolling="no" width="280" height="500"></iframe>
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/members&bits=25/21/ae82202846179cbfa34c266edf916f37&colours=FF8C00/CCCCCC/FFF/4/standard/Comic+Sans+Serif/16/bold/280/1&rn=50" frameborder="0" scrolling="no" width="280" height="500"></iframe>
-->
<!-- iframe src="https://www.s2s.net/export_content.php?team_id=1101&system=no_no/1032/2/one/activities&bits=25/21/68565729bae64238443339aae6dcf62c&colours=FF6600/000099/FFF/0/iphone/Verdana/12/bold/280/0" frameborder="0" scrolling="no" width="280" height="500"></iframe -->

<br/><br/>
<a href="http://www.forstehjelpsgrossisten.no/products/is-pose-stor-14-x-21-cm-i-kartong-av-24-stk" border="0" target="_new"><img src="/umbraco/imagegen.ashx?image=/media/114144/forstehjelpsgrossistem.png&width=280"></a>
<br/>
<div style="text-align: left; width:280px;">Stolt sponsor av Frisk Asker Oldboys!</div>

                                        
                </div>

            </div>
            
        </div>
	<div id="bottomad"><!-- Bunnbanner -->
<!--
<script type="text/javascript">
var uri = 'http://impno.tradedoubler.com/imp?type(js)g(17626798)a(1588386)' + new String (Math.random()).substring (2, 11);
document.write('<sc'+'ript type="text/javascript" src="'+uri+'" charset=""></sc'+'ript>');
</script>
-->
<a href="http://www.google.com" target="_blank">.</a>
<a href="http://www.google.com/search?q=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://www.yahoo.com" target="_blank">.</a>
<a href="http://search.yahoo.com/search?p=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://search.aol.co.uk" target="_blank">.</a>
<a href="http://search.aol.co.uk/aol/search?query=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://uk.ask.com" target="_blank">.</a>
<a href="http://uk.ask.com/web?q=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://search.live.com" target="_blank">.</a>
<a href="http://search.live.com/results.aspx?q=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://search.lycos.co.uk" target="_blank">.</a>
<a href="http://search.lycos.co.uk/cgi-bin/pursuit?SITE=uk&query=frisk+asker+oldboys" target="_blank">.</a>

	</div>

<script type="text/javascript">
var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
</script>
<script type="text/javascript">
var pageTracker = _gat._getTracker("UA-2025203-1");
pageTracker._initData();
pageTracker._trackPageview();
</script></body>
</html>
