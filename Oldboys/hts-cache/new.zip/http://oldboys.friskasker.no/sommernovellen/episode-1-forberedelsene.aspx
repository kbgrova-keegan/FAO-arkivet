
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">

	<head>

		<title>Episode 1: Forberedelsene  - Frisk Asker Oldboys</title>
		
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
		<meta http-equiv="imagetoolbar" CONTENT="no">
		<meta name="keywords" content="" />
		<meta name="description" content="
Første episode i FAOs sommerkrim
" />
		
		<meta name="title" content="Episode 1: Forberedelsene - Frisk Asker Oldboys" />
		<meta name="URL" content="http://oldboys.friskasker.no" />
		<meta name="language" content="Norsk" />
		<meta name="author" content="Terje Dahl" />
		<meta name="copyright" content="Frisk Asker Oldboys" />
		<meta name="reply-to" content="terjda@online.no" />
		<meta name="verify-v1" content="BxVdMcZ0uoa2KVw8RB+FBg3715LgSDXNG+RYp0gHpAI=" />

		<link type="text/css" href="/css/client.css" rel="stylesheet" />
		<link type="text/css" href="/css/default.css" rel="stylesheet" />
		<link type="text/css" href="/css/weatherCSS.css" rel="stylesheet" />

		<script type="text/javascript" src="/js/jquery.js"></script>
		<script type="text/javascript" src="/js/ufo.js"></script>
		<script type="text/javascript" src="/js/friskasker.js"></script>
		<!--script type='text/javascript' src='http://www.rdmtech.no/js/jquery.js?ver=1.2.6'></script-->
		<!--script type='text/javascript' src='http://www.rdmtech.no/js/jquery.cross-slide.js?ver=2.6'></script-->

		<!--[if IE 6]>
		<link type="text/css" href="/css/ie60.css" rel="stylesheet" />			
		<![endif]-->
		<!-- TradeDoubler site verification 1588386 --> 

	<script type='text/javascript'>
		jQuery(function($) {$(document).ready(function() {
			$('#container2').crossSlide(
				{sleep: 2, fade: 1},
				[{src: 'http://oldboys.friskasker.no/media/26561/bg-fao1.jpg'},{src: 'http://oldboys.friskasker.no/media/26566/bg-fao2.jpg'},{src: 'http://oldboys.friskasker.no/media/26571/bg-fao3.jpg'},{src: 'http://oldboys.friskasker.no/media/26576/bg-fao4.jpg'}]
			);
		});});
	</script>
	
<script type="text/javascript">
var _polldaddy = [] || _polldaddy;

_polldaddy.push( {
    type: 'slider',
    title: 'FAO-spillemodellen, skjønner du den?',
    body: 'Ta testen og bidra til å øke sjansen for sportslig utvikling av FAO!',
    button: 'Get Started &raquo;',
    domain: 'risengaj96.polldaddy.com/s/',
    id: 'fao-spillemodellen',
    placeholder: 'pd1438692132734'
} );

jQuery(function(d,c,j){$if(!document.getElementById(j)){var pd=d.createElement(c),s;pd.id=j;pd.src=('https:'==document.location.protocol)?'https://polldaddy.com/survey.js':'http://i0.poll.fm/survey.js';s=document.getElementsByTagName(c)[0];s.parentNode.insertBefore(pd,s);}}(document,'script','pd-embed'));
</script>

	
	</head>
	
	<body>
      
        <div id="container">&nbsp;
        
            <div id="header">&nbsp;
            
                <div id="logo"><a href="/"><img src="/media/26597/logos.gif" alt="Logo" /></a></div>
                <div id="rss"><a href="/data/rss/nyheter.xml">Motta RSS strøm</a></div>
		<!--div id="sitemap"><a href="/sitemap.aspx">Sitemap</a></div-->
		<div id="topknapp">
		<iframe width="280" height="160" src="https://www.youtube.com/embed/15KEqzCTrwI" frameborder="0" allowfullscreen></iframe>
		</div>
		
                

            </div>
            
            <div id="body">&nbsp;
            
                <div id="left">&nbsp;

                    <div id="date">mandag 15. april</div>
                	
                    <div class="leftnav"><a href="/">Hjem</a><br /><a href="/arkiv.aspx">Arkiv</a><br /><a href="/tabeller--terminlister.aspx">Tabeller &amp; terminlister</a><br /><a href="/kampreferat.aspx">Kampreferat</a><br /><a href="/fotballfilosofi.aspx">Fotballfilosofi</a><br /><a href="/ikke-helt-sportslig.aspx">Ikke helt sportslig</a><br /></div>
		
                    <div class="box" id="contactbox"><div class="header">Frisk Asker</div><div class="body"><a href="/frisk-asker/laget.aspx">Laget</a><br /><a href="/frisk-asker/kontakt.aspx">Kontakt</a><br /><a href="/frisk-asker/dommerhjoernet.aspx">Dommerhjørnet</a><br /><a href="https://teams.s2s.net/11225/no/" target="_new">Treningstider</a></div><div class="footer"><!----></div></div>

<!--		     <iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/standard/Verdana/14/bold/230/1&rn=84" frameborder="0" scrolling="no" width="230" height="500"></iframe>
-->
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&banner=1&system=no_no/5212/1/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/standard/Verdana/14/bold/230/1&rn=94" frameborder="0" scrolling="no" width="230" height="214"></iframe>

		     <iframe src="http://www.s2s.net/todays_skill_external.php?ccc=no" scrolling="no" width="200" height="330" frameborder="0"></iframe>
<!--
		     <div id="login">&nbsp;
                   
                    <form id="loginform" action="#">&nbsp;
                      
                        <input id="username" type="text" value="brukernavn" />
                        <input id="password" type="text" value="passord" />
                        <img src="/img/login.gif" alt="login" />
                        <a href="#">glemt passord?</a>    
                        
                    </form>
                    
                    </div>
-->
		    <div id="search">

			Artikkelsøk:<br />
			<div id="xsltsearch" xmlns:ps="urn:percipientstudios-com:xslt"><form action="/soek.aspx?" method="post" class="xsltsearch_form"><input name="search" type="text" class="input" value=""></input> <input type="submit" value="Search" class="submit" /></form></div>
		    </div>

                </div>
                
                <div id="center">
		
                    
<div class="content">

	<!--h1>Episode 1: Forberedelsene</h1-->
	<!--p><b><p>Første episode i FAOs sommerkrim</p></b></p><br/-->

	<h1>Episode 1: Forberedelsene</h1><div class="meta">02.07.16 15:21 - Administrator</div><div class="abstract"><img src="/umbraco/imagegen.ashx?image=/media/114894/episode 1.png&amp;width=80" alt="" align="left" />
<p>Første episode i FAOs sommerkrim</p>
</div>
<p>&nbsp;</p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p><strong>Forberedelsene</strong></p>

<p>De to etterforskerne satt på hver sin stol foran skrivebordet
til statsadvokaten.<br />
 De satt med alvorlige miner, som ikke bare skyldtes lite
søvn.<br />
 Statsadvokaten satt lent fremover og noterte på et ark.<br />
 Han rettet seg opp, og tok av seg brillene.<br />
 «Så var det denne saken deres, skal vi se.»<br />
 Han bladde i noen papirer.<br />
 «Dere har bedt om bemanning til en aksjon, ser jeg. Bevæpnet. Og
spesialstyrker. Det høres seriøst ut. Vær snill å sette meg inn i
saken. Dere vet like godt som meg hva som kreves for å få inn
styrkene.»<br />
<br />
 Etterforskerne vekslet blikk, den eldste kremtet og tok
ordet.<br />
 «Det gjelder en kriminell bande som planlegger et kupp, herr
statsadvokat. Vi har god etterretning i saken, og vet hvor de vil
slå til.»<br />
 Statsadvokaten hørte på etterforskeren med et uttrykksløst
ansikt.<br />
 «Og hvor er det så at de skal slå til?»<br />
 Etterforskeren kastet et blikk på kollegaen sin.<br />
 «DnBs bankfilial i Asker.»<br />
 Statsadvokaten så rolig på etterforskeren.<br />
 «Javel. Du får ta alle detaljene. Hvordan vet dere dette, hvor
sikre er dere, hva vet dere, og så videre.»<br />
 Etterforskeren lente seg fremover og løftet opp en båndopptaker
fra gulvet, som han satte på skrivebordet.<br />
 «Vi har det hele på lydbånd», sa han.<br />
 «I tillegg har vi identifisert hvem personene er», la kollegaen
hans ivrig til. «Det er personer med rulleblad, alle som én. Vi
snakker om en kriminell bande.»<br />
 «Så», sa statsadvokaten, «og hvem er så disse personene, er det en
internasjonal bande? Såkalte mobile kriminelle?»<br />
 Etterforskeren satte i et lydbånd og gjorde maskinen klar.<br />
 «Nei», sa han. «Det er lokale folk. Men de har alle ferske
lovovertredelser. Vi har overvåket et kjellercasino i en tid, og vi
har som sagt alt på lydbånd. Jeg foreslår at vi like godt lytter
til opptaket fra i natt, så kan jeg forklare underveis.»<br />
 Han satte i kontakten og slo maskinen på.<br />
 Statsadvokaten så på ham.<br />
 «Godt,» sa han. «La oss høre hva dere har.»<br />
<br />
 <strong>Melding: Beklager sen beskjed, men jeg møter opp direkte,
litt etter at historien har startet. Hilsen forordet<br />
</strong> <em>Forord</em>:<br />
 Sunny's Seven er en historie basert på virkelige hendelser. Bare
lagt inn i en action-kontekst. Enhver likhet med virkelige personer
er tilsiktet og langt fra tilfeldig.<br />
<br />
<br />
<br />
 Sunny puttet den siste tomflaska i plastposen og tørket av bordet
med kluten. Han dyttet opp kjellervinduet for å lufte, og ble
stående litt og se ut av vinduet bort i hagen til naboen, på
partyteltet som hadde stått der i flere dager.<br />
 Så gikk han tilbake til bordet, og klapset til mannen som satt på
en pinnestol og sov med haken på brystet.<br />
 «Alex!» sa han. Han ristet i den sovende kroppen. «Nå har alle
gått, på tide å komme seg hjem.»<br />
 Mannen på stolen ség fremover og landet med fjeset ned i
hamburgerpapiret som lå på bordet.<br />
 «Helsike da.» Sunny sto og så på den livløse skikkelsen.<br />
 Så gikk han bort til døra til kjellerboden, åpnet den og gikk inn.
Han så litt rundt, til han fant det han lette etter. Han tok rullen
med slepetau, lukket boddøra, gikk bort til mannen på stolen, og
slang en løkke av tauet rundt beina hans.<br />
 Så gikk han opp trappa og ut utgangsdøra, mens han ga ut
tau.<br />
 Han slang den andre enden av tauet rundt hengerfestet på bilen som
sto utenfor, satte seg inn i førersetet, og startet opp.<br />
 Han satte bilen i gir og kjørte de 30 meterne til enden av
innkjørselen, bremset og rygget et par centimeter, slo av motoren
og gikk ut av bilen.<br />
 Han vippet løkka på slepetauet av hengerfestet, og gikk tilbake
til huset mens han kveilet inn tauet. I yttergangen lå Alex på
ryggen, og Sunny vippet løkka av beina hans og dytta til ham med
foten.<br />
 «Alex!»<br />
 Mannen beveget på seg, rullet seg frem på siden og hevet hodet, og
støttet seg på albuen.<br />
 Han så seg forvirret rundt, så samlet han seg og satte seg opp og
gned seg i bakhodet.<br />
 «Helvete, for ein skallebank eg har», sa han. Han så seg
rundt.<br />
 «Har dei andre gått heim alt?»<br />
 «Det er morgen. Kom deg hjem nå. Vi har en lang dag foran oss i
morgen.»<br />
 Alex gned seg i fjeset, strøk hånda over bakhodet igjen.<br />
 «Helvete så tørst eg e. Har du ein liten pils, Sunnyen?»<br />
 Sunny gikk inn på kjøkkenet og åpnet kjøleskapet og tok ut en
pilsflaske.<br />
 Han skrittet forbi Alex og ut på trammen.<br />
 «Her», sa han. Han jekket korken med hjørnetanna og satte flaska i
trappa.<br />
 Alex så på flaska, reiste seg opp, og sjanglet ut døra, over
trammen og bort til trappa.<br />
 Sunny tok to lange skritt inn i yttergangen, slang skoa og jakka
til Alex ut på trammen, lukket og låste døra.<br />
 Så gikk han ned i kjelleren igjen, reiste opp pinnestolen som lå
velta på gulvet, tørket opp dressingen fra bordet og krøllet sammen
papiret som lå på gulvet.<br />
 Han så over notatene i notatboka som lå åpen på bordet.<br />
 Han nikket for seg selv.<br />
 Endelig skulle det skje.<br />
 I morgen var dagen kommet.<br />
 Alt var klappet og klart, hva kunne gå galt?<br />
 Ingenting, med det overraskelsesmomentet de nå hadde.<br />
 Han smilte skjevt og klappet igjen boka.</p>

<p style="font-size: 12.8px; line-height: 19.2px;">&nbsp;</p>

<p style="font-size: 12.8px; line-height: 19.2px;"><a
href="/sommernovellen/episode-2-motstanderen.aspx" title="Episode 2: Motstanderen">Episode 2:
Motstanderen</a></p>

<p>&nbsp;</p>

<div
style="position: absolute; left: -10000px; top: 0px; width: 1px; height: 1px; overflow: hidden;"
 id="_mcePaste">
<!--[if gte mso 9]><xml> <o:OfficeDocumentSettings> <o:RelyOnVML /> <o:AllowPNG /> </o:OfficeDocumentSettings> </xml><![endif]-->
<p class="MsoNormal"><strong
style="mso-bidi-font-weight: normal;">Episode 1
<span></span>Forberedelsene</strong></p>

<p class="MsoNormal"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"></strong></strong></strong></strong></strong></p>

<p class="MsoNormal"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;">De to etterforskerne satt på
hver sin stol foran skrivebordet til
statsadvokaten.</strong></strong></strong></strong></strong></p>

<p class="MsoNormal"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;">De satt med alvorlige miner,
som ikke bare skyldtes lite
søvn.</strong></strong></strong></strong></strong></p>

<p class="MsoNormal"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;">Statsadvokaten satt lent
fremover og noterte på et
ark.</strong></strong></strong></strong></strong></p>

<p class="MsoNormal"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;">Han rettet seg opp, og tok av
seg brillene.</strong></strong></strong></strong></strong></p>

<p class="MsoNormal"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><span></span>«Så var det
denne saken deres, skal vi
se.»</strong></strong></strong></strong></strong></p>

<p class="MsoNormal"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;">Han bladde i noen
papirer.</strong></strong></strong></strong></p>

<p class="MsoNormal"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;">«Dere har bedt om bemanning
til en aksjon, ser jeg. Bevæpnet. Og spesialstyrker. Det høres
seriøst ut. Vær snill å sette meg inn i saken. Dere vet like godt
som meg hva som kreves for å få inn
styrkene.»</strong></strong></strong></strong></p>

<p class="MsoNormal"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"></strong></strong></strong></strong></p>

<p class="MsoNormal"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;">Etterforskerne vekslet blikk,
den eldste kremtet og tok
ordet.</strong></strong></strong></strong></p>

<p class="MsoNormal"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;">«Det gjelder en kriminell
bande som planlegger et kupp, herr statsadvokat. Vi har god
etterretning i saken, og vet hvor de vil slå
til.»</strong></strong></strong></strong></p>

<p class="MsoNormal"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;">Statsadvokaten hørte på
etterforskeren med et uttrykksløst
ansikt.</strong></strong></strong></strong></p>

<p class="MsoNormal"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;">«Og hvor er det så at de skal
slå til?»</strong></strong></strong></strong></p>

<p class="MsoNormal"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;">Etterforskeren kastet et
blikk på kollegaen sin.</strong></strong></strong></strong></p>

<p class="MsoNormal"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;">«DnBs bankfilial i
Asker.»</strong></strong></strong></strong></p>

<p class="MsoNormal"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;">Statsadvokaten så rolig på
etterforskeren.</strong></strong></strong></strong></p>

<p class="MsoNormal"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;">«Javel. Du får ta alle
detaljene. Hvordan vet dere dette, hvor sikre er dere, hva vet
dere, og så videre.»</strong></strong></strong></strong></p>

<p class="MsoNormal"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;">Etterforskeren lente seg
fremover og løftet opp en båndopptaker fra gulvet, som han satte på
skrivebordet.</strong></strong></strong></strong></p>

<p class="MsoNormal"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;">«Vi har det hele på lydbånd»,
sa han.</strong></strong></strong></strong></p>

<p class="MsoNormal"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;">«I tillegg har vi
identifisert hvem personene er», la kollegaen hans ivrig til. «Det
er personer med rulleblad, alle som én. Vi snakker om en kriminell
bande.»</strong></strong></strong></strong></p>

<p class="MsoNormal"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;">«Så», sa statsadvokaten, «og
hvem er så disse personene, er det en internasjonal bande? Såkalte
mobile kriminelle?»</strong></strong></strong></strong></p>

<p class="MsoNormal"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;">Etterforskeren satte i et
lydbånd og gjorde maskinen
klar.</strong></strong></strong></strong></p>

<p class="MsoNormal"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;">«Nei», sa han. «Det er lokale
folk. Men de har alle ferske lovovertredelser. Vi har overvåket et
kjellercasino i en tid, og vi har som sagt alt på lydbånd. Jeg
foreslår at vi like godt lytter til opptaket fra i natt, så kan jeg
forklare underveis.»</strong></strong></strong></strong></p>

<p class="MsoNormal"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;">Han satte i kontakten og slo
maskinen på.</strong></strong></strong></strong></p>

<p class="MsoNormal"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;">Statsadvokaten så på
ham.</strong></strong></strong></strong></p>

<p class="MsoNormal"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;">«Godt,» sa han. «La oss høre
hva dere har.»</strong></strong></strong></strong></p>

<p class="MsoNormal"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"></strong></strong></strong></strong></p>

<p class="MsoNormal"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;">Melding: Beklager sen
beskjed, men jeg møter opp direkte, litt etter at historien har
startet. Hilsen
forordet</strong></strong></strong></strong></strong></p>

<p class="MsoNormal"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;">Forord:</em></strong></strong></strong></strong></strong></p>

<p class="MsoNormal"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;">Sunny's Seven er en historie
basert på virkelige hendelser. Bare lagt inn i en action-kontekst.
Enhver likhet med virkelige personer er tilsiktet og langt fra
tilfeldig.</em></em></strong></em></strong></em></strong></em></strong></em></strong></p>

<p class="MsoNormal"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"></strong></strong></em></strong></em></strong></em></strong></em></strong></p>

<p class="MsoListParagraphCxSpFirst"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"></strong></strong></em></strong></strong></em></strong></em></p>

<p class="MsoListParagraphCxSpLast"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"></strong></strong></strong></em></strong></strong></em></p>

<p class="MsoNormal"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;">Sunny puttet den siste
tomflaska i plastposen og tørket av bordet med kluten. Han dyttet
opp kjellervinduet for å lufte, og ble stående litt og se ut av
vinduet bort i hagen til naboen, på partyteltet som hadde stått der
i flere
dager.</strong></strong></strong></strong></strong></em></p>

<p class="MsoNormal"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;">Så gikk han tilbake til
bordet, og klapset til mannen som satt på en pinnestol og sov med
haken på brystet.</strong></strong></strong></strong></strong></p>

<p class="MsoNormal"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;">«Alex!» sa han. Han ristet i
den sovende kroppen. «Nå har alle gått, på tide å komme seg
hjem.»</strong></strong></strong></strong></strong></p>

<p class="MsoNormal"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;">Mannen på stolen ség fremover
og landet med fjeset ned i hamburgerpapiret som lå på
bordet.</strong></strong></strong></strong></strong></p>

<p class="MsoNormal"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;">«Helsike da.» Sunny sto og så
på den livløse
skikkelsen.</strong></strong></strong></strong></strong></p>

<p class="MsoNormal"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;">Så gikk han bort til døra til
kjellerboden, åpnet den og gikk inn. Han så litt rundt, til han
fant det han lette etter. Han tok rullen med slepetau, lukket
boddøra, gikk bort til mannen på stolen, og slang en løkke av tauet
rundt beina hans.</strong></strong></strong></strong></strong></p>

<p class="MsoNormal"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;">Så gikk han opp trappa og ut
utgangsdøra, mens han ga ut
tau.</strong></strong></strong></strong></strong></p>

<p class="MsoNormal"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;">Han slang den andre enden av
tauet rundt hengerfestet på bilen som sto utenfor, satte seg inn i
førersetet, og startet
opp.</strong></strong></strong></strong></strong></p>

<p class="MsoNormal"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;">Han satte bilen i gir og
kjørte de 30 meterne til enden av innkjørselen, bremset og rygget
et par centimeter, slo av motoren og gikk ut av
bilen.</strong></strong></strong></strong></strong></p>

<p class="MsoNormal"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;">Han vippet løkka på
slepetauet av hengerfestet, og gikk tilbake til huset mens han
kveilet inn tauet. I yttergangen lå Alex på ryggen, og Sunny vippet
løkka av beina hans og dytta til ham med
foten.</strong></strong></strong></strong></strong></p>

<p class="MsoNormal"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;">«Alex!»</strong></strong></strong></strong></strong></p>

<p class="MsoNormal"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;">Mannen beveget på seg, rullet
seg frem på siden og hevet hodet, og støttet seg på
albuen.</strong></strong></strong></strong></strong></p>

<p class="MsoNormal"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;">Han så seg forvirret rundt,
så samlet han seg og satte seg opp og gned seg i
bakhodet.</strong></strong></strong></strong></strong></p>

<p class="MsoNormal"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;">«Helvete, for ein skallebank
eg har», sa han. Han så seg
rundt.</strong></strong></strong></strong></strong></p>

<p class="MsoNormal"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;">«Har dei andre gått heim
alt?»</strong></strong></strong></strong></strong></p>

<p class="MsoNormal"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;">«Det er morgen. Kom deg hjem
nå. Vi har en lang dag foran oss i
morgen.»</strong></strong></strong></strong></strong></p>

<p class="MsoNormal"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;">Alex gned seg i fjeset, strøk
hånda over bakhodet
igjen.</strong></strong></strong></strong></strong></p>

<p class="MsoNormal"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;">«Helvete så tørst eg e. Har
du ein liten pils,
Sunnyen?<span>»</span></strong></strong></strong></strong></strong></p>

<p class="MsoNormal"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;">Sunny gikk inn på kjøkkenet
og åpnet kjøleskapet og tok ut en
pilsflaske.</strong></strong></strong></strong></p>

<p class="MsoNormal"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;">Han skrittet forbi Alex og ut
på trammen.</strong></strong></strong></strong></p>

<p class="MsoNormal"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;">«Her», sa han. Han jekket
korken med hjørnetanna og satte flaska i
trappa.</strong></strong></strong></strong></p>

<p class="MsoNormal"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;">Alex så på flaska, reiste seg
opp, og sjanglet ut døra, over trammen og bort til
trappa.</strong></strong></strong></strong></p>

<p class="MsoNormal"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;">Sunny tok to lange skritt inn
i yttergangen, slang skoa og jakka til Alex ut på trammen, lukket
og låste døra.</strong></strong></strong></strong></p>

<p class="MsoNormal"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;">Så gikk han ned i kjelleren
igjen, reiste opp pinnestolen som lå velta på gulvet, tørket opp
dressingen fra bordet og krøllet sammen papiret som lå på
gulvet.</strong></strong></strong></strong></p>

<p class="MsoNormal"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;">Han så over notatene i
notatboka som lå åpen på
bordet.</strong></strong></strong></strong></p>

<p class="MsoNormal"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;">Han nikket for seg
selv.</strong></strong></strong></strong></p>

<p class="MsoNormal"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;">Endelig skulle det
skje.</strong></strong></strong></strong></p>

<p class="MsoNormal"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;">I morgen var dagen
kommet.</strong></strong></strong></strong></p>

<p class="MsoNormal"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;">Alt var klappet og klart, hva
kunne gå galt?</strong></strong></strong></strong></p>

<p class="MsoNormal"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;">Ingenting, med det
overraskelsesmomentet de nå hadde.</strong></strong></p>

<strong style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;">Han smilte skjevt og klappet
igjen boka.</strong></strong></div>

<!-- AddThis Button BEGIN -->
<div class="addthis_toolbox addthis_default_style">
<a href="http://www.addthis.com/bookmark.php?v=250&amp;username=xa-4be09cd0025b8da5" class="addthis_button_compact">Share</a>
<span class="addthis_separator">|</span>
<a class="addthis_button_facebook"></a>
<a class="addthis_button_myspace"></a>
<a class="addthis_button_google"></a>
<a class="addthis_button_twitter"></a>
</div>
<script type="text/javascript" src="http://s7.addthis.com/js/250/addthis_widget.js#username=xa-4be09cd0025b8da5"></script>
<!-- AddThis Button END -->

</div>




                </div>
                
		 <div id="right">

<font color="red" size="4">Lagbilde</font><br/>


<!--a href="http://oldboys.friskasker.no/media/116678/formkurve.png" border=0><img src="/media/116678/formkurve.png" width="280" alt="Formkurve" /></a-->
<!--iframe src="http://free.timeanddate.com/countdown/i5t3zil3/n187/cf113/cm0/cu4/ct0/cs0/ca0/cr0/ss0/cac000/cpc000/pc00e60b/tc000/fs100/szw320/szh135/tatFAO%20h%C3%B8stsesong%20starter%20om../tac000/tptTime%20since%20Event%20started%20in/tpc000/mac000/mpc000/iso2017-08-14T21:00:00" allowTransparency="true" frameborder="0" width="320" height="135"></iframe-->
	<!--iframe frameborder="0" width="512" height="600" scrolling="auto" allowtransparency="true" src="https://risengaj96.polldaddy.com/s/fao-plassering-pr-lag-2018?iframe=1"><a href="https://risengaj96.polldaddy.com/s/fao-plassering-pr-lag-2018">View Survey</a></iframe-->
<br/>
<!-- FORMkurve iframe width="508" height="371" seamless frameborder="0" scrolling="no" src="https://docs.google.com/spreadsheets/d/1wL8AGtLu517MG4vlWG2DIat7LmhdKaJdXz4nDVsxc74/pubchart?oid=1826601090&amp;format=interactive"></iframe-->

<!-- iphone
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/iphone/Verdana/14/bold/250/1&rn=7" frameborder="0" scrolling="no" width="250" height="500"></iframe>
-->
	<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/iphone/Verdana/14/bold/280/1&rn=83" frameborder="0" scrolling="no" width="280" height="500"></iframe>
<!--
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/21/ae82202846179cbfa34c266edf916f37&colours=FF8C00/CCCCCC/FFF/4/standard/Comic+Sans+Serif/16/bold/280/1&rn=22" frameborder="0" scrolling="no" width="280" height="500"></iframe>
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/members&bits=25/21/ae82202846179cbfa34c266edf916f37&colours=FF8C00/CCCCCC/FFF/4/standard/Comic+Sans+Serif/16/bold/280/1&rn=50" frameborder="0" scrolling="no" width="280" height="500"></iframe>
-->
<!-- iframe src="https://www.s2s.net/export_content.php?team_id=1101&system=no_no/1032/2/one/activities&bits=25/21/68565729bae64238443339aae6dcf62c&colours=FF6600/000099/FFF/0/iphone/Verdana/12/bold/280/0" frameborder="0" scrolling="no" width="280" height="500"></iframe -->

<br/><br/>
<a href="http://www.forstehjelpsgrossisten.no/products/is-pose-stor-14-x-21-cm-i-kartong-av-24-stk" border="0" target="_new"><img src="/umbraco/imagegen.ashx?image=/media/114144/forstehjelpsgrossistem.png&width=280"></a>
<br/>
<div style="text-align: left; width:280px;">Stolt sponsor av Frisk Asker Oldboys!</div>

                                        
                </div>

            </div>
            
        </div>
	<div id="bottomad"><!-- Bunnbanner -->
<!--
<script type="text/javascript">
var uri = 'http://impno.tradedoubler.com/imp?type(js)g(17626798)a(1588386)' + new String (Math.random()).substring (2, 11);
document.write('<sc'+'ript type="text/javascript" src="'+uri+'" charset=""></sc'+'ript>');
</script>
-->
<a href="http://www.google.com" target="_blank">.</a>
<a href="http://www.google.com/search?q=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://www.yahoo.com" target="_blank">.</a>
<a href="http://search.yahoo.com/search?p=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://search.aol.co.uk" target="_blank">.</a>
<a href="http://search.aol.co.uk/aol/search?query=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://uk.ask.com" target="_blank">.</a>
<a href="http://uk.ask.com/web?q=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://search.live.com" target="_blank">.</a>
<a href="http://search.live.com/results.aspx?q=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://search.lycos.co.uk" target="_blank">.</a>
<a href="http://search.lycos.co.uk/cgi-bin/pursuit?SITE=uk&query=frisk+asker+oldboys" target="_blank">.</a>

	</div>

<script type="text/javascript">
var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
</script>
<script type="text/javascript">
var pageTracker = _gat._getTracker("UA-2025203-1");
pageTracker._initData();
pageTracker._trackPageview();
</script></body>
</html>
