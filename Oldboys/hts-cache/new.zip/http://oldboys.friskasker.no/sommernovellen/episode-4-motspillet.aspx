
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">

	<head>

		<title>Episode 4: Motspillet  - Frisk Asker Oldboys</title>
		
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
		<meta http-equiv="imagetoolbar" CONTENT="no">
		<meta name="keywords" content="" />
		<meta name="description" content="
Fjerde episode i sommerkrim'en, det tårner seg opp!
" />
		
		<meta name="title" content="Episode 4: Motspillet - Frisk Asker Oldboys" />
		<meta name="URL" content="http://oldboys.friskasker.no" />
		<meta name="language" content="Norsk" />
		<meta name="author" content="Terje Dahl" />
		<meta name="copyright" content="Frisk Asker Oldboys" />
		<meta name="reply-to" content="terjda@online.no" />
		<meta name="verify-v1" content="BxVdMcZ0uoa2KVw8RB+FBg3715LgSDXNG+RYp0gHpAI=" />

		<link type="text/css" href="/css/client.css" rel="stylesheet" />
		<link type="text/css" href="/css/default.css" rel="stylesheet" />
		<link type="text/css" href="/css/weatherCSS.css" rel="stylesheet" />

		<script type="text/javascript" src="/js/jquery.js"></script>
		<script type="text/javascript" src="/js/ufo.js"></script>
		<script type="text/javascript" src="/js/friskasker.js"></script>
		<!--script type='text/javascript' src='http://www.rdmtech.no/js/jquery.js?ver=1.2.6'></script-->
		<!--script type='text/javascript' src='http://www.rdmtech.no/js/jquery.cross-slide.js?ver=2.6'></script-->

		<!--[if IE 6]>
		<link type="text/css" href="/css/ie60.css" rel="stylesheet" />			
		<![endif]-->
		<!-- TradeDoubler site verification 1588386 --> 

	<script type='text/javascript'>
		jQuery(function($) {$(document).ready(function() {
			$('#container2').crossSlide(
				{sleep: 2, fade: 1},
				[{src: 'http://oldboys.friskasker.no/media/26561/bg-fao1.jpg'},{src: 'http://oldboys.friskasker.no/media/26566/bg-fao2.jpg'},{src: 'http://oldboys.friskasker.no/media/26571/bg-fao3.jpg'},{src: 'http://oldboys.friskasker.no/media/26576/bg-fao4.jpg'}]
			);
		});});
	</script>
	
<script type="text/javascript">
var _polldaddy = [] || _polldaddy;

_polldaddy.push( {
    type: 'slider',
    title: 'FAO-spillemodellen, skjønner du den?',
    body: 'Ta testen og bidra til å øke sjansen for sportslig utvikling av FAO!',
    button: 'Get Started &raquo;',
    domain: 'risengaj96.polldaddy.com/s/',
    id: 'fao-spillemodellen',
    placeholder: 'pd1438692132734'
} );

jQuery(function(d,c,j){$if(!document.getElementById(j)){var pd=d.createElement(c),s;pd.id=j;pd.src=('https:'==document.location.protocol)?'https://polldaddy.com/survey.js':'http://i0.poll.fm/survey.js';s=document.getElementsByTagName(c)[0];s.parentNode.insertBefore(pd,s);}}(document,'script','pd-embed'));
</script>

	
	</head>
	
	<body>
      
        <div id="container">&nbsp;
        
            <div id="header">&nbsp;
            
                <div id="logo"><a href="/"><img src="/media/26597/logos.gif" alt="Logo" /></a></div>
                <div id="rss"><a href="/data/rss/nyheter.xml">Motta RSS strøm</a></div>
		<!--div id="sitemap"><a href="/sitemap.aspx">Sitemap</a></div-->
		<div id="topknapp">
		<iframe width="280" height="160" src="https://www.youtube.com/embed/15KEqzCTrwI" frameborder="0" allowfullscreen></iframe>
		</div>
		
                

            </div>
            
            <div id="body">&nbsp;
            
                <div id="left">&nbsp;

                    <div id="date">mandag 15. april</div>
                	
                    <div class="leftnav"><a href="/">Hjem</a><br /><a href="/arkiv.aspx">Arkiv</a><br /><a href="/tabeller--terminlister.aspx">Tabeller &amp; terminlister</a><br /><a href="/kampreferat.aspx">Kampreferat</a><br /><a href="/fotballfilosofi.aspx">Fotballfilosofi</a><br /><a href="/ikke-helt-sportslig.aspx">Ikke helt sportslig</a><br /></div>
		
                    <div class="box" id="contactbox"><div class="header">Frisk Asker</div><div class="body"><a href="/frisk-asker/laget.aspx">Laget</a><br /><a href="/frisk-asker/kontakt.aspx">Kontakt</a><br /><a href="/frisk-asker/dommerhjoernet.aspx">Dommerhjørnet</a><br /><a href="https://teams.s2s.net/11225/no/" target="_new">Treningstider</a></div><div class="footer"><!----></div></div>

<!--		     <iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/standard/Verdana/14/bold/230/1&rn=84" frameborder="0" scrolling="no" width="230" height="500"></iframe>
-->
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&banner=1&system=no_no/5212/1/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/standard/Verdana/14/bold/230/1&rn=94" frameborder="0" scrolling="no" width="230" height="214"></iframe>

		     <iframe src="http://www.s2s.net/todays_skill_external.php?ccc=no" scrolling="no" width="200" height="330" frameborder="0"></iframe>
<!--
		     <div id="login">&nbsp;
                   
                    <form id="loginform" action="#">&nbsp;
                      
                        <input id="username" type="text" value="brukernavn" />
                        <input id="password" type="text" value="passord" />
                        <img src="/img/login.gif" alt="login" />
                        <a href="#">glemt passord?</a>    
                        
                    </form>
                    
                    </div>
-->
		    <div id="search">

			Artikkelsøk:<br />
			<div id="xsltsearch" xmlns:ps="urn:percipientstudios-com:xslt"><form action="/soek.aspx?" method="post" class="xsltsearch_form"><input name="search" type="text" class="input" value=""></input> <input type="submit" value="Search" class="submit" /></form></div>
		    </div>

                </div>
                
                <div id="center">
		
                    
<div class="content">

	<!--h1>Episode 4: Motspillet</h1-->
	<!--p><b><p>Fjerde episode i sommerkrim'en, det tårner seg opp!</p></b></p><br/-->

	<h1>Episode 4: Motspillet</h1><div class="meta">07.07.16 12:38 - </div><div class="abstract"><img src="/umbraco/imagegen.ashx?image=/media/115158/episode 4.png&amp;width=80" alt="" align="left" />
<p>Fjerde episode i sommerkrim'en, det tårner seg opp!</p>
</div>
<p>&nbsp;</p>

<p>&nbsp;</p>

<p><strong>Motspillet</strong></p>

<p>Den eldste etterforskeren trykket på knappen og stoppet
lydbåndet.<br />
 «Vi vet ganske mye her nå», sa han.<br />
 «Vi vet at de planlegger å slå til i morgen kveld, så vi har kort
tid på oss. Og det høres ut som at det er hvelvet i kjelleren hos
DnB som er målet. Dette kuppet her burde vi vel klare å få
stoppet?»<br />
 Inspektør Brøyn reiste seg og gikk noen skritt med en tenksom
mine, mens han holdt seg på haken med den ene hånden.<br />
 «For det første», sa han, så er det ikke snakk om at vi skal
<em>stoppe</em> dette kuppet. Det vi skal, er å <em>fakke</em>
denne fordømte gjengen med anarkister. Samfunnsfiender.»<br />
 De andre tre så på ham.<br />
 Dette var allerede blitt personlig for inspektør Brøyn.<br />
 «Men», sa han, «det er noe her som ikke stemmer.»<br />
 «Jeg får ikke tak i det. For det første, hva er det som har fått
Bleikerbanden til å satse på et brekk av denne typen? Fordømte
slamper. Innbrudd i en samfunnsinstitusjon. Lage uorden sånn.<br />
 Dessuten, hvordan tror de at de skal kunne komme seg inn i hvelvet
ved å kortslutte sikringsskapet? Hvor kørka går det an å bli? Dette
ligner ikke Sunny. Det ligner ikke Sunny i det hele tatt.»<br />
 Statsadvokaten hadde ikke sagt noe på lenge. Han var fascinert av
inspektør Brøyns engasjement og logiske sans. Det var helt klart en
riktig beslutning å sette Brøyn på denne oppgaven. Den stakkaren
som først kom inn i inspektør Brøyns infrarøde fokus, ville ikke
slippe unna. What so ever.<br />
 «Inspektør Brøyn», sa han, «hvis du har tenkt å fakke denne
banden, så er det viktig å tenke på <em>når</em> du tar dem, jeg
bare minner om det. Rent juridisk, mener jeg. Tar du dem på vei
<em>inn</em>, så straffes det som innbrudd på eiendom, med betinget
straff. Hvis du virkelig vil overmanne denne banden, så må du gjøre
det etter at de har tilegnet seg gjenstander, som det heter i
jussen. Lar du dem gjennomføre tyveriet, er det mye strengere
represalier. Mer i din ånd.»<br />
 Tennene til inspektør Brøyn vistes et øyeblikk, i en grimase i en
blanding av et glis og et glefs.<br />
<br />
 Inspektør Brøyn gikk bort til tavla i den andre delen av
kontoret.<br />
 «La oss strukturere det vi vet så langt», sa han. «Jeg kan ikke
fordra at ting er rotete.»<br />
 «Tell me about it», mumlet den yngste etterforskeren.<br />
 <em>BLEIKERBANDEN</em> skrev inspektør Brøyn med store bokstaver
øverst på tavla.<br />
 <em>Kriminell analyseprofil</em> skrev han under, og så tegnet han
syv fyrstikkmenn i en 2-3-1-formasjon.<br />
 På den første tegnet han et kapteinsbind.<br />
 «Sunny», sa han og skrev et ett-tall over. «Salgssjef i DnB
Eiendom som dekk-yrke. I virkeligheten en iskald bandeleder. En
skikkelig sta jævel. Så ille, at han var utredet for autisme i
ungdommen.»<br />
 «Moa», sa han videre, og tegnet et 2-tall over den neste figuren.
«Ferskvaresjef på Meny som dekk-yrke. Bandens mest proffe. Så
dedikert at han gir store offer for å lykkes. Moa hadde stupt inn i
fiendenes linjer i en krig, hvis han hadde trodd det måtte til for
å vinne krigen.»<br />
<br />
 «Så har vi Happi», sa Brøyn og skrev et 3-tall. «Bandens mest
uforutsigbare kort. Trekker raskere enn sin egen skygge. Spiser et
brød til frokost.»<br />
 «Bønna». Brøyn skrev et 4-tall.<br />
 «Elektro-spesialist. Hater regler. Svigermors drøm, helt til hun
utfordrer ham i kinasjakk. Abnormt kampinstinkt som har kostet ham
brudd i alt som kan brekkes i en kropp.<br />
 Så er det Alex, nr 5. Kruttønne lagd av stål. Kan legge en okse i
bakken med bare nevene, og holde den nede til den gir seg. Farlig
temperament som får ham opp i bråk hele tiden. Som er det han
elsker.<br />
 Nummer 6 er Trond-2. Kvinnebedårer med livsfarlig spontanitet som
fast levemåte. Schizofren. Derav navnet. Når han er Trond-1, er han
en ansvarlig omsorgsarbeider. Men som Trond-2, lever han blottet
for dømmekraft eller tanker om konsekvens, som naturligvis gjør
både ham selv og omgivelsene hans utsatt.<br />
 Til slutt har vi Mads, nummer 7. En stright økonomisjef i det
daglige. Har vansker med å innrette seg etter forordninger. Utgjør
sammen med Sunny bandens brains. Der resten av spetakkelet
utfordrer det bestående på rent instinkt, angriper Mads det
innenfor reglene i blådress.»<br />
<br />
 Brøyn la fra seg tusjen, tok et par skritt bakover og ble stående
og se på skissen. Han snudde seg mot statsadvokaten som satt i dype
tanker og hørte på.<br />
 «Herr statsadvokat, tenker du det samme som meg?»<br />
 Statsadvokaten blunket med begge øynene.<br />
 «Det kan godt være», svarte han. «Det kan godt være.»<br />
 Brøyn snudde seg mot tavla igjen.<br />
 Han gikk frem og holdt hånden over de syv figurene.<br />
 «La oss nå se på den kriminelle analyseprofilen for banden samlet
sett som gruppe, sa han. «En gruppeprofil».<br />
 «Hvilke egenskaper vil dere si går igjen i denne gjengen», sa han
og rettet seg mot de to etterforskerne.<br />
 Begge etterforskerne hadde fulgt nøye med på inspektørens
analysegjennomgang.<br />
 «Hm», sa den eldste av dem. «Det virker som de alle er sterke
motstandere av regler og retningslinjer. At de liker å gi
blaffen».<br />
 Den yngste etterforskeren vred seg litt i stolen.<br />
 «Og så virker de som en gjeng med stabukker», sa han.
«Uforutsigbare stabukker. Stakkars den som skulle prøvd å ha
kontroll på denne gjengen.»<br />
 «Nettopp!» sa Brøyn. «Og det er derfor dette ikke rimer, at disse
her skal prøve seg på et fordømt bankhvelv!» Han snudde seg mot
statsadvokaten, som satt med dype rynker i pannen og hørte
på.<br />
 «Det er noe muffens med hele dette opplegget», sa Brøyn. «Men at
de pønsker på noe bøll, det er jo helt klart».<br />
 Statsadvokaten nikket sakte, med blikket på tavla.<br />
 «Ja», sa han. «Noe skikkelig bøll».<br />
 Statsadvokaten reiste seg fra stolen.<br />
 «En så dårlig plan har jeg ikke sett siden Norges bortekamp mot
Ungarn», sa han.<br />
 Brøyn nikket.<br />
 «Men hva pokker'n har skjedd med denne stimen av lokale småfisk,
når de vil prøve seg på et bytte som dette. Jeg fatter det
ikke.»<br />
<br />
 Den eldste av de to etterforskerne tok opp den vibrerende mobilen
sin og så på den.<br />
 «Beklager», sa han. «Jeg må ta denne. Det er fra
etterretningen.»<br />
 Han trykket på telefonen og satte den til øret.<br />
 «Ja?»<br />
 De tre andre var stille.<br />
 «Ja. Ja. OK. Forstår. Greit. Takk.»<br />
 Han trykket på telefonen, og la den tilbake i jakkelomma.<br />
 «Det var etterretningen», sa han. «Det er verre enn vi
trodde.»<br />
 De andre så spente på ham.<br />
 «Hold dere fast. Ingen av dem har betalt treningsavgiften.»<br />
 «What!?» utbrøt statsadvokaten. «Er det mulig! Og du som sa dette
var småfisk!»<br />
 «Jeeeeezzzz», sa den yngste etterforskeren og plystret.<br />
 Inspektør Brøyn satt stille.<br />
 «La meg gjette», sa Brøyn. Han henvendte seg til etterforskeren
med telefonen.<br />
 «De har blitt ekskludert?»<br />
 «Hvordan visste du det?» sa etterforskeren overrasket. «Ja, det er
akkurat det de har. Ekskludert fra treningsapp'en og
WhatsApp-gruppa. Ingen kjære mor der i gården, tydeligvis.»<br />
 «Shit», sa den yngste etterforskeren.<br />
 «Nå faller brikkene på plass», sa Brøyn. «Folkens, dette her er
ikke bra.»<br />
 «Har du skjønt motivet?», sa den yngste etterforskeren.<br />
 «La meg forklare», sa Brøyn, i en belærende tone.<br />
 «Først har du en gjeng med utprega stabeiser. Som ikke tar fem øre
for å bryte retningslinjer. Så gir du dem en klar beskjed. Hva tror
du skjer da?»<br />
 Etterforskeren rynket brynene.<br />
 «De gjør ikke det de får beskjed om?» prøvde han.<br />
 «Riktig», svarte Brøyn. «De gjør ikke det det de får beskjed om.
Så får de en purring. Hva gjør de da, tror du?»<br />
 «De gjør fremdeles ikke det de får beskjed om?» Etterforskeren
følte seg sikrere på svaret nå.<br />
 «Riktig. Og så får de enda en beskjed, og det har nå gått
prestisje i saken. Jævla stabukker. Så blir de naturligvis til
slutt ekskludert, for hva skal den stakkars lagledelsen deres
gjøre? Og da har vi en deadlock. Stabeisene nekter å krype til
korset og gjøre opp med egne midler, og retningslinjene sier at de
må gjøre opp.»<br />
 Den unge etterforskeren nikket tenksom.<br />
 «Men hvordan i alle dager har dette ført til at de vil gå så langt
som å forgifte securitasvakter, kortslutte sikringsbokser, bryte
seg inn i bankhvelv, og gå så fullstendig bananas?»<br />
 Brøyn satte seg.<br />
 «Ja, det er jo det som er den skjebnebestemte ironien i det hele.
It's in their nature. Hva tror du skjer med en molotovcoctail, med
ingrediensene impulsive og temperamentsfulle stabeiser som gir
blaffen i regler, når du tilsetter en gnist tre ganger. Vel, da
kommer ting ut av kontroll, det er i hvert fall sikkert.»<br />
 Statsadvokaten gikk bort til stolen sin og tok på seg jakka.<br />
 «Vel, inspektør Brøyn», sa han. «Vi har kartlagt saken bra. Nå er
det vel bare å rigge til beredskapstroppen, og snøre sammen nettet
i morgen når stimen kommer?»<br />
 «Ja», sa Brøyn. «Jeg skal ta hånd om det. Vi vet <em>hvor</em> de
kommer, <em>når</em> de kommer, og <em>hvorfor</em> de kommer. Her
blir det bare å sanke sammen fangsten.»<br />
 Han klarte ikke å skjule hvor mye han gledet seg.</p>

<p>&nbsp;</p>

<p><a href="/sommernovellen/episode-5-gjennomfoeringen!.aspx"
title="Episode 5: Gjennomføringen!">Episode 5:
Gjennomføringen!</a></p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<!-- AddThis Button BEGIN -->
<div class="addthis_toolbox addthis_default_style">
<a href="http://www.addthis.com/bookmark.php?v=250&amp;username=xa-4be09cd0025b8da5" class="addthis_button_compact">Share</a>
<span class="addthis_separator">|</span>
<a class="addthis_button_facebook"></a>
<a class="addthis_button_myspace"></a>
<a class="addthis_button_google"></a>
<a class="addthis_button_twitter"></a>
</div>
<script type="text/javascript" src="http://s7.addthis.com/js/250/addthis_widget.js#username=xa-4be09cd0025b8da5"></script>
<!-- AddThis Button END -->

</div>




                </div>
                
		 <div id="right">

<font color="red" size="4">Lagbilde</font><br/>


<!--a href="http://oldboys.friskasker.no/media/116678/formkurve.png" border=0><img src="/media/116678/formkurve.png" width="280" alt="Formkurve" /></a-->
<!--iframe src="http://free.timeanddate.com/countdown/i5t3zil3/n187/cf113/cm0/cu4/ct0/cs0/ca0/cr0/ss0/cac000/cpc000/pc00e60b/tc000/fs100/szw320/szh135/tatFAO%20h%C3%B8stsesong%20starter%20om../tac000/tptTime%20since%20Event%20started%20in/tpc000/mac000/mpc000/iso2017-08-14T21:00:00" allowTransparency="true" frameborder="0" width="320" height="135"></iframe-->
	<!--iframe frameborder="0" width="512" height="600" scrolling="auto" allowtransparency="true" src="https://risengaj96.polldaddy.com/s/fao-plassering-pr-lag-2018?iframe=1"><a href="https://risengaj96.polldaddy.com/s/fao-plassering-pr-lag-2018">View Survey</a></iframe-->
<br/>
<!-- FORMkurve iframe width="508" height="371" seamless frameborder="0" scrolling="no" src="https://docs.google.com/spreadsheets/d/1wL8AGtLu517MG4vlWG2DIat7LmhdKaJdXz4nDVsxc74/pubchart?oid=1826601090&amp;format=interactive"></iframe-->

<!-- iphone
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/iphone/Verdana/14/bold/250/1&rn=7" frameborder="0" scrolling="no" width="250" height="500"></iframe>
-->
	<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/iphone/Verdana/14/bold/280/1&rn=83" frameborder="0" scrolling="no" width="280" height="500"></iframe>
<!--
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/21/ae82202846179cbfa34c266edf916f37&colours=FF8C00/CCCCCC/FFF/4/standard/Comic+Sans+Serif/16/bold/280/1&rn=22" frameborder="0" scrolling="no" width="280" height="500"></iframe>
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/members&bits=25/21/ae82202846179cbfa34c266edf916f37&colours=FF8C00/CCCCCC/FFF/4/standard/Comic+Sans+Serif/16/bold/280/1&rn=50" frameborder="0" scrolling="no" width="280" height="500"></iframe>
-->
<!-- iframe src="https://www.s2s.net/export_content.php?team_id=1101&system=no_no/1032/2/one/activities&bits=25/21/68565729bae64238443339aae6dcf62c&colours=FF6600/000099/FFF/0/iphone/Verdana/12/bold/280/0" frameborder="0" scrolling="no" width="280" height="500"></iframe -->

<br/><br/>
<a href="http://www.forstehjelpsgrossisten.no/products/is-pose-stor-14-x-21-cm-i-kartong-av-24-stk" border="0" target="_new"><img src="/umbraco/imagegen.ashx?image=/media/114144/forstehjelpsgrossistem.png&width=280"></a>
<br/>
<div style="text-align: left; width:280px;">Stolt sponsor av Frisk Asker Oldboys!</div>

                                        
                </div>

            </div>
            
        </div>
	<div id="bottomad"><!-- Bunnbanner -->
<!--
<script type="text/javascript">
var uri = 'http://impno.tradedoubler.com/imp?type(js)g(17626798)a(1588386)' + new String (Math.random()).substring (2, 11);
document.write('<sc'+'ript type="text/javascript" src="'+uri+'" charset=""></sc'+'ript>');
</script>
-->
<a href="http://www.google.com" target="_blank">.</a>
<a href="http://www.google.com/search?q=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://www.yahoo.com" target="_blank">.</a>
<a href="http://search.yahoo.com/search?p=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://search.aol.co.uk" target="_blank">.</a>
<a href="http://search.aol.co.uk/aol/search?query=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://uk.ask.com" target="_blank">.</a>
<a href="http://uk.ask.com/web?q=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://search.live.com" target="_blank">.</a>
<a href="http://search.live.com/results.aspx?q=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://search.lycos.co.uk" target="_blank">.</a>
<a href="http://search.lycos.co.uk/cgi-bin/pursuit?SITE=uk&query=frisk+asker+oldboys" target="_blank">.</a>

	</div>

<script type="text/javascript">
var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
</script>
<script type="text/javascript">
var pageTracker = _gat._getTracker("UA-2025203-1");
pageTracker._initData();
pageTracker._trackPageview();
</script></body>
</html>
