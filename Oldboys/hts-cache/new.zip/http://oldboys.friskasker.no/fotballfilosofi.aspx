
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">

	<head>

		<title>Fotballfilosofi  - Frisk Asker Oldboys</title>
		
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
		<meta http-equiv="imagetoolbar" CONTENT="no">
		<meta name="keywords" content="" />
		<meta name="description" content="" />
		
		<meta name="title" content="Fotballfilosofi - Frisk Asker Oldboys" />
		<meta name="URL" content="http://oldboys.friskasker.no" />
		<meta name="language" content="Norsk" />
		<meta name="author" content="Terje Dahl" />
		<meta name="copyright" content="Frisk Asker Oldboys" />
		<meta name="reply-to" content="terjda@online.no" />
		<meta name="verify-v1" content="BxVdMcZ0uoa2KVw8RB+FBg3715LgSDXNG+RYp0gHpAI=" />

		<link type="text/css" href="/css/client.css" rel="stylesheet" />
		<link type="text/css" href="/css/default.css" rel="stylesheet" />
		<link type="text/css" href="/css/weatherCSS.css" rel="stylesheet" />

		<script type="text/javascript" src="/js/jquery.js"></script>
		<script type="text/javascript" src="/js/ufo.js"></script>
		<script type="text/javascript" src="/js/friskasker.js"></script>
		<!--script type='text/javascript' src='http://www.rdmtech.no/js/jquery.js?ver=1.2.6'></script-->
		<!--script type='text/javascript' src='http://www.rdmtech.no/js/jquery.cross-slide.js?ver=2.6'></script-->

		<!--[if IE 6]>
		<link type="text/css" href="/css/ie60.css" rel="stylesheet" />			
		<![endif]-->
		<!-- TradeDoubler site verification 1588386 --> 

	<script type='text/javascript'>
		jQuery(function($) {$(document).ready(function() {
			$('#container2').crossSlide(
				{sleep: 2, fade: 1},
				[{src: 'http://oldboys.friskasker.no/media/26561/bg-fao1.jpg'},{src: 'http://oldboys.friskasker.no/media/26566/bg-fao2.jpg'},{src: 'http://oldboys.friskasker.no/media/26571/bg-fao3.jpg'},{src: 'http://oldboys.friskasker.no/media/26576/bg-fao4.jpg'}]
			);
		});});
	</script>
	
<script type="text/javascript">
var _polldaddy = [] || _polldaddy;

_polldaddy.push( {
    type: 'slider',
    title: 'FAO-spillemodellen, skjønner du den?',
    body: 'Ta testen og bidra til å øke sjansen for sportslig utvikling av FAO!',
    button: 'Get Started &raquo;',
    domain: 'risengaj96.polldaddy.com/s/',
    id: 'fao-spillemodellen',
    placeholder: 'pd1438692132734'
} );

jQuery(function(d,c,j){$if(!document.getElementById(j)){var pd=d.createElement(c),s;pd.id=j;pd.src=('https:'==document.location.protocol)?'https://polldaddy.com/survey.js':'http://i0.poll.fm/survey.js';s=document.getElementsByTagName(c)[0];s.parentNode.insertBefore(pd,s);}}(document,'script','pd-embed'));
</script>

	
	</head>
	
	<body>
      
        <div id="container">&nbsp;
        
            <div id="header">&nbsp;
            
                <div id="logo"><a href="/"><img src="/media/26597/logos.gif" alt="Logo" /></a></div>
                <div id="rss"><a href="/data/rss/nyheter.xml">Motta RSS strøm</a></div>
		<!--div id="sitemap"><a href="/sitemap.aspx">Sitemap</a></div-->
		<div id="topknapp">
		<iframe width="280" height="160" src="https://www.youtube.com/embed/15KEqzCTrwI" frameborder="0" allowfullscreen></iframe>
		</div>
		
                

            </div>
            
            <div id="body">&nbsp;
            
                <div id="left">&nbsp;

                    <div id="date">mandag 15. april</div>
                	
                    <div class="leftnav"><a href="/">Hjem</a><br /><a href="/arkiv.aspx">Arkiv</a><br /><a href="/tabeller--terminlister.aspx">Tabeller &amp; terminlister</a><br /><a href="/kampreferat.aspx">Kampreferat</a><br /><a href="/fotballfilosofi.aspx" class="current">Fotballfilosofi</a><br /><a href="/ikke-helt-sportslig.aspx">Ikke helt sportslig</a><br /></div>
		
                    <div class="box" id="contactbox"><div class="header">Frisk Asker</div><div class="body"><a href="/frisk-asker/laget.aspx">Laget</a><br /><a href="/frisk-asker/kontakt.aspx">Kontakt</a><br /><a href="/frisk-asker/dommerhjoernet.aspx">Dommerhjørnet</a><br /><a href="https://teams.s2s.net/11225/no/" target="_new">Treningstider</a></div><div class="footer"><!----></div></div>

<!--		     <iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/standard/Verdana/14/bold/230/1&rn=84" frameborder="0" scrolling="no" width="230" height="500"></iframe>
-->
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&banner=1&system=no_no/5212/1/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/standard/Verdana/14/bold/230/1&rn=94" frameborder="0" scrolling="no" width="230" height="214"></iframe>

		     <iframe src="http://www.s2s.net/todays_skill_external.php?ccc=no" scrolling="no" width="200" height="330" frameborder="0"></iframe>
<!--
		     <div id="login">&nbsp;
                   
                    <form id="loginform" action="#">&nbsp;
                      
                        <input id="username" type="text" value="brukernavn" />
                        <input id="password" type="text" value="passord" />
                        <img src="/img/login.gif" alt="login" />
                        <a href="#">glemt passord?</a>    
                        
                    </form>
                    
                    </div>
-->
		    <div id="search">

			Artikkelsøk:<br />
			<div id="xsltsearch" xmlns:ps="urn:percipientstudios-com:xslt"><form action="/soek.aspx?" method="post" class="xsltsearch_form"><input name="search" type="text" class="input" value=""></input> <input type="submit" value="Search" class="submit" /></form></div>
		    </div>

                </div>
                
                <div id="center">
		
                    
<div class="content">

	<h1>Fotballfilosofi</h1>
	<p><b>Generelle betraktninger fra bakrommet</b></p><br/>



	<div class="newsitem"><h2>Det beste er godt nok</h2><p><img src="/umbraco/imagegen.ashx?image=/media/126088/kelly.jpg&amp;width=80" alt="Bilde" align="left" />
<p>Kanskje...</p>
</p><a class="readmore" href="/fotballfilosofi/det-beste-er-godt-nok.aspx">Les mer ...</a></div><div class="newsitem"><h2>Oldboysguttas Blues</h2><p><img src="/umbraco/imagegen.ashx?image=/media/122161/blues.jpg&amp;width=80" alt="Bilde" align="left" />
<p>.</p>
</p><a class="readmore" href="/fotballfilosofi/oldboysguttas-blues.aspx">Les mer ...</a></div><div class="newsitem"><h2>Kona likte oss aldri uansett</h2><p><img src="/umbraco/imagegen.ashx?image=/media/119364/lions.jpg&amp;width=80" alt="Bilde" align="left" />
<p>.</p>
</p><a class="readmore" href="/fotballfilosofi/kona-likte-oss-aldri-uansett.aspx">Les mer ...</a></div><div class="newsitem"><h2>Special price for you, my friend</h2><p><img src="/umbraco/imagegen.ashx?image=/media/114082/and.jpg&amp;width=80" alt="Bilde" align="left" />
<p>Auksjonssang</p>
</p><a class="readmore" href="/fotballfilosofi/special-price-for-you,-my-friend.aspx">Les mer ...</a></div><div class="newsitem"><h2>Jakka til Frisk Asker</h2><p><img src="/umbraco/imagegen.ashx?image=/media/109330/jakke.jpg&amp;width=80" alt="Bilde" align="left" />
<p>Moas jakkekvad</p>
</p><a class="readmore" href="/fotballfilosofi/jakka-til-frisk-asker.aspx">Les mer ...</a></div><div class="newsitem"><h2>FAO Bohemian Rhapsody</h2><p><img src="/umbraco/imagegen.ashx?image=/media/103979/la-vie-de-boh$e3$a8me-$28the-bohemian-life$29.jpg&amp;width=80" alt="Bilde" align="left" />
<p>From a player's point of view</p>
</p><a class="readmore" href="/fotballfilosofi/fao-bohemian-rhapsody.aspx">Les mer ...</a></div><div class="newsitem"><h2>De aller beste</h2><p><img src="/umbraco/imagegen.ashx?image=/media/94475/de aller beste.jpg&amp;width=80" alt="Bilde" align="left" /></p><a class="readmore" href="/fotballfilosofi/de-aller-beste.aspx">Les mer ...</a></div><div class="newsitem"><h2>These days</h2><p><img src="/umbraco/imagegen.ashx?image=/media/90849/krabbefiske.jpg&amp;width=80" alt="Bilde" align="left" />
<p>Kjærlighetsbrev til FAO i sommerferien</p>
</p><a class="readmore" href="/fotballfilosofi/these-days.aspx">Les mer ...</a></div><div class="newsitem"><h2>Jeg er et gammalt fotballdraktsett</h2><p><img src="/umbraco/imagegen.ashx?image=/media/89948/bag.jpg&amp;width=80" alt="Bilde" align="left" />
<p>Draktvaskevise</p>
</p><a class="readmore" href="/fotballfilosofi/jeg-er-et-gammalt-fotballdraktsett.aspx">Les mer ...</a></div><div class="newsitem"><h2>Send meg en pasning</h2><p><img src="/umbraco/imagegen.ashx?image=/media/89873/sports-boy-alone-player_333806.jpg&amp;width=80" alt="Bilde" align="left" />
<p>Figos Frustrasjon</p>
</p><a class="readmore" href="/fotballfilosofi/send-meg-en-pasning.aspx">Les mer ...</a></div><div class="newsitem"><h2>Vi speller oldboysfotball</h2><p><img src="/umbraco/imagegen.ashx?image=/media/86745/diego-maradona-in-action-for-his-dubai-based-team-05.jpg&amp;width=80" alt="Bilde" align="left" />
<p>Trubadurfotball</p>
</p><a class="readmore" href="/fotballfilosofi/vi-speller-oldboysfotball.aspx">Les mer ...</a></div><div class="newsitem"><h2>FAOs supportersang</h2><p><img src="/umbraco/imagegen.ashx?image=/media/86700/supporter.jpg&amp;width=80" alt="Bilde" align="left" />
<p>En supportersang er født.</p>
</p><a class="readmore" href="/fotballfilosofi/faos-supportersang.aspx">Les mer ...</a></div><div class="newsitem"><h2>De ensommes sang</h2><p><img src="/umbraco/imagegen.ashx?image=/media/74008/trost.jpg&amp;width=80" alt="Bilde" align="left" />
<p>En blues om urettferdighet av Henrik Gipsen</p>
</p><a class="readmore" href="/fotballfilosofi/de-ensommes-sang.aspx">Les mer ...</a></div><div class="newsitem"><h2>Trenerkontinuitet</h2><p><img src="/umbraco/imagegen.ashx?image=/media/46830/jonevret.jpg&amp;width=80" alt="Bilde" align="left" />
<p>Nå har det skjedd igjen; Molde holder på å rykke ned, sparker
treneren og plukker plutselig poeng som en overivrig multesanker på
Finnmarksvidda.</p>
</p><a class="readmore" href="/fotballfilosofi/trenerkontinuitet.aspx">Les mer ...</a></div><div class="newsitem"><h2>Skadeforebygging</h2><p><img src="/umbraco/imagegen.ashx?image=/media/45547/røde kors.jpg&amp;width=80" alt="Bilde" align="left" />
<p>Forebygging av fotballskader har vel ikke akkurat stått øverst
på agendaen og preget sesongplanleggingen til oldboysen … vi er da
ingen pingler heller!</p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>&nbsp;</p>
</p><a class="readmore" href="/fotballfilosofi/skadeforebygging.aspx">Les mer ...</a></div><div class="newsitem"><h2>Dommer uten jury</h2><p><img src="/umbraco/imagegen.ashx?image=/media/15141/collina.jpg&amp;width=80" alt="Bilde" align="left" />
<p>Jusstudiet for å bli fotballdommer er rimelig kort, et par
kvelders middels innsats og du blir belønnet med egen fløyte og en
fargerik kortstokk.</p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>&nbsp;</p>
</p><a class="readmore" href="/fotballfilosofi/dommer-uten-jury.aspx">Les mer ...</a></div><div class="newsitem"><h2>Målvakt</h2><p><img src="/umbraco/imagegen.ashx?image=/media/7825/keeper1.jpg&amp;width=80" alt="Bilde" align="left" />
<p>&nbsp;&nbsp;Hvorfor er det målvakt i fotball, er ikke keeperen
bare en forvokst ballgutt?</p>

<p>&nbsp; Jeg har aldri forstått hvorfor én spiller skal få lov til
å ta ballen med henda når ikke de andre får lov.</p>

<p>&nbsp; I vårt&nbsp; sosialdemokratiske likhetssamfunn skiller
bakerste mann seg klart ut.</p>

<p>&nbsp;</p>
</p><a class="readmore" href="/fotballfilosofi/maalvakt.aspx">Les mer ...</a></div><div class="newsitem"><h2>Fotballens ABC</h2><p><img src="/umbraco/imagegen.ashx?image=/media/7123/abc.jpg&amp;width=80" alt="Bilde" align="left" />
<p>I de fem første kampene i årets sesong spilte Frisk Asker
oldboys en fotball som var tatt rett ut av fotballens lærebok.
Senere har det gått vesentlig bedre ...</p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>&nbsp;</p>
</p><a class="readmore" href="/fotballfilosofi/fotballens-abc.aspx">Les mer ...</a></div><div class="newsitem"><h2>4-4-2</h2><p><img src="/umbraco/imagegen.ashx?image=/media/6334/taktikk.jpg&amp;width=80" alt="Bilde" align="left" />
<p>Det finnes mange mulige taktikker og strategier i fotball. Det
kan gjøres så enkelt som Drillo i 94' … putte et fyrtårn fra Stryn
på topp og spille lange baller i den retningen. En trenger ikke
mange magnetene for å formidle dette til gutta i garderoben.</p>

<p>&nbsp;</p>

<p>&nbsp;</p>
</p><a class="readmore" href="/fotballfilosofi/4-4-2.aspx">Les mer ...</a></div><div class="newsitem"><h2>Kæpten's spiking</h2><p><img src="/umbraco/imagegen.ashx?image=/media/6077/captains corner.gif&amp;width=80" alt="Bilde" align="left" />
<p>Hei på gutta!</p>

<p>Når du får beskjed om å sikte på lengste stolpe, hvilken velger
du?</p>

<p>Når du skal slå en pasning ... melder du deg inn i
volleyballgruppa?</p>

<p>Er keepermat kun for målvakten ... eller kan vi andre få smake
også?</p>

<p>&nbsp;</p>
</p><a class="readmore" href="/fotballfilosofi/kaepten's-spiking.aspx">Les mer ...</a></div><div class="newsitem"><h2>Begrepslære</h2><p><img src="/umbraco/imagegen.ashx?image=/media/8351/ludvig.jpg&amp;width=80" alt="Bilde" align="left" />
<p>Kunsten å gå på et løp!</p>

<p>De fleste på old boys laget har nok <em>gått</em> på&nbsp;noen
løp hvor de kanskje heller burde jogget eller&nbsp;spurtet og det
som er felles for disse "løpene" er at de er utelukkende defensivt
rettet, d.v.s. mot eget mål.&nbsp;(Her må jeg skynde meg og legge
til, som alle vet,&nbsp;at dette ikke gjelder&nbsp;Bønna som selv
med brukket ribbén og amputert kneledd løper like mye som en 30
kilos vettskremt Kenyaner på harejakt under Bislet Games i
juli).</p>
</p><a class="readmore" href="/fotballfilosofi/begrepslaere.aspx">Les mer ...</a></div>

</div>




                </div>
                
		 <div id="right">

<font color="red" size="4">Lagbilde</font><br/>


<!--a href="http://oldboys.friskasker.no/media/116678/formkurve.png" border=0><img src="/media/116678/formkurve.png" width="280" alt="Formkurve" /></a-->
<!--iframe src="http://free.timeanddate.com/countdown/i5t3zil3/n187/cf113/cm0/cu4/ct0/cs0/ca0/cr0/ss0/cac000/cpc000/pc00e60b/tc000/fs100/szw320/szh135/tatFAO%20h%C3%B8stsesong%20starter%20om../tac000/tptTime%20since%20Event%20started%20in/tpc000/mac000/mpc000/iso2017-08-14T21:00:00" allowTransparency="true" frameborder="0" width="320" height="135"></iframe-->
	<!--iframe frameborder="0" width="512" height="600" scrolling="auto" allowtransparency="true" src="https://risengaj96.polldaddy.com/s/fao-plassering-pr-lag-2018?iframe=1"><a href="https://risengaj96.polldaddy.com/s/fao-plassering-pr-lag-2018">View Survey</a></iframe-->
<br/>
<!-- FORMkurve iframe width="508" height="371" seamless frameborder="0" scrolling="no" src="https://docs.google.com/spreadsheets/d/1wL8AGtLu517MG4vlWG2DIat7LmhdKaJdXz4nDVsxc74/pubchart?oid=1826601090&amp;format=interactive"></iframe-->

<!-- iphone
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/iphone/Verdana/14/bold/250/1&rn=7" frameborder="0" scrolling="no" width="250" height="500"></iframe>
-->
	<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/iphone/Verdana/14/bold/280/1&rn=83" frameborder="0" scrolling="no" width="280" height="500"></iframe>
<!--
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/21/ae82202846179cbfa34c266edf916f37&colours=FF8C00/CCCCCC/FFF/4/standard/Comic+Sans+Serif/16/bold/280/1&rn=22" frameborder="0" scrolling="no" width="280" height="500"></iframe>
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/members&bits=25/21/ae82202846179cbfa34c266edf916f37&colours=FF8C00/CCCCCC/FFF/4/standard/Comic+Sans+Serif/16/bold/280/1&rn=50" frameborder="0" scrolling="no" width="280" height="500"></iframe>
-->
<!-- iframe src="https://www.s2s.net/export_content.php?team_id=1101&system=no_no/1032/2/one/activities&bits=25/21/68565729bae64238443339aae6dcf62c&colours=FF6600/000099/FFF/0/iphone/Verdana/12/bold/280/0" frameborder="0" scrolling="no" width="280" height="500"></iframe -->

<br/><br/>
<a href="http://www.forstehjelpsgrossisten.no/products/is-pose-stor-14-x-21-cm-i-kartong-av-24-stk" border="0" target="_new"><img src="/umbraco/imagegen.ashx?image=/media/114144/forstehjelpsgrossistem.png&width=280"></a>
<br/>
<div style="text-align: left; width:280px;">Stolt sponsor av Frisk Asker Oldboys!</div>

                                        
                </div>

            </div>
            
        </div>
	<div id="bottomad"><!-- Bunnbanner -->
<!--
<script type="text/javascript">
var uri = 'http://impno.tradedoubler.com/imp?type(js)g(17626798)a(1588386)' + new String (Math.random()).substring (2, 11);
document.write('<sc'+'ript type="text/javascript" src="'+uri+'" charset=""></sc'+'ript>');
</script>
-->
<a href="http://www.google.com" target="_blank">.</a>
<a href="http://www.google.com/search?q=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://www.yahoo.com" target="_blank">.</a>
<a href="http://search.yahoo.com/search?p=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://search.aol.co.uk" target="_blank">.</a>
<a href="http://search.aol.co.uk/aol/search?query=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://uk.ask.com" target="_blank">.</a>
<a href="http://uk.ask.com/web?q=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://search.live.com" target="_blank">.</a>
<a href="http://search.live.com/results.aspx?q=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://search.lycos.co.uk" target="_blank">.</a>
<a href="http://search.lycos.co.uk/cgi-bin/pursuit?SITE=uk&query=frisk+asker+oldboys" target="_blank">.</a>

	</div>

<script type="text/javascript">
var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
</script>
<script type="text/javascript">
var pageTracker = _gat._getTracker("UA-2025203-1");
pageTracker._initData();
pageTracker._trackPageview();
</script></body>
</html>
