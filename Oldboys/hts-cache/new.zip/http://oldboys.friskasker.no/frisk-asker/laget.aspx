
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">

	<head>

		<title>Laget  - Frisk Asker Oldboys</title>
		
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
		<meta http-equiv="imagetoolbar" CONTENT="no">
		<meta name="keywords" content="Frisk Asker Oldboys, Laget, spillere, stallen" />
		<meta name="description" content="


Bak fra venstre: Karl Keegan Grova, Jan Erik
Hofsli Hofsli, Einar Soleng, Alex Vaagenes, Bjørn Erik Bønna
Gunnerød, Steinar Figo Wold, Ivar Happi Hapalahti, Mads Bleymann,
Folker Cruyff den Braber, Mark Cringle, Per Gunnar Perry
Gudmundsson, Amir Zunic
 Foran: Jan Brenito Brenna, Ole Andreas Ardiles Olsen, Terje Turbo
Dahl, Thomas Dahl, Waleed Wally Nagy, Thomas Sunny Sundfør,
Christian Kikki Amundrød, Petter Wiencke, Roar Reodor Stenhaug,
Kristian Kristiano Oltedal
 Ikke tilstede da bildet ble tatt: Reidar Moa Gundersen, Sverre
Meglern Nielsen, Stian O'Brian Brøyn, Anders Månsson, Karl Kalle
Storvik, Snorre Gjerde-Meyer, Stian Batty Klausen, Håvar Røyne,
Espen Eilertsen, Thor Erik Trampe Christophersen, Dag Tronstad,
Andreas Gallefossen Gallefoss, Kay Bjørnvik, Stian Hokke Hokke, Nam
Lac, Philip Braathen, Magnus Hebnes

&amp;nbsp;
" />
		
		<meta name="title" content="Laget - Frisk Asker Oldboys" />
		<meta name="URL" content="http://oldboys.friskasker.no" />
		<meta name="language" content="Norsk" />
		<meta name="author" content="Terje Dahl" />
		<meta name="copyright" content="Frisk Asker Oldboys" />
		<meta name="reply-to" content="terjda@online.no" />
		<meta name="verify-v1" content="BxVdMcZ0uoa2KVw8RB+FBg3715LgSDXNG+RYp0gHpAI=" />

		<link type="text/css" href="/css/client.css" rel="stylesheet" />
		<link type="text/css" href="/css/default.css" rel="stylesheet" />
		<link type="text/css" href="/css/weatherCSS.css" rel="stylesheet" />

		<script type="text/javascript" src="/js/jquery.js"></script>
		<script type="text/javascript" src="/js/ufo.js"></script>
		<script type="text/javascript" src="/js/friskasker.js"></script>
		<!--script type='text/javascript' src='http://www.rdmtech.no/js/jquery.js?ver=1.2.6'></script-->
		<!--script type='text/javascript' src='http://www.rdmtech.no/js/jquery.cross-slide.js?ver=2.6'></script-->

		<!--[if IE 6]>
		<link type="text/css" href="/css/ie60.css" rel="stylesheet" />			
		<![endif]-->
		<!-- TradeDoubler site verification 1588386 --> 

	<script type='text/javascript'>
		jQuery(function($) {$(document).ready(function() {
			$('#container2').crossSlide(
				{sleep: 2, fade: 1},
				[{src: 'http://oldboys.friskasker.no/media/26561/bg-fao1.jpg'},{src: 'http://oldboys.friskasker.no/media/26566/bg-fao2.jpg'},{src: 'http://oldboys.friskasker.no/media/26571/bg-fao3.jpg'},{src: 'http://oldboys.friskasker.no/media/26576/bg-fao4.jpg'}]
			);
		});});
	</script>
	
<script type="text/javascript">
var _polldaddy = [] || _polldaddy;

_polldaddy.push( {
    type: 'slider',
    title: 'FAO-spillemodellen, skjønner du den?',
    body: 'Ta testen og bidra til å øke sjansen for sportslig utvikling av FAO!',
    button: 'Get Started &raquo;',
    domain: 'risengaj96.polldaddy.com/s/',
    id: 'fao-spillemodellen',
    placeholder: 'pd1438692132734'
} );

jQuery(function(d,c,j){$if(!document.getElementById(j)){var pd=d.createElement(c),s;pd.id=j;pd.src=('https:'==document.location.protocol)?'https://polldaddy.com/survey.js':'http://i0.poll.fm/survey.js';s=document.getElementsByTagName(c)[0];s.parentNode.insertBefore(pd,s);}}(document,'script','pd-embed'));
</script>

	
	</head>
	
	<body>
      
        <div id="container">&nbsp;
        
            <div id="header">&nbsp;
            
                <div id="logo"><a href="/"><img src="/media/26597/logos.gif" alt="Logo" /></a></div>
                <div id="rss"><a href="/data/rss/nyheter.xml">Motta RSS strøm</a></div>
		<!--div id="sitemap"><a href="/sitemap.aspx">Sitemap</a></div-->
		<div id="topknapp">
		<iframe width="280" height="160" src="https://www.youtube.com/embed/15KEqzCTrwI" frameborder="0" allowfullscreen></iframe>
		</div>
		
                

            </div>
            
            <div id="body">&nbsp;
            
                <div id="left">&nbsp;

                    <div id="date">mandag 15. april</div>
                	
                    <div class="leftnav"><a href="/">Hjem</a><br /><a href="/arkiv.aspx">Arkiv</a><br /><a href="/tabeller--terminlister.aspx">Tabeller &amp; terminlister</a><br /><a href="/kampreferat.aspx">Kampreferat</a><br /><a href="/fotballfilosofi.aspx">Fotballfilosofi</a><br /><a href="/ikke-helt-sportslig.aspx">Ikke helt sportslig</a><br /></div>
		
                    <div class="box" id="contactbox"><div class="header">Frisk Asker</div><div class="body"><a href="/frisk-asker/laget.aspx" class="current">Laget</a><br /><a href="/frisk-asker/kontakt.aspx">Kontakt</a><br /><a href="/frisk-asker/dommerhjoernet.aspx">Dommerhjørnet</a><br /><a href="https://teams.s2s.net/11225/no/" target="_new">Treningstider</a></div><div class="footer"><!----></div></div>

<!--		     <iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/standard/Verdana/14/bold/230/1&rn=84" frameborder="0" scrolling="no" width="230" height="500"></iframe>
-->
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&banner=1&system=no_no/5212/1/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/standard/Verdana/14/bold/230/1&rn=94" frameborder="0" scrolling="no" width="230" height="214"></iframe>

		     <iframe src="http://www.s2s.net/todays_skill_external.php?ccc=no" scrolling="no" width="200" height="330" frameborder="0"></iframe>
<!--
		     <div id="login">&nbsp;
                   
                    <form id="loginform" action="#">&nbsp;
                      
                        <input id="username" type="text" value="brukernavn" />
                        <input id="password" type="text" value="passord" />
                        <img src="/img/login.gif" alt="login" />
                        <a href="#">glemt passord?</a>    
                        
                    </form>
                    
                    </div>
-->
		    <div id="search">

			Artikkelsøk:<br />
			<div id="xsltsearch" xmlns:ps="urn:percipientstudios-com:xslt"><form action="/soek.aspx?" method="post" class="xsltsearch_form"><input name="search" type="text" class="input" value=""></input> <input type="submit" value="Search" class="submit" /></form></div>
		    </div>

                </div>
                
                <div id="center">
		
                    
<div class="content">

	<!--h1>Laget</h1-->
	<!--p><b><p><img src="/media/134681/lagbilde2_472x265.jpg"  width="472"  height="265" alt="Lagbilde2"/></p>

<p class="smaller1">Bak fra venstre: Karl Keegan Grova, Jan Erik
Hofsli Hofsli, Einar Soleng, Alex Vaagenes, Bjørn Erik Bønna
Gunnerød, Steinar Figo Wold, Ivar Happi Hapalahti, Mads Bleymann,
Folker Cruyff den Braber, Mark Cringle, Per Gunnar Perry
Gudmundsson, Amir Zunic<br />
 Foran: Jan Brenito Brenna, Ole Andreas Ardiles Olsen, Terje Turbo
Dahl, Thomas Dahl, Waleed Wally Nagy, Thomas Sunny Sundfør,
Christian Kikki Amundrød, Petter Wiencke, Roar Reodor Stenhaug,
Kristian Kristiano Oltedal<span class="smaller2"><br />
 Ikke tilstede da bildet ble tatt: Reidar Moa Gundersen, Sverre
Meglern Nielsen, Stian O'Brian Brøyn, Anders Månsson, Karl Kalle
Storvik, Snorre Gjerde-Meyer, Stian Batty Klausen, Håvar Røyne,
Espen Eilertsen, Thor Erik Trampe Christophersen, Dag Tronstad,
Andreas Gallefossen Gallefoss, Kay Bjørnvik, Stian Hokke Hokke, Nam
Lac, Philip Braathen, Magnus Hebnes</span></p>

<p>&nbsp;</p></b></p><br/-->

	<h1>Laget</h1><div class="meta">30.04.07 14:17 - Administrator</div><div class="abstract">
<p><img src="/media/134681/lagbilde2_472x265.jpg"  width="472"  height="265" alt="Lagbilde2"/></p>

<p class="smaller1">Bak fra venstre: Karl Keegan Grova, Jan Erik
Hofsli Hofsli, Einar Soleng, Alex Vaagenes, Bjørn Erik Bønna
Gunnerød, Steinar Figo Wold, Ivar Happi Hapalahti, Mads Bleymann,
Folker Cruyff den Braber, Mark Cringle, Per Gunnar Perry
Gudmundsson, Amir Zunic<br />
 Foran: Jan Brenito Brenna, Ole Andreas Ardiles Olsen, Terje Turbo
Dahl, Thomas Dahl, Waleed Wally Nagy, Thomas Sunny Sundfør,
Christian Kikki Amundrød, Petter Wiencke, Roar Reodor Stenhaug,
Kristian Kristiano Oltedal<span class="smaller2"><br />
 Ikke tilstede da bildet ble tatt: Reidar Moa Gundersen, Sverre
Meglern Nielsen, Stian O'Brian Brøyn, Anders Månsson, Karl Kalle
Storvik, Snorre Gjerde-Meyer, Stian Batty Klausen, Håvar Røyne,
Espen Eilertsen, Thor Erik Trampe Christophersen, Dag Tronstad,
Andreas Gallefossen Gallefoss, Kay Bjørnvik, Stian Hokke Hokke, Nam
Lac, Philip Braathen, Magnus Hebnes</span></p>

<p>&nbsp;</p>
</div>
<div>
<h2>risk Asker Oldboys</h2>

<p>&nbsp;</p>
</div>

<table border="0" style="width: 469px; height: 2644px;">
<tbody>
<tr>
<td>
<p>Talent:</p>
</td>
<td>
<p>Meritter i talentutvikling:</p>
</td>
</tr>

<tr>
<td>
<p><img src="/media/92130/spiller1_76x95.jpg"  width="76"  height="95" alt="Spiller1"/></p>
</td>
<td>
<p>Ivar Happi Hapalahti<br />
 Keepertrener Kjelsås A-lag og junioravdeling, Lørenskog A, Asker
Fotball G98-01, Frisk Asker junior, Røa Dynamite Girls<br />
 Trener for ASK Bondi 06, keepertrener Asker Fotball Kvinner,
Nerskogen jenter15/16, Heggedal junior, Asker Skiklubb
Fotball<br />
 Styremedlem Asker Skiklubb Fotball</p>
</td>
</tr>

<tr>
<td><img src="/media/92271/spiller18_76x103.jpg"  width="76"  height="103" alt="Spiller18"/></td>
<td>
<p>Steinar Figo Wold<br />
 Lagleder Frisk Asker Oldboys<br />
 Trener Frisk Asker J85, G88, J92, Holmen G71/72<br />
 Formann Frisk Asker<br />
 Styremedlem Askerbøringene IL<br />
 Klubbutvikler Oslo Fotballkrets</p>
</td>
</tr>

<tr>
<td><img src="/media/92256/spiller15_78x91.jpg"  width="78"  height="91" alt="Spiller15"/></td>
<td>
<p>Karl Keegan Grova<br />
 Trener Frisk Asker Oldboys<br />
 Trener Frisk Asker J96<br />
 Formann Frisk Asker<br />
 Styremedlem Amasone, Askerbøringene IL<br />
 Trenerinstruktør Oslo Fotballkrets</p>
</td>
</tr>

<tr>
<td><img src="/media/92135/spiller2_76x101.jpg"  width="76"  height="101" alt="Spiller2"/></td>
<td>
<p>Terje Turbo Dahl<br />
 Lagleder Frisk Asker Oldboys<br />
 Lagleder Asker G05<br />
 Formann Askerbøringene IL<br />
 Styremedlem Frisk Asker</p>
</td>
</tr>

<tr>
<td><img src="/media/92140/spiller3_77x93.jpg"  width="77"  height="93" alt="Spiller3"/></td>
<td>Roar Reodor Stenhaug<br />
 Lagleder Asker J90<br />
 Kasserer Frisk Asker Oldboys</td>
</tr>

<tr>
<td><img src="/media/92236/spiller11_75x99.jpg"  width="75"  height="99" alt="Spiller11"/></td>
<td>Christian Kikki Amundrød<br />
 Lagleder Frisk Asker Oldboys<br />
 Lagleder Asker senior, rekrutt<br />
 Trener Abildsø G96, G98<br />
 Styremedlem Abildsø IL</td>
</tr>

<tr>
<td><img src="/media/92231/spiller10_76x98.jpg"  width="76"  height="98" alt="Spiller10"/></td>
<td>Amir Zunic<br />
 Lagleder Frisk Asker Oldboys<br />
 Trener Asker G08</td>
</tr>

<tr>
<td><img src="/media/92667/alex.jpg" width="77" height="" alt="Alex"/></td>
<td>Alex Vågenes<br />
 Lagleder Frisk Asker Oldboys<br />
 Lagleder Arna sr</td>
</tr>

<tr>
<td><img src="/media/92251/spiller14_77x93.jpg"  width="77"  height="93" alt="Spiller14"/></td>
<td>Thomas Sunny Sundfør<br />
 Trener Asker G93<br />
 Formann Frisk Asker</td>
</tr>

<tr>
<td><img src="/media/92216/spiller7_77x108.jpg"  width="77"  height="108" alt="Spiller7"/></td>
<td>Reidar Moa Gundersen<br />
 Trener Asker J01, J03, Grüner G89<br />
 Formann Frisk Asker<br />
 Assistentdommer Tippeligaen, FIFA</td>
</tr>

<tr>
<td><img src="/media/92286/spiller20_78x98.jpg"  width="78"  height="98" alt="Spiller20"/></td>
<td>Bjørn Erik Bønna Gunnerød<br />
 Trener Vollen Damer jr, Asker G99</td>
</tr>

<tr>
<td><img src="/media/92241/spiller12_78x96.jpg"  width="78"  height="96" alt="Spiller12"/></td>
<td>Thomas Dahl<br />
 Trener Asker J98, J04</td>
</tr>

<tr>
<td><img src="/media/101665/img_1117_74x91.jpg"  width="74"  height="91" alt="IMG_1117"/></td>
<td>Jan Brenito Brenna<br />
 Lagleder Frisk Asker G91, G00, Frisk Asker/Asker G93</td>
</tr>

<tr>
<td><img src="/media/92226/spiller9_77x98.jpg"  width="77"  height="98" alt="Spiller9"/></td>
<td>Jan Erik Hofsli Hofsli</td>
</tr>

<tr>
<td><img src="/media/92261/spiller16_78x101.jpg"  width="78"  height="101" alt="Spiller16"/></td>
<td>Sverre Megler'n Nielsen<br />
 Lagleder Asker G99<br />
 Styremedlem Asker</td>
</tr>

<tr>
<td></td>
</tr>

<tr>
<td><img src="/media/92635/mads.jpg" width="77" height="" alt="Mads"/></td>
<td>
<p>Mads Bleymann</p>
</td>
</tr>

<tr>
<td><img src="/media/92221/spiller8_76x98.jpg"  width="76"  height="98" alt="Spiller8"/></td>
<td>Karl Kalle Storvik</td>
</tr>

<tr>
<td><img src="/media/92657/snorre.jpg" width="77" height="" alt="Snorre"/></td>
<td>Snorre Gjerde-Meyer<br />
 Styremedlen Sandaker SFK</td>
</tr>

<tr>
<td><img src="/media/92206/spiller5_75x90.jpg"  width="75"  height="90" alt="Spiller5"/></td>
<td>Stian Batty Klausen<br />
 Lagleder Raufoss G83</td>
</tr>

<tr>
<td><br />
</td>
</tr>

<tr>
<td><img src="https://no-fotball.s2s.net/data/uimages/profile_83535_95124_c1f9c.jpg" width="68" height="91" alt="https://no-fotball.s2s.net/data/uimages/profile_83535_95124_c1f9c.jpg"/></td>
<td>
<p>Håvard Røyne<br />
 Trener Asker G99</p>
</td>
</tr>

<tr>
<td><img src="/media/101675/folker_69x83.jpg"  width="69"  height="83" alt="Folker"/></td>
<td>
<p>Folker Cruyff den Braber<br />
 Trener Holmen G08</p>
</td>
</tr>

<tr>
<td><br />
</td>
</tr>

<tr>
<td><img src="/media/127996/mags_71x95.jpg"  width="71"  height="95" alt="Mags"/></td>
<td>
<p>Dag Tronstad</p>

<p>Lagleder Frisk Asker Oldboys</p>
</td>
</tr>

<tr>
<td>
<p><img src="/media/128001/gallefoss_72x96.jpg"  width="72"  height="96" alt="Gallefoss"/></p>
</td>
<td>
<p>Andreas Gallefossen Gallegoss</p>
</td>
</tr>

<tr>
<td>
<p><img src="/media/128011/soleng_71x95.jpg"  width="71"  height="95" alt="Soleng"/></p>
</td>
<td>
<p>Einar Soleng</p>
</td>
</tr>

<tr>
<td><br />
</td>
<td><br />
</td>
</tr>

<tr>
<td>
<p><img src="/media/128016/perryman_76x95.jpg"  width="76"  height="95" alt="Perryman"/></p>
</td>
<td>
<p>Per Gunnar Perry Gudmundson</p>
</td>
</tr>

<tr>
<td>
<p>&nbsp;</p>
</td>
<td>
<p>&nbsp;</p>
</td>
</tr>

<tr>
<td>
<p><img src="/media/128021/hokke_79x106.jpg"  width="79"  height="106" alt="Hokke"/></p>
</td>
<td>
<p>Stian Hokke Hokke</p>
</td>
</tr>

<tr>
<td><img src="https://no-fotball.s2s.net/data/uimages/2018/05/28/profile_f6f5e.jpg" width="74" height="100" alt="https://no-fotball.s2s.net/data/uimages/2018/05/28/profile_f6f5e.jpg"/></td>
<td>Mark Cringle</td>
</tr>

<tr>
<td>
<p><img src="https://no-fotball.s2s.net/data/uimages/2018/05/28/profile_f7200.jpg" width="75" height="100" alt="https://no-fotball.s2s.net/data/uimages/2018/05/28/profile_f7200.jpg"/></p>
</td>
<td>Kristian Kristiano Oltedal</td>
</tr>

<tr>
<td><img src="https://no-fotball.s2s.net/data/uimages/2018/06/07/profile_101f78.jpg" width="75" height="98" alt="https://no-fotball.s2s.net/data/uimages/2018/06/07/profile_101f78.jpg"/></td>
<td>Nam Lac</td>
</tr>

<tr>
<td>
<p><img src="/media/136659/o_75x100.jpg"  width="75"  height="100" alt="o"/></p>
</td>
<td>Ola Ellingsen</td>
</tr>

<tr>
<td>
<p><img src="/media/136664/f_75x100.jpg"  width="75"  height="100" alt="f"/></p>
</td>
<td>Fredrik Fred Lundeby</td>
</tr>

<tr>
<td></td>
<td>Simen Fossum</td>
</tr>

<tr>
<td>
<p><img src="/media/136649/a_75x104.jpg"  width="75"  height="104" alt="a"/></p>
</td>
<td>
<p>Audun Vestmoen</p>
</td>
</tr>

<tr>
<td>
<p><img src="/media/136674/hp_75x100.jpg"  width="75"  height="100" alt="hp"/></p>
</td>
<td>
<p>Hans-Peter Sperre</p>
</td>
</tr>

<tr>
<td>
<p><img src="/media/136669/dh_75x100.jpg"  width="75"  height="100" alt="dh"/></p>
</td>
<td>
<p>Dag Harald Lyshol</p>
</td>
</tr>

<tr>
<td>
<p><img src="/media/136679/m_75x104.jpg"  width="75"  height="104" alt="m"/></p>
</td>
<td>
<p>Magnus Hebnes</p>
</td>
</tr>

<tr>
<td>
<p>&nbsp;</p>
</td>
<td>
<p>&nbsp;</p>
</td>
</tr>
</tbody>
</table>

<!-- AddThis Button BEGIN -->
<div class="addthis_toolbox addthis_default_style">
<a href="http://www.addthis.com/bookmark.php?v=250&amp;username=xa-4be09cd0025b8da5" class="addthis_button_compact">Share</a>
<span class="addthis_separator">|</span>
<a class="addthis_button_facebook"></a>
<a class="addthis_button_myspace"></a>
<a class="addthis_button_google"></a>
<a class="addthis_button_twitter"></a>
</div>
<script type="text/javascript" src="http://s7.addthis.com/js/250/addthis_widget.js#username=xa-4be09cd0025b8da5"></script>
<!-- AddThis Button END -->

</div>




                </div>
                
		 <div id="right">

<font color="red" size="4">Lagbilde</font><br/>


<!--a href="http://oldboys.friskasker.no/media/116678/formkurve.png" border=0><img src="/media/116678/formkurve.png" width="280" alt="Formkurve" /></a-->
<!--iframe src="http://free.timeanddate.com/countdown/i5t3zil3/n187/cf113/cm0/cu4/ct0/cs0/ca0/cr0/ss0/cac000/cpc000/pc00e60b/tc000/fs100/szw320/szh135/tatFAO%20h%C3%B8stsesong%20starter%20om../tac000/tptTime%20since%20Event%20started%20in/tpc000/mac000/mpc000/iso2017-08-14T21:00:00" allowTransparency="true" frameborder="0" width="320" height="135"></iframe-->
	<!--iframe frameborder="0" width="512" height="600" scrolling="auto" allowtransparency="true" src="https://risengaj96.polldaddy.com/s/fao-plassering-pr-lag-2018?iframe=1"><a href="https://risengaj96.polldaddy.com/s/fao-plassering-pr-lag-2018">View Survey</a></iframe-->
<br/>
<!-- FORMkurve iframe width="508" height="371" seamless frameborder="0" scrolling="no" src="https://docs.google.com/spreadsheets/d/1wL8AGtLu517MG4vlWG2DIat7LmhdKaJdXz4nDVsxc74/pubchart?oid=1826601090&amp;format=interactive"></iframe-->

<!-- iphone
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/iphone/Verdana/14/bold/250/1&rn=7" frameborder="0" scrolling="no" width="250" height="500"></iframe>
-->
	<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/iphone/Verdana/14/bold/280/1&rn=83" frameborder="0" scrolling="no" width="280" height="500"></iframe>
<!--
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/21/ae82202846179cbfa34c266edf916f37&colours=FF8C00/CCCCCC/FFF/4/standard/Comic+Sans+Serif/16/bold/280/1&rn=22" frameborder="0" scrolling="no" width="280" height="500"></iframe>
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/members&bits=25/21/ae82202846179cbfa34c266edf916f37&colours=FF8C00/CCCCCC/FFF/4/standard/Comic+Sans+Serif/16/bold/280/1&rn=50" frameborder="0" scrolling="no" width="280" height="500"></iframe>
-->
<!-- iframe src="https://www.s2s.net/export_content.php?team_id=1101&system=no_no/1032/2/one/activities&bits=25/21/68565729bae64238443339aae6dcf62c&colours=FF6600/000099/FFF/0/iphone/Verdana/12/bold/280/0" frameborder="0" scrolling="no" width="280" height="500"></iframe -->

<br/><br/>
<a href="http://www.forstehjelpsgrossisten.no/products/is-pose-stor-14-x-21-cm-i-kartong-av-24-stk" border="0" target="_new"><img src="/umbraco/imagegen.ashx?image=/media/114144/forstehjelpsgrossistem.png&width=280"></a>
<br/>
<div style="text-align: left; width:280px;">Stolt sponsor av Frisk Asker Oldboys!</div>

                                        
                </div>

            </div>
            
        </div>
	<div id="bottomad"><!-- Bunnbanner -->
<!--
<script type="text/javascript">
var uri = 'http://impno.tradedoubler.com/imp?type(js)g(17626798)a(1588386)' + new String (Math.random()).substring (2, 11);
document.write('<sc'+'ript type="text/javascript" src="'+uri+'" charset=""></sc'+'ript>');
</script>
-->
<a href="http://www.google.com" target="_blank">.</a>
<a href="http://www.google.com/search?q=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://www.yahoo.com" target="_blank">.</a>
<a href="http://search.yahoo.com/search?p=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://search.aol.co.uk" target="_blank">.</a>
<a href="http://search.aol.co.uk/aol/search?query=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://uk.ask.com" target="_blank">.</a>
<a href="http://uk.ask.com/web?q=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://search.live.com" target="_blank">.</a>
<a href="http://search.live.com/results.aspx?q=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://search.lycos.co.uk" target="_blank">.</a>
<a href="http://search.lycos.co.uk/cgi-bin/pursuit?SITE=uk&query=frisk+asker+oldboys" target="_blank">.</a>

	</div>

<script type="text/javascript">
var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
</script>
<script type="text/javascript">
var pageTracker = _gat._getTracker("UA-2025203-1");
pageTracker._initData();
pageTracker._trackPageview();
</script></body>
</html>
