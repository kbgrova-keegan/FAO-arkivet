
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">

	<head>

		<title>Skadeforebygging  - Frisk Asker Oldboys</title>
		
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
		<meta http-equiv="imagetoolbar" CONTENT="no">
		<meta name="keywords" content="Fotballskade, idrettsskade, oldboys, forebyggende skadebehandling," />
		<meta name="description" content="
Forebygging av fotballskader har vel ikke akkurat stått øverst
på agendaen og preget sesongplanleggingen til oldboysen … vi er da
ingen pingler heller!

&amp;nbsp;

&amp;nbsp;

&amp;nbsp;
" />
		
		<meta name="title" content="Skadeforebygging - Frisk Asker Oldboys" />
		<meta name="URL" content="http://oldboys.friskasker.no" />
		<meta name="language" content="Norsk" />
		<meta name="author" content="Terje Dahl" />
		<meta name="copyright" content="Frisk Asker Oldboys" />
		<meta name="reply-to" content="terjda@online.no" />
		<meta name="verify-v1" content="BxVdMcZ0uoa2KVw8RB+FBg3715LgSDXNG+RYp0gHpAI=" />

		<link type="text/css" href="/css/client.css" rel="stylesheet" />
		<link type="text/css" href="/css/default.css" rel="stylesheet" />
		<link type="text/css" href="/css/weatherCSS.css" rel="stylesheet" />

		<script type="text/javascript" src="/js/jquery.js"></script>
		<script type="text/javascript" src="/js/ufo.js"></script>
		<script type="text/javascript" src="/js/friskasker.js"></script>
		<!--script type='text/javascript' src='http://www.rdmtech.no/js/jquery.js?ver=1.2.6'></script-->
		<!--script type='text/javascript' src='http://www.rdmtech.no/js/jquery.cross-slide.js?ver=2.6'></script-->

		<!--[if IE 6]>
		<link type="text/css" href="/css/ie60.css" rel="stylesheet" />			
		<![endif]-->
		<!-- TradeDoubler site verification 1588386 --> 

	<script type='text/javascript'>
		jQuery(function($) {$(document).ready(function() {
			$('#container2').crossSlide(
				{sleep: 2, fade: 1},
				[{src: 'http://oldboys.friskasker.no/media/26561/bg-fao1.jpg'},{src: 'http://oldboys.friskasker.no/media/26566/bg-fao2.jpg'},{src: 'http://oldboys.friskasker.no/media/26571/bg-fao3.jpg'},{src: 'http://oldboys.friskasker.no/media/26576/bg-fao4.jpg'}]
			);
		});});
	</script>
	
<script type="text/javascript">
var _polldaddy = [] || _polldaddy;

_polldaddy.push( {
    type: 'slider',
    title: 'FAO-spillemodellen, skjønner du den?',
    body: 'Ta testen og bidra til å øke sjansen for sportslig utvikling av FAO!',
    button: 'Get Started &raquo;',
    domain: 'risengaj96.polldaddy.com/s/',
    id: 'fao-spillemodellen',
    placeholder: 'pd1438692132734'
} );

jQuery(function(d,c,j){$if(!document.getElementById(j)){var pd=d.createElement(c),s;pd.id=j;pd.src=('https:'==document.location.protocol)?'https://polldaddy.com/survey.js':'http://i0.poll.fm/survey.js';s=document.getElementsByTagName(c)[0];s.parentNode.insertBefore(pd,s);}}(document,'script','pd-embed'));
</script>

	
	</head>
	
	<body>
      
        <div id="container">&nbsp;
        
            <div id="header">&nbsp;
            
                <div id="logo"><a href="/"><img src="/media/26597/logos.gif" alt="Logo" /></a></div>
                <div id="rss"><a href="/data/rss/nyheter.xml">Motta RSS strøm</a></div>
		<!--div id="sitemap"><a href="/sitemap.aspx">Sitemap</a></div-->
		<div id="topknapp">
		<iframe width="280" height="160" src="https://www.youtube.com/embed/15KEqzCTrwI" frameborder="0" allowfullscreen></iframe>
		</div>
		
                

            </div>
            
            <div id="body">&nbsp;
            
                <div id="left">&nbsp;

                    <div id="date">mandag 15. april</div>
                	
                    <div class="leftnav"><a href="/">Hjem</a><br /><a href="/arkiv.aspx">Arkiv</a><br /><a href="/tabeller--terminlister.aspx">Tabeller &amp; terminlister</a><br /><a href="/kampreferat.aspx">Kampreferat</a><br /><a href="/fotballfilosofi.aspx">Fotballfilosofi</a><br /><a href="/ikke-helt-sportslig.aspx">Ikke helt sportslig</a><br /></div>
		
                    <div class="box" id="contactbox"><div class="header">Frisk Asker</div><div class="body"><a href="/frisk-asker/laget.aspx">Laget</a><br /><a href="/frisk-asker/kontakt.aspx">Kontakt</a><br /><a href="/frisk-asker/dommerhjoernet.aspx">Dommerhjørnet</a><br /><a href="https://teams.s2s.net/11225/no/" target="_new">Treningstider</a></div><div class="footer"><!----></div></div>

<!--		     <iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/standard/Verdana/14/bold/230/1&rn=84" frameborder="0" scrolling="no" width="230" height="500"></iframe>
-->
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&banner=1&system=no_no/5212/1/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/standard/Verdana/14/bold/230/1&rn=94" frameborder="0" scrolling="no" width="230" height="214"></iframe>

		     <iframe src="http://www.s2s.net/todays_skill_external.php?ccc=no" scrolling="no" width="200" height="330" frameborder="0"></iframe>
<!--
		     <div id="login">&nbsp;
                   
                    <form id="loginform" action="#">&nbsp;
                      
                        <input id="username" type="text" value="brukernavn" />
                        <input id="password" type="text" value="passord" />
                        <img src="/img/login.gif" alt="login" />
                        <a href="#">glemt passord?</a>    
                        
                    </form>
                    
                    </div>
-->
		    <div id="search">

			Artikkelsøk:<br />
			<div id="xsltsearch" xmlns:ps="urn:percipientstudios-com:xslt"><form action="/soek.aspx?" method="post" class="xsltsearch_form"><input name="search" type="text" class="input" value=""></input> <input type="submit" value="Search" class="submit" /></form></div>
		    </div>

                </div>
                
                <div id="center">
		
                    
<div class="content">

	<h1>Skadeforebygging</h1><div class="meta">13.09.10 14:44 - Figo</div><div class="abstract"><img src="/umbraco/imagegen.ashx?image=/media/45547/røde kors.jpg&amp;width=500" alt="" align="left" />
<p>Forebygging av fotballskader har vel ikke akkurat stått øverst
på agendaen og preget sesongplanleggingen til oldboysen … vi er da
ingen pingler heller!</p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>&nbsp;</p>
</div>
<p>Nå er det mange som ljuger på seg en idrettsskade for å slippe
unna ting de ikke ønsker å gjøre, alternativt for å ha en
unnskyldning for dårlig spill klar allerede før matchen starter …
"ikke forvent stort av meg i dag, jeg har en lei strekk …", men det
er litt skremmende når vi tar et overblikk på årets
tilbakemeldinger i forkant av seriekamper og finner blant annet
følgende:</p>

<p>&nbsp;</p>

<p><strong>&nbsp;</strong></p>

<p><strong>Thomas D</strong>. - "Sliter med en strekk, men kommer
om vi er få!"</p>

<p><strong>Bønna</strong> - "Jeg er veldig usikker med kneet. Ser
an i morgen."</p>

<p><strong>Sverre</strong> - "Kraftig strekk"</p>

<p><strong>Keegan</strong> - "Tåa holder ikke, kan stå i mål"</p>

<p><strong>Klausen</strong> - "Falt hardt i trappa i dag, men håper
ømheten gir seg til onsdag så jeg stiller"</p>

<p><strong>Brenna</strong> - "Kommer ikke. Problemer med hofta"</p>

<p><strong>Mads</strong> - "Jeg er skadet. Kommer ikke. Slet i
stykker leddbånd i ankelen sist kamp. Foten ble dobbelt så stor, og
mørkeblå! Trodde ett øyeblikk jeg hadde fått koldbrann i foten"</p>

<p><strong>Thomas S</strong>. - "Kommer innom som tilskuer (med bag
og lyskestrekk)"</p>

<p><strong>Brøyn</strong> - "Avventer - har en vondt i vondten, og
håper på bedring"</p>

<p>&nbsp;Nå har vi ikke tenkt til å kåre noen Norgesmester i
lyskestrekk her og nå, men det ville jo være et skikkelig overtråkk
i salaten om vi ikke informerte litt om de vanligste skadene våre
tapre menn blir utsatt for … og samtidig svinge innom de litt mer
sjeldne variantene som opptrer innimellom….</p>

<p><img src="/media/45556/fotballskade_275x183.jpg"  width="275"  height="183" alt="Fotballskade"/><br />
<strong>Leddbåndskader:<br />
</strong>Strekk eller avrivning av leddbåndene på yttersiden eller
innersiden av ankel eller kne. Skjer ofte i sammenheng med
overtråkk, stempling, eller vridning av ankelen om du lander hardt
i feil posisjon.</p>

<p>Dette hender oftest innendørs, når ballkåte FA-gamlinger ikke
har beveget andre ting enn fjerkontroll-armen på en stund. Hjernen
gir beskjed om en bråvending, kroppen starter bevegelsen mens foten
sitter fast i gulvbelegget.</p>

<p><br />
<strong>Strekk i lår, legg og lyske:<br />
</strong>Muskelbrist som kommer av at muskelfibrene dras fra
hverandre ved overbelastning. Oppstår ofte ved rask spurt (lite
sannsynlig i FA oldboys), voldsom oppbremsing (les: kollisjon med
annen spiller), retningsforandring eller skudd. <strong>Skadene
forekommer oftere dersom man ikke varmer opp tilstrekkelig</strong>
(red. utheving). Slike skader er som regel kortvarige og trening
kan startes opp igjen etter noen få dager (tror ikke det nei).</p>

<p><img src="/media/45551/fotballskade2_272x172.jpg"  width="272"  height="172" alt="skade"/><br />
<strong>Brudd:<br />
</strong>Bruddskader kan ha mange årsaker, og kan oppstå i de
fleste ben i underkroppen. Noen bruddskader skjer som følge av
stempling, vridning eller andre støt. Noen brudd kan komme pga
overbelastning over lang tid, også kalt stressbrudd. Det er ikke
uvanlig med skadeavbrekk på over et halvt år når det gjelder
bruddskader.</p>

<p>De eneste bruddene vi har registrert på FA-OB er brudd på
spilleregler og brutte løfter om oppmøte og egentrening.</p>

<p><br />
<strong>Meniskskade:<br />
</strong>Det er to menisker i hvert kne - en på yttersiden og en på
innersiden. Disse fungerer som støtdempere i kneet. Ved en vridning
av kneet kan det oppstå rift av ulik alvorlighetsgrad i meniskene.
Skaden skjer ofte ved taklinger, finter eller dersom man får kneet
under seg. Som oftest må meniskskadene opereres innen få dager
etter skaden. Dette har vi også sluppet pent unna, ikke fordi det
mangler finte- eller taklingsvilje, mer fordi ting skjer i et rolig
tempo.</p>

<p><img src="/media/45606/fotballskade9_299x204.jpg"  width="299"  height="204" alt="fotballskade9"/><br />
<strong>Korsbåndskade:</strong><br />
Denne skaden er en avrivning av fremre eller bakre korsbånd i
kneet. Skjer ofte ved overstrekking eller rotasjon av kneet -
veldig ofte i situasjoner der det ikke er kroppskontakt med andre,
spesielt under finter, landinger eller taklinger der benet blir
stående i bakken. En slik skade gjør virkelig vondt! Uten operasjon
i etterkant kan kneet bli ustabilt, men nesten alle fotballspillere
klarer å komme tilbake til nivået de var på før skaden.</p>

<p>Her er vi godt representert … i hvert fall ser vi ofte oldboys
spillere som skader seg uten at det har vært kroppskontakt med i
bildet. Å skulle "komme tilbake til nivået de var på før skaden" er
vel egentlig ikke noe å hige etter…</p>

<p><br />
<strong>Latinerskade:</strong><br />
Denne kan oppstå hvor som helst på kroppen, men som oftest på
leggen, og er tydeligvis forbundet med usannsynlige smerter. Skjer
nesten utelukkende i situasjoner der det er fordelaktig for den
skadde's lag, slik som innenfor motstanderens 16-meter eller dersom
motstander er i ferd med å få i gang en kontring. Rammer også
nesten utelukkende spillere fra Sør-Europa, derav skadens navn.
Behandlingsformer består av ispose, is-spray og oppmuntrende ord
fra lagets lege eller massør. Ikke så utbredt blant våre menn da
ingen tar hensyn til en som ligger og sutrer likevel …</p>

<p><img src="/media/45586/fotballskade4_284x188.jpg"  width="284"  height="188" alt="fotballskade4"/><br />
<strong>TV-skaden:<br />
</strong>Denne er ganske utbredt blant engelske spillere. Chelseas
John Terry mistet i 2002 serieåpningen på grunn av en skade han
pådro seg da han så tennis på TV. Han måtte operere kneet etter å
ha vridd det da han snudde seg for å diskutere en episode med
kompisen under tennis-kampen. Andre eksempler på TV-skaden er Rio
Ferdinand (strakk en sene i kneet da han spilte PlayStation med
beina på bordet), David Seaman (strekk da han skulle bøye seg etter
fjernkontrollen) og Robbie Keane (skadet ankelen ved å tråkke på
fjernkontrollen).</p>

<p>Vi FA-spillere innrømmer aldri en slik skade, til det er det for
mange andre usannsynlige forklaringer man kan benytte.</p>

<p>&nbsp;</p>

<p><strong>Jubelskaden:</strong><br />
Paulo Diogo spilte i 2004 for den sveitsiske toppklubben Servette.
I vill jubel etter å ha scoret mot Schaffhausen løp han bak målet
og mot fansen for hyllest. På vei ned fra gjerdet som omringet
banen satt gifteringen hans fast i selve gjerdet, og ikke før han
var godt inne på banen igjen merket han at ytterste ledd på
fingeren var borte. Et annet eksempel på denne skadetypen var da
Steve Morrow scoret det avgjørende målet mot Sheffield Wednesday i
ligacupfinalen i 1993. Tony Adams løftet han i været for å feire,
fant ut at han var for tung, og mistet han i bakken. Fallet
resulterte i en brukket skulder. Frisk Asker feirer sine mål med
verdighet og unngår slike håpløse skader.</p>

<p><strong><img src="/media/45591/fotballskade7_447x214.jpg"  width="447"  height="214" alt="fotballskade7"/></strong></p>

<p><strong>Reserveskaden:<br />
</strong>Denne er nært beslektet med jubelskaden, men rammer de som
sliter benken. Hertha Berlins reservekeeper Gabor Kiraly pådro seg
i 2004 en delvis avrevet muskel da han feiret lagets andre mål mot
Eintrach Frankfurt. Han satt selvfølgelig på benken da uhellet
skjedde. Skaden satte han ut av spill i flere uker, men laget vant
3-1. Arsenals Perry Groves var innbytter i en kamp og jublet så mye
at han skallet hodet i taket på benken. Groves ble slått ut og
måtte få behandling av klubblegen. Våre benker er både myke og uten
tak, noe som sammen med det faktum at vi er lite impulsive gjør at
vi så langt har sluppet denne skadetypen. Et annet faktum er jo at
vi på bortekamper ikke har med overflødig mannskap som kan være
disponible for denne skaden.</p>

<p><br />
<strong>Kjøkkenskaden:<br />
</strong>Norges mest tørste spiller gjennom tidene, Claus
Lundekvam, pådro seg en skade da han sto på kjøkkenet en januardag
i 2000. Han fikk en skiveutglidning i ryggen da han skulle plukke
opp noe fra gulvet. Dave Beasant spilte i begynnelsen av 90-tallet
for Chelsea. Han mistet sesongåpningen da han mistet et glass
salatdressing på foten. Darren Bent, nå Tottenham, skar seg da han
skulle lage en sandwich. Barnsleys Darren Barnard skled stygt
hjemme på sitt eget kjøkken. Grunnen var at familiens puddel ikke
rakk å gå ut da den skulle tisse. Barnard misset hele fem måneder
av sesongen.</p>

<p>Jeg bare gjentar ovenfornevnte utsagn om at Frisk Askers djerve
utvalgte har bedre fantasi enn at vi innrømmer slike skader.</p>

<p><img src="/media/45596/fotballskade5_266x175.jpg"  width="266"  height="175" alt="fotballskade5"/><br />
<strong>Fylleskaden:</strong><br />
Engelsk fotball har en del av disse. Arsenal-stopper Tony Adams
trynte i trappa på en nattklubb under en av sine mer flytende dager
i 1993. Skaden krevde 29 sting. Gazza og ovenfornevnte Lundis har
også hatt sine episoder, men den første vi kjenner som kombinerte
alkohol og fotball på en imponerende måte var vel George Best som
stadig vekk ble hentet på nachtspiel og fraktet til trening.
Utallige spillere verden rundt (FA's inkludert) har vært rammet av
dette i større eller mindre grad, og det var vel kun en liten stund
at Drillo kunne disponere flere avholdsmenn i samme tropp (Fjøra,
Bratseth osv.) men der tok Myggen ansvar og ballanserte det skjeve
inntrykket. Bernt Hulsker var nylig en tur i fyllearresten og
stiller vel neppe i Starts førsterekke på en stund.</p>

<p>&nbsp;</p>

<p><strong>Pappaskade:</strong></p>

<p>At det er slitsomt å få unger vet jo de fleste oldboys, men at
det er direkte farlig har man vært lykkelig uvitende om i alle år …
David Batty, kjent som råtass i blant annet Leeds og Blackburn, var
på vei tilbake fra skade da han ble truffet av sin egen ettåring på
trehjulsykkel. Tottenhams Allan Nielsen led samme skjebne. Datteren
stakk en finger rett i øyet på sin kjære pappa.</p>

<p>&nbsp;<img src="/media/45581/fotballskade6_259x185.jpg"  width="259"  height="185" alt="fotballskade6"/></p>

<p><strong>Idiotskade:</strong></p>

<p>At man er god på fotballbanen er jo som kjent ikke ensbetydende
med stor hjernekapasitet:</p>

<p>Dariuss Vassell, fikk i 2003 en kraftig blødning under den ene
tåa si. Vassell ville bli kvitt blemma, fant frem en drill og
begynte å borre ….</p>

<p>Lars Hirschfeld mistet en landskamp for Canada da han som RBK
spiller brukte ostehøvelen på egen tommelfinger &nbsp;i stedet for
på osten. Milan Rapaic mistet Hajduk Splits sesongstart etter at
han på en flyplass stakk et&nbsp; boarding-card rett i sitt eget
øye.</p>

<p>&nbsp;</p>

<p><strong>Sjeldne skadetyper</strong></p>

<p>Det finnes et utall av skader som er vanskelige å sette i en bås
av forskjellige årsaker. Thomas Hafstad hadde f.eks et stygt møte
med en ergometersykkel under trening. Sammenstøtet resulterte i ti
sting i hodet og en kraftig trøkk i kneet. Den norske backen Svein
Grøndalen, måtte melde forfall til en landskamp på 70-tallet da han
på en joggetur kolliderte med en elg midt i skogen. Arsenal-spiss
Charlie George skulle klippe det altfor lange gresset i hagen. Det
gikk litt fort i svingene og «Champagne-Charlie» mistet den ene
stortåa under hagearbeidet. Ronaldo fikk en mikrofon i øyet da han
gjorde comeback for Corinthinas mens en Svensk fotballspiller fikk
et spyd i ryggen da han trente på en friidrettsarena.<br />
<img src="/media/45650/fotballfeber_500x203.jpg"  width="500"  height="203" alt="fotballfeber"/></p>

<p><strong>Summa sumarum</strong> så er det mange farer som lurer
der ute og det er ingen garanti for å gå skadefri gjennom sesongen
selv om du legger skoene på hylla, så vi konkluderer vel med at det
er like greit å brette opp ermene, snøre skoa og trå litt hardere
til i taklingene slik at det er de andre som får skadene og ikke
vi.</p>

<p>Skal vi likevel få komme med noen oppsummerende gode og
skadeforebyggende råd så må det være å varme opp lenge og vel,
unngå taklinger og fysisk nærkontakt, ingen raske spurter eller brå
vendinger/finter, sitt rolig på benken og for all del ikke vis
overdreven lykke ved scoring av mål. I tillegg kan vi råde
FA-oldboys til å ligge unna kjøkkenet på hjemmebane, holde små barn
på en armlengdes avstand, vend alltid boret på drillen bort fra
egen kropp og ha til en hver tid oversikt over fjernkontrollen</p>

<p><img src="/media/45576/fotballskade8_500x350.jpg"  width="500"  height="350" alt="fotballskade8"/></p>

<p>Hilsen Kæpt'n</p>

<p>&nbsp;</p>



<div class="addthis_toolbox addthis_default_style">
<a href="http://www.addthis.com/bookmark.php?v=250&amp;username=xa-4be09cd0025b8da5" class="addthis_button_compact">Share</a>
<span class="addthis_separator">|</span>
<a class="addthis_button_facebook"></a>
<a class="addthis_button_myspace"></a>
<a class="addthis_button_google"></a>
<a class="addthis_button_twitter"></a>
</div>
<script type="text/javascript" src="http://s7.addthis.com/js/250/addthis_widget.js#username=xa-4be09cd0025b8da5"></script>
<!-- AddThis Button END -->

<hr>
<h2>Kommentarer:</h2>
	<div class="newsitem"><i><b>14.09.10 12:50 - <a href="mailto:">Terje</a></b></i><p>mange gode og kreative tips for unnasluntring her. Om jeg kommer til å bruke noen av de selv er vel heller tvilsomt, da må det i såfall være den med å kollidere med en elg under en joggetur midt i skogen..</p></div><div class="newsitem"><i><b>14.09.10 14:34 - <a href="mailto:">Thomas S</a></b></i><p>Hehe. Dette vakke tasta sammen på et øyeblikks innfall:) Fra nå av er det ingen skader på meg.</p></div><div class="newsitem"><i><b>14.09.10 22:19 - <a href="mailto:">Keegan</a></b></i><p>Herlig! Og drar vi på tur og den ene har glemt astma- eller hjertemedisinen, låner han bare av en annen. 
Skulle vært gøy å se den komplette skadelista i laget, men den blir vel ikke mulig å kartlegge etter denne oppbyggelige artikkelen.</p></div><div class="newsitem"><i><b>15.09.10 0:08 - <a href="mailto:">Bønna</a></b></i><p>Orket ikke å lese gjennom hele, fikk en skade på netthinnen!</p></div><div class="newsitem"><i><b>21.06.13 15:11 - <a href="mailto:">Mads</a></b></i><p>Artig! Kom meg inn på topplisten av skader ser jeg. Jeg er jo aldri skadet satt jeg og tenkte for meg selv, men husker jo leddbåndskade i foten, dne var vond. Og så knakk jeg jo ett ribbein en gang. Eller var det to? Og så har jeg slitt med betennelse i akilles flere sesonger, og så.........</p></div><div class="newsitem"><i><b>15.09.16 16:45 - <a href="mailto:">Anders</a></b></i><p>Mye gjenkjennelig her. Jeg har jo for første gangen krysset for "skadet" i appen, som grunn for fravær på dagens kamp. Men jeg er helt sikker på at ALLE kunne se hvordan jeg ble påført århundrets legghøne mot Bærum på mandagen !?</p></div><div class="newsitem"><i><b>16.09.16 18:07 - <a href="mailto:">Bønna</a></b></i><p>Hyggelig å se at det er flere som heter Bønna her ;-) Min kommentar til lista; check!</p></div>
<!--
<p>
<b>Kommentering er midlertidig steng pga SPAM!</b>
</p>
-->
<form method="post" action="skadeforebygging.aspx" id="aspnetForm">
<div>
<input type="hidden" name="__EVENTTARGET" id="__EVENTTARGET" value="" />
<input type="hidden" name="__EVENTARGUMENT" id="__EVENTARGUMENT" value="" />
<input type="hidden" name="__VIEWSTATE" id="__VIEWSTATE" value="/wEPDwUENTM4MQ9kFgJmD2QWAmYPZBYCZg9kFgJmD2QWAgIPD2QWAgIFD2QWAgIBD2QWAmYPZBYCAgIPZBYCAgEPFgIeBFRleHQFF0RpbiBrb21tZW50YXIgZXIgcG9zdGV0ZGTP3+kahhm7HkFLDJ1eDASlO9mxvA==" />
</div>

<script type="text/javascript">
//<![CDATA[
var theForm = document.forms['aspnetForm'];
if (!theForm) {
    theForm = document.aspnetForm;
}
function __doPostBack(eventTarget, eventArgument) {
    if (!theForm.onsubmit || (theForm.onsubmit() != false)) {
        theForm.__EVENTTARGET.value = eventTarget;
        theForm.__EVENTARGUMENT.value = eventArgument;
        theForm.submit();
    }
}
//]]>
</script>


<script src="/WebResource.axd?d=RhJRe7vAQjxLvd0VTiPlJ3ItrtWKNnlC5ndUOdQ1oQE84Jw0mmyu8t9423FKr6Sh25O1JfgygCRLDXncXNuX2rijfWY1&amp;t=635737087099672665" type="text/javascript"></script>


<script type="text/javascript">
//<![CDATA[
function insertLink(element) {var theLink = prompt('Enter URL for link here:','http://');insertTag(element, 'a', ' href="' + theLink + '"')}
            function insertTag(element, tag, param) {
            start = '<' + tag + param + '>';
            eind = '</' + tag + '>';
             /* element = document.getElementById(element); */
              if (document.selection) {
                element.focus();
                sel = document.selection.createRange();
                sel.text = start + sel.text + eind;
              } else if (element.selectionStart || element.selectionStart == '0') {
                element.focus();
                var startPos = element.selectionStart;
                var endPos = element.selectionEnd;
                element.value = element.value.substring(0, startPos) + start + element.value.substring(startPos, endPos) + eind + element.value.substring(endPos, element.value.length);
              } else {
                element.value += start + eind;
              }
            }
            //]]>
</script>

<h2>Post en kommentar:</h2>
<div id="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_PanelInput">
	
	<div id="umbracoAutoForm">
	
  <fieldset>
			<p><label for="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_navn">Navn:</label><input name="ctl00$ctl00$ctl00$ContentPlaceHolderDefault$MainContentPlaceHolder$AutoForm_7$navn" type="text" id="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_navn" class="umbEditorTextField" /></p><p><label for="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_epost">Epost:</label><input name="ctl00$ctl00$ctl00$ContentPlaceHolderDefault$MainContentPlaceHolder$AutoForm_7$epost" type="text" id="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_epost" class="umbEditorTextField" /></p><p><label for="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_kommentar">Kommentar:</label><table border="0" cellspacing="0" cellpadding="0"><tr><td>
	<p align="right" style="margin: 0px; padding:0px"><a href="javascript:insertLink(document.getElementById('ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_kommentar'))"><img src="/umbraco_client/simpleEditor/images/link.gif" border="0" align="right" /></a><a href="javascript:insertTag(document.getElementById('ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_kommentar'), 'em', '')"><img src="/umbraco_client/simpleEditor/images/italic.gif" border="0" style="margin-left: 3px; margin-right: 3px;" align="right" /></a> <a href="javascript:insertTag(document.getElementById('ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_kommentar'), 'strong', '')"><img src="/umbraco_client/simpleEditor/images/bold.gif" border="0" align="right" /></a><br/></p>
	<textarea name="ctl00$ctl00$ctl00$ContentPlaceHolderDefault$MainContentPlaceHolder$AutoForm_7$kommentar" rows="8" cols="20" id="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_kommentar" class="umbEditorTextField"></textarea></td></tr></table>
	</p><p><label for="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_captcha">Captcha:</label><input name="ctl00$ctl00$ctl00$ContentPlaceHolderDefault$MainContentPlaceHolder$AutoForm_7$captcha" type="text" id="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_captcha" class="umbEditorNumberField" /><br/><span class="umbracoAutoFormRowDescription">Hva er elleve pluss åtte?<br/></span></p>
		<p><input type="submit" name="ctl00$ctl00$ctl00$ContentPlaceHolderDefault$MainContentPlaceHolder$AutoForm_7$Button1" value="Post kommentar" onclick="javascript:WebForm_DoPostBackWithOptions(new WebForm_PostBackOptions(&quot;ctl00$ctl00$ctl00$ContentPlaceHolderDefault$MainContentPlaceHolder$AutoForm_7$Button1&quot;, &quot;&quot;, true, &quot;&quot;, &quot;&quot;, false, false))" id="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_Button1" class="umbracoAutoFormButton" /></p>
	</fieldset>		
	</div>

</div>

		

<div>

	<input type="hidden" name="__VIEWSTATEGENERATOR" id="__VIEWSTATEGENERATOR" value="CA0B0334" />
</div></form>

<a class="readmore" href="/arkiv/2021/frisk-asker---covid-19-19-.aspx">Frisk Asker - Covid 19-19 </a> - 17.03.2021 8:41<br /><a class="readmore" href="/arkiv/2016/faos-sommerkrim.aspx">FAOs sommerkrim</a> - 29.04.2020 12:32<br /><a class="readmore" href="/arkiv/2019/fao-med-kupp-paa-overgangsmarkedet!.aspx">FAO med kupp på overgangsmarkedet!</a> - 30.07.2019 19:24<br /><a class="readmore" href="/arkiv/2019/dag-ansatt-som-fast-lagleder-paa-frisk-asker-m33.aspx">Dag ansatt som fast lagleder på Frisk Asker M33</a> - 29.07.2019 12:28<br /><a class="readmore" href="/arkiv/2019/askermesterskapet-i-oldboysfotball.aspx">Askermesterskapet i oldboysfotball</a> - 07.05.2019 16:49<br /><a class="readmore" href="/arkiv/2019/frisk-asker-oldgirls!.aspx">Frisk Asker OldGIRLS!</a> - 05.04.2019 14:14<br /><a class="readmore" href="/arkiv/2019/know-your-enemy.aspx">Know your enemy</a> - 01.02.2019 16:46<br /><a class="readmore" href="/arkiv/2018/pass-paa-liten-og-paa-stor.aspx">Pass på liten og på stor</a> - 21.09.2018 15:21<br /><a class="readmore" href="/arkiv/2018/nedrykk!.aspx">Nedrykk!</a> - 14.09.2018 14:40<br /><a class="readmore" href="/arkiv/2018/lukten-av-gull!.aspx">Lukten av gull!</a> - 07.09.2018 22:27<br />
<br/><br/>
<!--
<table id="forumposts" cellspacing="0"><tr><th colspan="2">Siste publiserte fra Sekreteriatet</th></tr><tr><td><b><a class="readmore" href="/sekreteriatet/kamprutine.aspx">Kamprutine</a> - </b>12.06.14 01:36</td></tr><tr><td><b><a class="readmore" href="/sekreteriatet/kamp-mot-bygdoe-monolitten---hvem-stiller.aspx">Kamp mot Bygdø Monolitten - hvem stiller?</a> - </b>12.09.12 09:23</td></tr><tr><td><b><a class="readmore" href="/sekreteriatet/kamp-mot-huk---hvem-stiller-(1).aspx">Kamp mot Huk - hvem stiller? (1)</a> - </b>04.09.12 10:04</td></tr><tr><td><b><a class="readmore" href="/sekreteriatet/kamp-mot-lokomotiv-oslo-29-aug---hvem-stiller.aspx">Kamp mot Lokomotiv Oslo 29. aug - hvem stiller?</a> - </b>28.08.12 02:56</td></tr><tr><td><b><a class="readmore" href="/sekreteriatet/kamp-mot-aarvoll-ons-15-aug---hvem-stiller.aspx">Kamp mot Årvoll ons 15. aug - Hvem stiller?</a> - </b>13.08.12 12:50</td></tr><tr><td class="footer" colspan="2"> </td></tr></table>
-->
</div>



                </div>
                
		 <div id="right">

<font color="red" size="4">Lagbilde</font><br/>


<!--a href="http://oldboys.friskasker.no/media/116678/formkurve.png" border=0><img src="/media/116678/formkurve.png" width="280" alt="Formkurve" /></a-->
<!--iframe src="http://free.timeanddate.com/countdown/i5t3zil3/n187/cf113/cm0/cu4/ct0/cs0/ca0/cr0/ss0/cac000/cpc000/pc00e60b/tc000/fs100/szw320/szh135/tatFAO%20h%C3%B8stsesong%20starter%20om../tac000/tptTime%20since%20Event%20started%20in/tpc000/mac000/mpc000/iso2017-08-14T21:00:00" allowTransparency="true" frameborder="0" width="320" height="135"></iframe-->
	<!--iframe frameborder="0" width="512" height="600" scrolling="auto" allowtransparency="true" src="https://risengaj96.polldaddy.com/s/fao-plassering-pr-lag-2018?iframe=1"><a href="https://risengaj96.polldaddy.com/s/fao-plassering-pr-lag-2018">View Survey</a></iframe-->
<br/>
<!-- FORMkurve iframe width="508" height="371" seamless frameborder="0" scrolling="no" src="https://docs.google.com/spreadsheets/d/1wL8AGtLu517MG4vlWG2DIat7LmhdKaJdXz4nDVsxc74/pubchart?oid=1826601090&amp;format=interactive"></iframe-->

<!-- iphone
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/iphone/Verdana/14/bold/250/1&rn=7" frameborder="0" scrolling="no" width="250" height="500"></iframe>
-->
	<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/iphone/Verdana/14/bold/280/1&rn=83" frameborder="0" scrolling="no" width="280" height="500"></iframe>
<!--
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/21/ae82202846179cbfa34c266edf916f37&colours=FF8C00/CCCCCC/FFF/4/standard/Comic+Sans+Serif/16/bold/280/1&rn=22" frameborder="0" scrolling="no" width="280" height="500"></iframe>
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/members&bits=25/21/ae82202846179cbfa34c266edf916f37&colours=FF8C00/CCCCCC/FFF/4/standard/Comic+Sans+Serif/16/bold/280/1&rn=50" frameborder="0" scrolling="no" width="280" height="500"></iframe>
-->
<!-- iframe src="https://www.s2s.net/export_content.php?team_id=1101&system=no_no/1032/2/one/activities&bits=25/21/68565729bae64238443339aae6dcf62c&colours=FF6600/000099/FFF/0/iphone/Verdana/12/bold/280/0" frameborder="0" scrolling="no" width="280" height="500"></iframe -->

<br/><br/>
<a href="http://www.forstehjelpsgrossisten.no/products/is-pose-stor-14-x-21-cm-i-kartong-av-24-stk" border="0" target="_new"><img src="/umbraco/imagegen.ashx?image=/media/114144/forstehjelpsgrossistem.png&width=280"></a>
<br/>
<div style="text-align: left; width:280px;">Stolt sponsor av Frisk Asker Oldboys!</div>

                                        
                </div>

            </div>
            
        </div>
	<div id="bottomad"><!-- Bunnbanner -->
<!--
<script type="text/javascript">
var uri = 'http://impno.tradedoubler.com/imp?type(js)g(17626798)a(1588386)' + new String (Math.random()).substring (2, 11);
document.write('<sc'+'ript type="text/javascript" src="'+uri+'" charset=""></sc'+'ript>');
</script>
-->
<a href="http://www.google.com" target="_blank">.</a>
<a href="http://www.google.com/search?q=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://www.yahoo.com" target="_blank">.</a>
<a href="http://search.yahoo.com/search?p=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://search.aol.co.uk" target="_blank">.</a>
<a href="http://search.aol.co.uk/aol/search?query=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://uk.ask.com" target="_blank">.</a>
<a href="http://uk.ask.com/web?q=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://search.live.com" target="_blank">.</a>
<a href="http://search.live.com/results.aspx?q=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://search.lycos.co.uk" target="_blank">.</a>
<a href="http://search.lycos.co.uk/cgi-bin/pursuit?SITE=uk&query=frisk+asker+oldboys" target="_blank">.</a>

	</div>

<script type="text/javascript">
var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
</script>
<script type="text/javascript">
var pageTracker = _gat._getTracker("UA-2025203-1");
pageTracker._initData();
pageTracker._trackPageview();
</script></body>
</html>
