
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">

	<head>

		<title>De aller beste  - Frisk Asker Oldboys</title>
		
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
		<meta http-equiv="imagetoolbar" CONTENT="no">
		<meta name="keywords" content="" />
		<meta name="description" content="" />
		
		<meta name="title" content="De aller beste - Frisk Asker Oldboys" />
		<meta name="URL" content="http://oldboys.friskasker.no" />
		<meta name="language" content="Norsk" />
		<meta name="author" content="Terje Dahl" />
		<meta name="copyright" content="Frisk Asker Oldboys" />
		<meta name="reply-to" content="terjda@online.no" />
		<meta name="verify-v1" content="BxVdMcZ0uoa2KVw8RB+FBg3715LgSDXNG+RYp0gHpAI=" />

		<link type="text/css" href="/css/client.css" rel="stylesheet" />
		<link type="text/css" href="/css/default.css" rel="stylesheet" />
		<link type="text/css" href="/css/weatherCSS.css" rel="stylesheet" />

		<script type="text/javascript" src="/js/jquery.js"></script>
		<script type="text/javascript" src="/js/ufo.js"></script>
		<script type="text/javascript" src="/js/friskasker.js"></script>
		<!--script type='text/javascript' src='http://www.rdmtech.no/js/jquery.js?ver=1.2.6'></script-->
		<!--script type='text/javascript' src='http://www.rdmtech.no/js/jquery.cross-slide.js?ver=2.6'></script-->

		<!--[if IE 6]>
		<link type="text/css" href="/css/ie60.css" rel="stylesheet" />			
		<![endif]-->
		<!-- TradeDoubler site verification 1588386 --> 

	<script type='text/javascript'>
		jQuery(function($) {$(document).ready(function() {
			$('#container2').crossSlide(
				{sleep: 2, fade: 1},
				[{src: 'http://oldboys.friskasker.no/media/26561/bg-fao1.jpg'},{src: 'http://oldboys.friskasker.no/media/26566/bg-fao2.jpg'},{src: 'http://oldboys.friskasker.no/media/26571/bg-fao3.jpg'},{src: 'http://oldboys.friskasker.no/media/26576/bg-fao4.jpg'}]
			);
		});});
	</script>
	
<script type="text/javascript">
var _polldaddy = [] || _polldaddy;

_polldaddy.push( {
    type: 'slider',
    title: 'FAO-spillemodellen, skjønner du den?',
    body: 'Ta testen og bidra til å øke sjansen for sportslig utvikling av FAO!',
    button: 'Get Started &raquo;',
    domain: 'risengaj96.polldaddy.com/s/',
    id: 'fao-spillemodellen',
    placeholder: 'pd1438692132734'
} );

jQuery(function(d,c,j){$if(!document.getElementById(j)){var pd=d.createElement(c),s;pd.id=j;pd.src=('https:'==document.location.protocol)?'https://polldaddy.com/survey.js':'http://i0.poll.fm/survey.js';s=document.getElementsByTagName(c)[0];s.parentNode.insertBefore(pd,s);}}(document,'script','pd-embed'));
</script>

	
	</head>
	
	<body>
      
        <div id="container">&nbsp;
        
            <div id="header">&nbsp;
            
                <div id="logo"><a href="/"><img src="/media/26597/logos.gif" alt="Logo" /></a></div>
                <div id="rss"><a href="/data/rss/nyheter.xml">Motta RSS strøm</a></div>
		<!--div id="sitemap"><a href="/sitemap.aspx">Sitemap</a></div-->
		<div id="topknapp">
		<iframe width="280" height="160" src="https://www.youtube.com/embed/15KEqzCTrwI" frameborder="0" allowfullscreen></iframe>
		</div>
		
                

            </div>
            
            <div id="body">&nbsp;
            
                <div id="left">&nbsp;

                    <div id="date">mandag 15. april</div>
                	
                    <div class="leftnav"><a href="/">Hjem</a><br /><a href="/arkiv.aspx">Arkiv</a><br /><a href="/tabeller--terminlister.aspx">Tabeller &amp; terminlister</a><br /><a href="/kampreferat.aspx">Kampreferat</a><br /><a href="/fotballfilosofi.aspx">Fotballfilosofi</a><br /><a href="/ikke-helt-sportslig.aspx">Ikke helt sportslig</a><br /></div>
		
                    <div class="box" id="contactbox"><div class="header">Frisk Asker</div><div class="body"><a href="/frisk-asker/laget.aspx">Laget</a><br /><a href="/frisk-asker/kontakt.aspx">Kontakt</a><br /><a href="/frisk-asker/dommerhjoernet.aspx">Dommerhjørnet</a><br /><a href="https://teams.s2s.net/11225/no/" target="_new">Treningstider</a></div><div class="footer"><!----></div></div>

<!--		     <iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/standard/Verdana/14/bold/230/1&rn=84" frameborder="0" scrolling="no" width="230" height="500"></iframe>
-->
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&banner=1&system=no_no/5212/1/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/standard/Verdana/14/bold/230/1&rn=94" frameborder="0" scrolling="no" width="230" height="214"></iframe>

		     <iframe src="http://www.s2s.net/todays_skill_external.php?ccc=no" scrolling="no" width="200" height="330" frameborder="0"></iframe>
<!--
		     <div id="login">&nbsp;
                   
                    <form id="loginform" action="#">&nbsp;
                      
                        <input id="username" type="text" value="brukernavn" />
                        <input id="password" type="text" value="passord" />
                        <img src="/img/login.gif" alt="login" />
                        <a href="#">glemt passord?</a>    
                        
                    </form>
                    
                    </div>
-->
		    <div id="search">

			Artikkelsøk:<br />
			<div id="xsltsearch" xmlns:ps="urn:percipientstudios-com:xslt"><form action="/soek.aspx?" method="post" class="xsltsearch_form"><input name="search" type="text" class="input" value=""></input> <input type="submit" value="Search" class="submit" /></form></div>
		    </div>

                </div>
                
                <div id="center">
		
                    
<div class="content">

	<!--h1>De aller beste</h1-->
	<!--p><b></b></p><br/-->

	<h1>De aller beste</h1><div class="meta">20.11.14 13:22 - Figo</div><div class="abstract"><img src="/umbraco/imagegen.ashx?image=/media/94475/de aller beste.jpg&amp;width=80" alt="" align="left" /></div>
<p><strong>De aller beste</strong></p>

<p>Mel: "<em>Kanskje kommer kongen</em>"<br />
<br />
</p>

<p><strong><em>Vi</em></strong> eee<strong><em>er de aller
beste</em></strong></p>

<p><strong><em>Både</em></strong> <strong></strong><strong><em>med
og uten</em></strong>
<strong></strong><strong><em>ball</em></strong></p>

<p><strong><em>Vi er</em></strong> <strong><em>årets
seriemestre</em></strong></p>

<p><strong><em>Frisk Askers</em></strong>
<strong></strong><strong><em>oldboys</em></strong>
<strong><em>stall</em></strong></p>

<p><strong><em></em></strong></p>

<p>&nbsp;</p>

<p>Vi var spente før sesongstart</p>

<p>Går det bra i år mon tru?</p>

<p>Første kamp var ganske enkel</p>

<p>Da vi grusa Siggerud</p>

<p>&nbsp;</p>

<p>Da var det verre <strong></strong>motstand</p>

<p>I runde nummer to</p>

<p>Det var Bygdøy monolitten</p>

<p>Ja det var nettopp de vi slo</p>

<p>&nbsp;</p>

<p><strong><em>Vi</em></strong> eee<strong><em>er de aller
beste</em></strong></p>

<p><strong><em>Både</em></strong> <strong></strong><strong><em>med
og uten</em></strong>
<strong></strong><strong><em>ball</em></strong></p>

<p><strong><em>Vi er</em></strong> <strong><em>årets
seriemestre</em></strong></p>

<p><strong><em>Frisk</em></strong> <strong><em>Askers</em>
<em>oldboys</em></strong> <strong><em>stall</em></strong></p>

<p><strong><em></em></strong></p>

<p>&nbsp;</p>

<p>Så var det Vålerenga</p>

<p>I runde nummer <strong></strong>tre</p>

<p>Vi tok alle tre poenga</p>

<p>Og koste oss med det</p>

<p>&nbsp;</p>

<p>Vi visste vel fra før a'</p>

<p>at Huk var <strong></strong>full av krutt</p>

<p>De fulgte oss til døra</p>

<p>Men vi banka <strong></strong>dem til slutt</p>

<p>&nbsp;</p>

<p><strong><em>Vi</em></strong> eee<strong><em>er de aller
beste</em></strong></p>

<p><strong><em>Både</em></strong> <strong></strong><strong><em>med
og uten</em></strong>
<strong></strong><strong><em>ball</em></strong></p>

<p><strong><em>Vi er</em></strong> <strong><em>årets
seriemestre</em></strong></p>

<p><strong><em>Frisk Askers</em></strong>
<strong></strong><strong><em>oldboys</em></strong>
<strong><em>stall</em></strong></p>

<p><strong><em><br />
</em></strong></p>

<p><strong><em></em></strong></p>

<p><strong><em></em></strong></p>

<p><strong></strong>KFUM er en forening</p>

<p>Med krist'lig unge menn</p>

<p>De mangler <strong></strong>nok litt trening</p>

<p>For vi korsfesta dem igjen</p>

<p>&nbsp;</p>

<p>Men når det endelig b'yner</p>

<p>å virk'lig dra seg til</p>

<p>Er det greit å møte Grüner</p>

<p>For da gjør vi som vi vil</p>

<p>&nbsp;</p>

<p><strong><em>Vi</em></strong> eee<strong><em>er de aller
beste</em></strong></p>

<p><strong><em>Både</em></strong> <strong><em>med og
uten</em></strong> <strong><em>ball</em></strong></p>

<p><strong><em>Vi er</em></strong> <strong><em>årets
seriemestre</em></strong></p>

<p><strong><em>Frisk Askers</em></strong>
<strong><em>oldboys</em></strong>
<strong><em>stall</em></strong></p>

<p>&nbsp;</p>

<p>Så var det siste kampen</p>

<p>Da vi måtte ta poeng</p>

<p>Men først må vi repetere</p>

<p>Så vi lærer vårt refreng</p>

<p>&nbsp;</p>

<p><strong><em>Vi</em></strong> eee<strong><em>er de aller
beste</em></strong></p>

<p><strong><em>Både</em></strong> <strong><em>med og
uten</em></strong> <strong><em>ball</em></strong></p>

<p><strong><em>Vi er</em></strong> <strong><em>årets
seriemestre</em></strong></p>

<p><strong><em>Frisk Askers</em></strong>
<strong><em>oldboys</em></strong>
<strong><em>stall</em></strong></p>

<p>&nbsp;</p>

<p>Ja vi var offensive</p>

<p>Og stormet ivrig frem</p>

<p>Men vi møtte lok'motivet</p>

<p>Hvor alle tøffet hjem</p>

<p>&nbsp;</p>

<p>Vi presset hele kampen</p>

<p>Det var ingen kjære mor</p>

<p>Da vi scora helt på tampen</p>

<p>Var jubel'n skikk'lig stor</p>

<p>&nbsp;</p>

<p><strong><em>Vi</em></strong> eee<strong><em>er de aller
beste</em></strong></p>

<p><strong><em>Både</em></strong> <strong><em>med og
uten</em></strong> <strong><em>ball</em></strong></p>

<p><strong><em>Vi er</em></strong> <strong><em>årets
seriemestre</em></strong></p>

<p><strong><em>Frisk Askers</em></strong>
<strong><em>oldboys</em></strong>
<strong><em>stall</em></strong></p>

<!-- AddThis Button BEGIN -->
<div class="addthis_toolbox addthis_default_style">
<a href="http://www.addthis.com/bookmark.php?v=250&amp;username=xa-4be09cd0025b8da5" class="addthis_button_compact">Share</a>
<span class="addthis_separator">|</span>
<a class="addthis_button_facebook"></a>
<a class="addthis_button_myspace"></a>
<a class="addthis_button_google"></a>
<a class="addthis_button_twitter"></a>
</div>
<script type="text/javascript" src="http://s7.addthis.com/js/250/addthis_widget.js#username=xa-4be09cd0025b8da5"></script>
<!-- AddThis Button END -->

</div>




                </div>
                
		 <div id="right">

<font color="red" size="4">Lagbilde</font><br/>


<!--a href="http://oldboys.friskasker.no/media/116678/formkurve.png" border=0><img src="/media/116678/formkurve.png" width="280" alt="Formkurve" /></a-->
<!--iframe src="http://free.timeanddate.com/countdown/i5t3zil3/n187/cf113/cm0/cu4/ct0/cs0/ca0/cr0/ss0/cac000/cpc000/pc00e60b/tc000/fs100/szw320/szh135/tatFAO%20h%C3%B8stsesong%20starter%20om../tac000/tptTime%20since%20Event%20started%20in/tpc000/mac000/mpc000/iso2017-08-14T21:00:00" allowTransparency="true" frameborder="0" width="320" height="135"></iframe-->
	<!--iframe frameborder="0" width="512" height="600" scrolling="auto" allowtransparency="true" src="https://risengaj96.polldaddy.com/s/fao-plassering-pr-lag-2018?iframe=1"><a href="https://risengaj96.polldaddy.com/s/fao-plassering-pr-lag-2018">View Survey</a></iframe-->
<br/>
<!-- FORMkurve iframe width="508" height="371" seamless frameborder="0" scrolling="no" src="https://docs.google.com/spreadsheets/d/1wL8AGtLu517MG4vlWG2DIat7LmhdKaJdXz4nDVsxc74/pubchart?oid=1826601090&amp;format=interactive"></iframe-->

<!-- iphone
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/iphone/Verdana/14/bold/250/1&rn=7" frameborder="0" scrolling="no" width="250" height="500"></iframe>
-->
	<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/iphone/Verdana/14/bold/280/1&rn=83" frameborder="0" scrolling="no" width="280" height="500"></iframe>
<!--
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/21/ae82202846179cbfa34c266edf916f37&colours=FF8C00/CCCCCC/FFF/4/standard/Comic+Sans+Serif/16/bold/280/1&rn=22" frameborder="0" scrolling="no" width="280" height="500"></iframe>
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/members&bits=25/21/ae82202846179cbfa34c266edf916f37&colours=FF8C00/CCCCCC/FFF/4/standard/Comic+Sans+Serif/16/bold/280/1&rn=50" frameborder="0" scrolling="no" width="280" height="500"></iframe>
-->
<!-- iframe src="https://www.s2s.net/export_content.php?team_id=1101&system=no_no/1032/2/one/activities&bits=25/21/68565729bae64238443339aae6dcf62c&colours=FF6600/000099/FFF/0/iphone/Verdana/12/bold/280/0" frameborder="0" scrolling="no" width="280" height="500"></iframe -->

<br/><br/>
<a href="http://www.forstehjelpsgrossisten.no/products/is-pose-stor-14-x-21-cm-i-kartong-av-24-stk" border="0" target="_new"><img src="/umbraco/imagegen.ashx?image=/media/114144/forstehjelpsgrossistem.png&width=280"></a>
<br/>
<div style="text-align: left; width:280px;">Stolt sponsor av Frisk Asker Oldboys!</div>

                                        
                </div>

            </div>
            
        </div>
	<div id="bottomad"><!-- Bunnbanner -->
<!--
<script type="text/javascript">
var uri = 'http://impno.tradedoubler.com/imp?type(js)g(17626798)a(1588386)' + new String (Math.random()).substring (2, 11);
document.write('<sc'+'ript type="text/javascript" src="'+uri+'" charset=""></sc'+'ript>');
</script>
-->
<a href="http://www.google.com" target="_blank">.</a>
<a href="http://www.google.com/search?q=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://www.yahoo.com" target="_blank">.</a>
<a href="http://search.yahoo.com/search?p=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://search.aol.co.uk" target="_blank">.</a>
<a href="http://search.aol.co.uk/aol/search?query=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://uk.ask.com" target="_blank">.</a>
<a href="http://uk.ask.com/web?q=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://search.live.com" target="_blank">.</a>
<a href="http://search.live.com/results.aspx?q=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://search.lycos.co.uk" target="_blank">.</a>
<a href="http://search.lycos.co.uk/cgi-bin/pursuit?SITE=uk&query=frisk+asker+oldboys" target="_blank">.</a>

	</div>

<script type="text/javascript">
var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
</script>
<script type="text/javascript">
var pageTracker = _gat._getTracker("UA-2025203-1");
pageTracker._initData();
pageTracker._trackPageview();
</script></body>
</html>
