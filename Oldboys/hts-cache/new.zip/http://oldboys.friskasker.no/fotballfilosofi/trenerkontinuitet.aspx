
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">

	<head>

		<title>Trenerkontinuitet  - Frisk Asker Oldboys</title>
		
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
		<meta http-equiv="imagetoolbar" CONTENT="no">
		<meta name="keywords" content="" />
		<meta name="description" content="
Nå har det skjedd igjen; Molde holder på å rykke ned, sparker
treneren og plukker plutselig poeng som en overivrig multesanker på
Finnmarksvidda.
" />
		
		<meta name="title" content="Trenerkontinuitet - Frisk Asker Oldboys" />
		<meta name="URL" content="http://oldboys.friskasker.no" />
		<meta name="language" content="Norsk" />
		<meta name="author" content="Terje Dahl" />
		<meta name="copyright" content="Frisk Asker Oldboys" />
		<meta name="reply-to" content="terjda@online.no" />
		<meta name="verify-v1" content="BxVdMcZ0uoa2KVw8RB+FBg3715LgSDXNG+RYp0gHpAI=" />

		<link type="text/css" href="/css/client.css" rel="stylesheet" />
		<link type="text/css" href="/css/default.css" rel="stylesheet" />
		<link type="text/css" href="/css/weatherCSS.css" rel="stylesheet" />

		<script type="text/javascript" src="/js/jquery.js"></script>
		<script type="text/javascript" src="/js/ufo.js"></script>
		<script type="text/javascript" src="/js/friskasker.js"></script>
		<!--script type='text/javascript' src='http://www.rdmtech.no/js/jquery.js?ver=1.2.6'></script-->
		<!--script type='text/javascript' src='http://www.rdmtech.no/js/jquery.cross-slide.js?ver=2.6'></script-->

		<!--[if IE 6]>
		<link type="text/css" href="/css/ie60.css" rel="stylesheet" />			
		<![endif]-->
		<!-- TradeDoubler site verification 1588386 --> 

	<script type='text/javascript'>
		jQuery(function($) {$(document).ready(function() {
			$('#container2').crossSlide(
				{sleep: 2, fade: 1},
				[{src: 'http://oldboys.friskasker.no/media/26561/bg-fao1.jpg'},{src: 'http://oldboys.friskasker.no/media/26566/bg-fao2.jpg'},{src: 'http://oldboys.friskasker.no/media/26571/bg-fao3.jpg'},{src: 'http://oldboys.friskasker.no/media/26576/bg-fao4.jpg'}]
			);
		});});
	</script>
	
<script type="text/javascript">
var _polldaddy = [] || _polldaddy;

_polldaddy.push( {
    type: 'slider',
    title: 'FAO-spillemodellen, skjønner du den?',
    body: 'Ta testen og bidra til å øke sjansen for sportslig utvikling av FAO!',
    button: 'Get Started &raquo;',
    domain: 'risengaj96.polldaddy.com/s/',
    id: 'fao-spillemodellen',
    placeholder: 'pd1438692132734'
} );

jQuery(function(d,c,j){$if(!document.getElementById(j)){var pd=d.createElement(c),s;pd.id=j;pd.src=('https:'==document.location.protocol)?'https://polldaddy.com/survey.js':'http://i0.poll.fm/survey.js';s=document.getElementsByTagName(c)[0];s.parentNode.insertBefore(pd,s);}}(document,'script','pd-embed'));
</script>

	
	</head>
	
	<body>
      
        <div id="container">&nbsp;
        
            <div id="header">&nbsp;
            
                <div id="logo"><a href="/"><img src="/media/26597/logos.gif" alt="Logo" /></a></div>
                <div id="rss"><a href="/data/rss/nyheter.xml">Motta RSS strøm</a></div>
		<!--div id="sitemap"><a href="/sitemap.aspx">Sitemap</a></div-->
		<div id="topknapp">
		<iframe width="280" height="160" src="https://www.youtube.com/embed/15KEqzCTrwI" frameborder="0" allowfullscreen></iframe>
		</div>
		
                

            </div>
            
            <div id="body">&nbsp;
            
                <div id="left">&nbsp;

                    <div id="date">mandag 15. april</div>
                	
                    <div class="leftnav"><a href="/">Hjem</a><br /><a href="/arkiv.aspx">Arkiv</a><br /><a href="/tabeller--terminlister.aspx">Tabeller &amp; terminlister</a><br /><a href="/kampreferat.aspx">Kampreferat</a><br /><a href="/fotballfilosofi.aspx">Fotballfilosofi</a><br /><a href="/ikke-helt-sportslig.aspx">Ikke helt sportslig</a><br /></div>
		
                    <div class="box" id="contactbox"><div class="header">Frisk Asker</div><div class="body"><a href="/frisk-asker/laget.aspx">Laget</a><br /><a href="/frisk-asker/kontakt.aspx">Kontakt</a><br /><a href="/frisk-asker/dommerhjoernet.aspx">Dommerhjørnet</a><br /><a href="https://teams.s2s.net/11225/no/" target="_new">Treningstider</a></div><div class="footer"><!----></div></div>

<!--		     <iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/standard/Verdana/14/bold/230/1&rn=84" frameborder="0" scrolling="no" width="230" height="500"></iframe>
-->
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&banner=1&system=no_no/5212/1/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/standard/Verdana/14/bold/230/1&rn=94" frameborder="0" scrolling="no" width="230" height="214"></iframe>

		     <iframe src="http://www.s2s.net/todays_skill_external.php?ccc=no" scrolling="no" width="200" height="330" frameborder="0"></iframe>
<!--
		     <div id="login">&nbsp;
                   
                    <form id="loginform" action="#">&nbsp;
                      
                        <input id="username" type="text" value="brukernavn" />
                        <input id="password" type="text" value="passord" />
                        <img src="/img/login.gif" alt="login" />
                        <a href="#">glemt passord?</a>    
                        
                    </form>
                    
                    </div>
-->
		    <div id="search">

			Artikkelsøk:<br />
			<div id="xsltsearch" xmlns:ps="urn:percipientstudios-com:xslt"><form action="/soek.aspx?" method="post" class="xsltsearch_form"><input name="search" type="text" class="input" value=""></input> <input type="submit" value="Search" class="submit" /></form></div>
		    </div>

                </div>
                
                <div id="center">
		
                    
<div class="content">

	<!--h1>Trenerkontinuitet</h1-->
	<!--p><b><p>Nå har det skjedd igjen; Molde holder på å rykke ned, sparker
treneren og plukker plutselig poeng som en overivrig multesanker på
Finnmarksvidda.</p></b></p><br/-->

	<h1>Trenerkontinuitet</h1><div class="meta">28.10.10 10:37 - Figo</div><div class="abstract"><img src="/umbraco/imagegen.ashx?image=/media/46830/jonevret.jpg&amp;width=80" alt="" align="left" />
<p>Nå har det skjedd igjen; Molde holder på å rykke ned, sparker
treneren og plukker plutselig poeng som en overivrig multesanker på
Finnmarksvidda.</p>
</div>
<p>"Kjell har styrets fulle tillit" sa direktør-Tarje, kanskje de
ordene en fotballtrener frykter mest å høre, og ganske riktig;
dagen etter at disse famøse ord var uttalt så var tilliten
tydeligvis blåst vekk og Jonevret måtte rusle slukøret ut av
Røkkeløkka.<br />
<br />
Kan det være så enkelt som at moldenserne gir fyken til en moderat
ballansert svenske og erstatter han med en hissig tysker, så kommer
poengene trillende? Svensken hadde kjempesuksess året før mens
tysker'n da fikk en kald skulder og måtte flykte fra Stavanger,
njaa - skeptisk.<br />
<img src="/media/46849/trener_uwe_rösler_03.jpg" width="248" height="179" alt="trener_Uwe_Rösler_03"/><br />
Hva er det i tilfelle som forvandler et lag mest, er det at man
blir kvitt den treneren som går av eller er det den nye som kommer
inn som er så fantastisk? Hvis det første er tilfellet så har
Nordli kun hatt flaks og bløffet seg til lønn fra halve
tippeligaen, men om svaralternativ nr.2 er det riktige så har han
jo full rett til å kalle seg Messias. Med høy mirakelfaktor har han
jo da faktisk egenhendig reddet en haug av klubbene i de to øverste
divisjonene.<br />
<img src="/media/46854/trener nordli.jpeg" width="238" height="155" alt="trener nordli"/><br />
Nei det er vel grunn til å tro at svaret er mer nyansert enn som
så. Molde, Brann og Hønefoss har alle gjort de samme vurderingene
og vist henholdsvis Jonevret, Nilsen og Sundgott veien ut av
stadion. Lillestrøm og Stabæk var i samme situasjon lenge, men
valgte å beholde sine menn … og tabellen lyver som kjent ikke; de
to sistnevnte ligger høyere på tabellen enn de tre første i
skrivende stund, til tross for den umiddelbare gevinsten man blir
forespeilet ved å skifte trener.<br />
<br />
Når det gjelder kontinuitet så kan vel for øvrig ManU og Rosenborg
skrive under på at både Ferguson og Eggen representerer gode
eksempler på vellykkede kontinuitetsbærere. Nå er jeg rimelig
overbevist om at det også har vært diskusjoner om trenerkasting i
styrerommene både i Manchester og Trondheim, men det har nok heller
vært forårsaket av uoverveide hjerneløse uttalelser i pressen enn
akutt poengnød.<br />
<img src="/media/46859/trener_tørum.jpg" width="249" height="155" alt="trener_tørum"/><br />
Her er trenerne som skulle kjempe om tittelen i Tippeligaen 2007 og
mange av disse så sikkert for seg en lang og god karriere i nettopp
denne klubben:<br />
<span>Per Joar Hansen, Aalesund<br />
Anders Grönhagen FFK<br />
Dag-Eilev Fagermo, Godset<br />
Tor Thodesen, Sandefjord<br />
Stig Inge Bjørnebye, Start<br />
Jan Jönsson, Stabæk<br />
Henning Berg, Lyn<br />
Steinar Nilsen, Tromsø<br />
Knut Tørum, Rosenborg<br />
Tom Nordlie, Lillestrøm<br />
Uwe Rösler, Viking<br />
Arne Sandstø, Odd<br />
Petter Myhre, Vålerenga<br />
Mons Ivar Mjelde, Brann<br />
</span>.... nå, tre år senere er det bare Janne som fortsatt er på
sin post, og selv han har begynt å anlegge mustasje for å feire jul
i bartebyen.<br />
<img src="/media/46864/trener_nilsen.jpg" width="251" height="169" alt="trener_nilsen"/><br />
Alle lagene i nedrykkstriden vurderer nok en eller annen gang i
løpet av sesongen å sparke treneren sin. Selvsagt er det forskjell
på ressurser og ambisjoner hos de forskjellige klubbene. Der hvor
den jevne bergenser ønsker å rive stadion og koke Bruun-Hansen i
olje om de havner på femteplass et år, vil nok både et tilfeldig
valgt styremedlem i Kongsvinger eller en trofast Hønefoss supporter
gi den ene armen for å oppnå noe tilsvarende.<br />
<br />
Forskning gjennom de siste femten år i Tippeligaen viser imidlertid
at de som beholder treneren vil over tid ta flere poeng enn de som
kvitter seg med sin, så kan man jo fundere hvorfor syv trenere
sparkes i snitt hver sesong i Norges øverste serie … og ikke minst
kan man spørre seg om ikke Molde ville gjort det like bra om de
hadde beholdt Jonevret ... nei du, det får vi nok aldri vite.</p>

<p><img src="/media/46874/jonevret.jpg" width="274" height="184" alt="jonevret"/></p>

<p>Frisk Asker oldboys har nå hatt samme trener i fjorten år, noe
som jo har resultert i at vi er med i medaljekampen i den
hjemmelige toppserien hvert år og har stort sett deltatt i Europa
kontinuerlig siden 1999.</p>

<p>(Nå foreslo likevel styret å sparke både treneren og alle
spillerne forrige sesong, riktignok mer på grunn av evnen til
selvstendig tankegang enn mangel på sportslig suksess.
Red.anm.)</p>

<p>Selv om det kan virke som jeg her gjør hva jeg kan for å
lovprise kontinuitet på trenersiden så vil jeg likevel påpeke klart
og tydelig at rollen som oldboystrener som vanlig vil stilles til
disposisjon på neste årsmøte og at hvem som helst har undertegnedes
tillatelse til å fremme sitt ønske om å bekle denne posisjonen, og
med meget stor sannsynlighet også vil få innfridd sitt ønske.</p>

<!-- AddThis Button BEGIN -->
<div class="addthis_toolbox addthis_default_style">
<a href="http://www.addthis.com/bookmark.php?v=250&amp;username=xa-4be09cd0025b8da5" class="addthis_button_compact">Share</a>
<span class="addthis_separator">|</span>
<a class="addthis_button_facebook"></a>
<a class="addthis_button_myspace"></a>
<a class="addthis_button_google"></a>
<a class="addthis_button_twitter"></a>
</div>
<script type="text/javascript" src="http://s7.addthis.com/js/250/addthis_widget.js#username=xa-4be09cd0025b8da5"></script>
<!-- AddThis Button END -->

</div>




                </div>
                
		 <div id="right">

<font color="red" size="4">Lagbilde</font><br/>


<!--a href="http://oldboys.friskasker.no/media/116678/formkurve.png" border=0><img src="/media/116678/formkurve.png" width="280" alt="Formkurve" /></a-->
<!--iframe src="http://free.timeanddate.com/countdown/i5t3zil3/n187/cf113/cm0/cu4/ct0/cs0/ca0/cr0/ss0/cac000/cpc000/pc00e60b/tc000/fs100/szw320/szh135/tatFAO%20h%C3%B8stsesong%20starter%20om../tac000/tptTime%20since%20Event%20started%20in/tpc000/mac000/mpc000/iso2017-08-14T21:00:00" allowTransparency="true" frameborder="0" width="320" height="135"></iframe-->
	<!--iframe frameborder="0" width="512" height="600" scrolling="auto" allowtransparency="true" src="https://risengaj96.polldaddy.com/s/fao-plassering-pr-lag-2018?iframe=1"><a href="https://risengaj96.polldaddy.com/s/fao-plassering-pr-lag-2018">View Survey</a></iframe-->
<br/>
<!-- FORMkurve iframe width="508" height="371" seamless frameborder="0" scrolling="no" src="https://docs.google.com/spreadsheets/d/1wL8AGtLu517MG4vlWG2DIat7LmhdKaJdXz4nDVsxc74/pubchart?oid=1826601090&amp;format=interactive"></iframe-->

<!-- iphone
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/iphone/Verdana/14/bold/250/1&rn=7" frameborder="0" scrolling="no" width="250" height="500"></iframe>
-->
	<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/iphone/Verdana/14/bold/280/1&rn=83" frameborder="0" scrolling="no" width="280" height="500"></iframe>
<!--
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/21/ae82202846179cbfa34c266edf916f37&colours=FF8C00/CCCCCC/FFF/4/standard/Comic+Sans+Serif/16/bold/280/1&rn=22" frameborder="0" scrolling="no" width="280" height="500"></iframe>
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/members&bits=25/21/ae82202846179cbfa34c266edf916f37&colours=FF8C00/CCCCCC/FFF/4/standard/Comic+Sans+Serif/16/bold/280/1&rn=50" frameborder="0" scrolling="no" width="280" height="500"></iframe>
-->
<!-- iframe src="https://www.s2s.net/export_content.php?team_id=1101&system=no_no/1032/2/one/activities&bits=25/21/68565729bae64238443339aae6dcf62c&colours=FF6600/000099/FFF/0/iphone/Verdana/12/bold/280/0" frameborder="0" scrolling="no" width="280" height="500"></iframe -->

<br/><br/>
<a href="http://www.forstehjelpsgrossisten.no/products/is-pose-stor-14-x-21-cm-i-kartong-av-24-stk" border="0" target="_new"><img src="/umbraco/imagegen.ashx?image=/media/114144/forstehjelpsgrossistem.png&width=280"></a>
<br/>
<div style="text-align: left; width:280px;">Stolt sponsor av Frisk Asker Oldboys!</div>

                                        
                </div>

            </div>
            
        </div>
	<div id="bottomad"><!-- Bunnbanner -->
<!--
<script type="text/javascript">
var uri = 'http://impno.tradedoubler.com/imp?type(js)g(17626798)a(1588386)' + new String (Math.random()).substring (2, 11);
document.write('<sc'+'ript type="text/javascript" src="'+uri+'" charset=""></sc'+'ript>');
</script>
-->
<a href="http://www.google.com" target="_blank">.</a>
<a href="http://www.google.com/search?q=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://www.yahoo.com" target="_blank">.</a>
<a href="http://search.yahoo.com/search?p=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://search.aol.co.uk" target="_blank">.</a>
<a href="http://search.aol.co.uk/aol/search?query=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://uk.ask.com" target="_blank">.</a>
<a href="http://uk.ask.com/web?q=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://search.live.com" target="_blank">.</a>
<a href="http://search.live.com/results.aspx?q=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://search.lycos.co.uk" target="_blank">.</a>
<a href="http://search.lycos.co.uk/cgi-bin/pursuit?SITE=uk&query=frisk+asker+oldboys" target="_blank">.</a>

	</div>

<script type="text/javascript">
var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
</script>
<script type="text/javascript">
var pageTracker = _gat._getTracker("UA-2025203-1");
pageTracker._initData();
pageTracker._trackPageview();
</script></body>
</html>
