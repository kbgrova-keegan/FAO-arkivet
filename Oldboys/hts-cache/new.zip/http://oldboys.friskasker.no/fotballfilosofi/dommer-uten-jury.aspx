
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">

	<head>

		<title>Dommer uten jury  - Frisk Asker Oldboys</title>
		
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
		<meta http-equiv="imagetoolbar" CONTENT="no">
		<meta name="keywords" content="" />
		<meta name="description" content="
Jusstudiet for å bli fotballdommer er rimelig kort, et par
kvelders middels innsats og du blir belønnet med egen fløyte og en
fargerik kortstokk.

&amp;nbsp;

&amp;nbsp;

&amp;nbsp;
" />
		
		<meta name="title" content="Dommer uten jury - Frisk Asker Oldboys" />
		<meta name="URL" content="http://oldboys.friskasker.no" />
		<meta name="language" content="Norsk" />
		<meta name="author" content="Terje Dahl" />
		<meta name="copyright" content="Frisk Asker Oldboys" />
		<meta name="reply-to" content="terjda@online.no" />
		<meta name="verify-v1" content="BxVdMcZ0uoa2KVw8RB+FBg3715LgSDXNG+RYp0gHpAI=" />

		<link type="text/css" href="/css/client.css" rel="stylesheet" />
		<link type="text/css" href="/css/default.css" rel="stylesheet" />
		<link type="text/css" href="/css/weatherCSS.css" rel="stylesheet" />

		<script type="text/javascript" src="/js/jquery.js"></script>
		<script type="text/javascript" src="/js/ufo.js"></script>
		<script type="text/javascript" src="/js/friskasker.js"></script>
		<!--script type='text/javascript' src='http://www.rdmtech.no/js/jquery.js?ver=1.2.6'></script-->
		<!--script type='text/javascript' src='http://www.rdmtech.no/js/jquery.cross-slide.js?ver=2.6'></script-->

		<!--[if IE 6]>
		<link type="text/css" href="/css/ie60.css" rel="stylesheet" />			
		<![endif]-->
		<!-- TradeDoubler site verification 1588386 --> 

	<script type='text/javascript'>
		jQuery(function($) {$(document).ready(function() {
			$('#container2').crossSlide(
				{sleep: 2, fade: 1},
				[{src: 'http://oldboys.friskasker.no/media/26561/bg-fao1.jpg'},{src: 'http://oldboys.friskasker.no/media/26566/bg-fao2.jpg'},{src: 'http://oldboys.friskasker.no/media/26571/bg-fao3.jpg'},{src: 'http://oldboys.friskasker.no/media/26576/bg-fao4.jpg'}]
			);
		});});
	</script>
	
<script type="text/javascript">
var _polldaddy = [] || _polldaddy;

_polldaddy.push( {
    type: 'slider',
    title: 'FAO-spillemodellen, skjønner du den?',
    body: 'Ta testen og bidra til å øke sjansen for sportslig utvikling av FAO!',
    button: 'Get Started &raquo;',
    domain: 'risengaj96.polldaddy.com/s/',
    id: 'fao-spillemodellen',
    placeholder: 'pd1438692132734'
} );

jQuery(function(d,c,j){$if(!document.getElementById(j)){var pd=d.createElement(c),s;pd.id=j;pd.src=('https:'==document.location.protocol)?'https://polldaddy.com/survey.js':'http://i0.poll.fm/survey.js';s=document.getElementsByTagName(c)[0];s.parentNode.insertBefore(pd,s);}}(document,'script','pd-embed'));
</script>

	
	</head>
	
	<body>
      
        <div id="container">&nbsp;
        
            <div id="header">&nbsp;
            
                <div id="logo"><a href="/"><img src="/media/26597/logos.gif" alt="Logo" /></a></div>
                <div id="rss"><a href="/data/rss/nyheter.xml">Motta RSS strøm</a></div>
		<!--div id="sitemap"><a href="/sitemap.aspx">Sitemap</a></div-->
		<div id="topknapp">
		<iframe width="280" height="160" src="https://www.youtube.com/embed/15KEqzCTrwI" frameborder="0" allowfullscreen></iframe>
		</div>
		
                

            </div>
            
            <div id="body">&nbsp;
            
                <div id="left">&nbsp;

                    <div id="date">mandag 15. april</div>
                	
                    <div class="leftnav"><a href="/">Hjem</a><br /><a href="/arkiv.aspx">Arkiv</a><br /><a href="/tabeller--terminlister.aspx">Tabeller &amp; terminlister</a><br /><a href="/kampreferat.aspx">Kampreferat</a><br /><a href="/fotballfilosofi.aspx">Fotballfilosofi</a><br /><a href="/ikke-helt-sportslig.aspx">Ikke helt sportslig</a><br /></div>
		
                    <div class="box" id="contactbox"><div class="header">Frisk Asker</div><div class="body"><a href="/frisk-asker/laget.aspx">Laget</a><br /><a href="/frisk-asker/kontakt.aspx">Kontakt</a><br /><a href="/frisk-asker/dommerhjoernet.aspx">Dommerhjørnet</a><br /><a href="https://teams.s2s.net/11225/no/" target="_new">Treningstider</a></div><div class="footer"><!----></div></div>

<!--		     <iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/standard/Verdana/14/bold/230/1&rn=84" frameborder="0" scrolling="no" width="230" height="500"></iframe>
-->
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&banner=1&system=no_no/5212/1/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/standard/Verdana/14/bold/230/1&rn=94" frameborder="0" scrolling="no" width="230" height="214"></iframe>

		     <iframe src="http://www.s2s.net/todays_skill_external.php?ccc=no" scrolling="no" width="200" height="330" frameborder="0"></iframe>
<!--
		     <div id="login">&nbsp;
                   
                    <form id="loginform" action="#">&nbsp;
                      
                        <input id="username" type="text" value="brukernavn" />
                        <input id="password" type="text" value="passord" />
                        <img src="/img/login.gif" alt="login" />
                        <a href="#">glemt passord?</a>    
                        
                    </form>
                    
                    </div>
-->
		    <div id="search">

			Artikkelsøk:<br />
			<div id="xsltsearch" xmlns:ps="urn:percipientstudios-com:xslt"><form action="/soek.aspx?" method="post" class="xsltsearch_form"><input name="search" type="text" class="input" value=""></input> <input type="submit" value="Search" class="submit" /></form></div>
		    </div>

                </div>
                
                <div id="center">
		
                    
<div class="content">

	<!--h1>Dommer uten jury</h1-->
	<!--p><b><p>Jusstudiet for å bli fotballdommer er rimelig kort, et par
kvelders middels innsats og du blir belønnet med egen fløyte og en
fargerik kortstokk.</p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>&nbsp;</p></b></p><br/-->

	<h1>Dommer uten jury</h1><div class="meta">12.10.07 9:05 - Figo</div><div class="abstract"><img src="/umbraco/imagegen.ashx?image=/media/15141/collina.jpg&amp;width=80" alt="" align="left" />
<p>Jusstudiet for å bli fotballdommer er rimelig kort, et par
kvelders middels innsats og du blir belønnet med egen fløyte og en
fargerik kortstokk.</p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>&nbsp;</p>
</div>
<p>Det er i seg selv ganske skremmende med tanke på hva som møter
en nyutklekket kretsdommer av kjeft og trakassering, fysiske og
psykiske overgrep både på og utenfor banen. Vi snakker om
sjikanering og overgrep på lik linje med det tyskerungene i
etterkrigstiden opplevde, eller steriliseringen av sigøynere for
den saks skyld. Burde ikke opplæringen av kretsdommere for eksempel
inkludere et toukers ferieopphold i sørlige deler av Afghanistan
eller en lett joggetur gjennom Bagdad kun drapert i det amerikanske
flagget? Slike erfaringer ville nok gjøre den norske dommerstanden
bedre rustet til å tåle hverdagslivet i det norske seriesystemet
….</p>

<p>Fortjent mener du kanskje, ja vel, men like fullt er vi
avhengige av å ha en fløytespillende sortkledd som kjenner
regelverket sånn noenlunde, løpende rundt på banen og ta upopulære
avgjørelser på linje med en middels kommunepolitiker.</p>

<p>Kanskje kunne vi klart oss uten denne mørkets fyrste i vår
midte? Kanskje vi kunne innført det fullendte demokrati på
fotballbanen, med ren flertallsavstemning blant spillere og
publikum ved tvilstilfeller, samt korte og effektive møter i
konfliktrådet på sidelinjen der det fortsatt krangles om
situasjonsavgjørelser … neppe, og poenget med videodømming har jeg
aldri helt fått taket på, jeg mener, hvis dommeren sitter hjemme og
ser video.. njaaa - skeptisk.&nbsp;</p>

<p>Det som overrasker mest er fotballforbundets manglende evne til
å plukke ut de beste emnene i rekrutteringsfasen til dommerstanden.
Helt uten unntak har det vist seg at de beste dommerne aldri kommer
ut til midtsirkelen men i stedet, uten unntak, blir sittende på
tribunen, foran TV-apparatet eller til og med som spiller ute på
gressmatten … aldri (les: ALDRI) har den beste dommeren vært ikledd
sort drakt og hatt en sentral rolle på banen (det nærmeste må vel
sies å være&nbsp;Vinnie Jones som, i Wimbledons sorte klubbdrakt,
dømte motspillere til kortere og lengre sykehusopphold på strak
arm).</p>

<p>En annen ting er begrepet "hjemmedommer". Dette har ingen ting å
gjøre med hvem som bestemmer i hjemmets lune rede (jeg trodde først
det var snakk om kona), nei da, en riktig god hjemmedommer er en
som "er grei nok" (hederstittel for en sortkledd) fordi han lar
hjemmelagets noble spillere opptre med den fasthet og styrke som
behøves for å sette gjestende lag på plass, samtidig som han slår
effektivt ned på bortelagets uhøflige tendens til å holde ballen
for seg selv.</p>

<p>Nå kan vi selvsagt ikke skrive om dommerrekruttering uten å
nevne det faktum at samtlige som kommer ut fra NFF med sertifikat
som gir rett til overgrep mot hederlige fotballspillere har
synsforstyrrelser. Dette er selvsagt leit for den det gjelder, men
også for de dette går ut over, noe som gir seg utslag i tilrop som
"er'u blind eller?" og "skaff deg briller'a, dommer!".</p>

<p>Burde det ikke være obligatorisk med en synstest på dommerkurset
og utdeling av spesielt tilpassede briller/linser sammen med fløyte
og kortstokk?</p>

<p>Etter hver serierunde i tippeligaen står det ramset opp side
etter side, på avisenes sportssider, hva dommerstanden ikke har
sett, men som absolutt alle andre fikk med seg uten å lee på
øyelokket (men gjerne etter å ha frosset situasjonen ved den tredje
reprisen).</p>

<p>Jeg har selv dømt noen oldboyskamper i høst og er veldig
overrasket over alt jeg ikke så i løpet av kampen men som spillerne
velmenende nok passet på å holde meg oppdatert på, både underveis i
kampen og etter kampslutt. Nå har jeg gått til det skritt å
bestille time hos optikeren for å være sikker på å få med meg
innholdet i kampene neste sesong og hvis ikke det hjelper vil jeg
oppsøke blindeforbundet eller optikerforeningen for mulig
sponsing.&nbsp;</p>

<p>I et desperat forsøk på å forbedre forholdene vil jeg foreslå
følgende strakstiltak:</p>

<p>Gule og røde kort burde vært byttet ut med godt gammeldags
spanskrør eller balltre</p>

<p>Skal det først være kort så kan det godt utvides med flere
alternativer:</p>

<ul>
<li>Rosa kort&nbsp;- for utilbørlig feminin feiring av scoring</li>

<li>Grønt kort&nbsp;- til spillere fra land utenfor EU, ved
behov</li>

<li>Postkort - til de som vises ut ... av landet</li>

<li>Bursdagskort - i tilfelle noen fyller år</li>

<li>Minnekort - til de som glemte at fotball skal være gøy</li>

<li>Julekort - til dagens nisse?</li>

<li>Visa kort&nbsp;eller gavekort - til dommeren ved skikkelig
ufortjent hjemmeseier</li>
</ul>

<p>&nbsp;&nbsp;&nbsp;&nbsp;</p>

<p>Linjemannen kan med fordel bytte ut flagget til fordel for pil
og bue eller blåserør med giftpiler. Jeg mener, hvor mange offsider
vil Carew gå i da? (riktig svar er 1).</p>

<p>Og hvor mange vil holde i trøya til motspilleren hvis en
risikerer å få en dobbel Collina med balltre etter seg?</p>

<p>Da gjenstår det bare å få enkeltindivider blant de sortkledde
til å beholde litt fornuft og ikke kle seg i Barcelona drakten rett
før du skal dømme disse i Champions League finalen … slikt
bekrefter bare mistanken om manglende gangsyn.&nbsp;</p>

<p>Vi opererer for øvrig med følgende dommersatser i oldboysen:</p>

<p>Hjemmeseier: kr.300,-</p>

<p>Uavgjort: kr.200,-</p>

<p>Borteseier: kr.100,-</p>

<p>&nbsp;</p>

<p>Vel dømt!</p>

<p>&nbsp;</p>

<!-- AddThis Button BEGIN -->
<div class="addthis_toolbox addthis_default_style">
<a href="http://www.addthis.com/bookmark.php?v=250&amp;username=xa-4be09cd0025b8da5" class="addthis_button_compact">Share</a>
<span class="addthis_separator">|</span>
<a class="addthis_button_facebook"></a>
<a class="addthis_button_myspace"></a>
<a class="addthis_button_google"></a>
<a class="addthis_button_twitter"></a>
</div>
<script type="text/javascript" src="http://s7.addthis.com/js/250/addthis_widget.js#username=xa-4be09cd0025b8da5"></script>
<!-- AddThis Button END -->

</div>




                </div>
                
		 <div id="right">

<font color="red" size="4">Lagbilde</font><br/>


<!--a href="http://oldboys.friskasker.no/media/116678/formkurve.png" border=0><img src="/media/116678/formkurve.png" width="280" alt="Formkurve" /></a-->
<!--iframe src="http://free.timeanddate.com/countdown/i5t3zil3/n187/cf113/cm0/cu4/ct0/cs0/ca0/cr0/ss0/cac000/cpc000/pc00e60b/tc000/fs100/szw320/szh135/tatFAO%20h%C3%B8stsesong%20starter%20om../tac000/tptTime%20since%20Event%20started%20in/tpc000/mac000/mpc000/iso2017-08-14T21:00:00" allowTransparency="true" frameborder="0" width="320" height="135"></iframe-->
	<!--iframe frameborder="0" width="512" height="600" scrolling="auto" allowtransparency="true" src="https://risengaj96.polldaddy.com/s/fao-plassering-pr-lag-2018?iframe=1"><a href="https://risengaj96.polldaddy.com/s/fao-plassering-pr-lag-2018">View Survey</a></iframe-->
<br/>
<!-- FORMkurve iframe width="508" height="371" seamless frameborder="0" scrolling="no" src="https://docs.google.com/spreadsheets/d/1wL8AGtLu517MG4vlWG2DIat7LmhdKaJdXz4nDVsxc74/pubchart?oid=1826601090&amp;format=interactive"></iframe-->

<!-- iphone
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/iphone/Verdana/14/bold/250/1&rn=7" frameborder="0" scrolling="no" width="250" height="500"></iframe>
-->
	<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/iphone/Verdana/14/bold/280/1&rn=83" frameborder="0" scrolling="no" width="280" height="500"></iframe>
<!--
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/21/ae82202846179cbfa34c266edf916f37&colours=FF8C00/CCCCCC/FFF/4/standard/Comic+Sans+Serif/16/bold/280/1&rn=22" frameborder="0" scrolling="no" width="280" height="500"></iframe>
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/members&bits=25/21/ae82202846179cbfa34c266edf916f37&colours=FF8C00/CCCCCC/FFF/4/standard/Comic+Sans+Serif/16/bold/280/1&rn=50" frameborder="0" scrolling="no" width="280" height="500"></iframe>
-->
<!-- iframe src="https://www.s2s.net/export_content.php?team_id=1101&system=no_no/1032/2/one/activities&bits=25/21/68565729bae64238443339aae6dcf62c&colours=FF6600/000099/FFF/0/iphone/Verdana/12/bold/280/0" frameborder="0" scrolling="no" width="280" height="500"></iframe -->

<br/><br/>
<a href="http://www.forstehjelpsgrossisten.no/products/is-pose-stor-14-x-21-cm-i-kartong-av-24-stk" border="0" target="_new"><img src="/umbraco/imagegen.ashx?image=/media/114144/forstehjelpsgrossistem.png&width=280"></a>
<br/>
<div style="text-align: left; width:280px;">Stolt sponsor av Frisk Asker Oldboys!</div>

                                        
                </div>

            </div>
            
        </div>
	<div id="bottomad"><!-- Bunnbanner -->
<!--
<script type="text/javascript">
var uri = 'http://impno.tradedoubler.com/imp?type(js)g(17626798)a(1588386)' + new String (Math.random()).substring (2, 11);
document.write('<sc'+'ript type="text/javascript" src="'+uri+'" charset=""></sc'+'ript>');
</script>
-->
<a href="http://www.google.com" target="_blank">.</a>
<a href="http://www.google.com/search?q=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://www.yahoo.com" target="_blank">.</a>
<a href="http://search.yahoo.com/search?p=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://search.aol.co.uk" target="_blank">.</a>
<a href="http://search.aol.co.uk/aol/search?query=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://uk.ask.com" target="_blank">.</a>
<a href="http://uk.ask.com/web?q=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://search.live.com" target="_blank">.</a>
<a href="http://search.live.com/results.aspx?q=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://search.lycos.co.uk" target="_blank">.</a>
<a href="http://search.lycos.co.uk/cgi-bin/pursuit?SITE=uk&query=frisk+asker+oldboys" target="_blank">.</a>

	</div>

<script type="text/javascript">
var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
</script>
<script type="text/javascript">
var pageTracker = _gat._getTracker("UA-2025203-1");
pageTracker._initData();
pageTracker._trackPageview();
</script></body>
</html>
