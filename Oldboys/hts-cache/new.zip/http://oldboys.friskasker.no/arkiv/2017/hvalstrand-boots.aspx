
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">

	<head>

		<title>Hvalstrand boots  - Frisk Asker Oldboys</title>
		
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
		<meta http-equiv="imagetoolbar" CONTENT="no">
		<meta name="keywords" content="" />
		<meta name="description" content="En sann (epost-)historie" />
		
		<meta name="title" content="Hvalstrand boots - Frisk Asker Oldboys" />
		<meta name="URL" content="http://oldboys.friskasker.no" />
		<meta name="language" content="Norsk" />
		<meta name="author" content="Terje Dahl" />
		<meta name="copyright" content="Frisk Asker Oldboys" />
		<meta name="reply-to" content="terjda@online.no" />
		<meta name="verify-v1" content="BxVdMcZ0uoa2KVw8RB+FBg3715LgSDXNG+RYp0gHpAI=" />

		<link type="text/css" href="/css/client.css" rel="stylesheet" />
		<link type="text/css" href="/css/default.css" rel="stylesheet" />
		<link type="text/css" href="/css/weatherCSS.css" rel="stylesheet" />

		<script type="text/javascript" src="/js/jquery.js"></script>
		<script type="text/javascript" src="/js/ufo.js"></script>
		<script type="text/javascript" src="/js/friskasker.js"></script>
		<!--script type='text/javascript' src='http://www.rdmtech.no/js/jquery.js?ver=1.2.6'></script-->
		<!--script type='text/javascript' src='http://www.rdmtech.no/js/jquery.cross-slide.js?ver=2.6'></script-->

		<!--[if IE 6]>
		<link type="text/css" href="/css/ie60.css" rel="stylesheet" />			
		<![endif]-->
		<!-- TradeDoubler site verification 1588386 --> 

	<script type='text/javascript'>
		jQuery(function($) {$(document).ready(function() {
			$('#container2').crossSlide(
				{sleep: 2, fade: 1},
				[{src: 'http://oldboys.friskasker.no/media/26561/bg-fao1.jpg'},{src: 'http://oldboys.friskasker.no/media/26566/bg-fao2.jpg'},{src: 'http://oldboys.friskasker.no/media/26571/bg-fao3.jpg'},{src: 'http://oldboys.friskasker.no/media/26576/bg-fao4.jpg'}]
			);
		});});
	</script>
	
<script type="text/javascript">
var _polldaddy = [] || _polldaddy;

_polldaddy.push( {
    type: 'slider',
    title: 'FAO-spillemodellen, skjønner du den?',
    body: 'Ta testen og bidra til å øke sjansen for sportslig utvikling av FAO!',
    button: 'Get Started &raquo;',
    domain: 'risengaj96.polldaddy.com/s/',
    id: 'fao-spillemodellen',
    placeholder: 'pd1438692132734'
} );

jQuery(function(d,c,j){$if(!document.getElementById(j)){var pd=d.createElement(c),s;pd.id=j;pd.src=('https:'==document.location.protocol)?'https://polldaddy.com/survey.js':'http://i0.poll.fm/survey.js';s=document.getElementsByTagName(c)[0];s.parentNode.insertBefore(pd,s);}}(document,'script','pd-embed'));
</script>

	
	</head>
	
	<body>
      
        <div id="container">&nbsp;
        
            <div id="header">&nbsp;
            
                <div id="logo"><a href="/"><img src="/media/26597/logos.gif" alt="Logo" /></a></div>
                <div id="rss"><a href="/data/rss/nyheter.xml">Motta RSS strøm</a></div>
		<!--div id="sitemap"><a href="/sitemap.aspx">Sitemap</a></div-->
		<div id="topknapp">
		<iframe width="280" height="160" src="https://www.youtube.com/embed/15KEqzCTrwI" frameborder="0" allowfullscreen></iframe>
		</div>
		
                

            </div>
            
            <div id="body">&nbsp;
            
                <div id="left">&nbsp;

                    <div id="date">mandag 15. april</div>
                	
                    <div class="leftnav"><a href="/">Hjem</a><br /><a href="/arkiv.aspx">Arkiv</a><br /><a href="/tabeller--terminlister.aspx">Tabeller &amp; terminlister</a><br /><a href="/kampreferat.aspx">Kampreferat</a><br /><a href="/fotballfilosofi.aspx">Fotballfilosofi</a><br /><a href="/ikke-helt-sportslig.aspx">Ikke helt sportslig</a><br /></div>
		
                    <div class="box" id="contactbox"><div class="header">Frisk Asker</div><div class="body"><a href="/frisk-asker/laget.aspx">Laget</a><br /><a href="/frisk-asker/kontakt.aspx">Kontakt</a><br /><a href="/frisk-asker/dommerhjoernet.aspx">Dommerhjørnet</a><br /><a href="https://teams.s2s.net/11225/no/" target="_new">Treningstider</a></div><div class="footer"><!----></div></div>

<!--		     <iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/standard/Verdana/14/bold/230/1&rn=84" frameborder="0" scrolling="no" width="230" height="500"></iframe>
-->
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&banner=1&system=no_no/5212/1/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/standard/Verdana/14/bold/230/1&rn=94" frameborder="0" scrolling="no" width="230" height="214"></iframe>

		     <iframe src="http://www.s2s.net/todays_skill_external.php?ccc=no" scrolling="no" width="200" height="330" frameborder="0"></iframe>
<!--
		     <div id="login">&nbsp;
                   
                    <form id="loginform" action="#">&nbsp;
                      
                        <input id="username" type="text" value="brukernavn" />
                        <input id="password" type="text" value="passord" />
                        <img src="/img/login.gif" alt="login" />
                        <a href="#">glemt passord?</a>    
                        
                    </form>
                    
                    </div>
-->
		    <div id="search">

			Artikkelsøk:<br />
			<div id="xsltsearch" xmlns:ps="urn:percipientstudios-com:xslt"><form action="/soek.aspx?" method="post" class="xsltsearch_form"><input name="search" type="text" class="input" value=""></input> <input type="submit" value="Search" class="submit" /></form></div>
		    </div>

                </div>
                
                <div id="center">
		
                    
<div class="content">

	<h1>Hvalstrand boots</h1><div class="meta">19.11.17 13:04 - Keegan</div><div class="abstract"><img src="/umbraco/imagegen.ashx?image=/media/128098/sement.png&amp;width=500" alt="" align="left" />En sann (epost-)historie</div>
<p>&nbsp;</p>

<p><span class="smaller1">Prologen <a
href="/arkiv/2017/ledig-stilling.aspx">her.</a></span></p>

<p>&nbsp;</p>

<p>De slapp lagbagen med et dunk.</p>

<p>Plankene beveget seg av sammenstøtet.</p>

<p>- Ahh, sa Alex, fanken kor tung han va.</p>

<p>Han tok et par skritt tilbake. Han strakk armen bakover og
strakk ut muskelen i skulderen.</p>

<p>Amir børstet støv av jakka. - Helsike, jeg har støv over hele
meg.</p>

<p>Turbo blåste i nevene, stakk dem i lommene på frakken, og ble
stående med vekten på begge bena. Han så bort på Figo.</p>

<p>Figo sto litt til siden for dem og fisket etter en bok i
jakkelomma.<br />
<br />
 Reodor og Brøyn slepte bagen ut på kanten, rettet seg opp, og tok
stilling litt lenger inn på brygga.</p>

<p>De sto i en halvsirkel.</p>

<p>Natten var kald og svart.</p>

<p>Månen hang over horisonten, som et stirrende øye.</p>

<p>Frostrøyken lå over vannet og dempet lyden.</p>

<p>De så på skikkelsen.</p>

<p>Trøya hang utenpå den ukurante shortsen.</p>

<p>De hvite strømpene stakk opp av sementen.</p>

<p>- La oss bli ferdige, sa Kikki. Jeg har bedre ting å drive
med.</p>

<p><em></em></p>

<p class="smaller1"><em><br />
</em> From: Carleon<em>e<br />
 Til informasjon til FAOs stabsavdeling,<br />
 Vår automatiske vaskemaskin har tatt høstvasken på FAOs
spillerliste.<br />
 Avvikerne som ikke har betalt treningsavgiften har blitt vasket ut
av FAOs elektroniske kanaler.<br />
 Når de nyvaskede har gjort opp sine forpliktelser, kan de
gjennomføre en medarbeidersamtale med seg selv om hvordan de synes
det går i arbeidet med å gjøre livet lett for staben.<br />
 Lista har ikke overraskende ett navn: Shrinky.</em><br />
<br />
</p>

<p><em></em></p>

<p>Amir tok opp en pakke med røyk og fisket ut en sigarett.</p>

<p>- My god, så lei jeg er av denne pretenderen.</p>

<p>Han tente siggen med zippo'n, før han slo lokket ned.</p>

<p>- Den evige liksom-overraskelsen. I puke.</p>

<p>&nbsp;</p>

<p>- Fader vår, du som er i himmelen, leste Figo.<em><br />
</em></p>

<p class="smaller1">&nbsp;</p>

<p class="smaller1">From: Shrinky <em><br />
 Må si jeg reagerer med sjokk og vantro over å ha havnet på en
sådan liste. Hvordan kan man gjøre livet lettere for
staben?</em></p>

<p>&nbsp;</p>

<p>Turbo kastet med nakken.</p>

<p>- Forbanna filming. There's nothing worse. Vi kjenner det igjen
når vi ser det.</p>

<p>Han spytta i vannet.</p>

<p>&nbsp;</p>

<p>- La ditt navn holdes hellig, sa Figo.<em><br />
</em></p>

<p class="smaller1"><br />
 From: Carleone<br />
 <em>Hva om du foreslår et svar selv denne gangen, Shrinky?<br />
<br />
</em> From: Shrinky <em><br />
 Det er like vanskelig å komme på svaralternativer som å forstå
bakgrunnen for at man havner på en sånn liste. Så må nesten ha litt
hjelp...</em></p>

<p><em><br />
</em> - La ditt rike komme, sa Figo.</p>

<p>&nbsp;</p>

<p>Inne på stranda kunne de se to skikkelser sittende på den blå
benken.<br />
 De kunne se Trampe med hendene i fanget, mens han sakte ristet på
hodet.</p>

<p class="smaller1">&nbsp;</p>

<p class="smaller1">From: Carleone <em><br />
 OK, du kan ringe en venn. Trampe, du er ringt av en venn...<br />
</em> <em><br />
</em> From: Trampe<em><br />
 Hmmm..<br />
 Hva har du stelt i stand nå da, junior?<br />
 Er det på grunn av ditt uregelmessige utstyr?<br />
 Manglende betaling?<br />
 Eller rett og slett at du bommer på for mange opplagte
målsjanser?</em></p>

<p>&nbsp;</p>

<p>Kikki klappet hanskene mot hverandre. Han så spørrende bort på
Figo.</p>

<p>- La din vilje skje på jorden som i himmelen.</p>

<p>Kikki satte den ene foten mot kanten av bagen.<em><br />
</em></p>

<p class="smaller1"><em><br />
</em> From: Trampe <em><br />
 Hva er årsaken denne gangen? Fra min klient: "Jeg har betalt
avgiften. Det er vaffall sikkert. Hvis det er kvittering de
trenger, bistår jeg gjerne."</em></p>

<p>&nbsp;</p>

<p>Reodor dro lua lenger ned over ørene.</p>

<p>- En gang kjøpte jeg en pose poteter hvor alle var råtne, sa
han.</p>

<p>- Da jeg hadde skrella den første og så at den var råtten, så
skrellet jeg en til. Da den også var råtten, skrellet jeg enda en.
Sånn holdt jeg på, helt til posen var tom, og alle de råtne
potetene var skrelt.</p>

<p>Kikki så på ham med mysende blikk.</p>

<p>- Hvorfor var du en sånn dust?</p>

<p>- Jeg trodde det skulle bli bedre.</p>

<p>Reodor gikk frem, løftet den ene foten, og satte den på kanten
av bagen.</p>

<p>&nbsp;</p>

<p>- Gi oss i dag vårt daglige brød, sa Figo.</p>

<p><em><br />
</em></p>

<p><em></em></p>

<p class="smaller1">From: Carleone <em><br />
 Reodor, vil du dobbeltsjekke om vi har fått en innbetaling
likevel, eller kan Shrinky ha betalt til feil konto….?<br />
</em> <em><br />
</em> From: Reodor <em><br />
 Dobbeltsjekken har ikke avdekket noen ny informasjon angående
saken.</em></p>

<p><em></em></p>

<p class="smaller1">From: Carleone <em><br />
 Til sakfører Trampe,<br />
 1. Det er lovende at klienten i det minste har begynt å respondere
på henvendelser.<br />
 2. Siden det er innenfor rimelig tvil at klienten kan ha
<strong>trodd</strong> at han har betalt treningsavgiften, er
sanksjonene opphevet, og klienten er lagt til med alle rettigheter
på FAO igjen.<br />
 Klienten får sende kvitteringen til kasserer Reodor, så vi finner
ut hvor betalingen har tatt veien, siden den ikke fremkommer på
noen av FAOs kontoer på Seychellene.</em></p>

<p>&nbsp;</p>

<p>Alex trakk ned glidelåsen på jakka.</p>

<p>- Å væra stor i kjeften, er ein kunst, sa han. - Å brøle når du
berre er ei mus, er utilgjeveleg. Det å væra storkjefta krever sin
mann. Spør den beste.</p>

<p>Han løftet albuene opp og dro dem frem og tilbake mens han
dreide kroppen fra side til side, som om han varmet opp.</p>

<p>Så tok han et steg frem og stemplet foten ned på kanten av
bagen.</p>

<p>&nbsp;</p>

<p>- Forlat oss vår skyld, som vi òg forlater våre skyldnere, sa
Figo.</p>

<p><em><br />
</em></p>

<p class="smaller1">From: Trampe<em><br />
 Se utskrift fra min klient sin nettbank. Min klient sier han nå
forventer en kompensasjon etter alle disse ubehagelighetene og
merarbeidet dette har medført for ham.</em></p>

<p><br />
 Brøyn kikket over kanten.</p>

<p>Så gikk han bort til bagen, og kakket med hælen i sementen.</p>

<p>- Størknet fint, sa han.</p>

<p>Han satte foten ned på toppen, og støtet hælen inn mot kanten,
og sto med strak vrist. Han puttet hendene i lommene, og så bort på
Figo.</p>

<p><br />
 - Led oss ikke inn i fristelse, sa Figo.<em><br />
</em></p>

<p class="smaller1"><br />
 From: Carleone<br />
 <em>Du gjør et solid arbeid som støttekontakt, Trampe. Vi nærmer
oss noe nå. Jeg kjenner godt igjen den følelsen av å drive med
unødvendig merarbeid.<br />
 For å ta det hele fra starten, så har vi aldri fått respons på
våre utallige henvendelser om at klienten ikke har betalt. Til
slutt ble denne tvilsomme dokumentasjonen halt ut.<br />
 For det andre: Dokumentasjonen viser at klienten har betalt
overgangsgebyret som alle andre nye spillere. Dette har
<strong>ingenting</strong> med treningsavgiften å gjøre.<br />
 Gjør din klient med vilje arbeidet vanskelig for andre?<br />
 Kanskje ikke.<br />
 Men han er et surrehue.<br />
 Administrasjonen bruker like mye tid på ham alene som på alle de
35 andre spillerne til sammen.<br />
 Jeg følger deg helt på tanken om større bruk av
konsekvenser.<br />
 Din klient kan nå gjøre følgende:<br />
 1. Betal omgående.<br />
 2. Sett opp en tiltaksplan for hvordan han skal klare livet som
selvstendig oldboysspiller.<br />
 Klienten står i fare for å oppfattes som at han går i et personlig
demonstrasjonstog mot alle beskjeder.<br />
 For ordens skyld: Reaksjonen med utestengelsen fra
kommunikasjonskanalene var bare den første represalien, og den er
nå oppbrukt.<br />
 Neste gang vil vi enten slippe Brøyn løs fra kjettingen, eller
starte sementblanderen.<br />
 Vi har fortsatt troen på det gode i alle mennesker, men ørkenen er
full av dem…<br />
 To your health</em></p>

<p><br />
 Amir blåste ut røyken og knipset sneipen i vannet.</p>

<p>Han dro skjerfet tettere rundt halsen.</p>

<p>- Så mye dill.</p>

<p>Han satte tuppen av den ene skoa inn mot bagen.</p>

<p>- På Balkan hadde vi løst det raskere.</p>

<p>&nbsp;</p>

<p>- Frels oss fra det onde, sa Figo.<em><br />
</em></p>

<p>&nbsp;</p>

<p class="smaller1">From: Trampe&nbsp; <em><br />
 Håper maten og drikken smakte på festen på lørdag. Skulle gjerne
ha vært der, men følte jeg ikke kunne stille på grunn av denne
pågående konflikten. &nbsp;Da min klient trolig har vanskeligheter
med å lese så mye tekst før han blir distrahert av et eller annet,
kan du skrive beløp og kontonummer.<br />
 Ha en nydelig dag.</em></p>

<p class="smaller1">From: Carleone <em><br />
 Det er proft å ikke feste med motparten mens konflikt pågår.<br />
 For siste gang: 750 kr. Til Reodors lagkonto.<br />
 Ser frem til å møtes under normale omstendigheter igjen.</em></p>

<p><br />
 Turbo tok hendene ut av lommene på frakken og gikk frem.</p>

<p>Han så på bagen.</p>

<p>- Jeg har alltid lurt på hva som er verst, sa han. - Er det
verst å være en stokke idiot, eller å late som at man er det?</p>

<p>Han tok tak i bukselåret, trakk det opp, og satte foten på
bagen.</p>

<p>&nbsp;</p>

<p>- For riket er ditt.</p>

<p><em><br />
</em></p>

<p class="smaller1">From: Reodor, én måned senere<em><br />
 Status quo.</em></p>

<p class="smaller1"><br />
 From: Carleone<br />
 <em>Er det mulig...<br />
 Say goodbye to my little friend.</em></p>

<p>&nbsp;</p>

<p>- Og makten og æren i evighet.</p>

<p>&nbsp;</p>

<p>Inne på stranda hadde Trampe reist seg fra benken.<br />
 Han ristet sakte på hodet, mens han så utover mot dem. Så trakk
han på skuldrene, snudde seg, og begynte å gå oppover mot
parkeringsplassen.</p>

<p>&nbsp;</p>

<p class="smaller1">From: Carleone<br />
 <em>På treningen i går kom det for dagen at vår spiller Shrinky
vanvittig nok enda ikke har betalt treningsavgiften.<br />
 Han har allerede fått gult kort, og blir nå den første spilleren i
historien til å vise så lite respekt for FAO at han oppnår oransje
nivå på våre mafiasanksjoner.<br />
 Kjennelse i FAOs Domsutvalg:<br />
 Shrinky fjernes på nytt fra kommunikasjonskanalene, det er
åpenbart.<br />
 I tillegg kan han ikke delta på FAOs treninger eller
arrangementer.<br />
 Det holder heller ikke nå å bare betale treningsavgiften, som
ville vært tilstrekkelig på gult nivå.<br />
 Skal han få opphevet sanksjonene på oransje nivå, må han først ha
en medarbeidersamtale og overbevise oss om at han ikke vil
fortsette sin disrespekt av FAO.<br />
 Så må han betale treningsavgiften for tre år.</em></p>

<p class="smaller1">From: Trampe&nbsp; <em><br />
 Tror han må finne seg en ny forsvarer.... Jeg sier opp.</em></p>

<p>&nbsp;</p>

<p>Figo senket boka.</p>

<p>Han samlet hendene foran seg og trakk pusten.</p>

<p>- Shrinky, sa han.</p>

<p>- Du har nå en aller siste sjanse til å begynne å vise oss
respekt. Mitt råd til deg er å ikke fornærme intelligensen vår.
Tenk gjennom hva som er ditt svar.</p>

<p><em><br />
</em></p>

<p class="smaller1">From: Shrinky<br />
 <em>Det var da voldsomt mas da!!!<br />
 Sånn, nå har jeg vippsa den avgiften på 750 kroner.<br />
 Hva blir det neste, avgifter for oksygeninntak?</em></p>

<p><em><br />
</em></p>

<p><em></em></p>

<p>De så på Figo.</p>

<p>Figo så inn på stranden.</p>

<p>Han tok et steg tilbake.</p>

<p>&nbsp;</p>

<p>- Amen.</p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p><em><br />
</em></p>



<div class="addthis_toolbox addthis_default_style">
<a href="http://www.addthis.com/bookmark.php?v=250&amp;username=xa-4be09cd0025b8da5" class="addthis_button_compact">Share</a>
<span class="addthis_separator">|</span>
<a class="addthis_button_facebook"></a>
<a class="addthis_button_myspace"></a>
<a class="addthis_button_google"></a>
<a class="addthis_button_twitter"></a>
</div>
<script type="text/javascript" src="http://s7.addthis.com/js/250/addthis_widget.js#username=xa-4be09cd0025b8da5"></script>
<!-- AddThis Button END -->

<hr>
<h2>Kommentarer:</h2>
	
<!--
<p>
<b>Kommentering er midlertidig steng pga SPAM!</b>
</p>
-->
<form method="post" action="hvalstrand-boots.aspx" id="aspnetForm">
<div>
<input type="hidden" name="__EVENTTARGET" id="__EVENTTARGET" value="" />
<input type="hidden" name="__EVENTARGUMENT" id="__EVENTARGUMENT" value="" />
<input type="hidden" name="__VIEWSTATE" id="__VIEWSTATE" value="/wEPDwUENTM4MQ9kFgJmD2QWAmYPZBYCZg9kFgJmD2QWAgIPD2QWAgIFD2QWAgIBD2QWAmYPZBYCAgIPZBYCAgEPFgIeBFRleHQFF0RpbiBrb21tZW50YXIgZXIgcG9zdGV0ZGTP3+kahhm7HkFLDJ1eDASlO9mxvA==" />
</div>

<script type="text/javascript">
//<![CDATA[
var theForm = document.forms['aspnetForm'];
if (!theForm) {
    theForm = document.aspnetForm;
}
function __doPostBack(eventTarget, eventArgument) {
    if (!theForm.onsubmit || (theForm.onsubmit() != false)) {
        theForm.__EVENTTARGET.value = eventTarget;
        theForm.__EVENTARGUMENT.value = eventArgument;
        theForm.submit();
    }
}
//]]>
</script>


<script src="/WebResource.axd?d=RhJRe7vAQjxLvd0VTiPlJ3ItrtWKNnlC5ndUOdQ1oQE84Jw0mmyu8t9423FKr6Sh25O1JfgygCRLDXncXNuX2rijfWY1&amp;t=635737087099672665" type="text/javascript"></script>


<script type="text/javascript">
//<![CDATA[
function insertLink(element) {var theLink = prompt('Enter URL for link here:','http://');insertTag(element, 'a', ' href="' + theLink + '"')}
            function insertTag(element, tag, param) {
            start = '<' + tag + param + '>';
            eind = '</' + tag + '>';
             /* element = document.getElementById(element); */
              if (document.selection) {
                element.focus();
                sel = document.selection.createRange();
                sel.text = start + sel.text + eind;
              } else if (element.selectionStart || element.selectionStart == '0') {
                element.focus();
                var startPos = element.selectionStart;
                var endPos = element.selectionEnd;
                element.value = element.value.substring(0, startPos) + start + element.value.substring(startPos, endPos) + eind + element.value.substring(endPos, element.value.length);
              } else {
                element.value += start + eind;
              }
            }
            //]]>
</script>

<h2>Post en kommentar:</h2>
<div id="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_PanelInput">
	
	<div id="umbracoAutoForm">
	
  <fieldset>
			<p><label for="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_navn">Navn:</label><input name="ctl00$ctl00$ctl00$ContentPlaceHolderDefault$MainContentPlaceHolder$AutoForm_7$navn" type="text" id="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_navn" class="umbEditorTextField" /></p><p><label for="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_epost">Epost:</label><input name="ctl00$ctl00$ctl00$ContentPlaceHolderDefault$MainContentPlaceHolder$AutoForm_7$epost" type="text" id="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_epost" class="umbEditorTextField" /></p><p><label for="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_kommentar">Kommentar:</label><table border="0" cellspacing="0" cellpadding="0"><tr><td>
	<p align="right" style="margin: 0px; padding:0px"><a href="javascript:insertLink(document.getElementById('ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_kommentar'))"><img src="/umbraco_client/simpleEditor/images/link.gif" border="0" align="right" /></a><a href="javascript:insertTag(document.getElementById('ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_kommentar'), 'em', '')"><img src="/umbraco_client/simpleEditor/images/italic.gif" border="0" style="margin-left: 3px; margin-right: 3px;" align="right" /></a> <a href="javascript:insertTag(document.getElementById('ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_kommentar'), 'strong', '')"><img src="/umbraco_client/simpleEditor/images/bold.gif" border="0" align="right" /></a><br/></p>
	<textarea name="ctl00$ctl00$ctl00$ContentPlaceHolderDefault$MainContentPlaceHolder$AutoForm_7$kommentar" rows="8" cols="20" id="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_kommentar" class="umbEditorTextField"></textarea></td></tr></table>
	</p><p><label for="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_captcha">Captcha:</label><input name="ctl00$ctl00$ctl00$ContentPlaceHolderDefault$MainContentPlaceHolder$AutoForm_7$captcha" type="text" id="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_captcha" class="umbEditorNumberField" /><br/><span class="umbracoAutoFormRowDescription">Hva er elleve pluss åtte?<br/></span></p>
		<p><input type="submit" name="ctl00$ctl00$ctl00$ContentPlaceHolderDefault$MainContentPlaceHolder$AutoForm_7$Button1" value="Post kommentar" onclick="javascript:WebForm_DoPostBackWithOptions(new WebForm_PostBackOptions(&quot;ctl00$ctl00$ctl00$ContentPlaceHolderDefault$MainContentPlaceHolder$AutoForm_7$Button1&quot;, &quot;&quot;, true, &quot;&quot;, &quot;&quot;, false, false))" id="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_Button1" class="umbracoAutoFormButton" /></p>
	</fieldset>		
	</div>

</div>

		

<div>

	<input type="hidden" name="__VIEWSTATEGENERATOR" id="__VIEWSTATEGENERATOR" value="CA0B0334" />
</div></form>

<a class="readmore" href="/arkiv/2021/frisk-asker---covid-19-19-.aspx">Frisk Asker - Covid 19-19 </a> - 17.03.2021 8:41<br /><a class="readmore" href="/arkiv/2016/faos-sommerkrim.aspx">FAOs sommerkrim</a> - 29.04.2020 12:32<br /><a class="readmore" href="/arkiv/2019/fao-med-kupp-paa-overgangsmarkedet!.aspx">FAO med kupp på overgangsmarkedet!</a> - 30.07.2019 19:24<br /><a class="readmore" href="/arkiv/2019/dag-ansatt-som-fast-lagleder-paa-frisk-asker-m33.aspx">Dag ansatt som fast lagleder på Frisk Asker M33</a> - 29.07.2019 12:28<br /><a class="readmore" href="/arkiv/2019/askermesterskapet-i-oldboysfotball.aspx">Askermesterskapet i oldboysfotball</a> - 07.05.2019 16:49<br /><a class="readmore" href="/arkiv/2019/frisk-asker-oldgirls!.aspx">Frisk Asker OldGIRLS!</a> - 05.04.2019 14:14<br /><a class="readmore" href="/arkiv/2019/know-your-enemy.aspx">Know your enemy</a> - 01.02.2019 16:46<br /><a class="readmore" href="/arkiv/2018/pass-paa-liten-og-paa-stor.aspx">Pass på liten og på stor</a> - 21.09.2018 15:21<br /><a class="readmore" href="/arkiv/2018/nedrykk!.aspx">Nedrykk!</a> - 14.09.2018 14:40<br /><a class="readmore" href="/arkiv/2018/lukten-av-gull!.aspx">Lukten av gull!</a> - 07.09.2018 22:27<br />
<br/><br/>
<!--
<table id="forumposts" cellspacing="0"><tr><th colspan="2">Siste publiserte fra Sekreteriatet</th></tr><tr><td><b><a class="readmore" href="/sekreteriatet/kamprutine.aspx">Kamprutine</a> - </b>12.06.14 01:36</td></tr><tr><td><b><a class="readmore" href="/sekreteriatet/kamp-mot-bygdoe-monolitten---hvem-stiller.aspx">Kamp mot Bygdø Monolitten - hvem stiller?</a> - </b>12.09.12 09:23</td></tr><tr><td><b><a class="readmore" href="/sekreteriatet/kamp-mot-huk---hvem-stiller-(1).aspx">Kamp mot Huk - hvem stiller? (1)</a> - </b>04.09.12 10:04</td></tr><tr><td><b><a class="readmore" href="/sekreteriatet/kamp-mot-lokomotiv-oslo-29-aug---hvem-stiller.aspx">Kamp mot Lokomotiv Oslo 29. aug - hvem stiller?</a> - </b>28.08.12 02:56</td></tr><tr><td><b><a class="readmore" href="/sekreteriatet/kamp-mot-aarvoll-ons-15-aug---hvem-stiller.aspx">Kamp mot Årvoll ons 15. aug - Hvem stiller?</a> - </b>13.08.12 12:50</td></tr><tr><td class="footer" colspan="2"> </td></tr></table>
-->
</div>



                </div>
                
		 <div id="right">

<font color="red" size="4">Lagbilde</font><br/>


<!--a href="http://oldboys.friskasker.no/media/116678/formkurve.png" border=0><img src="/media/116678/formkurve.png" width="280" alt="Formkurve" /></a-->
<!--iframe src="http://free.timeanddate.com/countdown/i5t3zil3/n187/cf113/cm0/cu4/ct0/cs0/ca0/cr0/ss0/cac000/cpc000/pc00e60b/tc000/fs100/szw320/szh135/tatFAO%20h%C3%B8stsesong%20starter%20om../tac000/tptTime%20since%20Event%20started%20in/tpc000/mac000/mpc000/iso2017-08-14T21:00:00" allowTransparency="true" frameborder="0" width="320" height="135"></iframe-->
	<!--iframe frameborder="0" width="512" height="600" scrolling="auto" allowtransparency="true" src="https://risengaj96.polldaddy.com/s/fao-plassering-pr-lag-2018?iframe=1"><a href="https://risengaj96.polldaddy.com/s/fao-plassering-pr-lag-2018">View Survey</a></iframe-->
<br/>
<!-- FORMkurve iframe width="508" height="371" seamless frameborder="0" scrolling="no" src="https://docs.google.com/spreadsheets/d/1wL8AGtLu517MG4vlWG2DIat7LmhdKaJdXz4nDVsxc74/pubchart?oid=1826601090&amp;format=interactive"></iframe-->

<!-- iphone
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/iphone/Verdana/14/bold/250/1&rn=7" frameborder="0" scrolling="no" width="250" height="500"></iframe>
-->
	<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/iphone/Verdana/14/bold/280/1&rn=83" frameborder="0" scrolling="no" width="280" height="500"></iframe>
<!--
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/21/ae82202846179cbfa34c266edf916f37&colours=FF8C00/CCCCCC/FFF/4/standard/Comic+Sans+Serif/16/bold/280/1&rn=22" frameborder="0" scrolling="no" width="280" height="500"></iframe>
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/members&bits=25/21/ae82202846179cbfa34c266edf916f37&colours=FF8C00/CCCCCC/FFF/4/standard/Comic+Sans+Serif/16/bold/280/1&rn=50" frameborder="0" scrolling="no" width="280" height="500"></iframe>
-->
<!-- iframe src="https://www.s2s.net/export_content.php?team_id=1101&system=no_no/1032/2/one/activities&bits=25/21/68565729bae64238443339aae6dcf62c&colours=FF6600/000099/FFF/0/iphone/Verdana/12/bold/280/0" frameborder="0" scrolling="no" width="280" height="500"></iframe -->

<br/><br/>
<a href="http://www.forstehjelpsgrossisten.no/products/is-pose-stor-14-x-21-cm-i-kartong-av-24-stk" border="0" target="_new"><img src="/umbraco/imagegen.ashx?image=/media/114144/forstehjelpsgrossistem.png&width=280"></a>
<br/>
<div style="text-align: left; width:280px;">Stolt sponsor av Frisk Asker Oldboys!</div>

                                        
                </div>

            </div>
            
        </div>
	<div id="bottomad"><!-- Bunnbanner -->
<!--
<script type="text/javascript">
var uri = 'http://impno.tradedoubler.com/imp?type(js)g(17626798)a(1588386)' + new String (Math.random()).substring (2, 11);
document.write('<sc'+'ript type="text/javascript" src="'+uri+'" charset=""></sc'+'ript>');
</script>
-->
<a href="http://www.google.com" target="_blank">.</a>
<a href="http://www.google.com/search?q=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://www.yahoo.com" target="_blank">.</a>
<a href="http://search.yahoo.com/search?p=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://search.aol.co.uk" target="_blank">.</a>
<a href="http://search.aol.co.uk/aol/search?query=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://uk.ask.com" target="_blank">.</a>
<a href="http://uk.ask.com/web?q=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://search.live.com" target="_blank">.</a>
<a href="http://search.live.com/results.aspx?q=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://search.lycos.co.uk" target="_blank">.</a>
<a href="http://search.lycos.co.uk/cgi-bin/pursuit?SITE=uk&query=frisk+asker+oldboys" target="_blank">.</a>

	</div>

<script type="text/javascript">
var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
</script>
<script type="text/javascript">
var pageTracker = _gat._getTracker("UA-2025203-1");
pageTracker._initData();
pageTracker._trackPageview();
</script></body>
</html>
