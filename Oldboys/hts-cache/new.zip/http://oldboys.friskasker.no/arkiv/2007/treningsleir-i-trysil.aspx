
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">

	<head>

		<title>Treningsleir i Trysil  - Frisk Asker Oldboys</title>
		
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
		<meta http-equiv="imagetoolbar" CONTENT="no">
		<meta name="keywords" content="" />
		<meta name="description" content="Etter som treningsleir i Trysil på rekordraskt vis har blitt en tradisjon, holder vi oss til standard program...." />
		
		<meta name="title" content="Treningsleir i Trysil - Frisk Asker Oldboys" />
		<meta name="URL" content="http://oldboys.friskasker.no" />
		<meta name="language" content="Norsk" />
		<meta name="author" content="Terje Dahl" />
		<meta name="copyright" content="Frisk Asker Oldboys" />
		<meta name="reply-to" content="terjda@online.no" />
		<meta name="verify-v1" content="BxVdMcZ0uoa2KVw8RB+FBg3715LgSDXNG+RYp0gHpAI=" />

		<link type="text/css" href="/css/client.css" rel="stylesheet" />
		<link type="text/css" href="/css/default.css" rel="stylesheet" />
		<link type="text/css" href="/css/weatherCSS.css" rel="stylesheet" />

		<script type="text/javascript" src="/js/jquery.js"></script>
		<script type="text/javascript" src="/js/ufo.js"></script>
		<script type="text/javascript" src="/js/friskasker.js"></script>
		<!--script type='text/javascript' src='http://www.rdmtech.no/js/jquery.js?ver=1.2.6'></script-->
		<!--script type='text/javascript' src='http://www.rdmtech.no/js/jquery.cross-slide.js?ver=2.6'></script-->

		<!--[if IE 6]>
		<link type="text/css" href="/css/ie60.css" rel="stylesheet" />			
		<![endif]-->
		<!-- TradeDoubler site verification 1588386 --> 

	<script type='text/javascript'>
		jQuery(function($) {$(document).ready(function() {
			$('#container2').crossSlide(
				{sleep: 2, fade: 1},
				[{src: 'http://oldboys.friskasker.no/media/26561/bg-fao1.jpg'},{src: 'http://oldboys.friskasker.no/media/26566/bg-fao2.jpg'},{src: 'http://oldboys.friskasker.no/media/26571/bg-fao3.jpg'},{src: 'http://oldboys.friskasker.no/media/26576/bg-fao4.jpg'}]
			);
		});});
	</script>
	
<script type="text/javascript">
var _polldaddy = [] || _polldaddy;

_polldaddy.push( {
    type: 'slider',
    title: 'FAO-spillemodellen, skjønner du den?',
    body: 'Ta testen og bidra til å øke sjansen for sportslig utvikling av FAO!',
    button: 'Get Started &raquo;',
    domain: 'risengaj96.polldaddy.com/s/',
    id: 'fao-spillemodellen',
    placeholder: 'pd1438692132734'
} );

jQuery(function(d,c,j){$if(!document.getElementById(j)){var pd=d.createElement(c),s;pd.id=j;pd.src=('https:'==document.location.protocol)?'https://polldaddy.com/survey.js':'http://i0.poll.fm/survey.js';s=document.getElementsByTagName(c)[0];s.parentNode.insertBefore(pd,s);}}(document,'script','pd-embed'));
</script>

	
	</head>
	
	<body>
      
        <div id="container">&nbsp;
        
            <div id="header">&nbsp;
            
                <div id="logo"><a href="/"><img src="/media/26597/logos.gif" alt="Logo" /></a></div>
                <div id="rss"><a href="/data/rss/nyheter.xml">Motta RSS strøm</a></div>
		<!--div id="sitemap"><a href="/sitemap.aspx">Sitemap</a></div-->
		<div id="topknapp">
		<iframe width="280" height="160" src="https://www.youtube.com/embed/15KEqzCTrwI" frameborder="0" allowfullscreen></iframe>
		</div>
		
                

            </div>
            
            <div id="body">&nbsp;
            
                <div id="left">&nbsp;

                    <div id="date">mandag 15. april</div>
                	
                    <div class="leftnav"><a href="/">Hjem</a><br /><a href="/arkiv.aspx">Arkiv</a><br /><a href="/tabeller--terminlister.aspx">Tabeller &amp; terminlister</a><br /><a href="/kampreferat.aspx">Kampreferat</a><br /><a href="/fotballfilosofi.aspx">Fotballfilosofi</a><br /><a href="/ikke-helt-sportslig.aspx">Ikke helt sportslig</a><br /></div>
		
                    <div class="box" id="contactbox"><div class="header">Frisk Asker</div><div class="body"><a href="/frisk-asker/laget.aspx">Laget</a><br /><a href="/frisk-asker/kontakt.aspx">Kontakt</a><br /><a href="/frisk-asker/dommerhjoernet.aspx">Dommerhjørnet</a><br /><a href="https://teams.s2s.net/11225/no/" target="_new">Treningstider</a></div><div class="footer"><!----></div></div>

<!--		     <iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/standard/Verdana/14/bold/230/1&rn=84" frameborder="0" scrolling="no" width="230" height="500"></iframe>
-->
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&banner=1&system=no_no/5212/1/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/standard/Verdana/14/bold/230/1&rn=94" frameborder="0" scrolling="no" width="230" height="214"></iframe>

		     <iframe src="http://www.s2s.net/todays_skill_external.php?ccc=no" scrolling="no" width="200" height="330" frameborder="0"></iframe>
<!--
		     <div id="login">&nbsp;
                   
                    <form id="loginform" action="#">&nbsp;
                      
                        <input id="username" type="text" value="brukernavn" />
                        <input id="password" type="text" value="passord" />
                        <img src="/img/login.gif" alt="login" />
                        <a href="#">glemt passord?</a>    
                        
                    </form>
                    
                    </div>
-->
		    <div id="search">

			Artikkelsøk:<br />
			<div id="xsltsearch" xmlns:ps="urn:percipientstudios-com:xslt"><form action="/soek.aspx?" method="post" class="xsltsearch_form"><input name="search" type="text" class="input" value=""></input> <input type="submit" value="Search" class="submit" /></form></div>
		    </div>

                </div>
                
                <div id="center">
		
                    
<div class="content">

	<h1>Treningsleir i Trysil</h1><div class="meta">15.01.08 18:21 - Figo</div><div class="abstract"><img src="/umbraco/imagegen.ashx?image=/media/16044/velkommen.jpg&amp;width=500" alt="" align="left" />Etter som treningsleir i Trysil på rekordraskt vis har blitt en tradisjon, holder vi oss til standard program....</div><p> </p>

<p> </p>

<p> </p>

<p> </p>

<p> </p>

<p> </p>

<p><strong>Program for treningsleir</strong> (kan forandres på kort varsel ved humørfylte innfall fra deltagerne)</p>

<p><strong>Fredag</strong></p>

<p>Avreise Asker kl.?? (sjåførene bestemmer)</p>

<p>Ankomst Trysil 3 timer senere</p>

<p>Installering på rommene (dyner og puter er på plass - ta med eget sengetøy)</p>

<p>Middag/kveldsmat - &quot;Erter, kjøtt og flesk&quot;</p>

<p>Kortleik/sosialt samvær</p>

<p>Natta</p>

<p> </p>

<p><strong>Lørdag</strong></p>

<p>Kl.10:00  Frokost</p>

<p>Kl.11:30  Avreise fra Setra (minibuss)</p>

<p>Kl.13:00  Fotballkamp mot 5.div laget Trysil FK (kunstgress)</p>

<p>Kl.14:30  Transport til Østby</p>

<p>Kl.15:00  Badstue (Østby)</p>

<p>Kl.16:30  Transport tilbake til setra</p>

<p>Kl.18:30  Middag (æljgryte)</p>

<p>Kl …….   Sosialt samvær</p>

<p>Kl.03:00  Årsmøte Frisk Asker oldboys</p>

<p> </p>

<p><strong>Søndag</strong></p>

<p>Kl.11:00  Frokost</p>

<p>Deretter er det fritt valg og opp til hver mann/bil hva man vil benytte søndagen til og når man måtte ønske å vende nesa hjemover.</p>

<p> </p>

<p><strong>Forslag til aktiviteter på søndag:</strong></p>

<p>·    Sitte i solveggen og skryte/ljuge litt</p>

<p>·    Ta en tur på bortoverski (løypa er rett utenfor)</p>

<p>·    Alpine aktiviteter i Trysilfjellet</p>

<p>·    Nybergsund spiller hjemmekamp mot Haugesund</p>

<p> </p>

<p><strong>Ta med:</strong></p>

<p>·    Laken, dynetrekk og putevar</p>

<p>·    Tøfler/tykke sokker (gulvkaldt)</p>

<p>·    Fotballutstyr</p>

<p>·    Pokerkoffert (Bønna &amp; Stian K)</p>

<p>·    Godt humør</p>

<p> </p>

<p><strong>Til info:</strong></p>

<p>·    Det er bilvei helt frem til døra så man behøver ingen ski eller truger med mindre man faktisk har tenkt seg ut på tur.</p>

<p>·    Det er utedo (for sarte sjeler)</p>

<p>·    Sjåførene behøver bare kjøre strekningene Asker-Trysil-Asker, all transport lokalt blir arrangert</p>

<p>·    Vi kjører en &quot;all inclusive&quot; variant så ingen behøver å tenke på innkjøp av mat og drikke (med mindre man har glutenallergi eller andre særegenheter)</p>

<p>·    Alle tider oppgitt i programmet er &quot;cirka-tider&quot; og variasjoner på opptil 15.minutter kan forekomme ved spesielle uforutsette hendelser.</p>

<p> </p>




<div class="addthis_toolbox addthis_default_style">
<a href="http://www.addthis.com/bookmark.php?v=250&amp;username=xa-4be09cd0025b8da5" class="addthis_button_compact">Share</a>
<span class="addthis_separator">|</span>
<a class="addthis_button_facebook"></a>
<a class="addthis_button_myspace"></a>
<a class="addthis_button_google"></a>
<a class="addthis_button_twitter"></a>
</div>
<script type="text/javascript" src="http://s7.addthis.com/js/250/addthis_widget.js#username=xa-4be09cd0025b8da5"></script>
<!-- AddThis Button END -->

<hr>
<h2>Kommentarer:</h2>
	<div class="newsitem"><i><b>16.01.08 15:46 - <a href="mailto:stian.v.klausen@summit.no">StianK</a></b></i><p>Alternativ 1 : Allerede avklart med "sjefen"</p></div><div class="newsitem"><i><b>16.01.08 15:46 - <a href="mailto:hofslijanerik@yahoo.com">Jan Erik</a></b></i><p>Alternativ 2, evt 4
per dags dato.</p></div><div class="newsitem"><i><b>16.01.08 21:42 - <a href="mailto:">Bønna</a></b></i><p>Alternativ 2 eller 4 for meg!</p></div><div class="newsitem"><i><b>18.01.08 9:05 - <a href="mailto:">StB</a></b></i><p>Alt 2,3 eller 4 for meg (1 går ikke)</p></div><div class="newsitem"><i><b>21.01.08 0:14 - <a href="mailto:">Thomas D</a></b></i><p>Alt 1, 2 og 3 passer foreløpig.</p></div><div class="newsitem"><i><b>22.01.08 9:28 - <a href="mailto:">StB</a></b></i><p>Ingen avklaring ennå? - nye avtaler er gjort, og alternativ 2 og 4 er det som går for meg nå.</p></div><div class="newsitem"><i><b>22.01.08 11:03 - <a href="mailto:">Figo</a></b></i><p>1 gangs purring sendt! Alternativ 2 har pekt seg ut så langt, men det er mange potensielle førstegangsvelgere som kan forandre på det.</p></div><div class="newsitem"><i><b>22.01.08 11:08 - <a href="mailto:tarmo@quickbar.no">tarmo</a></b></i><p>Alternativ 2, hvis jeg er i Asker.</p></div><div class="newsitem"><i><b>22.01.08 11:33 - <a href="mailto:">Terje</a></b></i><p>jaja da setter jeg opp alternativ 1-4 foreløpig. En av helgen går kanskje bort i hyttetur til Trysil, men hvilken er ikke avgjort enda.</p></div><div class="newsitem"><i><b>22.01.08 12:20 - <a href="mailto:">Erlend </a></b></i><p>Alt 2 og 3</p></div><div class="newsitem"><i><b>22.01.08 12:23 - <a href="mailto:jan.brenna@telenor.com">Jan Brenna</a></b></i><p>Alternativ 1,2,eller 4</p></div><div class="newsitem"><i><b>22.01.08 20:34 - <a href="mailto:">Figo</a></b></i><p>Da konkluderer vi med at alternativ nr.2 vant suverent og setter datoen for treningsleir til helgen 11-13 april.</p></div><div class="newsitem"><i><b>22.01.08 22:40 - <a href="mailto:">Terje</a></b></i><p>Hurra! da blir det hyttetur!!</p></div><div class="newsitem"><i><b>23.01.08 0:59 - <a href="mailto:trojoh6@online.no">trond</a></b></i><p>tror mange av dere tuller. vitsen er at det er snø fremdeles. skjønner det ikke er lett. Bare tenk at det er dere som  bestemmer. Ikke kjerringene deres.  </p></div><div class="newsitem"><i><b>23.01.08 8:47 - <a href="mailto:"></a></b></i><p>Da har jeg 10 mann på blokken;
Jan Erik -
Bønna -
Thomas D -
Stian B -
Tarmo -
Erlend -
Jan -
Terje -
Trond -
Figo -

Stian K - jeg håper du kan selv om det ikke ble førstevalget ditt.
For resten av spillerne: gjør en innsats på hjemmebane og bli med!
</p></div><div class="newsitem"><i><b>23.01.08 12:48 - <a href="mailto:">Terje</a></b></i><p>Trond: ikke tøff deg sånn!</p></div><div class="newsitem"><i><b>23.01.08 15:21 - <a href="mailto:stian.v.klausen@summit.no">StianK</a></b></i><p>Jeg er med også 11-13.04</p></div><div class="newsitem"><i><b>24.01.08 12:08 - <a href="mailto:">StB</a></b></i><p>BRAVO - formen kan bygges opp på treninger på Føyka tirsdager og lørdager!</p></div><div class="newsitem"><i><b>24.01.08 12:11 - <a href="mailto:">Terje</a></b></i><p>Figo : ..husker det var nevnt noe om å sette opp en innekamp med de lokale heltene, er det fortsatt planen?</p></div><div class="newsitem"><i><b>25.01.08 8:15 - <a href="mailto:">Figo</a></b></i><p>Programmet er ikke satt enda. Men i vårsola i april så blir det vel på kunstgress utendørs tenker jeg.
Fullt program kommer først i mars.</p></div><div class="newsitem"><i><b>30.01.08 10:02 - <a href="mailto:">Terje</a></b></i><p>Nå er jeg klar, har øvd meg litt på poker og fikk denne: <a href="http://oldboys.friskasker.no/bilder/diverse/royal-stright-flush.aspx">Royal Stright Flush</a> (sjekk i chattevinduet til høyre) for aller første gang!</p></div><div class="newsitem"><i><b>31.01.08 2:06 - <a href="mailto:">Terje</a></b></i><p>..noen som blir med å spiller poker eller?</p></div><div class="newsitem"><i><b>31.01.08 13:19 - <a href="mailto:stian.v.klausen@summit.no">StianK</a></b></i><p>På turen mener du, eller før ? Hvor var RSF'en ?</p></div><div class="newsitem"><i><b>31.01.08 18:05 - <a href="mailto:">Terje</a></b></i><p>Jeg mente vel egentlig der og da. Satt oppe og ikke fikk sove og var sugen på noe poker.<br/>
monsterhånden var på på <b><a href="http://www.nordicbet.com/" target="_new">NordicBet</a></b>..<br/><br/>
Ellers er jeg alltid klar for litt spill både her og der og spesielt på hyttetur.</p></div><div class="newsitem"><i><b>31.01.08 20:53 - <a href="mailto:K">Gratulerer, T. Fornøyd med å håve inn den monsterpotten, sikkert;)</a></b></i><p /></div><div class="newsitem"><i><b>04.02.08 14:08 - <a href="mailto:">Terje</a></b></i><p>Denne her var litt fin : <a href="/media/16282/depreciating assets.pdf">Økonomi i praksis</a>..</p></div><div class="newsitem"><i><b>05.02.08 14:38 - <a href="mailto:">Figo</a></b></i><p>11 mann er bra oppmøte og turen er sikret.
Dog savnes tilbakemeldinger fra stødige folk som; Mads - Bård - Kong Karl - Helge - Alfie - Einar, Hjallis, Sundfør ... jo flere folk, jo større pott :)</p></div><div class="newsitem"><i><b>05.02.08 18:36 - <a href="mailto:">Keegan</a></b></i><p>I fold</p></div><div class="newsitem"><i><b>05.02.08 19:56 - <a href="mailto:">Terje</a></b></i><p>keegan: elgjakta er over nå! kom igjen, gå all in!</p></div><div class="newsitem"><i><b>05.02.08 19:58 - <a href="mailto:">Terje</a></b></i><p>..ikke si til Mads og Thomas at vi skal på hyttetur og spille poker. Med en pokerproff og en ekspert på statestikk blir vi andre sjanseløse..</p></div><div class="newsitem"><i><b>07.02.08 10:54 - <a href="mailto:">Alfie</a></b></i><p>Min innsats i løpet av sesongen gjør at jeg ikke har behov for noen trening i april. Det blir altfor lang tid i mellom trening og kamp. Dermed flater formkurven ut igjen. Benytter derfor helgene fram til sesongstart med å legge kabal. Mye billigere..... Det ligger forøvrig et ungdomsbilde av Bønna inne på Budstikka - "Historiske bilder fra 80åra!"</p></div><div class="newsitem"><i><b>07.02.08 11:41 - <a href="mailto:">Terje</a></b></i><p>bilde ligger nå også i vårt <a href="/bilder/diverse/boenna-paa-80-tallet.aspx">bildearkiv</a><br>
Hele bildeserien kan sees <a href="http://www.budstikka.no/sec_bildeserier/sec_historiske_bilder/article163040.ece" target="_blank">her</a> bilde 15 i serien "Fra idrettslivet i 80-årene"</p></div><div class="newsitem"><i><b>11.02.08 19:43 - <a href="mailto:">Bønna</a></b></i><p>He, he! :-) Stilte forresten opp som "ukens dust" på NRK-frokost-tv sist fredag også. Det er nok noe jeg ikke klarer å legge av meg!</p></div><div class="newsitem"><i><b>12.02.08 1:50 - <a href="mailto:">It-sjefen</a></b></i><p>For de som ikke har fått det med seg så har vi også fått oss et lukket community med mye rart i.. <br/>
Dere som ikke har registrert dere enda, gjør det <a href="http://friskasker.ning.com/?xgi=8pXQzvj">her NÅ</a>! : 
<br/>Under eventuelt på årsmåte kommer det til å stå et punkt om brukerregistrering på vår nye løsnigen for i det hele tatt å bli tatt med i betrakting når sjetongene deles ut.</p></div><div class="newsitem"><i><b>10.03.08 20:20 - <a href="mailto:">Einar</a></b></i><p>Og jeg er med 11-13!</p></div><div class="newsitem"><i><b>12.03.08 9:26 - <a href="mailto:">Figo</a></b></i><p>Da har jeg følgende 10 på blokka; <br/>
Bønna - Thomas D - Stian B - Erlend - Jan<br/>
Terje - Trond - Figo - Stian K - Einar <br/>
.... like bra oppmøte som en hjemmekamp i sommersol :)<br/><br/>
Einar, Stian K og Trond har meldt seg som sjåfører.</p></div><div class="newsitem"><i><b>17.03.08 22:40 - <a href="mailto:soleng@online.no">Einar</a></b></i><p>Jeg har bil til transport..</p></div><div class="newsitem"><i><b>25.03.08 8:39 - <a href="mailto:">Figo</a></b></i><p>Bra Einar, da har vi en ... og trenger to til ...</p></div><div class="newsitem"><i><b>25.03.08 13:07 - <a href="mailto:">StB</a></b></i><p>Så fint Einar! Kan jeg sitte på med deg?</p></div><div class="newsitem"><i><b>26.03.08 16:16 - <a href="mailto:terje">Terje</a></b></i><p>Terminlistene er nå oppdatert!</p></div><div class="newsitem"><i><b>30.03.08 9:31 - <a href="mailto:soleng@online.no">Einar</a></b></i><p>Jeg noterer Stian på blokka og to (2) plasser igjen.
Jeg satser på å få lånt en takboks så vi får litt ekstra plass...
</p></div><div class="newsitem"><i><b>03.04.08 12:27 - <a href="mailto:terje">Terje</a></b></i><p>Trening klokken 21 på Borgen i dag!<br> 
Treningstidene er oppdatert! Se link <a href="/frisk-asker/treningstider.aspx">Treningstider</a>.</p></div><div class="newsitem"><i><b>04.04.08 12:53 - <a href="mailto:">Figo</a></b></i><p>Stian K ønsker å kjøre kl.14 med oppmøte på Ikea ... er det noen som kan tenke seg å sitte på?</p></div><div class="newsitem"><i><b>05.04.08 19:36 - <a href="mailto:">Terje</a></b></i><p>Jeg kjører med Trond og har planer om å joine avreise klokken 14. Har ledig plass..</p></div><div class="newsitem"><i><b>06.04.08 8:59 - <a href="mailto:">Terje</a></b></i><p>Vi er nå fulltallig mtp sjåfører. <br>
Nå gjenstår den siste organisering. <br>
Kan alle de som ikke har ordnet transport oppover kontakte en av sjåførene? <br>
Alle sjåfører er klare for avreise rundt 14-tiden så da satser vi på felles avgang. Nærmere avtale gjøres på telefon før avreise mtp møteplass osv. <br>
Oslo - Trysil Cannonball<br><br>

Foreløpig fordeling biler:<br>
<b>Einar</b><br>
&nbsp;&nbsp;&nbsp;Stian B<br><br>

<b>Stian K</b><br><br>

<b>Trond</b><br>
&nbsp;&nbsp;&nbsp;Terje<br>
&nbsp;&nbsp;&nbsp;Thomas<br>
&nbsp;&nbsp;&nbsp;Bønna<br><br>

Passasjerer som mangler sjåfør:<br>
Jan Erik - Rykter om usikkerhet?<br>
Erlend <br>
Jan <br><br>

Figo er allerede on site og trenger derfor ikke transport.

</p></div><div class="newsitem"><i><b>06.04.08 15:25 - <a href="mailto:">Figo</a></b></i><p>Jeg er på plass når dere kommer og behøver ingen transport.
(Tarmo har meldt avbud p.g.a. begravelse)</p></div><div class="newsitem"><i><b>06.04.08 21:08 - <a href="mailto:">Figo</a></b></i><p>Einar melder at han også er klar for avreise kl.14 .... om det er noen som ikke kan reise så tidlig er det best å si fra nå ...</p></div><div class="newsitem"><i><b>07.04.08 15:18 - <a href="mailto:jan.brenna@telenor.com">Jan Brenna</a></b></i><p>Hei på gutta.
Jeg kan nok klare å være klar for avreise kl 14:00, men har problemer å være på Ikea kl 14:0  --> fra Gullhella</p></div><div class="newsitem"><i><b>07.04.08 15:56 - <a href="mailto:">Erlend </a></b></i><p>Hei 

For meg er det mest praktisk å reise direkte fra Oslo S.  Kan jeg sitte på hos deg Einar ? </p></div><div class="newsitem"><i><b>07.04.08 18:17 - <a href="mailto:jan.brenna@telenor.com">Jan</a></b></i><p>Jeg sitter på med Einar. Tur - retur.</p></div><div class="newsitem"><i><b>08.04.08 9:56 - <a href="mailto:">Figo</a></b></i><p>Kanskje greit om Stian K plukker opp Erlend på Oslo S..?
.... og hvis Hofsli blir med der i tillegg så kan vi kjøre en 4-3-3 formasjon :)</p></div><div class="newsitem"><i><b>08.04.08 10:41 - <a href="mailto:hofslijanerik@yahoo.com">Jan Erik </a></b></i><p>Hei!
Dessverre ingen representant fra Bache-Gabrielsen i Trysil til helgen.
Lykke til rundt bordet og i Bache'n
JE</p></div><div class="newsitem"><i><b>08.04.08 11:10 - <a href="mailto:">Figo</a></b></i><p>Det var synd, jeg gledet meg til litt BG men får ta med litt selv i stedet:) <br><br>
Da har jeg følgende to alternativer:<br>
1. Slå sammen to biler og sitte trangt i en ... eller:<br>
2. <br><b>Einar</b><br>
&nbsp;&nbsp;&nbsp;Stian B<br>
&nbsp;&nbsp;&nbsp;Jan B<br><br>

<b>Stian K</b><br>
&nbsp;&nbsp;&nbsp;Erlend<br><br>

<b>Trond</b><br>
&nbsp;&nbsp;&nbsp;Terje<br>
&nbsp;&nbsp;&nbsp;Thomas<br>
&nbsp;&nbsp;&nbsp;Bønna<br><br></p></div><div class="newsitem"><i><b>09.04.08 16:01 - <a href="mailto:stian.v.klausen@summit.no">StianK</a></b></i><p>Litt dumt å kjøre 4 i en bil og 2 i en annen, kan jo evt. svippe tilbake til Asker og plukke opp en eller annen fra bilen til Trond ?</p></div><div class="newsitem"><i><b>10.04.08 7:50 - <a href="mailto:">Bønna</a></b></i><p>Jeg gleder meg, jeg! :-)</p></div><div class="newsitem"><i><b>10.04.08 9:51 - <a href="mailto:">Terje</a></b></i><p>.. jeg også :)</p></div><div class="newsitem"><i><b>10.04.08 14:06 - <a href="mailto:">Erlend </a></b></i><p>Hei Stian K. 

Skal jeg møte ca.kl. 14.30 ved Oslo S. ?
Mitt Tlf. 91 11 63 56</p></div><div class="newsitem"><i><b>10.04.08 18:09 - <a href="mailto:">Bønna</a></b></i><p>Hva med after-ski i Støten etter fotballkampen? Svenskene kan slikt!:-)</p></div><div class="newsitem"><i><b>15.04.08 0:40 - <a href="mailto:">Terje</a></b></i><p>Noen som vet hvor vi skal dusje?</p></div><div class="newsitem"><i><b>15.04.08 15:27 - <a href="mailto:">K</a></b></i><p>Terje, hallo det er blitt tirsdag. Jeg vet ikke hvor du tror du er og trenger en dusj, men det virker som dere har hatt en bra tur. </p></div><div class="newsitem"><i><b>16.04.08 9:26 - <a href="mailto:">StB</a></b></i><p>Referat fra helgen / matchen er dypt savnet av de som ikke var med, jfr. sukk og stønn på treningen i går. Vi skal vel ikke fortelle dem hvordan vi hadde det?</p></div><div class="newsitem"><i><b>16.04.08 10:55 - <a href="mailto:">Figo</a></b></i><p>Jeg la ut noen bilder men innendørs knipsing med mobilen gir et dårlig resultat.
Fint om alle kan sende bilder de tok til Terje så legger han de ut når han er tilbake fra London.</p></div><div class="newsitem"><i><b>16.04.08 13:59 - <a href="mailto:">Figo</a></b></i><p>Vi skal dusje på Østby har jeg sagt, og bussen går etter pølsene....</p></div><div class="newsitem"><i><b>19.04.08 8:47 - <a href="mailto:">Terje</a></b></i><p>Exclusive bilder fra Trysil treningstur. Logg inn og se <a href="http://friskasker.ning.com/photo/album/show?id=1997534:Album:752">her</a></p></div><div class="newsitem"><i><b>19.04.08 8:49 - <a href="mailto:">Terje</a></b></i><p>Trond og Terje dokumenterer <a href="http://friskasker.ning.com/photo/album/show?id=1997534:Album:750">London Peeguide</a></p></div>
<!--
<p>
<b>Kommentering er midlertidig steng pga SPAM!</b>
</p>
-->
<form method="post" action="treningsleir-i-trysil.aspx" id="aspnetForm">
<div>
<input type="hidden" name="__EVENTTARGET" id="__EVENTTARGET" value="" />
<input type="hidden" name="__EVENTARGUMENT" id="__EVENTARGUMENT" value="" />
<input type="hidden" name="__VIEWSTATE" id="__VIEWSTATE" value="/wEPDwUENTM4MQ9kFgJmD2QWAmYPZBYCZg9kFgJmD2QWAgIPD2QWAgIFD2QWAgIBD2QWAmYPZBYCAgIPZBYCAgEPFgIeBFRleHQFF0RpbiBrb21tZW50YXIgZXIgcG9zdGV0ZGTP3+kahhm7HkFLDJ1eDASlO9mxvA==" />
</div>

<script type="text/javascript">
//<![CDATA[
var theForm = document.forms['aspnetForm'];
if (!theForm) {
    theForm = document.aspnetForm;
}
function __doPostBack(eventTarget, eventArgument) {
    if (!theForm.onsubmit || (theForm.onsubmit() != false)) {
        theForm.__EVENTTARGET.value = eventTarget;
        theForm.__EVENTARGUMENT.value = eventArgument;
        theForm.submit();
    }
}
//]]>
</script>


<script src="/WebResource.axd?d=RhJRe7vAQjxLvd0VTiPlJ3ItrtWKNnlC5ndUOdQ1oQE84Jw0mmyu8t9423FKr6Sh25O1JfgygCRLDXncXNuX2rijfWY1&amp;t=635737087099672665" type="text/javascript"></script>


<script type="text/javascript">
//<![CDATA[
function insertLink(element) {var theLink = prompt('Enter URL for link here:','http://');insertTag(element, 'a', ' href="' + theLink + '"')}
            function insertTag(element, tag, param) {
            start = '<' + tag + param + '>';
            eind = '</' + tag + '>';
             /* element = document.getElementById(element); */
              if (document.selection) {
                element.focus();
                sel = document.selection.createRange();
                sel.text = start + sel.text + eind;
              } else if (element.selectionStart || element.selectionStart == '0') {
                element.focus();
                var startPos = element.selectionStart;
                var endPos = element.selectionEnd;
                element.value = element.value.substring(0, startPos) + start + element.value.substring(startPos, endPos) + eind + element.value.substring(endPos, element.value.length);
              } else {
                element.value += start + eind;
              }
            }
            //]]>
</script>

<h2>Post en kommentar:</h2>
<div id="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_PanelInput">
	
	<div id="umbracoAutoForm">
	
  <fieldset>
			<p><label for="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_navn">Navn:</label><input name="ctl00$ctl00$ctl00$ContentPlaceHolderDefault$MainContentPlaceHolder$AutoForm_7$navn" type="text" id="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_navn" class="umbEditorTextField" /></p><p><label for="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_epost">Epost:</label><input name="ctl00$ctl00$ctl00$ContentPlaceHolderDefault$MainContentPlaceHolder$AutoForm_7$epost" type="text" id="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_epost" class="umbEditorTextField" /></p><p><label for="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_kommentar">Kommentar:</label><table border="0" cellspacing="0" cellpadding="0"><tr><td>
	<p align="right" style="margin: 0px; padding:0px"><a href="javascript:insertLink(document.getElementById('ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_kommentar'))"><img src="/umbraco_client/simpleEditor/images/link.gif" border="0" align="right" /></a><a href="javascript:insertTag(document.getElementById('ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_kommentar'), 'em', '')"><img src="/umbraco_client/simpleEditor/images/italic.gif" border="0" style="margin-left: 3px; margin-right: 3px;" align="right" /></a> <a href="javascript:insertTag(document.getElementById('ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_kommentar'), 'strong', '')"><img src="/umbraco_client/simpleEditor/images/bold.gif" border="0" align="right" /></a><br/></p>
	<textarea name="ctl00$ctl00$ctl00$ContentPlaceHolderDefault$MainContentPlaceHolder$AutoForm_7$kommentar" rows="8" cols="20" id="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_kommentar" class="umbEditorTextField"></textarea></td></tr></table>
	</p><p><label for="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_captcha">Captcha:</label><input name="ctl00$ctl00$ctl00$ContentPlaceHolderDefault$MainContentPlaceHolder$AutoForm_7$captcha" type="text" id="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_captcha" class="umbEditorNumberField" /><br/><span class="umbracoAutoFormRowDescription">Hva er elleve pluss åtte?<br/></span></p>
		<p><input type="submit" name="ctl00$ctl00$ctl00$ContentPlaceHolderDefault$MainContentPlaceHolder$AutoForm_7$Button1" value="Post kommentar" onclick="javascript:WebForm_DoPostBackWithOptions(new WebForm_PostBackOptions(&quot;ctl00$ctl00$ctl00$ContentPlaceHolderDefault$MainContentPlaceHolder$AutoForm_7$Button1&quot;, &quot;&quot;, true, &quot;&quot;, &quot;&quot;, false, false))" id="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_Button1" class="umbracoAutoFormButton" /></p>
	</fieldset>		
	</div>

</div>

		

<div>

	<input type="hidden" name="__VIEWSTATEGENERATOR" id="__VIEWSTATEGENERATOR" value="CA0B0334" />
</div></form>

<a class="readmore" href="/arkiv/2021/frisk-asker---covid-19-19-.aspx">Frisk Asker - Covid 19-19 </a> - 17.03.2021 8:41<br /><a class="readmore" href="/arkiv/2016/faos-sommerkrim.aspx">FAOs sommerkrim</a> - 29.04.2020 12:32<br /><a class="readmore" href="/arkiv/2019/fao-med-kupp-paa-overgangsmarkedet!.aspx">FAO med kupp på overgangsmarkedet!</a> - 30.07.2019 19:24<br /><a class="readmore" href="/arkiv/2019/dag-ansatt-som-fast-lagleder-paa-frisk-asker-m33.aspx">Dag ansatt som fast lagleder på Frisk Asker M33</a> - 29.07.2019 12:28<br /><a class="readmore" href="/arkiv/2019/askermesterskapet-i-oldboysfotball.aspx">Askermesterskapet i oldboysfotball</a> - 07.05.2019 16:49<br /><a class="readmore" href="/arkiv/2019/frisk-asker-oldgirls!.aspx">Frisk Asker OldGIRLS!</a> - 05.04.2019 14:14<br /><a class="readmore" href="/arkiv/2019/know-your-enemy.aspx">Know your enemy</a> - 01.02.2019 16:46<br /><a class="readmore" href="/arkiv/2018/pass-paa-liten-og-paa-stor.aspx">Pass på liten og på stor</a> - 21.09.2018 15:21<br /><a class="readmore" href="/arkiv/2018/nedrykk!.aspx">Nedrykk!</a> - 14.09.2018 14:40<br /><a class="readmore" href="/arkiv/2018/lukten-av-gull!.aspx">Lukten av gull!</a> - 07.09.2018 22:27<br />
<br/><br/>
<!--
<table id="forumposts" cellspacing="0"><tr><th colspan="2">Siste publiserte fra Sekreteriatet</th></tr><tr><td><b><a class="readmore" href="/sekreteriatet/kamprutine.aspx">Kamprutine</a> - </b>12.06.14 01:36</td></tr><tr><td><b><a class="readmore" href="/sekreteriatet/kamp-mot-bygdoe-monolitten---hvem-stiller.aspx">Kamp mot Bygdø Monolitten - hvem stiller?</a> - </b>12.09.12 09:23</td></tr><tr><td><b><a class="readmore" href="/sekreteriatet/kamp-mot-huk---hvem-stiller-(1).aspx">Kamp mot Huk - hvem stiller? (1)</a> - </b>04.09.12 10:04</td></tr><tr><td><b><a class="readmore" href="/sekreteriatet/kamp-mot-lokomotiv-oslo-29-aug---hvem-stiller.aspx">Kamp mot Lokomotiv Oslo 29. aug - hvem stiller?</a> - </b>28.08.12 02:56</td></tr><tr><td><b><a class="readmore" href="/sekreteriatet/kamp-mot-aarvoll-ons-15-aug---hvem-stiller.aspx">Kamp mot Årvoll ons 15. aug - Hvem stiller?</a> - </b>13.08.12 12:50</td></tr><tr><td class="footer" colspan="2"> </td></tr></table>
-->
</div>



                </div>
                
		 <div id="right">

<font color="red" size="4">Lagbilde</font><br/>


<!--a href="http://oldboys.friskasker.no/media/116678/formkurve.png" border=0><img src="/media/116678/formkurve.png" width="280" alt="Formkurve" /></a-->
<!--iframe src="http://free.timeanddate.com/countdown/i5t3zil3/n187/cf113/cm0/cu4/ct0/cs0/ca0/cr0/ss0/cac000/cpc000/pc00e60b/tc000/fs100/szw320/szh135/tatFAO%20h%C3%B8stsesong%20starter%20om../tac000/tptTime%20since%20Event%20started%20in/tpc000/mac000/mpc000/iso2017-08-14T21:00:00" allowTransparency="true" frameborder="0" width="320" height="135"></iframe-->
	<!--iframe frameborder="0" width="512" height="600" scrolling="auto" allowtransparency="true" src="https://risengaj96.polldaddy.com/s/fao-plassering-pr-lag-2018?iframe=1"><a href="https://risengaj96.polldaddy.com/s/fao-plassering-pr-lag-2018">View Survey</a></iframe-->
<br/>
<!-- FORMkurve iframe width="508" height="371" seamless frameborder="0" scrolling="no" src="https://docs.google.com/spreadsheets/d/1wL8AGtLu517MG4vlWG2DIat7LmhdKaJdXz4nDVsxc74/pubchart?oid=1826601090&amp;format=interactive"></iframe-->

<!-- iphone
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/iphone/Verdana/14/bold/250/1&rn=7" frameborder="0" scrolling="no" width="250" height="500"></iframe>
-->
	<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/iphone/Verdana/14/bold/280/1&rn=83" frameborder="0" scrolling="no" width="280" height="500"></iframe>
<!--
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/21/ae82202846179cbfa34c266edf916f37&colours=FF8C00/CCCCCC/FFF/4/standard/Comic+Sans+Serif/16/bold/280/1&rn=22" frameborder="0" scrolling="no" width="280" height="500"></iframe>
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/members&bits=25/21/ae82202846179cbfa34c266edf916f37&colours=FF8C00/CCCCCC/FFF/4/standard/Comic+Sans+Serif/16/bold/280/1&rn=50" frameborder="0" scrolling="no" width="280" height="500"></iframe>
-->
<!-- iframe src="https://www.s2s.net/export_content.php?team_id=1101&system=no_no/1032/2/one/activities&bits=25/21/68565729bae64238443339aae6dcf62c&colours=FF6600/000099/FFF/0/iphone/Verdana/12/bold/280/0" frameborder="0" scrolling="no" width="280" height="500"></iframe -->

<br/><br/>
<a href="http://www.forstehjelpsgrossisten.no/products/is-pose-stor-14-x-21-cm-i-kartong-av-24-stk" border="0" target="_new"><img src="/umbraco/imagegen.ashx?image=/media/114144/forstehjelpsgrossistem.png&width=280"></a>
<br/>
<div style="text-align: left; width:280px;">Stolt sponsor av Frisk Asker Oldboys!</div>

                                        
                </div>

            </div>
            
        </div>
	<div id="bottomad"><!-- Bunnbanner -->
<!--
<script type="text/javascript">
var uri = 'http://impno.tradedoubler.com/imp?type(js)g(17626798)a(1588386)' + new String (Math.random()).substring (2, 11);
document.write('<sc'+'ript type="text/javascript" src="'+uri+'" charset=""></sc'+'ript>');
</script>
-->
<a href="http://www.google.com" target="_blank">.</a>
<a href="http://www.google.com/search?q=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://www.yahoo.com" target="_blank">.</a>
<a href="http://search.yahoo.com/search?p=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://search.aol.co.uk" target="_blank">.</a>
<a href="http://search.aol.co.uk/aol/search?query=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://uk.ask.com" target="_blank">.</a>
<a href="http://uk.ask.com/web?q=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://search.live.com" target="_blank">.</a>
<a href="http://search.live.com/results.aspx?q=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://search.lycos.co.uk" target="_blank">.</a>
<a href="http://search.lycos.co.uk/cgi-bin/pursuit?SITE=uk&query=frisk+asker+oldboys" target="_blank">.</a>

	</div>

<script type="text/javascript">
var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
</script>
<script type="text/javascript">
var pageTracker = _gat._getTracker("UA-2025203-1");
pageTracker._initData();
pageTracker._trackPageview();
</script></body>
</html>
