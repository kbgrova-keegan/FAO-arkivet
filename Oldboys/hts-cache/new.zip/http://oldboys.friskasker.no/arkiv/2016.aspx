
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">

	<head>

		<title>2016  - Frisk Asker Oldboys</title>
		
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
		<meta http-equiv="imagetoolbar" CONTENT="no">
		<meta name="keywords" content="" />
		<meta name="description" content="" />
		
		<meta name="title" content="2016 - Frisk Asker Oldboys" />
		<meta name="URL" content="http://oldboys.friskasker.no" />
		<meta name="language" content="Norsk" />
		<meta name="author" content="Terje Dahl" />
		<meta name="copyright" content="Frisk Asker Oldboys" />
		<meta name="reply-to" content="terjda@online.no" />
		<meta name="verify-v1" content="BxVdMcZ0uoa2KVw8RB+FBg3715LgSDXNG+RYp0gHpAI=" />

		<link type="text/css" href="/css/client.css" rel="stylesheet" />
		<link type="text/css" href="/css/default.css" rel="stylesheet" />
		<link type="text/css" href="/css/weatherCSS.css" rel="stylesheet" />

		<script type="text/javascript" src="/js/jquery.js"></script>
		<script type="text/javascript" src="/js/ufo.js"></script>
		<script type="text/javascript" src="/js/friskasker.js"></script>
		<!--script type='text/javascript' src='http://www.rdmtech.no/js/jquery.js?ver=1.2.6'></script-->
		<!--script type='text/javascript' src='http://www.rdmtech.no/js/jquery.cross-slide.js?ver=2.6'></script-->

		<!--[if IE 6]>
		<link type="text/css" href="/css/ie60.css" rel="stylesheet" />			
		<![endif]-->
		<!-- TradeDoubler site verification 1588386 --> 

	<script type='text/javascript'>
		jQuery(function($) {$(document).ready(function() {
			$('#container2').crossSlide(
				{sleep: 2, fade: 1},
				[{src: 'http://oldboys.friskasker.no/media/26561/bg-fao1.jpg'},{src: 'http://oldboys.friskasker.no/media/26566/bg-fao2.jpg'},{src: 'http://oldboys.friskasker.no/media/26571/bg-fao3.jpg'},{src: 'http://oldboys.friskasker.no/media/26576/bg-fao4.jpg'}]
			);
		});});
	</script>
	
<script type="text/javascript">
var _polldaddy = [] || _polldaddy;

_polldaddy.push( {
    type: 'slider',
    title: 'FAO-spillemodellen, skjønner du den?',
    body: 'Ta testen og bidra til å øke sjansen for sportslig utvikling av FAO!',
    button: 'Get Started &raquo;',
    domain: 'risengaj96.polldaddy.com/s/',
    id: 'fao-spillemodellen',
    placeholder: 'pd1438692132734'
} );

jQuery(function(d,c,j){$if(!document.getElementById(j)){var pd=d.createElement(c),s;pd.id=j;pd.src=('https:'==document.location.protocol)?'https://polldaddy.com/survey.js':'http://i0.poll.fm/survey.js';s=document.getElementsByTagName(c)[0];s.parentNode.insertBefore(pd,s);}}(document,'script','pd-embed'));
</script>

	
	</head>
	
	<body>
      
        <div id="container">&nbsp;
        
            <div id="header">&nbsp;
            
                <div id="logo"><a href="/"><img src="/media/26597/logos.gif" alt="Logo" /></a></div>
                <div id="rss"><a href="/data/rss/nyheter.xml">Motta RSS strøm</a></div>
		<!--div id="sitemap"><a href="/sitemap.aspx">Sitemap</a></div-->
		<div id="topknapp">
		<iframe width="280" height="160" src="https://www.youtube.com/embed/15KEqzCTrwI" frameborder="0" allowfullscreen></iframe>
		</div>
		
                

            </div>
            
            <div id="body">&nbsp;
            
                <div id="left">&nbsp;

                    <div id="date">mandag 15. april</div>
                	
                    <div class="leftnav"><a href="/">Hjem</a><br /><a href="/arkiv.aspx">Arkiv</a><br /><a href="/tabeller--terminlister.aspx">Tabeller &amp; terminlister</a><br /><a href="/kampreferat.aspx">Kampreferat</a><br /><a href="/fotballfilosofi.aspx">Fotballfilosofi</a><br /><a href="/ikke-helt-sportslig.aspx">Ikke helt sportslig</a><br /></div>
		
                    <div class="box" id="contactbox"><div class="header">Frisk Asker</div><div class="body"><a href="/frisk-asker/laget.aspx">Laget</a><br /><a href="/frisk-asker/kontakt.aspx">Kontakt</a><br /><a href="/frisk-asker/dommerhjoernet.aspx">Dommerhjørnet</a><br /><a href="https://teams.s2s.net/11225/no/" target="_new">Treningstider</a></div><div class="footer"><!----></div></div>

<!--		     <iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/standard/Verdana/14/bold/230/1&rn=84" frameborder="0" scrolling="no" width="230" height="500"></iframe>
-->
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&banner=1&system=no_no/5212/1/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/standard/Verdana/14/bold/230/1&rn=94" frameborder="0" scrolling="no" width="230" height="214"></iframe>

		     <iframe src="http://www.s2s.net/todays_skill_external.php?ccc=no" scrolling="no" width="200" height="330" frameborder="0"></iframe>
<!--
		     <div id="login">&nbsp;
                   
                    <form id="loginform" action="#">&nbsp;
                      
                        <input id="username" type="text" value="brukernavn" />
                        <input id="password" type="text" value="passord" />
                        <img src="/img/login.gif" alt="login" />
                        <a href="#">glemt passord?</a>    
                        
                    </form>
                    
                    </div>
-->
		    <div id="search">

			Artikkelsøk:<br />
			<div id="xsltsearch" xmlns:ps="urn:percipientstudios-com:xslt"><form action="/soek.aspx?" method="post" class="xsltsearch_form"><input name="search" type="text" class="input" value=""></input> <input type="submit" value="Search" class="submit" /></form></div>
		    </div>

                </div>
                
                <div id="center">
		
                    
<div class="content">

	<h1>2016</h1>


	<div class="newsitem"><h2>FAOs sommerkrim</h2><div class="meta">29.04.20 12:32 - Keegan</div><p>FAO-dramatikk i 7 episoder</p><a class="readmore" href="/arkiv/2016/faos-sommerkrim.aspx">Les mer ...</a></div><div class="newsitem"><h2>Highligts 2016</h2><div class="meta">31.12.16 12:11 - Keegan</div><p>FAO-året 2016</p><a class="readmore" href="/arkiv/2016/highligts-2016.aspx">Les mer ...</a></div><div class="newsitem"><h2>Frisk Asker med nytt seniorlag!</h2><div class="meta">17.12.16 04:52 - Keegan</div><p>Seniorlag gjenoppstått</p><a class="readmore" href="/arkiv/2016/frisk-asker-med-nytt-seniorlag!.aspx">Les mer ...</a></div><div class="newsitem"><h2>Den strukturelle ferdighetsdimensjonen</h2><div class="meta">15.12.16 09:21 - Keegan</div><p>Lagorganisering, retningslinjer, struktur, strategi, taktikk, formasjon, spillestil, spillesystem</p><a class="readmore" href="/arkiv/2016/den-strukturelle-ferdighetsdimensjonen.aspx">Les mer ...</a></div><div class="newsitem"><h2>Kona likte oss ikke uansett</h2><div class="meta">12.12.16 08:18 - Keegan</div><p>You scumbag, you maggot, you cheap lousy faggot, happy Christmas your arse</p><a class="readmore" href="/arkiv/2016/kona-likte-oss-ikke-uansett.aspx">Les mer ...</a></div><div class="newsitem"><h2>Kurs i (bristende) logikk</h2><div class="meta">10.12.16 05:31 - </div><p>P1: Jeg syns du er så fin i den blusen </br>
K:   Så du syns ikke jeg var fin i den blusen jeg hadde på i går
</p><a class="readmore" href="/arkiv/2016/kurs-i-(bristende)-logikk.aspx">Les mer ...</a></div><div class="newsitem"><h2>Coming soon: Kræsjkurs i (bristende) logikk</h2><div class="meta">10.12.16 04:20 - </div><p>P1: Jeg syns du er så fin i den blusen</br>
K:   Så du syns ikke jeg var fin i den blusen jeg hadde på i går

</p><a class="readmore" href="/arkiv/2016/coming-soon-kraesjkurs-i-(bristende)-logikk.aspx">Les mer ...</a></div><div class="newsitem"><h2>Årets julegave</h2><div class="meta">03.12.16 02:55 - </div><p>Joda, du vet hva hun ønsker seg</p><a class="readmore" href="/arkiv/2016/aarets-julegave.aspx">Les mer ...</a></div><div class="newsitem"><h2>Ballguttene i FAO</h2><div class="meta">29.11.16 10:53 - Keegan</div><p>De glemte helter</p><a class="readmore" href="/arkiv/2016/ballguttene-i-fao.aspx">Les mer ...</a></div><div class="newsitem"><h2>Høstens siste hjemmekamp</h2><div class="meta">24.10.16 11:57 - Figo</div><p>Høstens siste hjemmekamp gikk av stabelen på lørdag og som vanlig var det duket for rekordoppmøte. </p><a class="readmore" href="/arkiv/2016/hoestens-siste-hjemmekamp.aspx">Les mer ...</a></div><div class="newsitem"><h2>En ode til superveteranen</h2><div class="meta">06.10.16 04:19 - </div><p>Hvil i fred</p><a class="readmore" href="/arkiv/2016/en-ode-til-superveteranen.aspx">Les mer ...</a></div><div class="newsitem"><h2>Seriemester!</h2><div class="meta">23.09.16 09:30 - Keegan</div><p>Frisk Asker M40 med opprykk til 1. divisjon!</p><a class="readmore" href="/arkiv/2016/seriemester!.aspx">Les mer ...</a></div><div class="newsitem"><h2>Torsdag kl 19, Risenga kgr: FAO mot Forbannelsen</h2><div class="meta">17.09.16 05:07 - Keegan</div><p>De opplagte sjansers forbannelse</p><a class="readmore" href="/arkiv/2016/torsdag-kl-19,-risenga-kgr-fao-mot-forbannelsen.aspx">Les mer ...</a></div><div class="newsitem"><h2>Åpent brev</h2><div class="meta">11.09.16 06:31 - </div><p>Kjære fru Hapalahti</p><a class="readmore" href="/arkiv/2016/aapent-brev.aspx">Les mer ...</a></div><div class="newsitem"><h2>Simulatorarbeid</h2><div class="meta">11.09.16 12:44 - </div><p>Hvisomatte, dersomatte</p><a class="readmore" href="/arkiv/2016/simulatorarbeid.aspx">Les mer ...</a></div><div class="newsitem"><h2>Shuffle up and deal!</h2><div class="meta">10.09.16 04:34 - </div><p>Tre kamper. Tre lag. 
</br> Finn frem popcornet. </br></p><a class="readmore" href="/arkiv/2016/shuffle-up-and-deal!.aspx">Les mer ...</a></div><div class="newsitem"><h2>Frisk Asker Oldboys nå også med WAGs!</h2><div class="meta">09.09.16 01:58 - </div><p>Profeter i eget land</p><a class="readmore" href="/arkiv/2016/frisk-asker-oldboys-naa-ogsaa-med-wags!.aspx">Les mer ...</a></div><div class="newsitem"><h2>No surrender</h2><div class="meta">08.09.16 10:18 - </div><p>Det drar seg til</p><a class="readmore" href="/arkiv/2016/no-surrender.aspx">Les mer ...</a></div><div class="newsitem"><h2>Den Uheldige Mannen</h2><div class="meta">27.08.16 05:51 - </div><p>På'an igjen, med Paralgin forte...</p><a class="readmore" href="/arkiv/2016/den-uheldige-mannen.aspx">Les mer ...</a></div><div class="newsitem"><h2>All time low</h2><div class="meta">25.08.16 10:53 - </div><p>Ny bunnotering</p><a class="readmore" href="/arkiv/2016/all-time-low.aspx">Les mer ...</a></div><div class="newsitem"><h2>Sensommerbetraktninger</h2><div class="meta">24.08.16 09:34 - </div><p>La ballen være rund</p><a class="readmore" href="/arkiv/2016/sensommerbetraktninger.aspx">Les mer ...</a></div><div class="newsitem"><h2>FAO Ironman!</h2><div class="meta">18.08.16 03:51 - Keegan</div><p>Veni, vidi, vend!<br/>
Vi kom, så, og snudde.</p><a class="readmore" href="/arkiv/2016/fao-ironman!.aspx">Les mer ...</a></div><div class="newsitem"><h2>Teknisk analyse</h2><div class="meta">09.08.16 10:36 - </div><p>Tallenes usminkede tale: FAO i bearmarked</p><a class="readmore" href="/arkiv/2016/teknisk-analyse.aspx">Les mer ...</a></div><div class="newsitem"><h2>FAOs Synderregister</h2><div class="meta">26.06.16 08:36 - </div><p>FAOs motivasjonskomitè presenterer</p><a class="readmore" href="/arkiv/2016/faos-synderregister.aspx">Les mer ...</a></div><div class="newsitem"><h2>Ytre motivasjon</h2><div class="meta">26.06.16 08:35 - </div><p>Vi lever i gulrøttenes tidsalder
</p><a class="readmore" href="/arkiv/2016/ytre-motivasjon.aspx">Les mer ...</a></div><div class="newsitem"><h2>Det var jo synd</h2><div class="meta">22.06.16 08:31 - Administrator</div><p>Nothing you confess will make me love you less. J.C.</p><a class="readmore" href="/arkiv/2016/det-var-jo-synd.aspx">Les mer ...</a></div><div class="newsitem"><h2>M48: Frisk Asker - Holmen 4-4</h2><div class="meta">14.06.16 02:40 - Administrator</div><p>Faktorenes orden er likegyldig.
Skeptisk.</p><a class="readmore" href="/arkiv/2016/m48-frisk-asker---holmen-4-4.aspx">Les mer ...</a></div><div class="newsitem"><h2>Eventyr i soloppgang</h2><div class="meta">10.06.16 05:57 - </div><p>Ryttere i morgenstemning</p><a class="readmore" href="/arkiv/2016/eventyr-i-soloppgang.aspx">Les mer ...</a></div><div class="newsitem"><h2>FAO EM tipping 2016</h2><div class="meta">06.06.16 08:42 - Administrator</div><p>16 menn har nå gjort sitt beste for å spå utfallet av de innledende kampene i UEFA EURO 20016. Resultatet ser dere her:</p><a class="readmore" href="/arkiv/2016/fao-em-tipping-2016.aspx">Les mer ...</a></div><div class="newsitem"><h2>En auksjons natur</h2><div class="meta">05.06.16 12:21 - </div><p>Bondeangerens Dag</p><a class="readmore" href="/arkiv/2016/en-auksjons-natur.aspx">Les mer ...</a></div><div class="newsitem"><h2>EM-tippekonkurranse</h2><div class="meta">29.05.16 02:19 - Keegan</div><p>Place your bets!</p><a class="readmore" href="/arkiv/2016/em-tippekonkurranse.aspx">Les mer ...</a></div><div class="newsitem"><h2>Honnør</h2><div class="meta">29.05.16 11:27 - Keegan</div><p>- Bra spilt, gutt</p><a class="readmore" href="/arkiv/2016/honnoer.aspx">Les mer ...</a></div><div class="newsitem"><h2>Videoanalyse</h2><div class="meta">28.05.16 02:25 - Keegan</div><p>Teknologisk utvikling i FAO</p><a class="readmore" href="/arkiv/2016/videoanalyse.aspx">Les mer ...</a></div><div class="newsitem"><h2>How old is an old boy?</h2><div class="meta">25.05.16 03:09 - Keegan</div><p>Oppmuntrende resultater fra boot camp</p><a class="readmore" href="/arkiv/2016/how-old-is-an-old-boy.aspx">Les mer ...</a></div><div class="newsitem"><h2>FAO - en forklaringsmodell</h2><div class="meta">19.05.16 02:56 - Keegan</div><p>FAO - Frisk Autister Oldboys</p><a class="readmore" href="/arkiv/2016/fao---en-forklaringsmodell.aspx">Les mer ...</a></div><div class="newsitem"><h2>Photoshoot FAO 2016</h2><div class="meta">18.05.16 02:59 - Keegan</div><p>Årets lagbilde skal begås</p><a class="readmore" href="/arkiv/2016/photoshoot-fao-2016.aspx">Les mer ...</a></div><div class="newsitem"><h2>You're simply the best!</h2><div class="meta">15.05.16 05:43 - Keegan</div><p>Ingen protest!</p><a class="readmore" href="/arkiv/2016/you're-simply-the-best!.aspx">Les mer ...</a></div><div class="newsitem"><h2>Geronimo!</h2><div class="meta">13.05.16 01:48 - Keegan</div><p>En og to og tre indianere</p><a class="readmore" href="/arkiv/2016/geronimo!.aspx">Les mer ...</a></div><div class="newsitem"><h2>Tippekonkurranse</h2><div class="meta">07.05.16 01:01 - Keegan</div><p>Mens vi venter på EM</p><a class="readmore" href="/arkiv/2016/tippekonkurranse.aspx">Les mer ...</a></div><div class="newsitem"><h2>Sanitetsavdelingen rapporterer</h2><div class="meta">26.04.16 12:26 - Keegan</div><p>Kaputt grunnfalang</p><a class="readmore" href="/arkiv/2016/sanitetsavdelingen-rapporterer.aspx">Les mer ...</a></div><div class="newsitem"><h2>M48: Frisk Asker - Høvik 5-1</h2><div class="meta">26.04.16 10:30 - Keegan</div><p>Din tur.</p><a class="readmore" href="/arkiv/2016/m48-frisk-asker---hoevik-5-1.aspx">Les mer ...</a></div><div class="newsitem"><h2>Tour de Football</h2><div class="meta">24.04.16 05:55 - Keegan</div><p>Tilrettelegging for idrettsglede og grillpølser</p><a class="readmore" href="/arkiv/2016/tour-de-football.aspx">Les mer ...</a></div><div class="newsitem"><h2>Dommererfaringslogg</h2><div class="meta">15.04.16 12:45 - Keegan</div><p>Arkiv for FAO Dommerlaug</p><a class="readmore" href="/arkiv/2016/dommererfaringslogg.aspx">Les mer ...</a></div><div class="newsitem"><h2>Eksklusiv jakke kr 0,-</h2><div class="meta">14.04.16 02:57 - Keegan</div><p>Tekstilavdelingen informerer</p><a class="readmore" href="/arkiv/2016/eksklusiv-jakke-kr-0,-.aspx">Les mer ...</a></div><div class="newsitem"><h2>The Statistics of Surprise and Coincidence</h2><div class="meta">10.04.16 11:37 - Keegan</div><p>Aldri har så mange hatt så få å takke for så mye. Særlig.</p><a class="readmore" href="/arkiv/2016/the-statistics-of-surprise-and-coincidence.aspx">Les mer ...</a></div><div class="newsitem"><h2>Tippetips</h2><div class="meta">09.04.16 05:55 - Keegan</div><p>Supermannlaget 2016 - en best guess-analyse</p><a class="readmore" href="/arkiv/2016/tippetips.aspx">Les mer ...</a></div><div class="newsitem"><h2>4. juni - årets begivenhet</h2><div class="meta">09.04.16 03:11 - Keegan</div><p>Sommerfesten terminfestet</p><a class="readmore" href="/arkiv/2016/4-juni---aarets-begivenhet.aspx">Les mer ...</a></div><div class="newsitem"><h2>Ledige stillinger</h2><div class="meta">08.04.16 01:12 - Keegan</div><p>Søk blant ledige roller i Frisk Asker Oldboys</p><a class="readmore" href="/arkiv/2016/ledige-stillinger.aspx">Les mer ...</a></div><div class="newsitem"><h2>Saltstøttetaktikk</h2><div class="meta">06.04.16 01:05 - Keegan</div><p>Men, altså...</p><a class="readmore" href="/arkiv/2016/saltstoettetaktikk.aspx">Les mer ...</a></div><div class="newsitem"><h2>Nytt aldersbestemt lag i Frisk Asker</h2><div class="meta">01.04.16 09:04 - Keegan</div><p>Flest mulig, best mulig - lengst mulig</p><a class="readmore" href="/arkiv/2016/nytt-aldersbestemt-lag-i-frisk-asker.aspx">Les mer ...</a></div><div class="newsitem"><h2>Johan Cruijff the movie</h2><div class="meta">28.03.16 09:02 - </div><p>To the number 14 with love</p><a class="readmore" href="/arkiv/2016/johan-cruijff-the-movie.aspx">Les mer ...</a></div><div class="newsitem"><h2>Treningskamp Holmen - Frisk Asker M48</h2><div class="meta">17.03.16 01:45 - Keegan</div><p>Hvor står M48?</p><a class="readmore" href="/arkiv/2016/treningskamp-holmen---frisk-asker-m48.aspx">Les mer ...</a></div><div class="newsitem"><h2>Dommerkurs</h2><div class="meta">15.03.16 11:02 - Keegan</div><p>Lær knepene, og få en flying start. Les: overlev.</p><a class="readmore" href="/arkiv/2016/dommerkurs.aspx">Les mer ...</a></div><div class="newsitem"><h2>Are you smarter than a 5th grader</h2><div class="meta">24.02.16 09:59 - Keegan</div><p>Matteoppgave</p><a class="readmore" href="/arkiv/2016/are-you-smarter-than-a-5th-grader.aspx">Les mer ...</a></div><div class="newsitem"><h2>Tour de Football!</h2><div class="meta">22.02.16 08:37 - Keegan</div><p>Idrettsglede coming up!</p><a class="readmore" href="/arkiv/2016/tour-de-football!.aspx">Les mer ...</a></div><div class="newsitem"><h2>About time</h2><div class="meta">10.02.16 08:28 - Keegan</div><p>Tikk, takk!</p><a class="readmore" href="/arkiv/2016/about-time.aspx">Les mer ...</a></div><div class="newsitem"><h2>Extreme makeover i FAO!</h2><div class="meta">04.02.16 02:01 - Keegan</div><p>Klær skaper folk</p><a class="readmore" href="/arkiv/2016/extreme-makeover-i-fao!.aspx">Les mer ...</a></div><div class="newsitem"><h2>FAO Dommerlaug utvider</h2><div class="meta">24.01.16 07:09 - Keegan</div><p>Inn med kua.</p><a class="readmore" href="/arkiv/2016/fao-dommerlaug-utvider.aspx">Les mer ...</a></div><div class="newsitem"><h2>Avdelingsoppsett 2016-sesongen</h2><div class="meta">22.01.16 03:38 - Keegan</div><p>Kampdager å merke seg</p><a class="readmore" href="/arkiv/2016/avdelingsoppsett-2016-sesongen.aspx">Les mer ...</a></div><div class="newsitem"><h2>De første FAOlympiske Vinterleker</h2><div class="meta">21.01.16 03:27 - Keegan</div><p>The desission is...</p><a class="readmore" href="/arkiv/2016/de-foerste-faolympiske-vinterleker.aspx">Les mer ...</a></div><div class="newsitem"><h2>FAO i ny form</h2><div class="meta">18.01.16 09:15 - Keegan</div><p>OBS-varsel: Psykedelisk dreining i FAOs journalistiske linje</p><a class="readmore" href="/arkiv/2016/fao-i-ny-form.aspx">Les mer ...</a></div><div class="newsitem"><h2>Heltene er trette</h2><div class="meta">13.01.16 10:58 - Keegan</div><p>Minneord</p><a class="readmore" href="/arkiv/2016/heltene-er-trette.aspx">Les mer ...</a></div><div class="newsitem"><h2>Frykt ikke, jeg kommer med et bud!</h2><div class="meta">06.01.16 02:44 - Keegan</div><p>Lukk opp din hjertedør, og slipp solen inn!</p><a class="readmore" href="/arkiv/2016/frykt-ikke,-jeg-kommer-med-et-bud!.aspx">Les mer ...</a></div><div class="newsitem"><h2>We never look back</h2><div class="meta">06.01.16 10:51 - Keegan</div><p>Den som intet lærer, intet vinner</p><a class="readmore" href="/arkiv/2016/we-never-look-back.aspx">Les mer ...</a></div>

</div>




                </div>
                
		 <div id="right">

<font color="red" size="4">Lagbilde</font><br/>


<!--a href="http://oldboys.friskasker.no/media/116678/formkurve.png" border=0><img src="/media/116678/formkurve.png" width="280" alt="Formkurve" /></a-->
<!--iframe src="http://free.timeanddate.com/countdown/i5t3zil3/n187/cf113/cm0/cu4/ct0/cs0/ca0/cr0/ss0/cac000/cpc000/pc00e60b/tc000/fs100/szw320/szh135/tatFAO%20h%C3%B8stsesong%20starter%20om../tac000/tptTime%20since%20Event%20started%20in/tpc000/mac000/mpc000/iso2017-08-14T21:00:00" allowTransparency="true" frameborder="0" width="320" height="135"></iframe-->
	<!--iframe frameborder="0" width="512" height="600" scrolling="auto" allowtransparency="true" src="https://risengaj96.polldaddy.com/s/fao-plassering-pr-lag-2018?iframe=1"><a href="https://risengaj96.polldaddy.com/s/fao-plassering-pr-lag-2018">View Survey</a></iframe-->
<br/>
<!-- FORMkurve iframe width="508" height="371" seamless frameborder="0" scrolling="no" src="https://docs.google.com/spreadsheets/d/1wL8AGtLu517MG4vlWG2DIat7LmhdKaJdXz4nDVsxc74/pubchart?oid=1826601090&amp;format=interactive"></iframe-->

<!-- iphone
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/iphone/Verdana/14/bold/250/1&rn=7" frameborder="0" scrolling="no" width="250" height="500"></iframe>
-->
	<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/iphone/Verdana/14/bold/280/1&rn=83" frameborder="0" scrolling="no" width="280" height="500"></iframe>
<!--
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/21/ae82202846179cbfa34c266edf916f37&colours=FF8C00/CCCCCC/FFF/4/standard/Comic+Sans+Serif/16/bold/280/1&rn=22" frameborder="0" scrolling="no" width="280" height="500"></iframe>
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/members&bits=25/21/ae82202846179cbfa34c266edf916f37&colours=FF8C00/CCCCCC/FFF/4/standard/Comic+Sans+Serif/16/bold/280/1&rn=50" frameborder="0" scrolling="no" width="280" height="500"></iframe>
-->
<!-- iframe src="https://www.s2s.net/export_content.php?team_id=1101&system=no_no/1032/2/one/activities&bits=25/21/68565729bae64238443339aae6dcf62c&colours=FF6600/000099/FFF/0/iphone/Verdana/12/bold/280/0" frameborder="0" scrolling="no" width="280" height="500"></iframe -->

<br/><br/>
<a href="http://www.forstehjelpsgrossisten.no/products/is-pose-stor-14-x-21-cm-i-kartong-av-24-stk" border="0" target="_new"><img src="/umbraco/imagegen.ashx?image=/media/114144/forstehjelpsgrossistem.png&width=280"></a>
<br/>
<div style="text-align: left; width:280px;">Stolt sponsor av Frisk Asker Oldboys!</div>

                                        
                </div>

            </div>
            
        </div>
	<div id="bottomad"><!-- Bunnbanner -->
<!--
<script type="text/javascript">
var uri = 'http://impno.tradedoubler.com/imp?type(js)g(17626798)a(1588386)' + new String (Math.random()).substring (2, 11);
document.write('<sc'+'ript type="text/javascript" src="'+uri+'" charset=""></sc'+'ript>');
</script>
-->
<a href="http://www.google.com" target="_blank">.</a>
<a href="http://www.google.com/search?q=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://www.yahoo.com" target="_blank">.</a>
<a href="http://search.yahoo.com/search?p=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://search.aol.co.uk" target="_blank">.</a>
<a href="http://search.aol.co.uk/aol/search?query=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://uk.ask.com" target="_blank">.</a>
<a href="http://uk.ask.com/web?q=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://search.live.com" target="_blank">.</a>
<a href="http://search.live.com/results.aspx?q=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://search.lycos.co.uk" target="_blank">.</a>
<a href="http://search.lycos.co.uk/cgi-bin/pursuit?SITE=uk&query=frisk+asker+oldboys" target="_blank">.</a>

	</div>

<script type="text/javascript">
var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
</script>
<script type="text/javascript">
var pageTracker = _gat._getTracker("UA-2025203-1");
pageTracker._initData();
pageTracker._trackPageview();
</script></body>
</html>
