
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">

	<head>

		<title>Simulatorarbeid  - Frisk Asker Oldboys</title>
		
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
		<meta http-equiv="imagetoolbar" CONTENT="no">
		<meta name="keywords" content="" />
		<meta name="description" content="Hvisomatte, dersomatte" />
		
		<meta name="title" content="Simulatorarbeid - Frisk Asker Oldboys" />
		<meta name="URL" content="http://oldboys.friskasker.no" />
		<meta name="language" content="Norsk" />
		<meta name="author" content="Terje Dahl" />
		<meta name="copyright" content="Frisk Asker Oldboys" />
		<meta name="reply-to" content="terjda@online.no" />
		<meta name="verify-v1" content="BxVdMcZ0uoa2KVw8RB+FBg3715LgSDXNG+RYp0gHpAI=" />

		<link type="text/css" href="/css/client.css" rel="stylesheet" />
		<link type="text/css" href="/css/default.css" rel="stylesheet" />
		<link type="text/css" href="/css/weatherCSS.css" rel="stylesheet" />

		<script type="text/javascript" src="/js/jquery.js"></script>
		<script type="text/javascript" src="/js/ufo.js"></script>
		<script type="text/javascript" src="/js/friskasker.js"></script>
		<!--script type='text/javascript' src='http://www.rdmtech.no/js/jquery.js?ver=1.2.6'></script-->
		<!--script type='text/javascript' src='http://www.rdmtech.no/js/jquery.cross-slide.js?ver=2.6'></script-->

		<!--[if IE 6]>
		<link type="text/css" href="/css/ie60.css" rel="stylesheet" />			
		<![endif]-->
		<!-- TradeDoubler site verification 1588386 --> 

	<script type='text/javascript'>
		jQuery(function($) {$(document).ready(function() {
			$('#container2').crossSlide(
				{sleep: 2, fade: 1},
				[{src: 'http://oldboys.friskasker.no/media/26561/bg-fao1.jpg'},{src: 'http://oldboys.friskasker.no/media/26566/bg-fao2.jpg'},{src: 'http://oldboys.friskasker.no/media/26571/bg-fao3.jpg'},{src: 'http://oldboys.friskasker.no/media/26576/bg-fao4.jpg'}]
			);
		});});
	</script>
	
<script type="text/javascript">
var _polldaddy = [] || _polldaddy;

_polldaddy.push( {
    type: 'slider',
    title: 'FAO-spillemodellen, skjønner du den?',
    body: 'Ta testen og bidra til å øke sjansen for sportslig utvikling av FAO!',
    button: 'Get Started &raquo;',
    domain: 'risengaj96.polldaddy.com/s/',
    id: 'fao-spillemodellen',
    placeholder: 'pd1438692132734'
} );

jQuery(function(d,c,j){$if(!document.getElementById(j)){var pd=d.createElement(c),s;pd.id=j;pd.src=('https:'==document.location.protocol)?'https://polldaddy.com/survey.js':'http://i0.poll.fm/survey.js';s=document.getElementsByTagName(c)[0];s.parentNode.insertBefore(pd,s);}}(document,'script','pd-embed'));
</script>

	
	</head>
	
	<body>
      
        <div id="container">&nbsp;
        
            <div id="header">&nbsp;
            
                <div id="logo"><a href="/"><img src="/media/26597/logos.gif" alt="Logo" /></a></div>
                <div id="rss"><a href="/data/rss/nyheter.xml">Motta RSS strøm</a></div>
		<!--div id="sitemap"><a href="/sitemap.aspx">Sitemap</a></div-->
		<div id="topknapp">
		<iframe width="280" height="160" src="https://www.youtube.com/embed/15KEqzCTrwI" frameborder="0" allowfullscreen></iframe>
		</div>
		
                

            </div>
            
            <div id="body">&nbsp;
            
                <div id="left">&nbsp;

                    <div id="date">mandag 15. april</div>
                	
                    <div class="leftnav"><a href="/">Hjem</a><br /><a href="/arkiv.aspx">Arkiv</a><br /><a href="/tabeller--terminlister.aspx">Tabeller &amp; terminlister</a><br /><a href="/kampreferat.aspx">Kampreferat</a><br /><a href="/fotballfilosofi.aspx">Fotballfilosofi</a><br /><a href="/ikke-helt-sportslig.aspx">Ikke helt sportslig</a><br /></div>
		
                    <div class="box" id="contactbox"><div class="header">Frisk Asker</div><div class="body"><a href="/frisk-asker/laget.aspx">Laget</a><br /><a href="/frisk-asker/kontakt.aspx">Kontakt</a><br /><a href="/frisk-asker/dommerhjoernet.aspx">Dommerhjørnet</a><br /><a href="https://teams.s2s.net/11225/no/" target="_new">Treningstider</a></div><div class="footer"><!----></div></div>

<!--		     <iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/standard/Verdana/14/bold/230/1&rn=84" frameborder="0" scrolling="no" width="230" height="500"></iframe>
-->
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&banner=1&system=no_no/5212/1/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/standard/Verdana/14/bold/230/1&rn=94" frameborder="0" scrolling="no" width="230" height="214"></iframe>

		     <iframe src="http://www.s2s.net/todays_skill_external.php?ccc=no" scrolling="no" width="200" height="330" frameborder="0"></iframe>
<!--
		     <div id="login">&nbsp;
                   
                    <form id="loginform" action="#">&nbsp;
                      
                        <input id="username" type="text" value="brukernavn" />
                        <input id="password" type="text" value="passord" />
                        <img src="/img/login.gif" alt="login" />
                        <a href="#">glemt passord?</a>    
                        
                    </form>
                    
                    </div>
-->
		    <div id="search">

			Artikkelsøk:<br />
			<div id="xsltsearch" xmlns:ps="urn:percipientstudios-com:xslt"><form action="/soek.aspx?" method="post" class="xsltsearch_form"><input name="search" type="text" class="input" value=""></input> <input type="submit" value="Search" class="submit" /></form></div>
		    </div>

                </div>
                
                <div id="center">
		
                    
<div class="content">

	<h1>Simulatorarbeid</h1><div class="meta">11.09.16 12:44 - </div><div class="abstract"><img src="/umbraco/imagegen.ashx?image=/media/117049/sim.jpg&amp;width=500" alt="" align="left" />Hvisomatte, dersomatte</div>
<p>FAOs analyseavdeling har analysert den forestående thrilleren i
M40.</p>

<p>Tabellen før runde 12 ser slik ut:</p>

<p><img src="/media/117062/tt_279x196.jpg"  width="279"  height="196" alt="tt"/></p>

<p>hvor tabellteorien sier at det nå står mellom tre lag:</p>

<p class="smaller1">Frisk Asker 11&nbsp; +20&nbsp;&nbsp; 25<br />
 Røa&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
11&nbsp; +13&nbsp;&nbsp; 21<br />
 Lyn&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
11&nbsp; +12&nbsp;&nbsp; 21</p>

<p>De tre gjenstående rundene for kandidatene ser slik ut, med to
bortekamper for Frisk, og to hjemmekamper for Røa og Lyn:</p>

<table border="0" cellspacing="0" cellpadding="0"
style="width: 453px; height: 86px;">
<tbody>
<tr height="19">
<td width="116" height="19">Runde 12:</td>
<td width="18"><br />
</td>
<td width="120">Runde 13:</td>
<td width="18"><br />
</td>
<td width="83">Runde 14:</td>
</tr>

<tr height="19">
<td height="19">Ullern - Frisk Asker</td>
<td><br />
</td>
<td>Frisk Asker - Kjelsås</td>
<td><br />
</td>
<td>Røa - Frisk Asker</td>
</tr>

<tr height="19">
<td height="19">Røa - Høyb/St</td>
<td><br />
</td>
<td>Vollen - Røa</td>
<td><br />
</td>
<td>Kjelsås - Lyn</td>
</tr>

<tr height="19">
<td height="19">Lyn - BVH</td>
<td><br />
</td>
<td>Lyn - Ullern</td>
<td><br />
</td>
<td><br />
</td>
</tr>
</tbody>
</table>

<p>&nbsp;</p>

<p><em>Simulering av runde 12:</em></p>

<p>De tre øverste lagene som kjemper om opprykk, møter de tre
nederste lagene som kjemper mot nedrykk.<br />
 Frisk møter det aller nederste, men Frisk er det eneste av
topplagene som spiller borte.<br />
 Simulatoren gir derfor lik sjanse for seier til de tre topplagene,
og størst sannsynlighet for at alle tre vinner, og at tabellen med
to gjenstående kamper da ser slik ut:</p>

<p class="smaller1">Frisk Asker 12&nbsp; +21 &nbsp; 28<br />
 Røa&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
12&nbsp; +14 &nbsp; 24<br />
 Lyn&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
12&nbsp; +13 &nbsp; 24</p>

<p><em>Simulering av runde 13:<br />
</em> Lyn møter bunnlaget hjemme, og vinner.<br />
 Frisk og Røa har sterkere, og omtrent lik, motstand.<br />
 Sannsynligheten for kamputfallene i de to kampene er like, med en
liten overvekt på uavgjort resultat.<br />
 Med én gjenstående kamp, ser da tabellen slik ut:</p>

<p class="smaller1">Frisk Asker 13&nbsp; +21 &nbsp; 29<br />
 Lyn&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
13&nbsp; +14 &nbsp; 27<br />
 Røa
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
13&nbsp; +14 &nbsp; 25</p>

<p><em>Simulering av runde 14:<br />
</em> Lyn MÅ ha seier, og klarer det.<br />
 Frisk MÅ ha uavgjort, og klarer det.<br />
 Dette gir følgende sluttabell:</p>

<p class="smaller1">Frisk Asker 14&nbsp; +21 &nbsp; 30<br />
 Lyn&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
14&nbsp; +15 &nbsp; 30<br />
 Røa
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
14&nbsp; +14 &nbsp; 26</p>

<p>Simuloppsummert:<br />
 Lyn kommer til å vinne alle sine tre siste kamper, som betyr at
Frisk for det første absolutt bør slå Ullern førstkommende torsdag,
og deretter ta to poeng på de to siste kampene, enten med uavgjort
i begge, eller ved å vinne én av dem.</p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p><img src="/media/117181/f40_445x280.jpg"  width="445"  height="280" alt="f40"/></p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>&nbsp;</p>



<div class="addthis_toolbox addthis_default_style">
<a href="http://www.addthis.com/bookmark.php?v=250&amp;username=xa-4be09cd0025b8da5" class="addthis_button_compact">Share</a>
<span class="addthis_separator">|</span>
<a class="addthis_button_facebook"></a>
<a class="addthis_button_myspace"></a>
<a class="addthis_button_google"></a>
<a class="addthis_button_twitter"></a>
</div>
<script type="text/javascript" src="http://s7.addthis.com/js/250/addthis_widget.js#username=xa-4be09cd0025b8da5"></script>
<!-- AddThis Button END -->

<hr>
<h2>Kommentarer:</h2>
	<div class="newsitem"><i><b>11.09.16 13:56 - <a href="mailto:">Nr 7</a></b></i><p>Simulering 2: Frisk vinner sine to neste kamper, og ferdig med det.</p></div><div class="newsitem"><i><b>11.09.16 23:07 - <a href="mailto:">happi</a></b></i><p>Hvordan blir det med poenglikhet? Teller målforskjell først, og så innbyrdes? </p></div><div class="newsitem"><i><b>11.09.16 23:11 - <a href="mailto:">Nr 7</a></b></i><p>Ja, det er vanlig målforskjell og så antall scora mål i seriesystemet. Innbyrdes er vel mere i turneringer.</p></div><div class="newsitem"><i><b>12.09.16 7:40 - <a href="mailto:">Happi</a></b></i><p>Innbyrdes gjelder også i serier. 

Noen serier tar til og med omkamp, og bryr seg ikke om målforskjellen.</p></div><div class="newsitem"><i><b>12.09.16 13:39 - <a href="mailto:">Mads</a></b></i><p>Tror vi vinner serien i nest siste kamp mot Kjelsås. Siste kamp borte mot Røa er jeg bortreist :(</p></div>
<!--
<p>
<b>Kommentering er midlertidig steng pga SPAM!</b>
</p>
-->
<form method="post" action="simulatorarbeid.aspx" id="aspnetForm">
<div>
<input type="hidden" name="__EVENTTARGET" id="__EVENTTARGET" value="" />
<input type="hidden" name="__EVENTARGUMENT" id="__EVENTARGUMENT" value="" />
<input type="hidden" name="__VIEWSTATE" id="__VIEWSTATE" value="/wEPDwUENTM4MQ9kFgJmD2QWAmYPZBYCZg9kFgJmD2QWAgIPD2QWAgIFD2QWAgIBD2QWAmYPZBYCAgIPZBYCAgEPFgIeBFRleHQFF0RpbiBrb21tZW50YXIgZXIgcG9zdGV0ZGTP3+kahhm7HkFLDJ1eDASlO9mxvA==" />
</div>

<script type="text/javascript">
//<![CDATA[
var theForm = document.forms['aspnetForm'];
if (!theForm) {
    theForm = document.aspnetForm;
}
function __doPostBack(eventTarget, eventArgument) {
    if (!theForm.onsubmit || (theForm.onsubmit() != false)) {
        theForm.__EVENTTARGET.value = eventTarget;
        theForm.__EVENTARGUMENT.value = eventArgument;
        theForm.submit();
    }
}
//]]>
</script>


<script src="/WebResource.axd?d=RhJRe7vAQjxLvd0VTiPlJ3ItrtWKNnlC5ndUOdQ1oQE84Jw0mmyu8t9423FKr6Sh25O1JfgygCRLDXncXNuX2rijfWY1&amp;t=635737087099672665" type="text/javascript"></script>


<script type="text/javascript">
//<![CDATA[
function insertLink(element) {var theLink = prompt('Enter URL for link here:','http://');insertTag(element, 'a', ' href="' + theLink + '"')}
            function insertTag(element, tag, param) {
            start = '<' + tag + param + '>';
            eind = '</' + tag + '>';
             /* element = document.getElementById(element); */
              if (document.selection) {
                element.focus();
                sel = document.selection.createRange();
                sel.text = start + sel.text + eind;
              } else if (element.selectionStart || element.selectionStart == '0') {
                element.focus();
                var startPos = element.selectionStart;
                var endPos = element.selectionEnd;
                element.value = element.value.substring(0, startPos) + start + element.value.substring(startPos, endPos) + eind + element.value.substring(endPos, element.value.length);
              } else {
                element.value += start + eind;
              }
            }
            //]]>
</script>

<h2>Post en kommentar:</h2>
<div id="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_PanelInput">
	
	<div id="umbracoAutoForm">
	
  <fieldset>
			<p><label for="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_navn">Navn:</label><input name="ctl00$ctl00$ctl00$ContentPlaceHolderDefault$MainContentPlaceHolder$AutoForm_7$navn" type="text" id="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_navn" class="umbEditorTextField" /></p><p><label for="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_epost">Epost:</label><input name="ctl00$ctl00$ctl00$ContentPlaceHolderDefault$MainContentPlaceHolder$AutoForm_7$epost" type="text" id="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_epost" class="umbEditorTextField" /></p><p><label for="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_kommentar">Kommentar:</label><table border="0" cellspacing="0" cellpadding="0"><tr><td>
	<p align="right" style="margin: 0px; padding:0px"><a href="javascript:insertLink(document.getElementById('ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_kommentar'))"><img src="/umbraco_client/simpleEditor/images/link.gif" border="0" align="right" /></a><a href="javascript:insertTag(document.getElementById('ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_kommentar'), 'em', '')"><img src="/umbraco_client/simpleEditor/images/italic.gif" border="0" style="margin-left: 3px; margin-right: 3px;" align="right" /></a> <a href="javascript:insertTag(document.getElementById('ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_kommentar'), 'strong', '')"><img src="/umbraco_client/simpleEditor/images/bold.gif" border="0" align="right" /></a><br/></p>
	<textarea name="ctl00$ctl00$ctl00$ContentPlaceHolderDefault$MainContentPlaceHolder$AutoForm_7$kommentar" rows="8" cols="20" id="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_kommentar" class="umbEditorTextField"></textarea></td></tr></table>
	</p><p><label for="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_captcha">Captcha:</label><input name="ctl00$ctl00$ctl00$ContentPlaceHolderDefault$MainContentPlaceHolder$AutoForm_7$captcha" type="text" id="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_captcha" class="umbEditorNumberField" /><br/><span class="umbracoAutoFormRowDescription">Hva er elleve pluss åtte?<br/></span></p>
		<p><input type="submit" name="ctl00$ctl00$ctl00$ContentPlaceHolderDefault$MainContentPlaceHolder$AutoForm_7$Button1" value="Post kommentar" onclick="javascript:WebForm_DoPostBackWithOptions(new WebForm_PostBackOptions(&quot;ctl00$ctl00$ctl00$ContentPlaceHolderDefault$MainContentPlaceHolder$AutoForm_7$Button1&quot;, &quot;&quot;, true, &quot;&quot;, &quot;&quot;, false, false))" id="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_Button1" class="umbracoAutoFormButton" /></p>
	</fieldset>		
	</div>

</div>

		

<div>

	<input type="hidden" name="__VIEWSTATEGENERATOR" id="__VIEWSTATEGENERATOR" value="CA0B0334" />
</div></form>

<a class="readmore" href="/arkiv/2021/frisk-asker---covid-19-19-.aspx">Frisk Asker - Covid 19-19 </a> - 17.03.2021 8:41<br /><a class="readmore" href="/arkiv/2016/faos-sommerkrim.aspx">FAOs sommerkrim</a> - 29.04.2020 12:32<br /><a class="readmore" href="/arkiv/2019/fao-med-kupp-paa-overgangsmarkedet!.aspx">FAO med kupp på overgangsmarkedet!</a> - 30.07.2019 19:24<br /><a class="readmore" href="/arkiv/2019/dag-ansatt-som-fast-lagleder-paa-frisk-asker-m33.aspx">Dag ansatt som fast lagleder på Frisk Asker M33</a> - 29.07.2019 12:28<br /><a class="readmore" href="/arkiv/2019/askermesterskapet-i-oldboysfotball.aspx">Askermesterskapet i oldboysfotball</a> - 07.05.2019 16:49<br /><a class="readmore" href="/arkiv/2019/frisk-asker-oldgirls!.aspx">Frisk Asker OldGIRLS!</a> - 05.04.2019 14:14<br /><a class="readmore" href="/arkiv/2019/know-your-enemy.aspx">Know your enemy</a> - 01.02.2019 16:46<br /><a class="readmore" href="/arkiv/2018/pass-paa-liten-og-paa-stor.aspx">Pass på liten og på stor</a> - 21.09.2018 15:21<br /><a class="readmore" href="/arkiv/2018/nedrykk!.aspx">Nedrykk!</a> - 14.09.2018 14:40<br /><a class="readmore" href="/arkiv/2018/lukten-av-gull!.aspx">Lukten av gull!</a> - 07.09.2018 22:27<br />
<br/><br/>
<!--
<table id="forumposts" cellspacing="0"><tr><th colspan="2">Siste publiserte fra Sekreteriatet</th></tr><tr><td><b><a class="readmore" href="/sekreteriatet/kamprutine.aspx">Kamprutine</a> - </b>12.06.14 01:36</td></tr><tr><td><b><a class="readmore" href="/sekreteriatet/kamp-mot-bygdoe-monolitten---hvem-stiller.aspx">Kamp mot Bygdø Monolitten - hvem stiller?</a> - </b>12.09.12 09:23</td></tr><tr><td><b><a class="readmore" href="/sekreteriatet/kamp-mot-huk---hvem-stiller-(1).aspx">Kamp mot Huk - hvem stiller? (1)</a> - </b>04.09.12 10:04</td></tr><tr><td><b><a class="readmore" href="/sekreteriatet/kamp-mot-lokomotiv-oslo-29-aug---hvem-stiller.aspx">Kamp mot Lokomotiv Oslo 29. aug - hvem stiller?</a> - </b>28.08.12 02:56</td></tr><tr><td><b><a class="readmore" href="/sekreteriatet/kamp-mot-aarvoll-ons-15-aug---hvem-stiller.aspx">Kamp mot Årvoll ons 15. aug - Hvem stiller?</a> - </b>13.08.12 12:50</td></tr><tr><td class="footer" colspan="2"> </td></tr></table>
-->
</div>



                </div>
                
		 <div id="right">

<font color="red" size="4">Lagbilde</font><br/>


<!--a href="http://oldboys.friskasker.no/media/116678/formkurve.png" border=0><img src="/media/116678/formkurve.png" width="280" alt="Formkurve" /></a-->
<!--iframe src="http://free.timeanddate.com/countdown/i5t3zil3/n187/cf113/cm0/cu4/ct0/cs0/ca0/cr0/ss0/cac000/cpc000/pc00e60b/tc000/fs100/szw320/szh135/tatFAO%20h%C3%B8stsesong%20starter%20om../tac000/tptTime%20since%20Event%20started%20in/tpc000/mac000/mpc000/iso2017-08-14T21:00:00" allowTransparency="true" frameborder="0" width="320" height="135"></iframe-->
	<!--iframe frameborder="0" width="512" height="600" scrolling="auto" allowtransparency="true" src="https://risengaj96.polldaddy.com/s/fao-plassering-pr-lag-2018?iframe=1"><a href="https://risengaj96.polldaddy.com/s/fao-plassering-pr-lag-2018">View Survey</a></iframe-->
<br/>
<!-- FORMkurve iframe width="508" height="371" seamless frameborder="0" scrolling="no" src="https://docs.google.com/spreadsheets/d/1wL8AGtLu517MG4vlWG2DIat7LmhdKaJdXz4nDVsxc74/pubchart?oid=1826601090&amp;format=interactive"></iframe-->

<!-- iphone
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/iphone/Verdana/14/bold/250/1&rn=7" frameborder="0" scrolling="no" width="250" height="500"></iframe>
-->
	<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/iphone/Verdana/14/bold/280/1&rn=83" frameborder="0" scrolling="no" width="280" height="500"></iframe>
<!--
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/21/ae82202846179cbfa34c266edf916f37&colours=FF8C00/CCCCCC/FFF/4/standard/Comic+Sans+Serif/16/bold/280/1&rn=22" frameborder="0" scrolling="no" width="280" height="500"></iframe>
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/members&bits=25/21/ae82202846179cbfa34c266edf916f37&colours=FF8C00/CCCCCC/FFF/4/standard/Comic+Sans+Serif/16/bold/280/1&rn=50" frameborder="0" scrolling="no" width="280" height="500"></iframe>
-->
<!-- iframe src="https://www.s2s.net/export_content.php?team_id=1101&system=no_no/1032/2/one/activities&bits=25/21/68565729bae64238443339aae6dcf62c&colours=FF6600/000099/FFF/0/iphone/Verdana/12/bold/280/0" frameborder="0" scrolling="no" width="280" height="500"></iframe -->

<br/><br/>
<a href="http://www.forstehjelpsgrossisten.no/products/is-pose-stor-14-x-21-cm-i-kartong-av-24-stk" border="0" target="_new"><img src="/umbraco/imagegen.ashx?image=/media/114144/forstehjelpsgrossistem.png&width=280"></a>
<br/>
<div style="text-align: left; width:280px;">Stolt sponsor av Frisk Asker Oldboys!</div>

                                        
                </div>

            </div>
            
        </div>
	<div id="bottomad"><!-- Bunnbanner -->
<!--
<script type="text/javascript">
var uri = 'http://impno.tradedoubler.com/imp?type(js)g(17626798)a(1588386)' + new String (Math.random()).substring (2, 11);
document.write('<sc'+'ript type="text/javascript" src="'+uri+'" charset=""></sc'+'ript>');
</script>
-->
<a href="http://www.google.com" target="_blank">.</a>
<a href="http://www.google.com/search?q=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://www.yahoo.com" target="_blank">.</a>
<a href="http://search.yahoo.com/search?p=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://search.aol.co.uk" target="_blank">.</a>
<a href="http://search.aol.co.uk/aol/search?query=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://uk.ask.com" target="_blank">.</a>
<a href="http://uk.ask.com/web?q=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://search.live.com" target="_blank">.</a>
<a href="http://search.live.com/results.aspx?q=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://search.lycos.co.uk" target="_blank">.</a>
<a href="http://search.lycos.co.uk/cgi-bin/pursuit?SITE=uk&query=frisk+asker+oldboys" target="_blank">.</a>

	</div>

<script type="text/javascript">
var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
</script>
<script type="text/javascript">
var pageTracker = _gat._getTracker("UA-2025203-1");
pageTracker._initData();
pageTracker._trackPageview();
</script></body>
</html>
