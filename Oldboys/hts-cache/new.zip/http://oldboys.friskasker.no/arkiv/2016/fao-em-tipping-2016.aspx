
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">

	<head>

		<title>FAO EM tipping 2016  - Frisk Asker Oldboys</title>
		
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
		<meta http-equiv="imagetoolbar" CONTENT="no">
		<meta name="keywords" content="" />
		<meta name="description" content="16 menn har nå gjort sitt beste for å spå utfallet av de innledende kampene i UEFA EURO 20016. Resultatet ser dere her:" />
		
		<meta name="title" content="FAO EM tipping 2016 - Frisk Asker Oldboys" />
		<meta name="URL" content="http://oldboys.friskasker.no" />
		<meta name="language" content="Norsk" />
		<meta name="author" content="Terje Dahl" />
		<meta name="copyright" content="Frisk Asker Oldboys" />
		<meta name="reply-to" content="terjda@online.no" />
		<meta name="verify-v1" content="BxVdMcZ0uoa2KVw8RB+FBg3715LgSDXNG+RYp0gHpAI=" />

		<link type="text/css" href="/css/client.css" rel="stylesheet" />
		<link type="text/css" href="/css/default.css" rel="stylesheet" />
		<link type="text/css" href="/css/weatherCSS.css" rel="stylesheet" />

		<script type="text/javascript" src="/js/jquery.js"></script>
		<script type="text/javascript" src="/js/ufo.js"></script>
		<script type="text/javascript" src="/js/friskasker.js"></script>
		<!--script type='text/javascript' src='http://www.rdmtech.no/js/jquery.js?ver=1.2.6'></script-->
		<!--script type='text/javascript' src='http://www.rdmtech.no/js/jquery.cross-slide.js?ver=2.6'></script-->

		<!--[if IE 6]>
		<link type="text/css" href="/css/ie60.css" rel="stylesheet" />			
		<![endif]-->
		<!-- TradeDoubler site verification 1588386 --> 

	<script type='text/javascript'>
		jQuery(function($) {$(document).ready(function() {
			$('#container2').crossSlide(
				{sleep: 2, fade: 1},
				[{src: 'http://oldboys.friskasker.no/media/26561/bg-fao1.jpg'},{src: 'http://oldboys.friskasker.no/media/26566/bg-fao2.jpg'},{src: 'http://oldboys.friskasker.no/media/26571/bg-fao3.jpg'},{src: 'http://oldboys.friskasker.no/media/26576/bg-fao4.jpg'}]
			);
		});});
	</script>
	
<script type="text/javascript">
var _polldaddy = [] || _polldaddy;

_polldaddy.push( {
    type: 'slider',
    title: 'FAO-spillemodellen, skjønner du den?',
    body: 'Ta testen og bidra til å øke sjansen for sportslig utvikling av FAO!',
    button: 'Get Started &raquo;',
    domain: 'risengaj96.polldaddy.com/s/',
    id: 'fao-spillemodellen',
    placeholder: 'pd1438692132734'
} );

jQuery(function(d,c,j){$if(!document.getElementById(j)){var pd=d.createElement(c),s;pd.id=j;pd.src=('https:'==document.location.protocol)?'https://polldaddy.com/survey.js':'http://i0.poll.fm/survey.js';s=document.getElementsByTagName(c)[0];s.parentNode.insertBefore(pd,s);}}(document,'script','pd-embed'));
</script>

	
	</head>
	
	<body>
      
        <div id="container">&nbsp;
        
            <div id="header">&nbsp;
            
                <div id="logo"><a href="/"><img src="/media/26597/logos.gif" alt="Logo" /></a></div>
                <div id="rss"><a href="/data/rss/nyheter.xml">Motta RSS strøm</a></div>
		<!--div id="sitemap"><a href="/sitemap.aspx">Sitemap</a></div-->
		<div id="topknapp">
		<iframe width="280" height="160" src="https://www.youtube.com/embed/15KEqzCTrwI" frameborder="0" allowfullscreen></iframe>
		</div>
		
                

            </div>
            
            <div id="body">&nbsp;
            
                <div id="left">&nbsp;

                    <div id="date">mandag 15. april</div>
                	
                    <div class="leftnav"><a href="/">Hjem</a><br /><a href="/arkiv.aspx">Arkiv</a><br /><a href="/tabeller--terminlister.aspx">Tabeller &amp; terminlister</a><br /><a href="/kampreferat.aspx">Kampreferat</a><br /><a href="/fotballfilosofi.aspx">Fotballfilosofi</a><br /><a href="/ikke-helt-sportslig.aspx">Ikke helt sportslig</a><br /></div>
		
                    <div class="box" id="contactbox"><div class="header">Frisk Asker</div><div class="body"><a href="/frisk-asker/laget.aspx">Laget</a><br /><a href="/frisk-asker/kontakt.aspx">Kontakt</a><br /><a href="/frisk-asker/dommerhjoernet.aspx">Dommerhjørnet</a><br /><a href="https://teams.s2s.net/11225/no/" target="_new">Treningstider</a></div><div class="footer"><!----></div></div>

<!--		     <iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/standard/Verdana/14/bold/230/1&rn=84" frameborder="0" scrolling="no" width="230" height="500"></iframe>
-->
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&banner=1&system=no_no/5212/1/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/standard/Verdana/14/bold/230/1&rn=94" frameborder="0" scrolling="no" width="230" height="214"></iframe>

		     <iframe src="http://www.s2s.net/todays_skill_external.php?ccc=no" scrolling="no" width="200" height="330" frameborder="0"></iframe>
<!--
		     <div id="login">&nbsp;
                   
                    <form id="loginform" action="#">&nbsp;
                      
                        <input id="username" type="text" value="brukernavn" />
                        <input id="password" type="text" value="passord" />
                        <img src="/img/login.gif" alt="login" />
                        <a href="#">glemt passord?</a>    
                        
                    </form>
                    
                    </div>
-->
		    <div id="search">

			Artikkelsøk:<br />
			<div id="xsltsearch" xmlns:ps="urn:percipientstudios-com:xslt"><form action="/soek.aspx?" method="post" class="xsltsearch_form"><input name="search" type="text" class="input" value=""></input> <input type="submit" value="Search" class="submit" /></form></div>
		    </div>

                </div>
                
                <div id="center">
		
                    
 <div class="content">

	<h1>FAO EM tipping 2016</h1>
	<p><b>16 menn har nå gjort sitt beste for å spå utfallet av de innledende kampene i UEFA EURO 20016. Resultatet ser dere her:</b></p>

<!--<h1>FAO EM tipping 2016</h1><div class="meta">06.06.16 20:42</div><div class="abstract"><img src="/umbraco/imagegen.ashx?image=/media/114105/uefa.jpg&amp;width=80" alt="" align="left" />16 menn har nå gjort sitt beste for å spå utfallet av de innledende kampene i UEFA EURO 20016. Resultatet ser dere her:</div>
<div id="_mcePaste"
style="position: absolute; left: -10000px; top: 0px; width: 1px; height: 1px; overflow: hidden;">
Spilleregler, overordnet:</div>

<div id="_mcePaste"
style="position: absolute; left: -10000px; top: 0px; width: 1px; height: 1px; overflow: hidden;">
Først vedder man på alle kampresultater i innledende puljespill,
innen fredag 3. juni kl 23:59.</div>

<div id="_mcePaste"
style="position: absolute; left: -10000px; top: 0px; width: 1px; height: 1px; overflow: hidden;">
Onsdag 22. juni er puljespillet slutt, og man vedder innen torsdag
23. juni kl 23:59 på kampresultatene i de oppsatte
åttendedelsfinalene, samt vinnere av alle kamper i
sluttspillet.</div>

<div id="_mcePaste"
style="position: absolute; left: -10000px; top: 0px; width: 1px; height: 1px; overflow: hidden;">
FAO Bookmaking departement's Houndini Betting Engine vil dynamisk
rapportere hvordan resultatlisten ser ut, etter følgende
regler:</div>

<div id="_mcePaste"
style="position: absolute; left: -10000px; top: 0px; width: 1px; height: 1px; overflow: hidden;">
</div>

<div id="_mcePaste"
style="position: absolute; left: -10000px; top: 0px; width: 1px; height: 1px; overflow: hidden;">
Spilleregler, detaljert:</div>

<div id="_mcePaste"
style="position: absolute; left: -10000px; top: 0px; width: 1px; height: 1px; overflow: hidden;">
Riktig kamputfall (HUB): 1 poeng</div>

<div id="_mcePaste"
style="position: absolute; left: -10000px; top: 0px; width: 1px; height: 1px; overflow: hidden;">
Riktig resultat: 1 ekstra poeng</div>

<div id="_mcePaste"
style="position: absolute; left: -10000px; top: 0px; width: 1px; height: 1px; overflow: hidden;">
Hvert riktig lag tippet videre (inkludert beste treere): 2
poeng</div>

<div id="_mcePaste"
style="position: absolute; left: -10000px; top: 0px; width: 1px; height: 1px; overflow: hidden;">
Både lag 1 og 2 riktig i en pulje, men i feil rekkefølge: 1
bonuspoeng</div>

<div id="_mcePaste"
style="position: absolute; left: -10000px; top: 0px; width: 1px; height: 1px; overflow: hidden;">
Både lag 1 og 2 riktig i en pulje, i riktig rekkefølge: 2
bonuspoeng</div>

<div id="_mcePaste"
style="position: absolute; left: -10000px; top: 0px; width: 1px; height: 1px; overflow: hidden;">
Antall mulig poeng i innledende puljespill:</div>

<div id="_mcePaste"
style="position: absolute; left: -10000px; top: 0px; width: 1px; height: 1px; overflow: hidden;">
36*1 + 36*1 +16*2 + 6*2 = 116</div>

<div id="_mcePaste"
style="position: absolute; left: -10000px; top: 0px; width: 1px; height: 1px; overflow: hidden;">
</div>

<div id="_mcePaste"
style="position: absolute; left: -10000px; top: 0px; width: 1px; height: 1px; overflow: hidden;">
Etter ferdigspilt puljespill, tippes sluttspillet:</div>

<div id="_mcePaste"
style="position: absolute; left: -10000px; top: 0px; width: 1px; height: 1px; overflow: hidden;">
Riktig vinner i 1/8-delsfinale: 2 poeng</div>

<div id="_mcePaste"
style="position: absolute; left: -10000px; top: 0px; width: 1px; height: 1px; overflow: hidden;">
Riktig resultat etter ordinær tid i 1/8-delsfinale: 2 ekstra
poeng</div>

<div id="_mcePaste"
style="position: absolute; left: -10000px; top: 0px; width: 1px; height: 1px; overflow: hidden;">
Riktig vinner kvartfinale: 4 poeng</div>

<div id="_mcePaste"
style="position: absolute; left: -10000px; top: 0px; width: 1px; height: 1px; overflow: hidden;">
Riktig vinner semifinale: 8 poeng</div>

<div id="_mcePaste"
style="position: absolute; left: -10000px; top: 0px; width: 1px; height: 1px; overflow: hidden;">
Riktig vinner finale: 16 poeng</div>

<div id="_mcePaste"
style="position: absolute; left: -10000px; top: 0px; width: 1px; height: 1px; overflow: hidden;">
Antall mulig poeng i sluttspill:</div>

<div id="_mcePaste"
style="position: absolute; left: -10000px; top: 0px; width: 1px; height: 1px; overflow: hidden;">
8*2 + 8*2 + 4*4 + 2*8* + 16 = 80 poeng</div>

<div id="_mcePaste"
style="position: absolute; left: -10000px; top: 0px; width: 1px; height: 1px; overflow: hidden;">
Vinneren er den med flest poeng sammenlagt.</div>

<div id="_mcePaste"
style="position: absolute; left: -10000px; top: 0px; width: 1px; height: 1px; overflow: hidden;">
Ved eventuell poenglikhet teller seneste riktige begivenhet mest
(eksempel: to riktige tippet finalelag går foran ett riktig
finalelag).</div>

<div id="_mcePaste"
style="position: absolute; left: -10000px; top: 0px; width: 1px; height: 1px; overflow: hidden;">
Innsatsen går uavkortet tilbake til vinneren, med en trøstepremie
til nummer 2.</div>

<div id="_mcePaste"
style="position: absolute; left: -10000px; top: 0px; width: 1px; height: 1px; overflow: hidden;">
</div>

<div id="_mcePaste"
style="position: absolute; left: -10000px; top: 0px; width: 1px; height: 1px; overflow: hidden;">
Lykke til, måtte den heldigste vinne!</div>

<p><a style="font-size: 12.8px; line-height: 19.2px;"
href="https://docs.google.com/spreadsheets/d/1W2rFswr5PL0o-p76DsfSI200QJZIzqbgc1uu6HW2kXw/edit?usp=sharing"
 target="_blank" title="UEFA 2016 sluttspill"><strong>Mobilversjon
sluttspill</strong></a></p>

<p><a
href="https://docs.google.com/spreadsheets/d/1a6OevYR-8WBRLfR__fCXgdAxBFxiKYoqvBVzj1kuwA4/edit?usp=sharing"
 target="_blank" title="Mobilversjon sidebet">Mobilversjon
sluttspill sidebet (oddstipping)</a></p>

<p><a
href="https://docs.google.com/spreadsheets/d/1ogdUNdeoFVVUnQ5fxLDLRyWgxdxqvFvoupZQ7fK8iUM/edit?usp=sharing">
Mobilversjon&nbsp;gruppespill</a></p>

<p>Vinneren er den med flest poeng sammenlagt.</p>

<p>Ved eventuell poenglikhet teller seneste riktige begivenhet mest
(eksempel: to riktige tippet finalelag går foran ett riktig
finalelag).</p>

<p>Innsatsen går uavkortet tilbake til vinneren, med en
trøstepremie til nummer 2.</p>

<p>&nbsp;</p>

<p>Lykke til, måtte den heldigste vinne!</p>
-->

<iframe width="1460" height="1150" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://docs.google.com/spreadsheets/d/1OqXOPaZfZDdTnIQYMUpM5TBPQKRhcTLvFffDp_7f1lI/edit#gid=1811222117"></iframe>

<p><div id="_mcePaste"
style="position: absolute; left: -10000px; top: 0px; width: 1px; height: 1px; overflow: hidden;">
Spilleregler, overordnet:</div>

<div id="_mcePaste"
style="position: absolute; left: -10000px; top: 0px; width: 1px; height: 1px; overflow: hidden;">
Først vedder man på alle kampresultater i innledende puljespill,
innen fredag 3. juni kl 23:59.</div>

<div id="_mcePaste"
style="position: absolute; left: -10000px; top: 0px; width: 1px; height: 1px; overflow: hidden;">
Onsdag 22. juni er puljespillet slutt, og man vedder innen torsdag
23. juni kl 23:59 på kampresultatene i de oppsatte
åttendedelsfinalene, samt vinnere av alle kamper i
sluttspillet.</div>

<div id="_mcePaste"
style="position: absolute; left: -10000px; top: 0px; width: 1px; height: 1px; overflow: hidden;">
FAO Bookmaking departement's Houndini Betting Engine vil dynamisk
rapportere hvordan resultatlisten ser ut, etter følgende
regler:</div>

<div id="_mcePaste"
style="position: absolute; left: -10000px; top: 0px; width: 1px; height: 1px; overflow: hidden;">
</div>

<div id="_mcePaste"
style="position: absolute; left: -10000px; top: 0px; width: 1px; height: 1px; overflow: hidden;">
Spilleregler, detaljert:</div>

<div id="_mcePaste"
style="position: absolute; left: -10000px; top: 0px; width: 1px; height: 1px; overflow: hidden;">
Riktig kamputfall (HUB): 1 poeng</div>

<div id="_mcePaste"
style="position: absolute; left: -10000px; top: 0px; width: 1px; height: 1px; overflow: hidden;">
Riktig resultat: 1 ekstra poeng</div>

<div id="_mcePaste"
style="position: absolute; left: -10000px; top: 0px; width: 1px; height: 1px; overflow: hidden;">
Hvert riktig lag tippet videre (inkludert beste treere): 2
poeng</div>

<div id="_mcePaste"
style="position: absolute; left: -10000px; top: 0px; width: 1px; height: 1px; overflow: hidden;">
Både lag 1 og 2 riktig i en pulje, men i feil rekkefølge: 1
bonuspoeng</div>

<div id="_mcePaste"
style="position: absolute; left: -10000px; top: 0px; width: 1px; height: 1px; overflow: hidden;">
Både lag 1 og 2 riktig i en pulje, i riktig rekkefølge: 2
bonuspoeng</div>

<div id="_mcePaste"
style="position: absolute; left: -10000px; top: 0px; width: 1px; height: 1px; overflow: hidden;">
Antall mulig poeng i innledende puljespill:</div>

<div id="_mcePaste"
style="position: absolute; left: -10000px; top: 0px; width: 1px; height: 1px; overflow: hidden;">
36*1 + 36*1 +16*2 + 6*2 = 116</div>

<div id="_mcePaste"
style="position: absolute; left: -10000px; top: 0px; width: 1px; height: 1px; overflow: hidden;">
</div>

<div id="_mcePaste"
style="position: absolute; left: -10000px; top: 0px; width: 1px; height: 1px; overflow: hidden;">
Etter ferdigspilt puljespill, tippes sluttspillet:</div>

<div id="_mcePaste"
style="position: absolute; left: -10000px; top: 0px; width: 1px; height: 1px; overflow: hidden;">
Riktig vinner i 1/8-delsfinale: 2 poeng</div>

<div id="_mcePaste"
style="position: absolute; left: -10000px; top: 0px; width: 1px; height: 1px; overflow: hidden;">
Riktig resultat etter ordinær tid i 1/8-delsfinale: 2 ekstra
poeng</div>

<div id="_mcePaste"
style="position: absolute; left: -10000px; top: 0px; width: 1px; height: 1px; overflow: hidden;">
Riktig vinner kvartfinale: 4 poeng</div>

<div id="_mcePaste"
style="position: absolute; left: -10000px; top: 0px; width: 1px; height: 1px; overflow: hidden;">
Riktig vinner semifinale: 8 poeng</div>

<div id="_mcePaste"
style="position: absolute; left: -10000px; top: 0px; width: 1px; height: 1px; overflow: hidden;">
Riktig vinner finale: 16 poeng</div>

<div id="_mcePaste"
style="position: absolute; left: -10000px; top: 0px; width: 1px; height: 1px; overflow: hidden;">
Antall mulig poeng i sluttspill:</div>

<div id="_mcePaste"
style="position: absolute; left: -10000px; top: 0px; width: 1px; height: 1px; overflow: hidden;">
8*2 + 8*2 + 4*4 + 2*8* + 16 = 80 poeng</div>

<div id="_mcePaste"
style="position: absolute; left: -10000px; top: 0px; width: 1px; height: 1px; overflow: hidden;">
Vinneren er den med flest poeng sammenlagt.</div>

<div id="_mcePaste"
style="position: absolute; left: -10000px; top: 0px; width: 1px; height: 1px; overflow: hidden;">
Ved eventuell poenglikhet teller seneste riktige begivenhet mest
(eksempel: to riktige tippet finalelag går foran ett riktig
finalelag).</div>

<div id="_mcePaste"
style="position: absolute; left: -10000px; top: 0px; width: 1px; height: 1px; overflow: hidden;">
Innsatsen går uavkortet tilbake til vinneren, med en trøstepremie
til nummer 2.</div>

<div id="_mcePaste"
style="position: absolute; left: -10000px; top: 0px; width: 1px; height: 1px; overflow: hidden;">
</div>

<div id="_mcePaste"
style="position: absolute; left: -10000px; top: 0px; width: 1px; height: 1px; overflow: hidden;">
Lykke til, måtte den heldigste vinne!</div>

<p><a style="font-size: 12.8px; line-height: 19.2px;"
href="https://docs.google.com/spreadsheets/d/1W2rFswr5PL0o-p76DsfSI200QJZIzqbgc1uu6HW2kXw/edit?usp=sharing"
 target="_blank" title="UEFA 2016 sluttspill"><strong>Mobilversjon
sluttspill</strong></a></p>

<p><a
href="https://docs.google.com/spreadsheets/d/1a6OevYR-8WBRLfR__fCXgdAxBFxiKYoqvBVzj1kuwA4/edit?usp=sharing"
 target="_blank" title="Mobilversjon sidebet">Mobilversjon
sluttspill sidebet (oddstipping)</a></p>

<p><a
href="https://docs.google.com/spreadsheets/d/1ogdUNdeoFVVUnQ5fxLDLRyWgxdxqvFvoupZQ7fK8iUM/edit?usp=sharing">
Mobilversjon&nbsp;gruppespill</a></p>

<p>Vinneren er den med flest poeng sammenlagt.</p>

<p>Ved eventuell poenglikhet teller seneste riktige begivenhet mest
(eksempel: to riktige tippet finalelag går foran ett riktig
finalelag).</p>

<p>Innsatsen går uavkortet tilbake til vinneren, med en
trøstepremie til nummer 2.</p>

<p>&nbsp;</p>

<p>Lykke til, måtte den heldigste vinne!</p></p>

<!-- AddThis Button BEGIN -->
<div class="addthis_toolbox addthis_default_style">
<a href="http://www.addthis.com/bookmark.php?v=250&amp;username=xa-4be09cd0025b8da5" class="addthis_button_compact">Share</a>
<span class="addthis_separator">|</span>
<a class="addthis_button_facebook"></a>
<a class="addthis_button_myspace"></a>
<a class="addthis_button_google"></a>
<a class="addthis_button_twitter"></a>
</div>
<script type="text/javascript" src="http://s7.addthis.com/js/250/addthis_widget.js#username=xa-4be09cd0025b8da5"></script>
<!-- AddThis Button END -->

<hr>
<h2>Kommentarer:</h2>
	<div class="newsitem"><i><b>12.06.16 21:02 - <a href="mailto:">Turbo</a></b></i><p>Usedvanlig presis tipping av Folker! Lykke til Dahl med Tyskland Ukraina, her går du mot strømmen :)</p></div><div class="newsitem"><i><b>23.06.16 11:01 - <a href="mailto:">Turbo</a></b></i><p>Oppdatert med link til sluttspill</p></div><div class="newsitem"><i><b>30.06.16 21:51 - <a href="mailto:">Keegan</a></b></i><p>Før kvartfinalene, er 11 av 16 mann ute. Det skyldes naturligvis at man nå i stor grad ikke kan ta igjen alle foran seg, siden man har mange av de samme vinnerne i de gjenstående kampene...</p></div><div class="newsitem"><i><b>30.06.16 21:54 - <a href="mailto:">Keegan</a></b></i><p>De eneste som kan vinne, håper på hvert sitt lag: Folker (TYS), Mads (WAL), Moa (POR), Turbo (FRA), Keegan (BEL)</p></div><div class="newsitem"><i><b>01.07.16 22:57 - <a href="mailto:">Keegan</a></b></i><p>Slått ut sammen med Belgia, but that's okay - go Wales!!! Folker også ute. Mads, Moa, Turbo eneste gjenlevende! </p></div><div class="newsitem"><i><b>02.07.16 1:06 - <a href="mailto:">Sunny</a></b></i><p>Etter et kjapt overslag ser det ut som det står mellom 4 orakler etter to kvartfinaler;
Moa, Mads, Turbo og Keegan.
Av disse har Keegan antagelig høyest odds som kun vil vinne dersom Italia møter Island i finalen. Vinner hjemmelaget vinner Turbo. </p></div><div class="newsitem"><i><b>02.07.16 1:09 - <a href="mailto:">Sunny</a></b></i><p>Kun 3 orakler! Keegan er selvsagt ute ettersom W møter P i semin.
Alt for kjapt regnet.</p></div><div class="newsitem"><i><b>02.07.16 17:53 - <a href="mailto:reidar.gundersen@gmail.comi">Moa</a></b></i><p>Mest sannsynlig så avgjør Wales-Portugal i semi`n hvem som vinner. </p></div><div class="newsitem"><i><b>11.07.16 10:56 - <a href="mailto:">Clattenburg</a></b></i><p>We hereby announce!<br/>
In the money, in the FAO Euro 2016 betting competition:<br/>
Winner of Main event: Moa!<br/>
2nd place: Kikki<br/>
Side bet: Keegan<br/>
Best secretariate ever: Turbo!<br/>
Congratulations!
<br/></p></div>

<!--p>
<b>Kommentering er midlertidig steng pga SPAM!</b>
</p-->


<form method="post" action="fao-em-tipping-2016.aspx" id="aspnetForm">
<div>
<input type="hidden" name="__EVENTTARGET" id="__EVENTTARGET" value="" />
<input type="hidden" name="__EVENTARGUMENT" id="__EVENTARGUMENT" value="" />
<input type="hidden" name="__VIEWSTATE" id="__VIEWSTATE" value="/wEPDwUENTM4MQ9kFgJmD2QWAmYPZBYCZg9kFgJmD2QWAgIPD2QWAgILD2QWAgIBD2QWAmYPZBYCAgIPZBYCAgEPFgIeBFRleHQFF0RpbiBrb21tZW50YXIgZXIgcG9zdGV0ZGQWQv4zPSp8xElt1zaTFgveGenDIQ==" />
</div>

<script type="text/javascript">
//<![CDATA[
var theForm = document.forms['aspnetForm'];
if (!theForm) {
    theForm = document.aspnetForm;
}
function __doPostBack(eventTarget, eventArgument) {
    if (!theForm.onsubmit || (theForm.onsubmit() != false)) {
        theForm.__EVENTTARGET.value = eventTarget;
        theForm.__EVENTARGUMENT.value = eventArgument;
        theForm.submit();
    }
}
//]]>
</script>


<script src="/WebResource.axd?d=RhJRe7vAQjxLvd0VTiPlJ3ItrtWKNnlC5ndUOdQ1oQE84Jw0mmyu8t9423FKr6Sh25O1JfgygCRLDXncXNuX2rijfWY1&amp;t=635737087099672665" type="text/javascript"></script>


<script type="text/javascript">
//<![CDATA[
function insertLink(element) {var theLink = prompt('Enter URL for link here:','http://');insertTag(element, 'a', ' href="' + theLink + '"')}
            function insertTag(element, tag, param) {
            start = '<' + tag + param + '>';
            eind = '</' + tag + '>';
             /* element = document.getElementById(element); */
              if (document.selection) {
                element.focus();
                sel = document.selection.createRange();
                sel.text = start + sel.text + eind;
              } else if (element.selectionStart || element.selectionStart == '0') {
                element.focus();
                var startPos = element.selectionStart;
                var endPos = element.selectionEnd;
                element.value = element.value.substring(0, startPos) + start + element.value.substring(startPos, endPos) + eind + element.value.substring(endPos, element.value.length);
              } else {
                element.value += start + eind;
              }
            }
            //]]>
</script>

<h2>Post en kommentar:</h2>
<div id="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_PanelInput">
	
	<div id="umbracoAutoForm">
	
  <fieldset>
			<p><label for="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_navn">Navn:</label><input name="ctl00$ctl00$ctl00$ContentPlaceHolderDefault$MainContentPlaceHolder$AutoForm_7$navn" type="text" id="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_navn" class="umbEditorTextField" /></p><p><label for="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_epost">Epost:</label><input name="ctl00$ctl00$ctl00$ContentPlaceHolderDefault$MainContentPlaceHolder$AutoForm_7$epost" type="text" id="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_epost" class="umbEditorTextField" /></p><p><label for="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_kommentar">Kommentar:</label><table border="0" cellspacing="0" cellpadding="0"><tr><td>
	<p align="right" style="margin: 0px; padding:0px"><a href="javascript:insertLink(document.getElementById('ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_kommentar'))"><img src="/umbraco_client/simpleEditor/images/link.gif" border="0" align="right" /></a><a href="javascript:insertTag(document.getElementById('ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_kommentar'), 'em', '')"><img src="/umbraco_client/simpleEditor/images/italic.gif" border="0" style="margin-left: 3px; margin-right: 3px;" align="right" /></a> <a href="javascript:insertTag(document.getElementById('ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_kommentar'), 'strong', '')"><img src="/umbraco_client/simpleEditor/images/bold.gif" border="0" align="right" /></a><br/></p>
	<textarea name="ctl00$ctl00$ctl00$ContentPlaceHolderDefault$MainContentPlaceHolder$AutoForm_7$kommentar" rows="8" cols="20" id="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_kommentar" class="umbEditorTextField"></textarea></td></tr></table>
	</p><p><label for="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_captcha">Captcha:</label><input name="ctl00$ctl00$ctl00$ContentPlaceHolderDefault$MainContentPlaceHolder$AutoForm_7$captcha" type="text" id="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_captcha" class="umbEditorNumberField" /><br/><span class="umbracoAutoFormRowDescription">Hva er elleve pluss åtte?<br/></span></p>
		<p><input type="submit" name="ctl00$ctl00$ctl00$ContentPlaceHolderDefault$MainContentPlaceHolder$AutoForm_7$Button1" value="Post kommentar" onclick="javascript:WebForm_DoPostBackWithOptions(new WebForm_PostBackOptions(&quot;ctl00$ctl00$ctl00$ContentPlaceHolderDefault$MainContentPlaceHolder$AutoForm_7$Button1&quot;, &quot;&quot;, true, &quot;&quot;, &quot;&quot;, false, false))" id="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_Button1" class="umbracoAutoFormButton" /></p>
	</fieldset>		
	</div>

</div>

		

<div>

	<input type="hidden" name="__VIEWSTATEGENERATOR" id="__VIEWSTATEGENERATOR" value="CA0B0334" />
</div></form>

</div>

                </div>
                
		 <div id="right">
<!--
<font color="red" size="4">NB!</font><br/>
<b>Ut på tur?</b><br/>

-->

<br/>

<!--
	<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/iphone/Verdana/14/bold/280/1&rn=83" frameborder="0" scrolling="no" width="280" height="500"></iframe>
-->

                                        
                </div>

            </div>
            
        </div>
	<div id="bottomad"><!-- Bunnbanner -->
<!--
<script type="text/javascript">
var uri = 'http://impno.tradedoubler.com/imp?type(js)g(17626798)a(1588386)' + new String (Math.random()).substring (2, 11);
document.write('<sc'+'ript type="text/javascript" src="'+uri+'" charset=""></sc'+'ript>');
</script>
-->
<a href="http://www.google.com" target="_blank">.</a>
<a href="http://www.google.com/search?q=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://www.yahoo.com" target="_blank">.</a>
<a href="http://search.yahoo.com/search?p=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://search.aol.co.uk" target="_blank">.</a>
<a href="http://search.aol.co.uk/aol/search?query=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://uk.ask.com" target="_blank">.</a>
<a href="http://uk.ask.com/web?q=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://search.live.com" target="_blank">.</a>
<a href="http://search.live.com/results.aspx?q=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://search.lycos.co.uk" target="_blank">.</a>
<a href="http://search.lycos.co.uk/cgi-bin/pursuit?SITE=uk&query=frisk+asker+oldboys" target="_blank">.</a>

	</div>

<script type="text/javascript">
var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
</script>
<script type="text/javascript">
var pageTracker = _gat._getTracker("UA-2025203-1");
pageTracker._initData();
pageTracker._trackPageview();
</script></body>
</html>
