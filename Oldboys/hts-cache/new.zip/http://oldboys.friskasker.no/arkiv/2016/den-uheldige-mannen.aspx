
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">

	<head>

		<title>Den Uheldige Mannen  - Frisk Asker Oldboys</title>
		
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
		<meta http-equiv="imagetoolbar" CONTENT="no">
		<meta name="keywords" content="" />
		<meta name="description" content="På'an igjen, med Paralgin forte..." />
		
		<meta name="title" content="Den Uheldige Mannen - Frisk Asker Oldboys" />
		<meta name="URL" content="http://oldboys.friskasker.no" />
		<meta name="language" content="Norsk" />
		<meta name="author" content="Terje Dahl" />
		<meta name="copyright" content="Frisk Asker Oldboys" />
		<meta name="reply-to" content="terjda@online.no" />
		<meta name="verify-v1" content="BxVdMcZ0uoa2KVw8RB+FBg3715LgSDXNG+RYp0gHpAI=" />

		<link type="text/css" href="/css/client.css" rel="stylesheet" />
		<link type="text/css" href="/css/default.css" rel="stylesheet" />
		<link type="text/css" href="/css/weatherCSS.css" rel="stylesheet" />

		<script type="text/javascript" src="/js/jquery.js"></script>
		<script type="text/javascript" src="/js/ufo.js"></script>
		<script type="text/javascript" src="/js/friskasker.js"></script>
		<!--script type='text/javascript' src='http://www.rdmtech.no/js/jquery.js?ver=1.2.6'></script-->
		<!--script type='text/javascript' src='http://www.rdmtech.no/js/jquery.cross-slide.js?ver=2.6'></script-->

		<!--[if IE 6]>
		<link type="text/css" href="/css/ie60.css" rel="stylesheet" />			
		<![endif]-->
		<!-- TradeDoubler site verification 1588386 --> 

	<script type='text/javascript'>
		jQuery(function($) {$(document).ready(function() {
			$('#container2').crossSlide(
				{sleep: 2, fade: 1},
				[{src: 'http://oldboys.friskasker.no/media/26561/bg-fao1.jpg'},{src: 'http://oldboys.friskasker.no/media/26566/bg-fao2.jpg'},{src: 'http://oldboys.friskasker.no/media/26571/bg-fao3.jpg'},{src: 'http://oldboys.friskasker.no/media/26576/bg-fao4.jpg'}]
			);
		});});
	</script>
	
<script type="text/javascript">
var _polldaddy = [] || _polldaddy;

_polldaddy.push( {
    type: 'slider',
    title: 'FAO-spillemodellen, skjønner du den?',
    body: 'Ta testen og bidra til å øke sjansen for sportslig utvikling av FAO!',
    button: 'Get Started &raquo;',
    domain: 'risengaj96.polldaddy.com/s/',
    id: 'fao-spillemodellen',
    placeholder: 'pd1438692132734'
} );

jQuery(function(d,c,j){$if(!document.getElementById(j)){var pd=d.createElement(c),s;pd.id=j;pd.src=('https:'==document.location.protocol)?'https://polldaddy.com/survey.js':'http://i0.poll.fm/survey.js';s=document.getElementsByTagName(c)[0];s.parentNode.insertBefore(pd,s);}}(document,'script','pd-embed'));
</script>

	
	</head>
	
	<body>
      
        <div id="container">&nbsp;
        
            <div id="header">&nbsp;
            
                <div id="logo"><a href="/"><img src="/media/26597/logos.gif" alt="Logo" /></a></div>
                <div id="rss"><a href="/data/rss/nyheter.xml">Motta RSS strøm</a></div>
		<!--div id="sitemap"><a href="/sitemap.aspx">Sitemap</a></div-->
		<div id="topknapp">
		<iframe width="280" height="160" src="https://www.youtube.com/embed/15KEqzCTrwI" frameborder="0" allowfullscreen></iframe>
		</div>
		
                

            </div>
            
            <div id="body">&nbsp;
            
                <div id="left">&nbsp;

                    <div id="date">mandag 15. april</div>
                	
                    <div class="leftnav"><a href="/">Hjem</a><br /><a href="/arkiv.aspx">Arkiv</a><br /><a href="/tabeller--terminlister.aspx">Tabeller &amp; terminlister</a><br /><a href="/kampreferat.aspx">Kampreferat</a><br /><a href="/fotballfilosofi.aspx">Fotballfilosofi</a><br /><a href="/ikke-helt-sportslig.aspx">Ikke helt sportslig</a><br /></div>
		
                    <div class="box" id="contactbox"><div class="header">Frisk Asker</div><div class="body"><a href="/frisk-asker/laget.aspx">Laget</a><br /><a href="/frisk-asker/kontakt.aspx">Kontakt</a><br /><a href="/frisk-asker/dommerhjoernet.aspx">Dommerhjørnet</a><br /><a href="https://teams.s2s.net/11225/no/" target="_new">Treningstider</a></div><div class="footer"><!----></div></div>

<!--		     <iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/standard/Verdana/14/bold/230/1&rn=84" frameborder="0" scrolling="no" width="230" height="500"></iframe>
-->
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&banner=1&system=no_no/5212/1/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/standard/Verdana/14/bold/230/1&rn=94" frameborder="0" scrolling="no" width="230" height="214"></iframe>

		     <iframe src="http://www.s2s.net/todays_skill_external.php?ccc=no" scrolling="no" width="200" height="330" frameborder="0"></iframe>
<!--
		     <div id="login">&nbsp;
                   
                    <form id="loginform" action="#">&nbsp;
                      
                        <input id="username" type="text" value="brukernavn" />
                        <input id="password" type="text" value="passord" />
                        <img src="/img/login.gif" alt="login" />
                        <a href="#">glemt passord?</a>    
                        
                    </form>
                    
                    </div>
-->
		    <div id="search">

			Artikkelsøk:<br />
			<div id="xsltsearch" xmlns:ps="urn:percipientstudios-com:xslt"><form action="/soek.aspx?" method="post" class="xsltsearch_form"><input name="search" type="text" class="input" value=""></input> <input type="submit" value="Search" class="submit" /></form></div>
		    </div>

                </div>
                
                <div id="center">
		
                    
<div class="content">

	<h1>Den Uheldige Mannen</h1><div class="meta">27.08.16 17:51 - </div><div class="abstract"><img src="/umbraco/imagegen.ashx?image=/media/116543/bønna.jpg&amp;width=500" alt="" align="left" />På'an igjen, med Paralgin forte...</div>
<p>Noen fotballspillere har en godt utviklet evne til å <em>si
ifra</em> når de får en skade, og godt er det.<br />
 Skrikingen starter før de har truffet bakken, og det rulles for
sikkerhets skyld en ekstra gang.<br />
 Det må være brudd!<br />
 Minst!<br />
 Hæ, var det ikke?<br />
 Er det mulig?<br />
 Sånn som jeg datt??<br />
 Ja, ja, det var nå sannelig flaks, da!<br />
 Ikke skada denne gangen heller, gitt, oh my gooood.</p>

<p>Og så har vi den andre varianten.</p>

<p>Denne uka spilte M40 bortekamp, østenfor sol, mot
Høybråten/Stovner.<br />
 Bønna var med, hans tredje kamp på tre dager, klemt inn mellom
hockeytreningene.</p>

<p>I en hodeduell fikk han en Høybråtenspiller i fleisen, og knakk
kjevebeinet.<br />
 Bønna tok telling til ti, vrikket kjeften på plass med nevene, og
var klar igjen.</p>

<p>Etter en stund ble det bytte likevel.<br />
 For i fotballspill inngår taklinger - i hvert fall med Bønnas
spillestil - og i taklinger er det naturlig å bite kjeven
sammen.<br />
 Og med knekt kjevebein, er dette såpass smertefullt at Bønna
bedømte situasjonen til at det var bedre å bytte ut, siden han ikke
klarte å konsentrere seg 100% når smerten jog gjennom skallen.</p>

<p>Da han ikke klarte å tygge kveldsmaten hjemme, ble legevakten
neste stopp, og suppe som meny de neste 6 ukene konstatert.</p>

<p>Dermed har både M48, M40 og M33 én spiller mindre resten av
sesongen, og det var jo dumt, nå som Bønna endelig var tilbake
etter å ha vært ute i fire uker med sitt årlige ribbeinsbrudd.</p>

<p>I fjor fikk Bønna også en spiller i fleisen, den gangen var det
kinnbeinet som knakk, på to steder.<br />
 - Her må vi operere, sa legen, ellers kommer det til å bli en
bulk.<br />
 - Jeg vil ikke operere, sa Bønna, men Tone får bestemme, det er
hun som skal se på den fleisen.<br />
 - Du kan slippe å operere, sa Tone - Det er så mye annet uansett,
så en bulk ekstra gjør ikke noen forskjell.<br />
 Det syns Bønna var forståelsesfullt sagt, og hjematt de for.</p>

<p>På vei til treningsleir noen uker senere, kjørte den ene bilen
innom en plass for å hente Bønna hvor han hadde løpt et
orienteringsløp. Bilen kom frem litt senere til leiren enn resten,
for de måtte stoppe på legevakta i Elverum for å få gitt Bønna noen
sting og en stivkrampesprøyte, siden han hadde vært uheldig under
løpet og blitt bitt av en hund, i nesa.<br />
 Men han så flott ut med plaster midt i glaningen, det ga ham mer
karakter enn året før, da han bare saget seg i tommelen under en av
øvelsene på treningsleiren.</p>

<p>Når man har med sånne spillere å gjøre som mangler evnen til å
si ifra, så er det enklere for omgivelsene at skadene tross alt er
litt synlige, så vi får vite om dem.<br />
 Som den gangen da Bønna røyk akillessen mot Siggerud, da så vi jo
det på beinet hans de neste ukene, og det var mye enklere enn da
han røyk korsbåndet, eller de gangene han opererte meniskene.</p>

<p>Det blir på samme måte som da han brakk stortåa, og ikke kunne
gå med sko på noen uker, dette ble det enklere for oss andre å
forholde oss til, enn for eksempel den hjerteflimmergreia hans,
hvor vi bare får høre om at de har restartet blodpumpa hans på
sykehuset når pulsen ikke kommer ned igjen etter kamp.<br />
<br />
 Våre tanker går til nærmeste familie, selv om vi har en mistanke
om at FAO der i gården ikke står så høyt i kurs.</p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<div
style="position: absolute; left: -10000px; top: 0px; width: 1px; height: 1px; overflow: hidden;"
 id="_mcePaste">
<!--[if gte mso 9]><xml> <w:WordDocument> <w:View>Normal</w:View> <w:Zoom>0</w:Zoom> <w:TrackMoves /> <w:TrackFormatting /> <w:HyphenationZone>21</w:HyphenationZone> <w:PunctuationKerning /> <w:ValidateAgainstSchemas /> <w:SaveIfXMLInvalid>false</w:SaveIfXMLInvalid> <w:IgnoreMixedContent>false</w:IgnoreMixedContent> <w:AlwaysShowPlaceholderText>false</w:AlwaysShowPlaceholderText> <w:DoNotPromoteQF /> <w:LidThemeOther>NO-BOK</w:LidThemeOther> <w:LidThemeAsian>X-NONE</w:LidThemeAsian> <w:LidThemeComplexScript>NE</w:LidThemeComplexScript> <w:Compatibility> <w:BreakWrappedTables /> <w:SnapToGridInCell /> <w:WrapTextWithPunct /> <w:UseAsianBreakRules /> <w:DontGrowAutofit /> <w:SplitPgBreakAndParaMark /> <w:EnableOpenTypeKerning /> <w:DontFlipMirrorIndents /> <w:OverrideTableStyleHps /> </w:Compatibility> <w:BrowserLevel>MicrosoftInternetExplorer4</w:BrowserLevel> <m:mathPr> <m:mathFont m:val="Cambria Math" /> <m:brkBin m:val="before" /> <m:brkBinSub m:val="&#45;-" /> <m:smallFrac m:val="off" /> <m:dispDef /> <m:lMargin m:val="0" /> <m:rMargin m:val="0" /> <m:defJc m:val="centerGroup" /> <m:wrapIndent m:val="1440" /> <m:intLim m:val="subSup" /> <m:naryLim m:val="undOvr" /> </m:mathPr></w:WordDocument> </xml><![endif]-->
<p class="MsoNormal">Noen fotballspillere har en godt utviklet evne
til å <em style="mso-bidi-font-style:normal">si ifra</em> når de
får en skade, og godt er det.</p>

<p class="MsoNormal">Skrikingen starter før de har truffet bakken,
og det rulles for sikkerhets skyld en ekstra gang.</p>

<p class="MsoNormal">Det må være brudd!</p>

<p class="MsoNormal">Minst!</p>

<p class="MsoNormal">Hæ, var det ikke?</p>

<p class="MsoNormal">Er det mulig?</p>

<p class="MsoNormal">Sånn som jeg datt??</p>

<p class="MsoNormal">Ja, ja, det var nå sannelig flaks, da!</p>

<p class="MsoNormal">Ikke skada denne gangen heller, gitt., oh my
gooood.</p>

<p class="MsoNormal">&nbsp;</p>

<p class="MsoNormal">&nbsp;</p>

<p class="MsoNormal">Og så har vi den andre varianten.</p>

<p class="MsoNormal">&nbsp;</p>

<p class="MsoNormal">Denne uka spilte M40 bortekamp, østenfor sol,
mot Høybråten/Stovner.</p>

<p class="MsoNormal">Bønna var med, hans tredje kamp på tre dager,
klemt inn mellom hockeytreningene.</p>

<p class="MsoNormal">&nbsp;</p>

<p class="MsoNormal">I en hodeduell fikk han en Høybråtenspiller i
fleisen, og knakk kjevebenet.</p>

<p class="MsoNormal">Han tok telling til ti, vrikket kjeften på
plass med nevene, og var klar igjen.</p>

<p class="MsoNormal">&nbsp;</p>

<p class="MsoNormal">Etter en stund ble det bytte likevel.</p>

<p class="MsoNormal">For i fotballspill inngår taklinger - i hvert
fall med Bønnas spillestil - og i taklinger er det naturlig å bite
kjeven sammen.</p>

<p class="MsoNormal">Og med knekt kjevebein, er dette såpass
smertefullt at Bønna bedømte situasjonen til at det var bedre å
bytte ut, siden han ikke klarte å konsentrere seg 100% når smerten
jog gjennom skallen.</p>

<p class="MsoNormal"><span></span></p>

<p class="MsoNormal">Da han ikke klarte å tygge kveldsmaten hjemme,
ble legevakten neste stopp, og suppe som meny de neste 6 ukene
konstatert.</p>

<p class="MsoNormal">&nbsp;</p>

<p class="MsoNormal">Dermed har både M48, M40 og M33 én spiller
mindre resten av sesongen, og det var jo dumt, nå som Bønna endelig
var tilbake etter å ha vært ute i fire uker med sitt årlige
ribbeinsbrudd.</p>

<p class="MsoNormal">&nbsp;</p>

<p class="MsoNormal">I fjor fikk Bønna også en spiller i fleisen,
den gangen var det <em
style="mso-bidi-font-style: normal;">kinnbeinet som knakk, på to
steder.</em></p>

<p class="MsoNormal"><em style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;">- Her må vi operere, sa legen,
ellers kommer det til å bli en bulk i fleisen.<br />
 - Jeg vil ikke operere, sa Bønna, men Tone får bestemme, det er
hun som skal se på den fleisen.<br />
 - Du kan slippe å operere, sa Tone - Det er så mye annet uansett,
så en ekstra bulk gjør ikke noen
forskjell.</em></em></em></em></em></em></em></em></em></em></p>

<p class="MsoNormal"><em style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;">Det syns Bønna var
forståelsesfullt sagt, og hjematt de
for.</em></em></em></em></em></em></em></em></em></p>

<p class="MsoNormal"><em style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"></em></em></em></em></em></em></em></em></p>

<p class="MsoNormal"><em style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;">På vei til treningsleir noen
uker senere, kjørte den ene bilen innom en plass for å hente Bønna
hvor han hadde løpt et orienteringsløp. Bilen kom litt senere frem
til leiren enn resten, for de måtte stoppe på legevakta i Elverum
for å få gitt Bønna en stivkrampesprøyte, siden han hadde vært
uheldig under løpet og blitt bitt av en hund, i
nesa.</em></em></em></em></em></em></em></em></em></em></p>

<p class="MsoNormal"><em style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"></em></em></em></em></em></em></em></em></em></p>

<p class="MsoNormal"><em style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;">Men han så flott ut med
plaster midt i glaningen, det ga ham mer karakter enn året før, da
han bare saget seg i tommelen under en av øvelsene på
treningsleiren.</em></em></em></em></em></em></em></em></em></em></p>

<p class="MsoNormal"><em style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"></em></em></em></em></em></em></em></em></em></p>

<p class="MsoNormal"><em style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;">Når man har med sånne spillere
å gjøre som mangler evnen til å si ifra, så er det enklere for
omgivelsene at skadene tross alt er litt synlige, så vi får vite om
dem.</em></em></em></em></em></em></em></em></em></em></p>

<p class="MsoNormal"><em style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;">Som den gangen da Bønna røyk
akillessen mot Siggerud, da så vi jo det på beinet hans de neste
ukene, og det var mye enklere enn da han røyk korsbåndet, eller de
gangene han opererte
meniskene.</em></em></em></em></em></em></em></em></em></p>

<p class="MsoNormal"><em style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"></em></em></em></em></em></em></em></em></p>

<p class="MsoNormal"><em style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;">Det blir på samme måte som da
han brakk stortåa, og ikke kunne gå med sko på noen uker, dette ble
det enklere for oss andre å forholde oss til, enn for eksempel den
hjerteflimmergreia hans, hvor vi bare får høre om at de har
restarter blodpumpa hans på sykehuset når pulsen ikke kommer ned
igjen etter
kamp.</em></em></em></em></em></em></em></em></em></em></p>

<p class="MsoNormal"><em style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"></em></em></em></em></em></em></em></em></em></p>

<p class="MsoNormal"><em style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"></em></em></em></em></em></em></em></em></em></em></p>

<p class="MsoNormal"><em style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;">Våre tanker går til nærmeste
familie, selv om vi mistenker at FAO der i gården ikke står så høyt
i kurs.</em></em></em></em></em></em></em></em></em></em></p>

<em style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;">
<!--[if gte mso 9]><xml> <w:LatentStyles DefLockedState="false" DefUnhideWhenUsed="true"   DefSemiHidden="true" DefQFormat="false" DefPriority="99"   LatentStyleCount="267"> <w:LsdException Locked="false" Priority="0" SemiHidden="false"    UnhideWhenUsed="false" QFormat="true" Name="Normal" /> <w:LsdException Locked="false" Priority="9" SemiHidden="false"    UnhideWhenUsed="false" QFormat="true" Name="heading 1" /> <w:LsdException Locked="false" Priority="9" QFormat="true" Name="heading 2" /> <w:LsdException Locked="false" Priority="9" QFormat="true" Name="heading 3" /> <w:LsdException Locked="false" Priority="9" QFormat="true" Name="heading 4" /> <w:LsdException Locked="false" Priority="9" QFormat="true" Name="heading 5" /> <w:LsdException Locked="false" Priority="9" QFormat="true" Name="heading 6" /> <w:LsdException Locked="false" Priority="9" QFormat="true" Name="heading 7" /> <w:LsdException Locked="false" Priority="9" QFormat="true" Name="heading 8" /> <w:LsdException Locked="false" Priority="9" QFormat="true" Name="heading 9" /> <w:LsdException Locked="false" Priority="39" Name="toc 1" /> <w:LsdException Locked="false" Priority="39" Name="toc 2" /> <w:LsdException Locked="false" Priority="39" Name="toc 3" /> <w:LsdException Locked="false" Priority="39" Name="toc 4" /> <w:LsdException Locked="false" Priority="39" Name="toc 5" /> <w:LsdException Locked="false" Priority="39" Name="toc 6" /> <w:LsdException Locked="false" Priority="39" Name="toc 7" /> <w:LsdException Locked="false" Priority="39" Name="toc 8" /> <w:LsdException Locked="false" Priority="39" Name="toc 9" /> <w:LsdException Locked="false" Priority="35" QFormat="true" Name="caption" /> <w:LsdException Locked="false" Priority="10" SemiHidden="false"    UnhideWhenUsed="false" QFormat="true" Name="Title" /> <w:LsdException Locked="false" Priority="1" Name="Default Paragraph Font" /> <w:LsdException Locked="false" Priority="11" SemiHidden="false"    UnhideWhenUsed="false" QFormat="true" Name="Subtitle" /> <w:LsdException Locked="false" Priority="22" SemiHidden="false"    UnhideWhenUsed="false" QFormat="true" Name="Strong" /> <w:LsdException Locked="false" Priority="20" SemiHidden="false"    UnhideWhenUsed="false" QFormat="true" Name="Emphasis" /> <w:LsdException Locked="false" Priority="59" SemiHidden="false"    UnhideWhenUsed="false" Name="Table Grid" /> <w:LsdException Locked="false" UnhideWhenUsed="false" Name="Placeholder Text" /> <w:LsdException Locked="false" Priority="1" SemiHidden="false"    UnhideWhenUsed="false" QFormat="true" Name="No Spacing" /> <w:LsdException Locked="false" Priority="60" SemiHidden="false"    UnhideWhenUsed="false" Name="Light Shading" /> <w:LsdException Locked="false" Priority="61" SemiHidden="false"    UnhideWhenUsed="false" Name="Light List" /> <w:LsdException Locked="false" Priority="62" SemiHidden="false"    UnhideWhenUsed="false" Name="Light Grid" /> <w:LsdException Locked="false" Priority="63" SemiHidden="false"    UnhideWhenUsed="false" Name="Medium Shading 1" /> <w:LsdException Locked="false" Priority="64" SemiHidden="false"    UnhideWhenUsed="false" Name="Medium Shading 2" /> <w:LsdException Locked="false" Priority="65" SemiHidden="false"    UnhideWhenUsed="false" Name="Medium List 1" /> <w:LsdException Locked="false" Priority="66" SemiHidden="false"    UnhideWhenUsed="false" Name="Medium List 2" /> <w:LsdException Locked="false" Priority="67" SemiHidden="false"    UnhideWhenUsed="false" Name="Medium Grid 1" /> <w:LsdException Locked="false" Priority="68" SemiHidden="false"    UnhideWhenUsed="false" Name="Medium Grid 2" /> <w:LsdException Locked="false" Priority="69" SemiHidden="false"    UnhideWhenUsed="false" Name="Medium Grid 3" /> <w:LsdException Locked="false" Priority="70" SemiHidden="false"    UnhideWhenUsed="false" Name="Dark List" /> <w:LsdException Locked="false" Priority="71" SemiHidden="false"    UnhideWhenUsed="false" Name="Colorful Shading" /> <w:LsdException Locked="false" Priority="72" SemiHidden="false"    UnhideWhenUsed="false" Name="Colorful List" /> <w:LsdException Locked="false" Priority="73" SemiHidden="false"    UnhideWhenUsed="false" Name="Colorful Grid" /> <w:LsdException Locked="false" Priority="60" SemiHidden="false"    UnhideWhenUsed="false" Name="Light Shading Accent 1" /> <w:LsdException Locked="false" Priority="61" SemiHidden="false"    UnhideWhenUsed="false" Name="Light List Accent 1" /> <w:LsdException Locked="false" Priority="62" SemiHidden="false"    UnhideWhenUsed="false" Name="Light Grid Accent 1" /> <w:LsdException Locked="false" Priority="63" SemiHidden="false"    UnhideWhenUsed="false" Name="Medium Shading 1 Accent 1" /> <w:LsdException Locked="false" Priority="64" SemiHidden="false"    UnhideWhenUsed="false" Name="Medium Shading 2 Accent 1" /> <w:LsdException Locked="false" Priority="65" SemiHidden="false"    UnhideWhenUsed="false" Name="Medium List 1 Accent 1" /> <w:LsdException Locked="false" UnhideWhenUsed="false" Name="Revision" /> <w:LsdException Locked="false" Priority="34" SemiHidden="false"    UnhideWhenUsed="false" QFormat="true" Name="List Paragraph" /> <w:LsdException Locked="false" Priority="29" SemiHidden="false"    UnhideWhenUsed="false" QFormat="true" Name="Quote" /> <w:LsdException Locked="false" Priority="30" SemiHidden="false"    UnhideWhenUsed="false" QFormat="true" Name="Intense Quote" /> <w:LsdException Locked="false" Priority="66" SemiHidden="false"    UnhideWhenUsed="false" Name="Medium List 2 Accent 1" /> <w:LsdException Locked="false" Priority="67" SemiHidden="false"    UnhideWhenUsed="false" Name="Medium Grid 1 Accent 1" /> <w:LsdException Locked="false" Priority="68" SemiHidden="false"    UnhideWhenUsed="false" Name="Medium Grid 2 Accent 1" /> <w:LsdException Locked="false" Priority="69" SemiHidden="false"    UnhideWhenUsed="false" Name="Medium Grid 3 Accent 1" /> <w:LsdException Locked="false" Priority="70" SemiHidden="false"    UnhideWhenUsed="false" Name="Dark List Accent 1" /> <w:LsdException Locked="false" Priority="71" SemiHidden="false"    UnhideWhenUsed="false" Name="Colorful Shading Accent 1" /> <w:LsdException Locked="false" Priority="72" SemiHidden="false"    UnhideWhenUsed="false" Name="Colorful List Accent 1" /> <w:LsdException Locked="false" Priority="73" SemiHidden="false"    UnhideWhenUsed="false" Name="Colorful Grid Accent 1" /> <w:LsdException Locked="false" Priority="60" SemiHidden="false"    UnhideWhenUsed="false" Name="Light Shading Accent 2" /> <w:LsdException Locked="false" Priority="61" SemiHidden="false"    UnhideWhenUsed="false" Name="Light List Accent 2" /> <w:LsdException Locked="false" Priority="62" SemiHidden="false"    UnhideWhenUsed="false" Name="Light Grid Accent 2" /> <w:LsdException Locked="false" Priority="63" SemiHidden="false"    UnhideWhenUsed="false" Name="Medium Shading 1 Accent 2" /> <w:LsdException Locked="false" Priority="64" SemiHidden="false"    UnhideWhenUsed="false" Name="Medium Shading 2 Accent 2" /> <w:LsdException Locked="false" Priority="65" SemiHidden="false"    UnhideWhenUsed="false" Name="Medium List 1 Accent 2" /> <w:LsdException Locked="false" Priority="66" SemiHidden="false"    UnhideWhenUsed="false" Name="Medium List 2 Accent 2" /> <w:LsdException Locked="false" Priority="67" SemiHidden="false"    UnhideWhenUsed="false" Name="Medium Grid 1 Accent 2" /> <w:LsdException Locked="false" Priority="68" SemiHidden="false"    UnhideWhenUsed="false" Name="Medium Grid 2 Accent 2" /> <w:LsdException Locked="false" Priority="69" SemiHidden="false"    UnhideWhenUsed="false" Name="Medium Grid 3 Accent 2" /> <w:LsdException Locked="false" Priority="70" SemiHidden="false"    UnhideWhenUsed="false" Name="Dark List Accent 2" /> <w:LsdException Locked="false" Priority="71" SemiHidden="false"    UnhideWhenUsed="false" Name="Colorful Shading Accent 2" /> <w:LsdException Locked="false" Priority="72" SemiHidden="false"    UnhideWhenUsed="false" Name="Colorful List Accent 2" /> <w:LsdException Locked="false" Priority="73" SemiHidden="false"    UnhideWhenUsed="false" Name="Colorful Grid Accent 2" /> <w:LsdException Locked="false" Priority="60" SemiHidden="false"    UnhideWhenUsed="false" Name="Light Shading Accent 3" /> <w:LsdException Locked="false" Priority="61" SemiHidden="false"    UnhideWhenUsed="false" Name="Light List Accent 3" /> <w:LsdException Locked="false" Priority="62" SemiHidden="false"    UnhideWhenUsed="false" Name="Light Grid Accent 3" /> <w:LsdException Locked="false" Priority="63" SemiHidden="false"    UnhideWhenUsed="false" Name="Medium Shading 1 Accent 3" /> <w:LsdException Locked="false" Priority="64" SemiHidden="false"    UnhideWhenUsed="false" Name="Medium Shading 2 Accent 3" /> <w:LsdException Locked="false" Priority="65" SemiHidden="false"    UnhideWhenUsed="false" Name="Medium List 1 Accent 3" /> <w:LsdException Locked="false" Priority="66" SemiHidden="false"    UnhideWhenUsed="false" Name="Medium List 2 Accent 3" /> <w:LsdException Locked="false" Priority="67" SemiHidden="false"    UnhideWhenUsed="false" Name="Medium Grid 1 Accent 3" /> <w:LsdException Locked="false" Priority="68" SemiHidden="false"    UnhideWhenUsed="false" Name="Medium Grid 2 Accent 3" /> <w:LsdException Locked="false" Priority="69" SemiHidden="false"    UnhideWhenUsed="false" Name="Medium Grid 3 Accent 3" /> <w:LsdException Locked="false" Priority="70" SemiHidden="false"    UnhideWhenUsed="false" Name="Dark List Accent 3" /> <w:LsdException Locked="false" Priority="71" SemiHidden="false"    UnhideWhenUsed="false" Name="Colorful Shading Accent 3" /> <w:LsdException Locked="false" Priority="72" SemiHidden="false"    UnhideWhenUsed="false" Name="Colorful List Accent 3" /> <w:LsdException Locked="false" Priority="73" SemiHidden="false"    UnhideWhenUsed="false" Name="Colorful Grid Accent 3" /> <w:LsdException Locked="false" Priority="60" SemiHidden="false"    UnhideWhenUsed="false" Name="Light Shading Accent 4" /> <w:LsdException Locked="false" Priority="61" SemiHidden="false"    UnhideWhenUsed="false" Name="Light List Accent 4" /> <w:LsdException Locked="false" Priority="62" SemiHidden="false"    UnhideWhenUsed="false" Name="Light Grid Accent 4" /> <w:LsdException Locked="false" Priority="63" SemiHidden="false"    UnhideWhenUsed="false" Name="Medium Shading 1 Accent 4" /> <w:LsdException Locked="false" Priority="64" SemiHidden="false"    UnhideWhenUsed="false" Name="Medium Shading 2 Accent 4" /> <w:LsdException Locked="false" Priority="65" SemiHidden="false"    UnhideWhenUsed="false" Name="Medium List 1 Accent 4" /> <w:LsdException Locked="false" Priority="66" SemiHidden="false"    UnhideWhenUsed="false" Name="Medium List 2 Accent 4" /> <w:LsdException Locked="false" Priority="67" SemiHidden="false"    UnhideWhenUsed="false" Name="Medium Grid 1 Accent 4" /> <w:LsdException Locked="false" Priority="68" SemiHidden="false"    UnhideWhenUsed="false" Name="Medium Grid 2 Accent 4" /> <w:LsdException Locked="false" Priority="69" SemiHidden="false"    UnhideWhenUsed="false" Name="Medium Grid 3 Accent 4" /> <w:LsdException Locked="false" Priority="70" SemiHidden="false"    UnhideWhenUsed="false" Name="Dark List Accent 4" /> <w:LsdException Locked="false" Priority="71" SemiHidden="false"    UnhideWhenUsed="false" Name="Colorful Shading Accent 4" /> <w:LsdException Locked="false" Priority="72" SemiHidden="false"    UnhideWhenUsed="false" Name="Colorful List Accent 4" /> <w:LsdException Locked="false" Priority="73" SemiHidden="false"    UnhideWhenUsed="false" Name="Colorful Grid Accent 4" /> <w:LsdException Locked="false" Priority="60" SemiHidden="false"    UnhideWhenUsed="false" Name="Light Shading Accent 5" /> <w:LsdException Locked="false" Priority="61" SemiHidden="false"    UnhideWhenUsed="false" Name="Light List Accent 5" /> <w:LsdException Locked="false" Priority="62" SemiHidden="false"    UnhideWhenUsed="false" Name="Light Grid Accent 5" /> <w:LsdException Locked="false" Priority="63" SemiHidden="false"    UnhideWhenUsed="false" Name="Medium Shading 1 Accent 5" /> <w:LsdException Locked="false" Priority="64" SemiHidden="false"    UnhideWhenUsed="false" Name="Medium Shading 2 Accent 5" /> <w:LsdException Locked="false" Priority="65" SemiHidden="false"    UnhideWhenUsed="false" Name="Medium List 1 Accent 5" /> <w:LsdException Locked="false" Priority="66" SemiHidden="false"    UnhideWhenUsed="false" Name="Medium List 2 Accent 5" /> <w:LsdException Locked="false" Priority="67" SemiHidden="false"    UnhideWhenUsed="false" Name="Medium Grid 1 Accent 5" /> <w:LsdException Locked="false" Priority="68" SemiHidden="false"    UnhideWhenUsed="false" Name="Medium Grid 2 Accent 5" /> <w:LsdException Locked="false" Priority="69" SemiHidden="false"    UnhideWhenUsed="false" Name="Medium Grid 3 Accent 5" /> <w:LsdException Locked="false" Priority="70" SemiHidden="false"    UnhideWhenUsed="false" Name="Dark List Accent 5" /> <w:LsdException Locked="false" Priority="71" SemiHidden="false"    UnhideWhenUsed="false" Name="Colorful Shading Accent 5" /> <w:LsdException Locked="false" Priority="72" SemiHidden="false"    UnhideWhenUsed="false" Name="Colorful List Accent 5" /> <w:LsdException Locked="false" Priority="73" SemiHidden="false"    UnhideWhenUsed="false" Name="Colorful Grid Accent 5" /> <w:LsdException Locked="false" Priority="60" SemiHidden="false"    UnhideWhenUsed="false" Name="Light Shading Accent 6" /> <w:LsdException Locked="false" Priority="61" SemiHidden="false"    UnhideWhenUsed="false" Name="Light List Accent 6" /> <w:LsdException Locked="false" Priority="62" SemiHidden="false"    UnhideWhenUsed="false" Name="Light Grid Accent 6" /> <w:LsdException Locked="false" Priority="63" SemiHidden="false"    UnhideWhenUsed="false" Name="Medium Shading 1 Accent 6" /> <w:LsdException Locked="false" Priority="64" SemiHidden="false"    UnhideWhenUsed="false" Name="Medium Shading 2 Accent 6" /> <w:LsdException Locked="false" Priority="65" SemiHidden="false"    UnhideWhenUsed="false" Name="Medium List 1 Accent 6" /> <w:LsdException Locked="false" Priority="66" SemiHidden="false"    UnhideWhenUsed="false" Name="Medium List 2 Accent 6" /> <w:LsdException Locked="false" Priority="67" SemiHidden="false"    UnhideWhenUsed="false" Name="Medium Grid 1 Accent 6" /> <w:LsdException Locked="false" Priority="68" SemiHidden="false"    UnhideWhenUsed="false" Name="Medium Grid 2 Accent 6" /> <w:LsdException Locked="false" Priority="69" SemiHidden="false"    UnhideWhenUsed="false" Name="Medium Grid 3 Accent 6" /> <w:LsdException Locked="false" Priority="70" SemiHidden="false"    UnhideWhenUsed="false" Name="Dark List Accent 6" /> <w:LsdException Locked="false" Priority="71" SemiHidden="false"    UnhideWhenUsed="false" Name="Colorful Shading Accent 6" /> <w:LsdException Locked="false" Priority="72" SemiHidden="false"    UnhideWhenUsed="false" Name="Colorful List Accent 6" /> <w:LsdException Locked="false" Priority="73" SemiHidden="false"    UnhideWhenUsed="false" Name="Colorful Grid Accent 6" /> <w:LsdException Locked="false" Priority="19" SemiHidden="false"    UnhideWhenUsed="false" QFormat="true" Name="Subtle Emphasis" /> <w:LsdException Locked="false" Priority="21" SemiHidden="false"    UnhideWhenUsed="false" QFormat="true" Name="Intense Emphasis" /> <w:LsdException Locked="false" Priority="31" SemiHidden="false"    UnhideWhenUsed="false" QFormat="true" Name="Subtle Reference" /> <w:LsdException Locked="false" Priority="32" SemiHidden="false"    UnhideWhenUsed="false" QFormat="true" Name="Intense Reference" /> <w:LsdException Locked="false" Priority="33" SemiHidden="false"    UnhideWhenUsed="false" QFormat="true" Name="Book Title" /> <w:LsdException Locked="false" Priority="37" Name="Bibliography" /> <w:LsdException Locked="false" Priority="39" QFormat="true" Name="TOC Heading" /> </w:LatentStyles> </xml><![endif]--><!--[if gte mso 10]> <mce:style><!   /* Style Definitions */  table.MsoNormalTable     {mso-style-name:"Vanlig tabell";    mso-tstyle-rowband-size:0;  mso-tstyle-colband-size:0;  mso-style-noshow:yes;   mso-style-priority:99;  mso-style-parent:"";    mso-padding-alt:0cm 5.4pt 0cm 5.4pt;    mso-para-margin:0cm;    mso-para-margin-bottom:.0001pt;     mso-pagination:widow-orphan;    font-size:10.0pt;   font-family:"Times New Roman","serif";  mso-bidi-language:NE;} --><!--[endif] --></em></em></em></em></em></em></em></em></em></em></em></em></em></em></em></em></em></em></em></em></em></div>



<div class="addthis_toolbox addthis_default_style">
<a href="http://www.addthis.com/bookmark.php?v=250&amp;username=xa-4be09cd0025b8da5" class="addthis_button_compact">Share</a>
<span class="addthis_separator">|</span>
<a class="addthis_button_facebook"></a>
<a class="addthis_button_myspace"></a>
<a class="addthis_button_google"></a>
<a class="addthis_button_twitter"></a>
</div>
<script type="text/javascript" src="http://s7.addthis.com/js/250/addthis_widget.js#username=xa-4be09cd0025b8da5"></script>
<!-- AddThis Button END -->

<hr>
<h2>Kommentarer:</h2>
	<div class="newsitem"><i><b>28.08.16 11:22 - <a href="mailto:">Sympatisør</a></b></i><p>10 ulykker kommer <a href="https://www.youtube.com/watch?v=xfNHxKu9haI&oref=https%3A%2F%2Fwww.youtube.com%2Fwatch%3Fv%3DxfNHxKu9haI&has_verified=1">sjelden alene</a></p></div><div class="newsitem"><i><b>28.08.16 14:32 - <a href="mailto:">Bønna</a></b></i><p>Det har du helt rett i. Tror du ikke at jeg ble bitt av en bikkje igjen i går. :-( Ble bitt i hånda. Alt i alt gikk det bra. Blødde litt, men dæven så redd jeg ble. En svær jævel av en mannevond hund.</p></div><div class="newsitem"><i><b>29.08.16 14:33 - <a href="mailto:">Figo</a></b></i><p>Jeg husker at vi delte ut en forgylt krykke på årsfesten for en del år siden ... det var ikke ment som noen oppmuntring til flere skader, men vi registrerer dessverre at det bare har eskalert siden den gang ....</p></div><div class="newsitem"><i><b>29.08.16 23:38 - <a href="mailto:">Bønna</a></b></i><p>Problemet er at jeg bare vant en krykke. Jeg trenger den andre, også!</p></div><div class="newsitem"><i><b>04.09.16 13:29 - <a href="mailto:">Mjaugis</a></b></i><p>Men om dere setter plaster på alle stedene for å markere. Vil Bønna da synes?</p></div>
<!--
<p>
<b>Kommentering er midlertidig steng pga SPAM!</b>
</p>
-->
<form method="post" action="den-uheldige-mannen.aspx" id="aspnetForm">
<div>
<input type="hidden" name="__EVENTTARGET" id="__EVENTTARGET" value="" />
<input type="hidden" name="__EVENTARGUMENT" id="__EVENTARGUMENT" value="" />
<input type="hidden" name="__VIEWSTATE" id="__VIEWSTATE" value="/wEPDwUENTM4MQ9kFgJmD2QWAmYPZBYCZg9kFgJmD2QWAgIPD2QWAgIFD2QWAgIBD2QWAmYPZBYCAgIPZBYCAgEPFgIeBFRleHQFF0RpbiBrb21tZW50YXIgZXIgcG9zdGV0ZGTP3+kahhm7HkFLDJ1eDASlO9mxvA==" />
</div>

<script type="text/javascript">
//<![CDATA[
var theForm = document.forms['aspnetForm'];
if (!theForm) {
    theForm = document.aspnetForm;
}
function __doPostBack(eventTarget, eventArgument) {
    if (!theForm.onsubmit || (theForm.onsubmit() != false)) {
        theForm.__EVENTTARGET.value = eventTarget;
        theForm.__EVENTARGUMENT.value = eventArgument;
        theForm.submit();
    }
}
//]]>
</script>


<script src="/WebResource.axd?d=RhJRe7vAQjxLvd0VTiPlJ3ItrtWKNnlC5ndUOdQ1oQE84Jw0mmyu8t9423FKr6Sh25O1JfgygCRLDXncXNuX2rijfWY1&amp;t=635737087099672665" type="text/javascript"></script>


<script type="text/javascript">
//<![CDATA[
function insertLink(element) {var theLink = prompt('Enter URL for link here:','http://');insertTag(element, 'a', ' href="' + theLink + '"')}
            function insertTag(element, tag, param) {
            start = '<' + tag + param + '>';
            eind = '</' + tag + '>';
             /* element = document.getElementById(element); */
              if (document.selection) {
                element.focus();
                sel = document.selection.createRange();
                sel.text = start + sel.text + eind;
              } else if (element.selectionStart || element.selectionStart == '0') {
                element.focus();
                var startPos = element.selectionStart;
                var endPos = element.selectionEnd;
                element.value = element.value.substring(0, startPos) + start + element.value.substring(startPos, endPos) + eind + element.value.substring(endPos, element.value.length);
              } else {
                element.value += start + eind;
              }
            }
            //]]>
</script>

<h2>Post en kommentar:</h2>
<div id="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_PanelInput">
	
	<div id="umbracoAutoForm">
	
  <fieldset>
			<p><label for="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_navn">Navn:</label><input name="ctl00$ctl00$ctl00$ContentPlaceHolderDefault$MainContentPlaceHolder$AutoForm_7$navn" type="text" id="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_navn" class="umbEditorTextField" /></p><p><label for="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_epost">Epost:</label><input name="ctl00$ctl00$ctl00$ContentPlaceHolderDefault$MainContentPlaceHolder$AutoForm_7$epost" type="text" id="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_epost" class="umbEditorTextField" /></p><p><label for="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_kommentar">Kommentar:</label><table border="0" cellspacing="0" cellpadding="0"><tr><td>
	<p align="right" style="margin: 0px; padding:0px"><a href="javascript:insertLink(document.getElementById('ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_kommentar'))"><img src="/umbraco_client/simpleEditor/images/link.gif" border="0" align="right" /></a><a href="javascript:insertTag(document.getElementById('ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_kommentar'), 'em', '')"><img src="/umbraco_client/simpleEditor/images/italic.gif" border="0" style="margin-left: 3px; margin-right: 3px;" align="right" /></a> <a href="javascript:insertTag(document.getElementById('ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_kommentar'), 'strong', '')"><img src="/umbraco_client/simpleEditor/images/bold.gif" border="0" align="right" /></a><br/></p>
	<textarea name="ctl00$ctl00$ctl00$ContentPlaceHolderDefault$MainContentPlaceHolder$AutoForm_7$kommentar" rows="8" cols="20" id="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_kommentar" class="umbEditorTextField"></textarea></td></tr></table>
	</p><p><label for="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_captcha">Captcha:</label><input name="ctl00$ctl00$ctl00$ContentPlaceHolderDefault$MainContentPlaceHolder$AutoForm_7$captcha" type="text" id="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_captcha" class="umbEditorNumberField" /><br/><span class="umbracoAutoFormRowDescription">Hva er elleve pluss åtte?<br/></span></p>
		<p><input type="submit" name="ctl00$ctl00$ctl00$ContentPlaceHolderDefault$MainContentPlaceHolder$AutoForm_7$Button1" value="Post kommentar" onclick="javascript:WebForm_DoPostBackWithOptions(new WebForm_PostBackOptions(&quot;ctl00$ctl00$ctl00$ContentPlaceHolderDefault$MainContentPlaceHolder$AutoForm_7$Button1&quot;, &quot;&quot;, true, &quot;&quot;, &quot;&quot;, false, false))" id="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_Button1" class="umbracoAutoFormButton" /></p>
	</fieldset>		
	</div>

</div>

		

<div>

	<input type="hidden" name="__VIEWSTATEGENERATOR" id="__VIEWSTATEGENERATOR" value="CA0B0334" />
</div></form>

<a class="readmore" href="/arkiv/2021/frisk-asker---covid-19-19-.aspx">Frisk Asker - Covid 19-19 </a> - 17.03.2021 8:41<br /><a class="readmore" href="/arkiv/2016/faos-sommerkrim.aspx">FAOs sommerkrim</a> - 29.04.2020 12:32<br /><a class="readmore" href="/arkiv/2019/fao-med-kupp-paa-overgangsmarkedet!.aspx">FAO med kupp på overgangsmarkedet!</a> - 30.07.2019 19:24<br /><a class="readmore" href="/arkiv/2019/dag-ansatt-som-fast-lagleder-paa-frisk-asker-m33.aspx">Dag ansatt som fast lagleder på Frisk Asker M33</a> - 29.07.2019 12:28<br /><a class="readmore" href="/arkiv/2019/askermesterskapet-i-oldboysfotball.aspx">Askermesterskapet i oldboysfotball</a> - 07.05.2019 16:49<br /><a class="readmore" href="/arkiv/2019/frisk-asker-oldgirls!.aspx">Frisk Asker OldGIRLS!</a> - 05.04.2019 14:14<br /><a class="readmore" href="/arkiv/2019/know-your-enemy.aspx">Know your enemy</a> - 01.02.2019 16:46<br /><a class="readmore" href="/arkiv/2018/pass-paa-liten-og-paa-stor.aspx">Pass på liten og på stor</a> - 21.09.2018 15:21<br /><a class="readmore" href="/arkiv/2018/nedrykk!.aspx">Nedrykk!</a> - 14.09.2018 14:40<br /><a class="readmore" href="/arkiv/2018/lukten-av-gull!.aspx">Lukten av gull!</a> - 07.09.2018 22:27<br />
<br/><br/>
<!--
<table id="forumposts" cellspacing="0"><tr><th colspan="2">Siste publiserte fra Sekreteriatet</th></tr><tr><td><b><a class="readmore" href="/sekreteriatet/kamprutine.aspx">Kamprutine</a> - </b>12.06.14 01:36</td></tr><tr><td><b><a class="readmore" href="/sekreteriatet/kamp-mot-bygdoe-monolitten---hvem-stiller.aspx">Kamp mot Bygdø Monolitten - hvem stiller?</a> - </b>12.09.12 09:23</td></tr><tr><td><b><a class="readmore" href="/sekreteriatet/kamp-mot-huk---hvem-stiller-(1).aspx">Kamp mot Huk - hvem stiller? (1)</a> - </b>04.09.12 10:04</td></tr><tr><td><b><a class="readmore" href="/sekreteriatet/kamp-mot-lokomotiv-oslo-29-aug---hvem-stiller.aspx">Kamp mot Lokomotiv Oslo 29. aug - hvem stiller?</a> - </b>28.08.12 02:56</td></tr><tr><td><b><a class="readmore" href="/sekreteriatet/kamp-mot-aarvoll-ons-15-aug---hvem-stiller.aspx">Kamp mot Årvoll ons 15. aug - Hvem stiller?</a> - </b>13.08.12 12:50</td></tr><tr><td class="footer" colspan="2"> </td></tr></table>
-->
</div>



                </div>
                
		 <div id="right">

<font color="red" size="4">Lagbilde</font><br/>


<!--a href="http://oldboys.friskasker.no/media/116678/formkurve.png" border=0><img src="/media/116678/formkurve.png" width="280" alt="Formkurve" /></a-->
<!--iframe src="http://free.timeanddate.com/countdown/i5t3zil3/n187/cf113/cm0/cu4/ct0/cs0/ca0/cr0/ss0/cac000/cpc000/pc00e60b/tc000/fs100/szw320/szh135/tatFAO%20h%C3%B8stsesong%20starter%20om../tac000/tptTime%20since%20Event%20started%20in/tpc000/mac000/mpc000/iso2017-08-14T21:00:00" allowTransparency="true" frameborder="0" width="320" height="135"></iframe-->
	<!--iframe frameborder="0" width="512" height="600" scrolling="auto" allowtransparency="true" src="https://risengaj96.polldaddy.com/s/fao-plassering-pr-lag-2018?iframe=1"><a href="https://risengaj96.polldaddy.com/s/fao-plassering-pr-lag-2018">View Survey</a></iframe-->
<br/>
<!-- FORMkurve iframe width="508" height="371" seamless frameborder="0" scrolling="no" src="https://docs.google.com/spreadsheets/d/1wL8AGtLu517MG4vlWG2DIat7LmhdKaJdXz4nDVsxc74/pubchart?oid=1826601090&amp;format=interactive"></iframe-->

<!-- iphone
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/iphone/Verdana/14/bold/250/1&rn=7" frameborder="0" scrolling="no" width="250" height="500"></iframe>
-->
	<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/iphone/Verdana/14/bold/280/1&rn=83" frameborder="0" scrolling="no" width="280" height="500"></iframe>
<!--
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/21/ae82202846179cbfa34c266edf916f37&colours=FF8C00/CCCCCC/FFF/4/standard/Comic+Sans+Serif/16/bold/280/1&rn=22" frameborder="0" scrolling="no" width="280" height="500"></iframe>
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/members&bits=25/21/ae82202846179cbfa34c266edf916f37&colours=FF8C00/CCCCCC/FFF/4/standard/Comic+Sans+Serif/16/bold/280/1&rn=50" frameborder="0" scrolling="no" width="280" height="500"></iframe>
-->
<!-- iframe src="https://www.s2s.net/export_content.php?team_id=1101&system=no_no/1032/2/one/activities&bits=25/21/68565729bae64238443339aae6dcf62c&colours=FF6600/000099/FFF/0/iphone/Verdana/12/bold/280/0" frameborder="0" scrolling="no" width="280" height="500"></iframe -->

<br/><br/>
<a href="http://www.forstehjelpsgrossisten.no/products/is-pose-stor-14-x-21-cm-i-kartong-av-24-stk" border="0" target="_new"><img src="/umbraco/imagegen.ashx?image=/media/114144/forstehjelpsgrossistem.png&width=280"></a>
<br/>
<div style="text-align: left; width:280px;">Stolt sponsor av Frisk Asker Oldboys!</div>

                                        
                </div>

            </div>
            
        </div>
	<div id="bottomad"><!-- Bunnbanner -->
<!--
<script type="text/javascript">
var uri = 'http://impno.tradedoubler.com/imp?type(js)g(17626798)a(1588386)' + new String (Math.random()).substring (2, 11);
document.write('<sc'+'ript type="text/javascript" src="'+uri+'" charset=""></sc'+'ript>');
</script>
-->
<a href="http://www.google.com" target="_blank">.</a>
<a href="http://www.google.com/search?q=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://www.yahoo.com" target="_blank">.</a>
<a href="http://search.yahoo.com/search?p=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://search.aol.co.uk" target="_blank">.</a>
<a href="http://search.aol.co.uk/aol/search?query=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://uk.ask.com" target="_blank">.</a>
<a href="http://uk.ask.com/web?q=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://search.live.com" target="_blank">.</a>
<a href="http://search.live.com/results.aspx?q=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://search.lycos.co.uk" target="_blank">.</a>
<a href="http://search.lycos.co.uk/cgi-bin/pursuit?SITE=uk&query=frisk+asker+oldboys" target="_blank">.</a>

	</div>

<script type="text/javascript">
var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
</script>
<script type="text/javascript">
var pageTracker = _gat._getTracker("UA-2025203-1");
pageTracker._initData();
pageTracker._trackPageview();
</script></body>
</html>
