
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">

	<head>

		<title>B.mrk; Sosialkurator søkes  - Frisk Asker Oldboys</title>
		
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
		<meta http-equiv="imagetoolbar" CONTENT="no">
		<meta name="keywords" content="" />
		<meta name="description" content="Like sikkert som høstløvet faller (i takt med børsnoteringene), daler aktiviteten på Frisk Asker oldboys sine sider rått og brutalt.
Denne artikkelen er ment som en solid krisepakke fra ledelsen og skal styrke troen på at det fortsatt finnes oldboys i live der ute et sted. 
Pilen skal atter peke oppover, like stødig som renten hos DnB.
" />
		
		<meta name="title" content="B.mrk; Sosialkurator søkes - Frisk Asker Oldboys" />
		<meta name="URL" content="http://oldboys.friskasker.no" />
		<meta name="language" content="Norsk" />
		<meta name="author" content="Terje Dahl" />
		<meta name="copyright" content="Frisk Asker Oldboys" />
		<meta name="reply-to" content="terjda@online.no" />
		<meta name="verify-v1" content="BxVdMcZ0uoa2KVw8RB+FBg3715LgSDXNG+RYp0gHpAI=" />

		<link type="text/css" href="/css/client.css" rel="stylesheet" />
		<link type="text/css" href="/css/default.css" rel="stylesheet" />
		<link type="text/css" href="/css/weatherCSS.css" rel="stylesheet" />

		<script type="text/javascript" src="/js/jquery.js"></script>
		<script type="text/javascript" src="/js/ufo.js"></script>
		<script type="text/javascript" src="/js/friskasker.js"></script>
		<!--script type='text/javascript' src='http://www.rdmtech.no/js/jquery.js?ver=1.2.6'></script-->
		<!--script type='text/javascript' src='http://www.rdmtech.no/js/jquery.cross-slide.js?ver=2.6'></script-->

		<!--[if IE 6]>
		<link type="text/css" href="/css/ie60.css" rel="stylesheet" />			
		<![endif]-->
		<!-- TradeDoubler site verification 1588386 --> 

	<script type='text/javascript'>
		jQuery(function($) {$(document).ready(function() {
			$('#container2').crossSlide(
				{sleep: 2, fade: 1},
				[{src: 'http://oldboys.friskasker.no/media/26561/bg-fao1.jpg'},{src: 'http://oldboys.friskasker.no/media/26566/bg-fao2.jpg'},{src: 'http://oldboys.friskasker.no/media/26571/bg-fao3.jpg'},{src: 'http://oldboys.friskasker.no/media/26576/bg-fao4.jpg'}]
			);
		});});
	</script>
	
<script type="text/javascript">
var _polldaddy = [] || _polldaddy;

_polldaddy.push( {
    type: 'slider',
    title: 'FAO-spillemodellen, skjønner du den?',
    body: 'Ta testen og bidra til å øke sjansen for sportslig utvikling av FAO!',
    button: 'Get Started &raquo;',
    domain: 'risengaj96.polldaddy.com/s/',
    id: 'fao-spillemodellen',
    placeholder: 'pd1438692132734'
} );

jQuery(function(d,c,j){$if(!document.getElementById(j)){var pd=d.createElement(c),s;pd.id=j;pd.src=('https:'==document.location.protocol)?'https://polldaddy.com/survey.js':'http://i0.poll.fm/survey.js';s=document.getElementsByTagName(c)[0];s.parentNode.insertBefore(pd,s);}}(document,'script','pd-embed'));
</script>

	
	</head>
	
	<body>
      
        <div id="container">&nbsp;
        
            <div id="header">&nbsp;
            
                <div id="logo"><a href="/"><img src="/media/26597/logos.gif" alt="Logo" /></a></div>
                <div id="rss"><a href="/data/rss/nyheter.xml">Motta RSS strøm</a></div>
		<!--div id="sitemap"><a href="/sitemap.aspx">Sitemap</a></div-->
		<div id="topknapp">
		<iframe width="280" height="160" src="https://www.youtube.com/embed/15KEqzCTrwI" frameborder="0" allowfullscreen></iframe>
		</div>
		
                

            </div>
            
            <div id="body">&nbsp;
            
                <div id="left">&nbsp;

                    <div id="date">mandag 15. april</div>
                	
                    <div class="leftnav"><a href="/">Hjem</a><br /><a href="/arkiv.aspx">Arkiv</a><br /><a href="/tabeller--terminlister.aspx">Tabeller &amp; terminlister</a><br /><a href="/kampreferat.aspx">Kampreferat</a><br /><a href="/fotballfilosofi.aspx">Fotballfilosofi</a><br /><a href="/ikke-helt-sportslig.aspx">Ikke helt sportslig</a><br /></div>
		
                    <div class="box" id="contactbox"><div class="header">Frisk Asker</div><div class="body"><a href="/frisk-asker/laget.aspx">Laget</a><br /><a href="/frisk-asker/kontakt.aspx">Kontakt</a><br /><a href="/frisk-asker/dommerhjoernet.aspx">Dommerhjørnet</a><br /><a href="https://teams.s2s.net/11225/no/" target="_new">Treningstider</a></div><div class="footer"><!----></div></div>

<!--		     <iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/standard/Verdana/14/bold/230/1&rn=84" frameborder="0" scrolling="no" width="230" height="500"></iframe>
-->
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&banner=1&system=no_no/5212/1/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/standard/Verdana/14/bold/230/1&rn=94" frameborder="0" scrolling="no" width="230" height="214"></iframe>

		     <iframe src="http://www.s2s.net/todays_skill_external.php?ccc=no" scrolling="no" width="200" height="330" frameborder="0"></iframe>
<!--
		     <div id="login">&nbsp;
                   
                    <form id="loginform" action="#">&nbsp;
                      
                        <input id="username" type="text" value="brukernavn" />
                        <input id="password" type="text" value="passord" />
                        <img src="/img/login.gif" alt="login" />
                        <a href="#">glemt passord?</a>    
                        
                    </form>
                    
                    </div>
-->
		    <div id="search">

			Artikkelsøk:<br />
			<div id="xsltsearch" xmlns:ps="urn:percipientstudios-com:xslt"><form action="/soek.aspx?" method="post" class="xsltsearch_form"><input name="search" type="text" class="input" value=""></input> <input type="submit" value="Search" class="submit" /></form></div>
		    </div>

                </div>
                
                <div id="center">
		
                    
<div class="content">

	<h1>B.mrk; Sosialkurator søkes</h1><div class="meta">01.11.08 14:55 - Figo</div><div class="abstract"><img src="/umbraco/imagegen.ashx?image=/media/26112/pondus1xcopy.jpg&amp;width=500" alt="" align="left" />Like sikkert som høstløvet faller (i takt med børsnoteringene), daler aktiviteten på Frisk Asker oldboys sine sider rått og brutalt.
Denne artikkelen er ment som en solid krisepakke fra ledelsen og skal styrke troen på at det fortsatt finnes oldboys i live der ute et sted. 
Pilen skal atter peke oppover, like stødig som renten hos DnB.
</div><p>Fortvil ikke, det finnes håp i vanskelige tider!</p>

<p>Selv om Island synker i havet og de samme idiotene beveger seg ut på sommergummi, år etter år, så snart de første snøkrystallende viser seg og skaper det komplette kaos, kan vi bøte på verdens undergang.</p>

<p>     Vi søker nå sosiale oldboys spillere som kan gå foran og ta initiativ til en form for sosial samling, det være seg alt fra museumsbesøk til grøftefyll … nåvel, det første er litt dødfødt og det siste blir for kaldt, men det meste derimellom skulle gå bra.</p>

<p>Om nå alle dommedagsprofetier skulle slå inn, med miljøkatastrofer, finanskriser, krig og andre styggedommer kan vi ha det litt morsomt på veien :)</p>

<p>Og husk at det finnes alltid lyspunkter (satt opp i tilfeldig rekkefølge):</p>

<ul>
<li>
<div class="MsoNormal"><span class="c1">Bush har dimmelenke og rekker med all sannsynlighet ikke å ødelegge hele kloden.<?xml:namespace prefix = o ns = "urn:schemas-microsoft-com:office:office" />
</span></div>
</li>

<li>
<div class="MsoNormal"><span class="c1">Statoil har fortsatt sjokoladebiter i bollene sine (Dette tiårets største oppfinnelse)</span></div>
</li>

<li>
<div class="MsoNormal"><span class="c1">Gaute Ormåsen har endelig sluttet å danse - det var mest skremmende med halloween</span></div>
</li>
</ul>

<p class="MsoNormal"> </p>

<p class="MsoNormal"><span class="c1">Ballen er spilt ut på banen ...</span></p>




<div class="addthis_toolbox addthis_default_style">
<a href="http://www.addthis.com/bookmark.php?v=250&amp;username=xa-4be09cd0025b8da5" class="addthis_button_compact">Share</a>
<span class="addthis_separator">|</span>
<a class="addthis_button_facebook"></a>
<a class="addthis_button_myspace"></a>
<a class="addthis_button_google"></a>
<a class="addthis_button_twitter"></a>
</div>
<script type="text/javascript" src="http://s7.addthis.com/js/250/addthis_widget.js#username=xa-4be09cd0025b8da5"></script>
<!-- AddThis Button END -->

<hr>
<h2>Kommentarer:</h2>
	<div class="newsitem"><i><b>01.11.08 16:18 - <a href="mailto:">Terje Dahl</a></b></i><p>..vi prøver da så godt vi kan å holde liv i sosiale aktiviteter etter som aktivitetene på de diverse kamparenaene avsluttes for høsten.<br/>
Vi har vel funnet ut at midt mellom museumsbesøk og grøftefyll finner vi aktiviteten kortspill der det gjelder å ha de 2 beste kortene på hånden i kombinasjon med 3+1+1 kort på bordet.<br/>
Dette var en aktivitet som senest ble avholdt i går inn i de sene nattetimer med tilhørende fludium og store mengder overskuddslager av halloweengotterier.<br/>
Beklageligvis var det bare 2 representanter fra oldboysklassen i denne runden selv om flere hadde invitasjon til å komme<br/>
..men fortvil ikke, sannsynligheten er relativt stor for at det ikke blir lenge til neste økt.</p></div><div class="newsitem"><i><b>03.11.08 9:31 - <a href="mailto:">nr 7</a></b></i><p>Et initiativ! Dette må følges opp. Hva med å snu på flisa, Terje - i stedet for å bestemmer seg for å spille poker og se om det blir morsomt, så bestemmer vi oss for å gjøre noe morsomt og ser om det blir poker.</p></div><div class="newsitem"><i><b>03.11.08 9:43 - <a href="mailto:">nr 8</a></b></i><p>Følger opp hjernestormen: Har noen prøvd å gå ut i Asker og ta en øl de siste 10 årene? Er det så morsomt som det engang var og et alternativ til hobbykveld i sofaen?</p></div><div class="newsitem"><i><b>03.11.08 15:42 - <a href="mailto:">Alfie</a></b></i><p>Forslag:
Lørdag 15.11 
Hjemme hos Mølla Dekk.
Storskjerm: MANU - Stoke.
FIGO: Ordner du lokalet?</p></div><div class="newsitem"><i><b>03.11.08 19:15 - <a href="mailto:">Terje Dahl</a></b></i><p>..en aktivitet som kom opp på forrige kortleiksamling var bowling(!)<br/>
Såfremt de har startet med ølservering..<br/>
Vi måtte til Sandvika for å få til dette forrige gang i 2006, mye kan ha skjedd i Asker etter den tid uten at jeg har fått med meg dette.<br/>
Ulempen er at Tore er en rev i Bowling og kan skryte på seg snitt oppunder 300 så sjansen for å vinne er minimal om han er med.<br/>
Vi andre kan alltids gamble om 2. plassen.</p></div><div class="newsitem"><i><b>03.11.08 19:31 - <a href="mailto:">nr 9</a></b></i><p>..kan følge opp uteaktiviteter i Asker. Vi i Risengveien har rutine på å dra ned til <a href="http://www.baracoa.no/baracoa/quiz/index.html" target="_blank">Baracoa</a> 1. onsdag i mnd for quiz. Denne aktiviteten går forøvrig HVER onsdag og pleier å være en ganske så sosial aktivitet. Som kjent serveres det også øl av ulike sorter på <a href="http://www.baracoa.no/baracoa/quiz/index.html" target="_blank">Baracoa</a></p></div><div class="newsitem"><i><b>04.11.08 9:13 - <a href="mailto:">Figo</a></b></i><p>Mange bra forslag her, godt å registrere at gutta er i live ;)
Jeg har holdt av klubbhuset til neste lørdag (15.nov) og publiserer en egen sak på det.
</p></div><div class="newsitem"><i><b>04.11.08 13:17 - <a href="mailto:">Keegan</a></b></i><p>Bra, la oss holde alle forslag åpne. Jeg støtter også tiltaket over og drar på Baracoa på onsdag kl 19 for å styrke/utgjøre FAO sitt lag i quizen!</p></div><div class="newsitem"><i><b>04.11.08 13:37 - <a href="mailto:">Terje Dahl</a></b></i><p>snakker vi om førstkommende onsdag i morgen, som er 1. onsdag i mnd? <br/>
interressekonflikt for min del, men stiller uansett.<br/> 
Ryktene går om at det er stort oppmøte fra "Hengelauget" i morgen og da lagindelingen er maks 5 på hvert quiz-lag så blir det flere lag uansett..</p></div><div class="newsitem"><i><b>05.11.08 15:36 - <a href="mailto:">StianK</a></b></i><p>Quiz og kunnskaper er jeg en rev på, men i kveld kl 19 byr nok på problemer. Ellers er motivasjonen for FSOP eller andre tiltak tilstede</p></div><div class="newsitem"><i><b>06.11.08 11:24 - <a href="mailto:">Keegan</a></b></i><p>FAO har nå markert seg i lokalmiljøet med en sterk debutkamp i quiz-serien på Baracoa i går kveld.
Lagoppstillingen tatt i betraktning.
Laget kom godt ut med overbevisende kunnskaper om anatomi og nyheter. Så falt laget noe tilbake på geografi, historie, sport(!) og kjøkkenrelaterte tema. På slutten hentet man seg noe inn igjen på skogbruk og insekter.  22. plass av 28 lag var i det minste over nedrykksstreken og et godt utgangspunkt for videre tabellklatring.</p></div><div class="newsitem"><i><b>06.11.08 20:14 - <a href="mailto:">Terje Dahl</a></b></i><p>..kom meg desverre aldri avgårde i går. Godt å høre at FAO også markerer seg på andre arenaer.</p></div><div class="newsitem"><i><b>06.11.08 21:42 - <a href="mailto:">Bønna</a></b></i><p>Hadde selvfølgelig kommet om jeg visste at det var noen som skulle! Kunne bidratt bra på geografi! Si fra neste gang!!!!! :-)</p></div><div class="newsitem"><i><b>06.11.08 23:34 - <a href="mailto:">Keegan</a></b></i><p>Onsdag om to uker. Oppmøte 18.55 for pep-talk, blyantkvessing og pilsbestilling.</p></div><div class="newsitem"><i><b>10.11.08 15:07 - <a href="mailto:">Terje Dahl</a></b></i><p>snakker vi om onsdag 19. november her?</p></div><div class="newsitem"><i><b>20.11.08 15:20 - <a href="mailto:">Figo</a></b></i><p>Hvis FAO hadde stukket av med pokalen i går så hadde vi vel hørt det......?</p></div><div class="newsitem"><i><b>20.11.08 18:15 - <a href="mailto:">nr 7</a></b></i><p>Helt riktig. Førsteeneren satt ut med feber. Førstereserven tom for goodwill på hjemmebane. Andrereserven kunne ikke rekke kampstart. Så det ble tap på walk-under, ganske riktig.</p></div><div class="newsitem"><i><b>03.12.08 13:18 - <a href="mailto:">Figo</a></b></i><p>Stiller oldboys'n lag i kveldens quiz?
... grunnen til at jeg spør er at vi har en søker til jobben som sølvpusser i FAO og da må jeg beregne en stillingsprosent etter størrelsen på det pokalskapet som skal bestilles...</p></div><div class="newsitem"><i><b>03.12.08 15:03 - <a href="mailto:">nr 7</a></b></i><p>Har ikke hørt at noen er ute av vinterdvalen. Stiller dog på kort varsel om det ikke blir som enmannsorkester med sikker utsikt til plassering på tabellens nedre del pga alle blanke svar på temaer som f eks nettopp sølvpuss.</p></div><div class="newsitem"><i><b>06.12.08 20:26 - <a href="mailto:kandubareglemme">Terje Dahl</a></b></i><p>..ja her var det liv!</p></div><div class="newsitem"><i><b>01.04.09 14:10 - <a href="mailto:">Figo</a></b></i><p>Første onsdag i april ... noen som har tenkt seg på quiz i dag?</p></div><div class="newsitem"><i><b>03.04.09 19:00 - <a href="mailto:">Figo</a></b></i><p>Nei vel da ...</p></div>
<!--
<p>
<b>Kommentering er midlertidig steng pga SPAM!</b>
</p>
-->
<form method="post" action="bmrk-sosialkurator-soekes.aspx" id="aspnetForm">
<div>
<input type="hidden" name="__EVENTTARGET" id="__EVENTTARGET" value="" />
<input type="hidden" name="__EVENTARGUMENT" id="__EVENTARGUMENT" value="" />
<input type="hidden" name="__VIEWSTATE" id="__VIEWSTATE" value="/wEPDwUENTM4MQ9kFgJmD2QWAmYPZBYCZg9kFgJmD2QWAgIPD2QWAgIFD2QWAgIBD2QWAmYPZBYCAgIPZBYCAgEPFgIeBFRleHQFF0RpbiBrb21tZW50YXIgZXIgcG9zdGV0ZGTP3+kahhm7HkFLDJ1eDASlO9mxvA==" />
</div>

<script type="text/javascript">
//<![CDATA[
var theForm = document.forms['aspnetForm'];
if (!theForm) {
    theForm = document.aspnetForm;
}
function __doPostBack(eventTarget, eventArgument) {
    if (!theForm.onsubmit || (theForm.onsubmit() != false)) {
        theForm.__EVENTTARGET.value = eventTarget;
        theForm.__EVENTARGUMENT.value = eventArgument;
        theForm.submit();
    }
}
//]]>
</script>


<script src="/WebResource.axd?d=RhJRe7vAQjxLvd0VTiPlJ3ItrtWKNnlC5ndUOdQ1oQE84Jw0mmyu8t9423FKr6Sh25O1JfgygCRLDXncXNuX2rijfWY1&amp;t=635737087099672665" type="text/javascript"></script>


<script type="text/javascript">
//<![CDATA[
function insertLink(element) {var theLink = prompt('Enter URL for link here:','http://');insertTag(element, 'a', ' href="' + theLink + '"')}
            function insertTag(element, tag, param) {
            start = '<' + tag + param + '>';
            eind = '</' + tag + '>';
             /* element = document.getElementById(element); */
              if (document.selection) {
                element.focus();
                sel = document.selection.createRange();
                sel.text = start + sel.text + eind;
              } else if (element.selectionStart || element.selectionStart == '0') {
                element.focus();
                var startPos = element.selectionStart;
                var endPos = element.selectionEnd;
                element.value = element.value.substring(0, startPos) + start + element.value.substring(startPos, endPos) + eind + element.value.substring(endPos, element.value.length);
              } else {
                element.value += start + eind;
              }
            }
            //]]>
</script>

<h2>Post en kommentar:</h2>
<div id="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_PanelInput">
	
	<div id="umbracoAutoForm">
	
  <fieldset>
			<p><label for="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_navn">Navn:</label><input name="ctl00$ctl00$ctl00$ContentPlaceHolderDefault$MainContentPlaceHolder$AutoForm_7$navn" type="text" id="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_navn" class="umbEditorTextField" /></p><p><label for="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_epost">Epost:</label><input name="ctl00$ctl00$ctl00$ContentPlaceHolderDefault$MainContentPlaceHolder$AutoForm_7$epost" type="text" id="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_epost" class="umbEditorTextField" /></p><p><label for="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_kommentar">Kommentar:</label><table border="0" cellspacing="0" cellpadding="0"><tr><td>
	<p align="right" style="margin: 0px; padding:0px"><a href="javascript:insertLink(document.getElementById('ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_kommentar'))"><img src="/umbraco_client/simpleEditor/images/link.gif" border="0" align="right" /></a><a href="javascript:insertTag(document.getElementById('ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_kommentar'), 'em', '')"><img src="/umbraco_client/simpleEditor/images/italic.gif" border="0" style="margin-left: 3px; margin-right: 3px;" align="right" /></a> <a href="javascript:insertTag(document.getElementById('ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_kommentar'), 'strong', '')"><img src="/umbraco_client/simpleEditor/images/bold.gif" border="0" align="right" /></a><br/></p>
	<textarea name="ctl00$ctl00$ctl00$ContentPlaceHolderDefault$MainContentPlaceHolder$AutoForm_7$kommentar" rows="8" cols="20" id="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_kommentar" class="umbEditorTextField"></textarea></td></tr></table>
	</p><p><label for="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_captcha">Captcha:</label><input name="ctl00$ctl00$ctl00$ContentPlaceHolderDefault$MainContentPlaceHolder$AutoForm_7$captcha" type="text" id="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_captcha" class="umbEditorNumberField" /><br/><span class="umbracoAutoFormRowDescription">Hva er elleve pluss åtte?<br/></span></p>
		<p><input type="submit" name="ctl00$ctl00$ctl00$ContentPlaceHolderDefault$MainContentPlaceHolder$AutoForm_7$Button1" value="Post kommentar" onclick="javascript:WebForm_DoPostBackWithOptions(new WebForm_PostBackOptions(&quot;ctl00$ctl00$ctl00$ContentPlaceHolderDefault$MainContentPlaceHolder$AutoForm_7$Button1&quot;, &quot;&quot;, true, &quot;&quot;, &quot;&quot;, false, false))" id="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_Button1" class="umbracoAutoFormButton" /></p>
	</fieldset>		
	</div>

</div>

		

<div>

	<input type="hidden" name="__VIEWSTATEGENERATOR" id="__VIEWSTATEGENERATOR" value="CA0B0334" />
</div></form>

<a class="readmore" href="/arkiv/2021/frisk-asker---covid-19-19-.aspx">Frisk Asker - Covid 19-19 </a> - 17.03.2021 8:41<br /><a class="readmore" href="/arkiv/2016/faos-sommerkrim.aspx">FAOs sommerkrim</a> - 29.04.2020 12:32<br /><a class="readmore" href="/arkiv/2019/fao-med-kupp-paa-overgangsmarkedet!.aspx">FAO med kupp på overgangsmarkedet!</a> - 30.07.2019 19:24<br /><a class="readmore" href="/arkiv/2019/dag-ansatt-som-fast-lagleder-paa-frisk-asker-m33.aspx">Dag ansatt som fast lagleder på Frisk Asker M33</a> - 29.07.2019 12:28<br /><a class="readmore" href="/arkiv/2019/askermesterskapet-i-oldboysfotball.aspx">Askermesterskapet i oldboysfotball</a> - 07.05.2019 16:49<br /><a class="readmore" href="/arkiv/2019/frisk-asker-oldgirls!.aspx">Frisk Asker OldGIRLS!</a> - 05.04.2019 14:14<br /><a class="readmore" href="/arkiv/2019/know-your-enemy.aspx">Know your enemy</a> - 01.02.2019 16:46<br /><a class="readmore" href="/arkiv/2018/pass-paa-liten-og-paa-stor.aspx">Pass på liten og på stor</a> - 21.09.2018 15:21<br /><a class="readmore" href="/arkiv/2018/nedrykk!.aspx">Nedrykk!</a> - 14.09.2018 14:40<br /><a class="readmore" href="/arkiv/2018/lukten-av-gull!.aspx">Lukten av gull!</a> - 07.09.2018 22:27<br />
<br/><br/>
<!--
<table id="forumposts" cellspacing="0"><tr><th colspan="2">Siste publiserte fra Sekreteriatet</th></tr><tr><td><b><a class="readmore" href="/sekreteriatet/kamprutine.aspx">Kamprutine</a> - </b>12.06.14 01:36</td></tr><tr><td><b><a class="readmore" href="/sekreteriatet/kamp-mot-bygdoe-monolitten---hvem-stiller.aspx">Kamp mot Bygdø Monolitten - hvem stiller?</a> - </b>12.09.12 09:23</td></tr><tr><td><b><a class="readmore" href="/sekreteriatet/kamp-mot-huk---hvem-stiller-(1).aspx">Kamp mot Huk - hvem stiller? (1)</a> - </b>04.09.12 10:04</td></tr><tr><td><b><a class="readmore" href="/sekreteriatet/kamp-mot-lokomotiv-oslo-29-aug---hvem-stiller.aspx">Kamp mot Lokomotiv Oslo 29. aug - hvem stiller?</a> - </b>28.08.12 02:56</td></tr><tr><td><b><a class="readmore" href="/sekreteriatet/kamp-mot-aarvoll-ons-15-aug---hvem-stiller.aspx">Kamp mot Årvoll ons 15. aug - Hvem stiller?</a> - </b>13.08.12 12:50</td></tr><tr><td class="footer" colspan="2"> </td></tr></table>
-->
</div>



                </div>
                
		 <div id="right">

<font color="red" size="4">Lagbilde</font><br/>


<!--a href="http://oldboys.friskasker.no/media/116678/formkurve.png" border=0><img src="/media/116678/formkurve.png" width="280" alt="Formkurve" /></a-->
<!--iframe src="http://free.timeanddate.com/countdown/i5t3zil3/n187/cf113/cm0/cu4/ct0/cs0/ca0/cr0/ss0/cac000/cpc000/pc00e60b/tc000/fs100/szw320/szh135/tatFAO%20h%C3%B8stsesong%20starter%20om../tac000/tptTime%20since%20Event%20started%20in/tpc000/mac000/mpc000/iso2017-08-14T21:00:00" allowTransparency="true" frameborder="0" width="320" height="135"></iframe-->
	<!--iframe frameborder="0" width="512" height="600" scrolling="auto" allowtransparency="true" src="https://risengaj96.polldaddy.com/s/fao-plassering-pr-lag-2018?iframe=1"><a href="https://risengaj96.polldaddy.com/s/fao-plassering-pr-lag-2018">View Survey</a></iframe-->
<br/>
<!-- FORMkurve iframe width="508" height="371" seamless frameborder="0" scrolling="no" src="https://docs.google.com/spreadsheets/d/1wL8AGtLu517MG4vlWG2DIat7LmhdKaJdXz4nDVsxc74/pubchart?oid=1826601090&amp;format=interactive"></iframe-->

<!-- iphone
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/iphone/Verdana/14/bold/250/1&rn=7" frameborder="0" scrolling="no" width="250" height="500"></iframe>
-->
	<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/iphone/Verdana/14/bold/280/1&rn=83" frameborder="0" scrolling="no" width="280" height="500"></iframe>
<!--
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/21/ae82202846179cbfa34c266edf916f37&colours=FF8C00/CCCCCC/FFF/4/standard/Comic+Sans+Serif/16/bold/280/1&rn=22" frameborder="0" scrolling="no" width="280" height="500"></iframe>
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/members&bits=25/21/ae82202846179cbfa34c266edf916f37&colours=FF8C00/CCCCCC/FFF/4/standard/Comic+Sans+Serif/16/bold/280/1&rn=50" frameborder="0" scrolling="no" width="280" height="500"></iframe>
-->
<!-- iframe src="https://www.s2s.net/export_content.php?team_id=1101&system=no_no/1032/2/one/activities&bits=25/21/68565729bae64238443339aae6dcf62c&colours=FF6600/000099/FFF/0/iphone/Verdana/12/bold/280/0" frameborder="0" scrolling="no" width="280" height="500"></iframe -->

<br/><br/>
<a href="http://www.forstehjelpsgrossisten.no/products/is-pose-stor-14-x-21-cm-i-kartong-av-24-stk" border="0" target="_new"><img src="/umbraco/imagegen.ashx?image=/media/114144/forstehjelpsgrossistem.png&width=280"></a>
<br/>
<div style="text-align: left; width:280px;">Stolt sponsor av Frisk Asker Oldboys!</div>

                                        
                </div>

            </div>
            
        </div>
	<div id="bottomad"><!-- Bunnbanner -->
<!--
<script type="text/javascript">
var uri = 'http://impno.tradedoubler.com/imp?type(js)g(17626798)a(1588386)' + new String (Math.random()).substring (2, 11);
document.write('<sc'+'ript type="text/javascript" src="'+uri+'" charset=""></sc'+'ript>');
</script>
-->
<a href="http://www.google.com" target="_blank">.</a>
<a href="http://www.google.com/search?q=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://www.yahoo.com" target="_blank">.</a>
<a href="http://search.yahoo.com/search?p=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://search.aol.co.uk" target="_blank">.</a>
<a href="http://search.aol.co.uk/aol/search?query=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://uk.ask.com" target="_blank">.</a>
<a href="http://uk.ask.com/web?q=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://search.live.com" target="_blank">.</a>
<a href="http://search.live.com/results.aspx?q=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://search.lycos.co.uk" target="_blank">.</a>
<a href="http://search.lycos.co.uk/cgi-bin/pursuit?SITE=uk&query=frisk+asker+oldboys" target="_blank">.</a>

	</div>

<script type="text/javascript">
var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
</script>
<script type="text/javascript">
var pageTracker = _gat._getTracker("UA-2025203-1");
pageTracker._initData();
pageTracker._trackPageview();
</script></body>
</html>
