
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">

	<head>

		<title>Norges tøffeste oldboys = Keegan  - Frisk Asker Oldboys</title>
		
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
		<meta http-equiv="imagetoolbar" CONTENT="no">
		<meta name="keywords" content="" />
		<meta name="description" content="Etter å ha vært gjennom ti krevende og varierte konkurranser som strakk seg over hele lørdagen ble Mesternes Mester 2010 kåret. Karl Bernhard "Keegan" Grova stakk i år fortjent av med pokalen, mens Bønna og Stian K. fylte opp resten av seierspallen og får med seg heder og ære som kan benyttes vilt og uhemmet i hele 2010 sesongen" />
		
		<meta name="title" content="Norges tøffeste oldboys = Keegan - Frisk Asker Oldboys" />
		<meta name="URL" content="http://oldboys.friskasker.no" />
		<meta name="language" content="Norsk" />
		<meta name="author" content="Terje Dahl" />
		<meta name="copyright" content="Frisk Asker Oldboys" />
		<meta name="reply-to" content="terjda@online.no" />
		<meta name="verify-v1" content="BxVdMcZ0uoa2KVw8RB+FBg3715LgSDXNG+RYp0gHpAI=" />

		<link type="text/css" href="/css/client.css" rel="stylesheet" />
		<link type="text/css" href="/css/default.css" rel="stylesheet" />
		<link type="text/css" href="/css/weatherCSS.css" rel="stylesheet" />

		<script type="text/javascript" src="/js/jquery.js"></script>
		<script type="text/javascript" src="/js/ufo.js"></script>
		<script type="text/javascript" src="/js/friskasker.js"></script>
		<!--script type='text/javascript' src='http://www.rdmtech.no/js/jquery.js?ver=1.2.6'></script-->
		<!--script type='text/javascript' src='http://www.rdmtech.no/js/jquery.cross-slide.js?ver=2.6'></script-->

		<!--[if IE 6]>
		<link type="text/css" href="/css/ie60.css" rel="stylesheet" />			
		<![endif]-->
		<!-- TradeDoubler site verification 1588386 --> 

	<script type='text/javascript'>
		jQuery(function($) {$(document).ready(function() {
			$('#container2').crossSlide(
				{sleep: 2, fade: 1},
				[{src: 'http://oldboys.friskasker.no/media/26561/bg-fao1.jpg'},{src: 'http://oldboys.friskasker.no/media/26566/bg-fao2.jpg'},{src: 'http://oldboys.friskasker.no/media/26571/bg-fao3.jpg'},{src: 'http://oldboys.friskasker.no/media/26576/bg-fao4.jpg'}]
			);
		});});
	</script>
	
<script type="text/javascript">
var _polldaddy = [] || _polldaddy;

_polldaddy.push( {
    type: 'slider',
    title: 'FAO-spillemodellen, skjønner du den?',
    body: 'Ta testen og bidra til å øke sjansen for sportslig utvikling av FAO!',
    button: 'Get Started &raquo;',
    domain: 'risengaj96.polldaddy.com/s/',
    id: 'fao-spillemodellen',
    placeholder: 'pd1438692132734'
} );

jQuery(function(d,c,j){$if(!document.getElementById(j)){var pd=d.createElement(c),s;pd.id=j;pd.src=('https:'==document.location.protocol)?'https://polldaddy.com/survey.js':'http://i0.poll.fm/survey.js';s=document.getElementsByTagName(c)[0];s.parentNode.insertBefore(pd,s);}}(document,'script','pd-embed'));
</script>

	
	</head>
	
	<body>
      
        <div id="container">&nbsp;
        
            <div id="header">&nbsp;
            
                <div id="logo"><a href="/"><img src="/media/26597/logos.gif" alt="Logo" /></a></div>
                <div id="rss"><a href="/data/rss/nyheter.xml">Motta RSS strøm</a></div>
		<!--div id="sitemap"><a href="/sitemap.aspx">Sitemap</a></div-->
		<div id="topknapp">
		<iframe width="280" height="160" src="https://www.youtube.com/embed/15KEqzCTrwI" frameborder="0" allowfullscreen></iframe>
		</div>
		
                

            </div>
            
            <div id="body">&nbsp;
            
                <div id="left">&nbsp;

                    <div id="date">mandag 15. april</div>
                	
                    <div class="leftnav"><a href="/">Hjem</a><br /><a href="/arkiv.aspx">Arkiv</a><br /><a href="/tabeller--terminlister.aspx">Tabeller &amp; terminlister</a><br /><a href="/kampreferat.aspx">Kampreferat</a><br /><a href="/fotballfilosofi.aspx">Fotballfilosofi</a><br /><a href="/ikke-helt-sportslig.aspx">Ikke helt sportslig</a><br /></div>
		
                    <div class="box" id="contactbox"><div class="header">Frisk Asker</div><div class="body"><a href="/frisk-asker/laget.aspx">Laget</a><br /><a href="/frisk-asker/kontakt.aspx">Kontakt</a><br /><a href="/frisk-asker/dommerhjoernet.aspx">Dommerhjørnet</a><br /><a href="https://teams.s2s.net/11225/no/" target="_new">Treningstider</a></div><div class="footer"><!----></div></div>

<!--		     <iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/standard/Verdana/14/bold/230/1&rn=84" frameborder="0" scrolling="no" width="230" height="500"></iframe>
-->
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&banner=1&system=no_no/5212/1/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/standard/Verdana/14/bold/230/1&rn=94" frameborder="0" scrolling="no" width="230" height="214"></iframe>

		     <iframe src="http://www.s2s.net/todays_skill_external.php?ccc=no" scrolling="no" width="200" height="330" frameborder="0"></iframe>
<!--
		     <div id="login">&nbsp;
                   
                    <form id="loginform" action="#">&nbsp;
                      
                        <input id="username" type="text" value="brukernavn" />
                        <input id="password" type="text" value="passord" />
                        <img src="/img/login.gif" alt="login" />
                        <a href="#">glemt passord?</a>    
                        
                    </form>
                    
                    </div>
-->
		    <div id="search">

			Artikkelsøk:<br />
			<div id="xsltsearch" xmlns:ps="urn:percipientstudios-com:xslt"><form action="/soek.aspx?" method="post" class="xsltsearch_form"><input name="search" type="text" class="input" value=""></input> <input type="submit" value="Search" class="submit" /></form></div>
		    </div>

                </div>
                
                <div id="center">
		
                    
<div class="content">

	<h1>Norges tøffeste oldboys = Keegan</h1><div class="meta">03.05.10 22:57 - Figo</div><div class="abstract"><img src="/umbraco/imagegen.ashx?image=/media/42106/seierspallen1.jpg&amp;width=500" alt="" align="left" />Etter å ha vært gjennom ti krevende og varierte konkurranser som strakk seg over hele lørdagen ble Mesternes Mester 2010 kåret. Karl Bernhard "Keegan" Grova stakk i år fortjent av med pokalen, mens Bønna og Stian K. fylte opp resten av seierspallen og får med seg heder og ære som kan benyttes vilt og uhemmet i hele 2010 sesongen</div>
<p>Spenningen var stor rundt frokostbordet lørdag morgen. Hvilke
konkurransegrener blir det, er det mange fysiske øvelser etc?
Spørsmålene var mange mens Bønnas egg og bacon ble fortært og
snøfillene dalte stille utenfor vinduet.</p>

<p>Kåringen av Norges tøffeste oldboys startet rolig, med åtte
karer dypt konsentrert i en real Trysil quiz, hvor kunnskapsnivået
om bygda viste seg å være sørgelige saker. Når man kan innkassere
en bronse ved å svare riktig på ett eneste spørsmål forstår man at
her har opplysningskontoret for skogdrift mye å jobbe med. Godt å
vite at alle åtte nå kan lokalisere hommelsbota &nbsp;på kroppen
slik at vi kan gjers åt og unngå forvirring i rekkene på en gnæret
dag.</p>

<p>Vel, vel, det var tid for litt fysisk arbeid og vi beveget oss
utendørs for dagens kviste/bære/kappe øvelse. Nesten alle forstod
hvilket lag de var på og i hvilken retning det bar og etter en
spurt ned i lia var alle mann i gang. Thomas og Bønna var soleklart
først oppe med stokken og hadde tid til en kaffepause om de hadde
ønsket. Seieren var i boks selv om enkelte onde tunger snakket
lenge og vel om hvordan standardisering av vedkubber bør foregå og
hvordan den perfekte kubben skal se ut.</p>

<p><img src="/media/42203/web_sag_209x140.jpg"  width="209"  height="140" alt="web_sag"/><img src="/media/42208/web_terje_sag_186x140.jpg"  width="186"  height="140" alt="web_terje_sag"/></p>

<p>Det var tid for innveiing og etter et par øvelser hvor du må
lete langt nede på resultatlista for å finne Keegan, viste han seg
her frem for første gang. Det hele var avgjort når kubben ble lagt
på vekta og den ble klokket inn på 2,0 kg blank!</p>

<p>Elgjegern fra Drangedal var vel også regnet med i
favoritt-skiktet i den neste øvelsen; presisjonsskyting, men her
var det en annen kar som slo overraskende til.</p>

<p>Trond hadde spesialtilpassede bifokale linser i differensiert
styrke på hver iris, spesielt tilpasset links skyting, og gikk
seirende ut av duellen. Det ble mumlet en del om inntak av
beroligende og blodfortynnende remedier, men etter som
dopingkontrollørene ikke fant veien i Trysils dype skoger ble
resultatet stående.</p>

<p><img src="/media/42237/web_luftgevær_bøm_212x159.jpg"  width="212"  height="159" alt="web_Luftgevær_bøm"/><img src="/media/42242/web_luftgevær_186x160.jpg"  width="186"  height="160" alt="Web_Luftgevær"/></p>

<p>Når fire innledende runder var unnagjort var det Terje som hadde
en knapp ledelse, med 9 poeng, etter å ha hanket inn tre
andreplasser på de fire første konkurransene. Det var imidlertid
såpass jevnt at alt var åpent og vi gjorde oss klare til
transportetappen til neste konkurransested.</p>

<p>Dagens største opplevelse for undertegnede var å observere
deltagernes reaksjoner da det omsider gikk opp for disse at de
hårete farkostene som kom ruslende oppover faktisk skulle
transportere de modne herrer videre.</p>

<p><img src="/media/42259/web_hester2_219x167.jpg"  width="219"  height="167" alt="web_hester2"/> <img src="/media/42264/web_hester_224x161.jpg"  width="224"  height="161" alt="web_hester"/></p>

<p>Etter fem spennende kilometer på hesteryggen var det klart for
rodeo. Alle hadde nå forstått instruksene om hvordan man bremser,
styrer og gasser et kjøretøy med hale, og det var på tide å sette
denne lærdommen ut i praksis ved å la to og to ri i mot hverandre i
en løype bestående av flere spennende utfordringer så som
svampekasting, hjelmflytting, kjegleslalom og sist men ikke minst
et kjempehøyt hinder som skulle hoppes over. Cowboy-Keegan&nbsp;
tok sin andre etappeseier i tour'en etter mye imponerende ridning
av alle mann.</p>

<p><img src="/media/42109/cowboy-keegan_200x192.jpg"  width="200"  height="192" alt="Cowboy Keegan"/> <img src="/media/42281/web_rodeo_250x146.jpg"  width="250"  height="146" alt="Web_rodeo"/></p>

<p>Bønna var storfavoritt på øvelsen "mellomdistanse med fasit" og
bar favorittstempelet uten problemer. Mens de andre lå i målområdet
og hev etter pusten løp han likegodt løypa to ganger til, både med
og uten sekk. Det går rykter om en massiv felles tjuvstart i løpet,
men jeg kan garantere at dommeren ikke registrerte noe slikt så det
må kun være rykter.</p>

<p>Det var på tide med en pølserast og tilhørende kald drikke før
vi skulle gå løs på dagens syvende øvelse; Hesteskokasting.</p>

<p>I Trysil er kasting av hestesko ranket på lik linje med tennis i
Bærum så reglene og konkurranseformer er standardisert og
målepinner pinlige nøyaktige. Nå var det ikke nødvendig med
finmåling her i gården da den største utfordringen tidvis var å
finne igjen skoene. Banen var, for oldboysen, lagt skremmende nært
samfunnshuset i Nesvollberget, men vi slapp heldigvis unna
erstatningsansvar for knuste vinduer. Det ville nok gått gjetord i
bygda om byfolket som ikke kunne kaste hestesko om ikke Einar hadde
fått lykketreff og omringet pinnen med det ene kastet.</p>

<p><img src="/media/42310/web_hestesko_einar_205x138.jpg"  width="205"  height="138" alt="web_hestesko_einar"/> <img src="/media/42315/web_hestesko_einar2_215x135.jpg"  width="215"  height="135" alt="web_hestesko_einar2"/></p>

<p>Så var turen kommet til pilkast, og der hvor Einar bare trengte
en sko for å vinne forrige øvelse var det bare nødvendig for Thomas
å bruke tre piler før han demonstrativt satte resten godt unna
blinken. Seieren var uansett sikret. For øvrig lite imponerende
treffprosent også i denne ferdigheten, men her får vi skylde på
manglende oppvarmingsrunde.</p>

<p>Da var de innledende runder unnagjort og vi stod igjen med tre
finalister; Bønna, Karl og Stian K. Mens de to førstnevnte hadde
sikret seg førsteplass i opp til flere grener, hadde Klausen kjørt
en allround variant og plukket poeng jevnt og trutt.</p>

<p>En tur i badstua er obligatorisk og med tanke på den avgjørende
finalerunden på setra var det godt å få varmen i kroppen, myket opp
muskulaturen samt få i seg styrkende næring.</p>

<p>Vel tilbake på setra var det klart for to finalerunder før vi
kunne stå igjen med årets utkårede mester. Først skulle det kastes
på stikka, en variant av boule, hvor Klausen ble hengende etter og
måtte forlate mesterskapet med en hederlig bronseplass.</p>

<p>Das grande finale stod derfor mellom Bønna og Keegan, kanskje de
to stabukkene med det største konkurranseinstinktet. Her gikk det
på styrke og vinnervilje, med tre kilo i hver av sine to strake
armer. Røde, grimasefylte ansikter, og armer som skalv som gele og
begynte å kroke seg som bjørka … en spent tilskuerskare trodde at
begge skulle gi opp samtidig da Bønna senket armene og Keegan stod
igjen som den ubestridte mester. Ti tøffe prøvelser var tilbakelagt
og resultatlisten talte sitt tydelige språk.</p>

<p><img src="/media/42332/web_finale_228x136.jpg"  width="228"  height="136" alt="web_finale"/> <img src="/media/42337/web_figo og keegan2_176x127.jpg"  width="176"  height="127" alt="Web_Figo og Keegan2"/></p>

<p>Etter en liten konferanse med kona om hva som behøves å få gjort
på setra så har vi begynt å kategorisere neste års mesterskap inn i
flere delkonkurranser så som byggmesternes mester, malemesternes
mester osv.</p>

<p>Takk til alle deltagerne for noenlunde god sportsånd og
fabelaktig innsats.</p>

<p>Hilsen Farmen-Figo</p>

<p>&nbsp;</p>

<p><strong><a href="/arkiv/2011/megler1-ble-kaaret-til-aarets-toeffeste-oldboys-2011!.aspx"
title="Megler1 ble kåret til årets tøffeste oldboys 2011!">Megler1
ble kåret til årets tøffeste oldboys 2011!</a></strong></p>



<div class="addthis_toolbox addthis_default_style">
<a href="http://www.addthis.com/bookmark.php?v=250&amp;username=xa-4be09cd0025b8da5" class="addthis_button_compact">Share</a>
<span class="addthis_separator">|</span>
<a class="addthis_button_facebook"></a>
<a class="addthis_button_myspace"></a>
<a class="addthis_button_google"></a>
<a class="addthis_button_twitter"></a>
</div>
<script type="text/javascript" src="http://s7.addthis.com/js/250/addthis_widget.js#username=xa-4be09cd0025b8da5"></script>
<!-- AddThis Button END -->

<hr>
<h2>Kommentarer:</h2>
	<div class="newsitem"><i><b>04.05.10 12:38 - <a href="mailto:">Bønna</a></b></i><p>....og en stor takk til arrangøren!:-) </p></div><div class="newsitem"><i><b>04.05.10 12:44 - <a href="mailto:">Mads</a></b></i><p>Utrolig artig!!

Jeg merker meg også at to av våre "skadede" er de tøffeste, og at de også spilte kamp mot Trysil?
Er de klare til kamp mot Odin i morgen?</p></div><div class="newsitem"><i><b>04.05.10 13:39 - <a href="mailto:">StianK</a></b></i><p>Om ikke de nevnte kan stille så skal i alle fall jeg kute alt jeg kan (og det er ikke mye) og sørge for at Odins menn tar attvippen med et par sugende taklinger</p></div><div class="newsitem"><i><b>05.05.10 18:47 - <a href="mailto:">Anna Lisa </a></b></i><p>HAHA! Jeg må le av den sinnsykt tøffe sykkelhjelmcapsen fatter:D Høres ut som dere har hatt det alt for bra, gleder meg til jeg kommer på Old og kan få ha det like gøy :)</p></div>
<!--
<p>
<b>Kommentering er midlertidig steng pga SPAM!</b>
</p>
-->
<form method="post" action="norges-toeffeste-oldboys-=-keegan.aspx" id="aspnetForm">
<div>
<input type="hidden" name="__EVENTTARGET" id="__EVENTTARGET" value="" />
<input type="hidden" name="__EVENTARGUMENT" id="__EVENTARGUMENT" value="" />
<input type="hidden" name="__VIEWSTATE" id="__VIEWSTATE" value="/wEPDwUENTM4MQ9kFgJmD2QWAmYPZBYCZg9kFgJmD2QWAgIPD2QWAgIFD2QWAgIBD2QWAmYPZBYCAgIPZBYCAgEPFgIeBFRleHQFF0RpbiBrb21tZW50YXIgZXIgcG9zdGV0ZGTP3+kahhm7HkFLDJ1eDASlO9mxvA==" />
</div>

<script type="text/javascript">
//<![CDATA[
var theForm = document.forms['aspnetForm'];
if (!theForm) {
    theForm = document.aspnetForm;
}
function __doPostBack(eventTarget, eventArgument) {
    if (!theForm.onsubmit || (theForm.onsubmit() != false)) {
        theForm.__EVENTTARGET.value = eventTarget;
        theForm.__EVENTARGUMENT.value = eventArgument;
        theForm.submit();
    }
}
//]]>
</script>


<script src="/WebResource.axd?d=RhJRe7vAQjxLvd0VTiPlJ3ItrtWKNnlC5ndUOdQ1oQE84Jw0mmyu8t9423FKr6Sh25O1JfgygCRLDXncXNuX2rijfWY1&amp;t=635737087099672665" type="text/javascript"></script>


<script type="text/javascript">
//<![CDATA[
function insertLink(element) {var theLink = prompt('Enter URL for link here:','http://');insertTag(element, 'a', ' href="' + theLink + '"')}
            function insertTag(element, tag, param) {
            start = '<' + tag + param + '>';
            eind = '</' + tag + '>';
             /* element = document.getElementById(element); */
              if (document.selection) {
                element.focus();
                sel = document.selection.createRange();
                sel.text = start + sel.text + eind;
              } else if (element.selectionStart || element.selectionStart == '0') {
                element.focus();
                var startPos = element.selectionStart;
                var endPos = element.selectionEnd;
                element.value = element.value.substring(0, startPos) + start + element.value.substring(startPos, endPos) + eind + element.value.substring(endPos, element.value.length);
              } else {
                element.value += start + eind;
              }
            }
            //]]>
</script>

<h2>Post en kommentar:</h2>
<div id="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_PanelInput">
	
	<div id="umbracoAutoForm">
	
  <fieldset>
			<p><label for="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_navn">Navn:</label><input name="ctl00$ctl00$ctl00$ContentPlaceHolderDefault$MainContentPlaceHolder$AutoForm_7$navn" type="text" id="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_navn" class="umbEditorTextField" /></p><p><label for="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_epost">Epost:</label><input name="ctl00$ctl00$ctl00$ContentPlaceHolderDefault$MainContentPlaceHolder$AutoForm_7$epost" type="text" id="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_epost" class="umbEditorTextField" /></p><p><label for="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_kommentar">Kommentar:</label><table border="0" cellspacing="0" cellpadding="0"><tr><td>
	<p align="right" style="margin: 0px; padding:0px"><a href="javascript:insertLink(document.getElementById('ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_kommentar'))"><img src="/umbraco_client/simpleEditor/images/link.gif" border="0" align="right" /></a><a href="javascript:insertTag(document.getElementById('ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_kommentar'), 'em', '')"><img src="/umbraco_client/simpleEditor/images/italic.gif" border="0" style="margin-left: 3px; margin-right: 3px;" align="right" /></a> <a href="javascript:insertTag(document.getElementById('ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_kommentar'), 'strong', '')"><img src="/umbraco_client/simpleEditor/images/bold.gif" border="0" align="right" /></a><br/></p>
	<textarea name="ctl00$ctl00$ctl00$ContentPlaceHolderDefault$MainContentPlaceHolder$AutoForm_7$kommentar" rows="8" cols="20" id="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_kommentar" class="umbEditorTextField"></textarea></td></tr></table>
	</p><p><label for="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_captcha">Captcha:</label><input name="ctl00$ctl00$ctl00$ContentPlaceHolderDefault$MainContentPlaceHolder$AutoForm_7$captcha" type="text" id="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_captcha" class="umbEditorNumberField" /><br/><span class="umbracoAutoFormRowDescription">Hva er elleve pluss åtte?<br/></span></p>
		<p><input type="submit" name="ctl00$ctl00$ctl00$ContentPlaceHolderDefault$MainContentPlaceHolder$AutoForm_7$Button1" value="Post kommentar" onclick="javascript:WebForm_DoPostBackWithOptions(new WebForm_PostBackOptions(&quot;ctl00$ctl00$ctl00$ContentPlaceHolderDefault$MainContentPlaceHolder$AutoForm_7$Button1&quot;, &quot;&quot;, true, &quot;&quot;, &quot;&quot;, false, false))" id="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_Button1" class="umbracoAutoFormButton" /></p>
	</fieldset>		
	</div>

</div>

		

<div>

	<input type="hidden" name="__VIEWSTATEGENERATOR" id="__VIEWSTATEGENERATOR" value="CA0B0334" />
</div></form>

<a class="readmore" href="/arkiv/2021/frisk-asker---covid-19-19-.aspx">Frisk Asker - Covid 19-19 </a> - 17.03.2021 8:41<br /><a class="readmore" href="/arkiv/2016/faos-sommerkrim.aspx">FAOs sommerkrim</a> - 29.04.2020 12:32<br /><a class="readmore" href="/arkiv/2019/fao-med-kupp-paa-overgangsmarkedet!.aspx">FAO med kupp på overgangsmarkedet!</a> - 30.07.2019 19:24<br /><a class="readmore" href="/arkiv/2019/dag-ansatt-som-fast-lagleder-paa-frisk-asker-m33.aspx">Dag ansatt som fast lagleder på Frisk Asker M33</a> - 29.07.2019 12:28<br /><a class="readmore" href="/arkiv/2019/askermesterskapet-i-oldboysfotball.aspx">Askermesterskapet i oldboysfotball</a> - 07.05.2019 16:49<br /><a class="readmore" href="/arkiv/2019/frisk-asker-oldgirls!.aspx">Frisk Asker OldGIRLS!</a> - 05.04.2019 14:14<br /><a class="readmore" href="/arkiv/2019/know-your-enemy.aspx">Know your enemy</a> - 01.02.2019 16:46<br /><a class="readmore" href="/arkiv/2018/pass-paa-liten-og-paa-stor.aspx">Pass på liten og på stor</a> - 21.09.2018 15:21<br /><a class="readmore" href="/arkiv/2018/nedrykk!.aspx">Nedrykk!</a> - 14.09.2018 14:40<br /><a class="readmore" href="/arkiv/2018/lukten-av-gull!.aspx">Lukten av gull!</a> - 07.09.2018 22:27<br />
<br/><br/>
<!--
<table id="forumposts" cellspacing="0"><tr><th colspan="2">Siste publiserte fra Sekreteriatet</th></tr><tr><td><b><a class="readmore" href="/sekreteriatet/kamprutine.aspx">Kamprutine</a> - </b>12.06.14 01:36</td></tr><tr><td><b><a class="readmore" href="/sekreteriatet/kamp-mot-bygdoe-monolitten---hvem-stiller.aspx">Kamp mot Bygdø Monolitten - hvem stiller?</a> - </b>12.09.12 09:23</td></tr><tr><td><b><a class="readmore" href="/sekreteriatet/kamp-mot-huk---hvem-stiller-(1).aspx">Kamp mot Huk - hvem stiller? (1)</a> - </b>04.09.12 10:04</td></tr><tr><td><b><a class="readmore" href="/sekreteriatet/kamp-mot-lokomotiv-oslo-29-aug---hvem-stiller.aspx">Kamp mot Lokomotiv Oslo 29. aug - hvem stiller?</a> - </b>28.08.12 02:56</td></tr><tr><td><b><a class="readmore" href="/sekreteriatet/kamp-mot-aarvoll-ons-15-aug---hvem-stiller.aspx">Kamp mot Årvoll ons 15. aug - Hvem stiller?</a> - </b>13.08.12 12:50</td></tr><tr><td class="footer" colspan="2"> </td></tr></table>
-->
</div>



                </div>
                
		 <div id="right">

<font color="red" size="4">Lagbilde</font><br/>


<!--a href="http://oldboys.friskasker.no/media/116678/formkurve.png" border=0><img src="/media/116678/formkurve.png" width="280" alt="Formkurve" /></a-->
<!--iframe src="http://free.timeanddate.com/countdown/i5t3zil3/n187/cf113/cm0/cu4/ct0/cs0/ca0/cr0/ss0/cac000/cpc000/pc00e60b/tc000/fs100/szw320/szh135/tatFAO%20h%C3%B8stsesong%20starter%20om../tac000/tptTime%20since%20Event%20started%20in/tpc000/mac000/mpc000/iso2017-08-14T21:00:00" allowTransparency="true" frameborder="0" width="320" height="135"></iframe-->
	<!--iframe frameborder="0" width="512" height="600" scrolling="auto" allowtransparency="true" src="https://risengaj96.polldaddy.com/s/fao-plassering-pr-lag-2018?iframe=1"><a href="https://risengaj96.polldaddy.com/s/fao-plassering-pr-lag-2018">View Survey</a></iframe-->
<br/>
<!-- FORMkurve iframe width="508" height="371" seamless frameborder="0" scrolling="no" src="https://docs.google.com/spreadsheets/d/1wL8AGtLu517MG4vlWG2DIat7LmhdKaJdXz4nDVsxc74/pubchart?oid=1826601090&amp;format=interactive"></iframe-->

<!-- iphone
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/iphone/Verdana/14/bold/250/1&rn=7" frameborder="0" scrolling="no" width="250" height="500"></iframe>
-->
	<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/iphone/Verdana/14/bold/280/1&rn=83" frameborder="0" scrolling="no" width="280" height="500"></iframe>
<!--
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/21/ae82202846179cbfa34c266edf916f37&colours=FF8C00/CCCCCC/FFF/4/standard/Comic+Sans+Serif/16/bold/280/1&rn=22" frameborder="0" scrolling="no" width="280" height="500"></iframe>
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/members&bits=25/21/ae82202846179cbfa34c266edf916f37&colours=FF8C00/CCCCCC/FFF/4/standard/Comic+Sans+Serif/16/bold/280/1&rn=50" frameborder="0" scrolling="no" width="280" height="500"></iframe>
-->
<!-- iframe src="https://www.s2s.net/export_content.php?team_id=1101&system=no_no/1032/2/one/activities&bits=25/21/68565729bae64238443339aae6dcf62c&colours=FF6600/000099/FFF/0/iphone/Verdana/12/bold/280/0" frameborder="0" scrolling="no" width="280" height="500"></iframe -->

<br/><br/>
<a href="http://www.forstehjelpsgrossisten.no/products/is-pose-stor-14-x-21-cm-i-kartong-av-24-stk" border="0" target="_new"><img src="/umbraco/imagegen.ashx?image=/media/114144/forstehjelpsgrossistem.png&width=280"></a>
<br/>
<div style="text-align: left; width:280px;">Stolt sponsor av Frisk Asker Oldboys!</div>

                                        
                </div>

            </div>
            
        </div>
	<div id="bottomad"><!-- Bunnbanner -->
<!--
<script type="text/javascript">
var uri = 'http://impno.tradedoubler.com/imp?type(js)g(17626798)a(1588386)' + new String (Math.random()).substring (2, 11);
document.write('<sc'+'ript type="text/javascript" src="'+uri+'" charset=""></sc'+'ript>');
</script>
-->
<a href="http://www.google.com" target="_blank">.</a>
<a href="http://www.google.com/search?q=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://www.yahoo.com" target="_blank">.</a>
<a href="http://search.yahoo.com/search?p=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://search.aol.co.uk" target="_blank">.</a>
<a href="http://search.aol.co.uk/aol/search?query=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://uk.ask.com" target="_blank">.</a>
<a href="http://uk.ask.com/web?q=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://search.live.com" target="_blank">.</a>
<a href="http://search.live.com/results.aspx?q=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://search.lycos.co.uk" target="_blank">.</a>
<a href="http://search.lycos.co.uk/cgi-bin/pursuit?SITE=uk&query=frisk+asker+oldboys" target="_blank">.</a>

	</div>

<script type="text/javascript">
var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
</script>
<script type="text/javascript">
var pageTracker = _gat._getTracker("UA-2025203-1");
pageTracker._initData();
pageTracker._trackPageview();
</script></body>
</html>
