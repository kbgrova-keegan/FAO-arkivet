
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">

	<head>

		<title>2008  - Frisk Asker Oldboys</title>
		
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
		<meta http-equiv="imagetoolbar" CONTENT="no">
		<meta name="keywords" content="" />
		<meta name="description" content="" />
		
		<meta name="title" content="2008 - Frisk Asker Oldboys" />
		<meta name="URL" content="http://oldboys.friskasker.no" />
		<meta name="language" content="Norsk" />
		<meta name="author" content="Terje Dahl" />
		<meta name="copyright" content="Frisk Asker Oldboys" />
		<meta name="reply-to" content="terjda@online.no" />
		<meta name="verify-v1" content="BxVdMcZ0uoa2KVw8RB+FBg3715LgSDXNG+RYp0gHpAI=" />

		<link type="text/css" href="/css/client.css" rel="stylesheet" />
		<link type="text/css" href="/css/default.css" rel="stylesheet" />
		<link type="text/css" href="/css/weatherCSS.css" rel="stylesheet" />

		<script type="text/javascript" src="/js/jquery.js"></script>
		<script type="text/javascript" src="/js/ufo.js"></script>
		<script type="text/javascript" src="/js/friskasker.js"></script>
		<!--script type='text/javascript' src='http://www.rdmtech.no/js/jquery.js?ver=1.2.6'></script-->
		<!--script type='text/javascript' src='http://www.rdmtech.no/js/jquery.cross-slide.js?ver=2.6'></script-->

		<!--[if IE 6]>
		<link type="text/css" href="/css/ie60.css" rel="stylesheet" />			
		<![endif]-->
		<!-- TradeDoubler site verification 1588386 --> 

	<script type='text/javascript'>
		jQuery(function($) {$(document).ready(function() {
			$('#container2').crossSlide(
				{sleep: 2, fade: 1},
				[{src: 'http://oldboys.friskasker.no/media/26561/bg-fao1.jpg'},{src: 'http://oldboys.friskasker.no/media/26566/bg-fao2.jpg'},{src: 'http://oldboys.friskasker.no/media/26571/bg-fao3.jpg'},{src: 'http://oldboys.friskasker.no/media/26576/bg-fao4.jpg'}]
			);
		});});
	</script>
	
<script type="text/javascript">
var _polldaddy = [] || _polldaddy;

_polldaddy.push( {
    type: 'slider',
    title: 'FAO-spillemodellen, skjønner du den?',
    body: 'Ta testen og bidra til å øke sjansen for sportslig utvikling av FAO!',
    button: 'Get Started &raquo;',
    domain: 'risengaj96.polldaddy.com/s/',
    id: 'fao-spillemodellen',
    placeholder: 'pd1438692132734'
} );

jQuery(function(d,c,j){$if(!document.getElementById(j)){var pd=d.createElement(c),s;pd.id=j;pd.src=('https:'==document.location.protocol)?'https://polldaddy.com/survey.js':'http://i0.poll.fm/survey.js';s=document.getElementsByTagName(c)[0];s.parentNode.insertBefore(pd,s);}}(document,'script','pd-embed'));
</script>

	
	</head>
	
	<body>
      
        <div id="container">&nbsp;
        
            <div id="header">&nbsp;
            
                <div id="logo"><a href="/"><img src="/media/26597/logos.gif" alt="Logo" /></a></div>
                <div id="rss"><a href="/data/rss/nyheter.xml">Motta RSS strøm</a></div>
		<!--div id="sitemap"><a href="/sitemap.aspx">Sitemap</a></div-->
		<div id="topknapp">
		<iframe width="280" height="160" src="https://www.youtube.com/embed/15KEqzCTrwI" frameborder="0" allowfullscreen></iframe>
		</div>
		
                

            </div>
            
            <div id="body">&nbsp;
            
                <div id="left">&nbsp;

                    <div id="date">mandag 15. april</div>
                	
                    <div class="leftnav"><a href="/">Hjem</a><br /><a href="/arkiv.aspx">Arkiv</a><br /><a href="/tabeller--terminlister.aspx">Tabeller &amp; terminlister</a><br /><a href="/kampreferat.aspx">Kampreferat</a><br /><a href="/fotballfilosofi.aspx">Fotballfilosofi</a><br /><a href="/ikke-helt-sportslig.aspx">Ikke helt sportslig</a><br /></div>
		
                    <div class="box" id="contactbox"><div class="header">Frisk Asker</div><div class="body"><a href="/frisk-asker/laget.aspx">Laget</a><br /><a href="/frisk-asker/kontakt.aspx">Kontakt</a><br /><a href="/frisk-asker/dommerhjoernet.aspx">Dommerhjørnet</a><br /><a href="https://teams.s2s.net/11225/no/" target="_new">Treningstider</a></div><div class="footer"><!----></div></div>

<!--		     <iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/standard/Verdana/14/bold/230/1&rn=84" frameborder="0" scrolling="no" width="230" height="500"></iframe>
-->
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&banner=1&system=no_no/5212/1/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/standard/Verdana/14/bold/230/1&rn=94" frameborder="0" scrolling="no" width="230" height="214"></iframe>

		     <iframe src="http://www.s2s.net/todays_skill_external.php?ccc=no" scrolling="no" width="200" height="330" frameborder="0"></iframe>
<!--
		     <div id="login">&nbsp;
                   
                    <form id="loginform" action="#">&nbsp;
                      
                        <input id="username" type="text" value="brukernavn" />
                        <input id="password" type="text" value="passord" />
                        <img src="/img/login.gif" alt="login" />
                        <a href="#">glemt passord?</a>    
                        
                    </form>
                    
                    </div>
-->
		    <div id="search">

			Artikkelsøk:<br />
			<div id="xsltsearch" xmlns:ps="urn:percipientstudios-com:xslt"><form action="/soek.aspx?" method="post" class="xsltsearch_form"><input name="search" type="text" class="input" value=""></input> <input type="submit" value="Search" class="submit" /></form></div>
		    </div>

                </div>
                
                <div id="center">
		
                    
<div class="content">

	<h1>2008</h1>


	<div class="newsitem"><h2>God jul!</h2><div class="meta">20.12.08 05:12 - Figo</div><p>Nå som det er fjerde søndag i akevitt og julebordene begynner å gå mot slutten, forhåpentligvis uten nevneverdige skandaler med diverse sekretærer og avdelingssjefer involvert, begynner julefreden å senke seg over oldboys gjengen. </p><a class="readmore" href="/arkiv/2008/god-jul!.aspx">Les mer ...</a></div><div class="newsitem"><h2>Tippekamp.</h2><div class="meta">04.11.08 09:33 - Figo</div><p>Dette er tiden for nostalgi, med den gode gamle tippekampen og plingfest i stua!

Vi har holdt av oldboysens eget klubbhus hos den forhenværende stjernespilleren (og Tronds faste støttekontakt på utenlandsreiser) Pål "Mølla" Fosnæs i Strandveien 25, lørdag 15.november.
</p><a class="readmore" href="/arkiv/2008/tippekamp.aspx">Les mer ...</a></div><div class="newsitem"><h2>B.mrk; Sosialkurator søkes</h2><div class="meta">01.11.08 02:55 - Figo</div><p>Like sikkert som høstløvet faller (i takt med børsnoteringene), daler aktiviteten på Frisk Asker oldboys sine sider rått og brutalt.
Denne artikkelen er ment som en solid krisepakke fra ledelsen og skal styrke troen på at det fortsatt finnes oldboys i live der ute et sted. 
Pilen skal atter peke oppover, like stødig som renten hos DnB.
</p><a class="readmore" href="/arkiv/2008/bmrk-sosialkurator-soekes.aspx">Les mer ...</a></div><div class="newsitem"><h2>Sølvet er sikret!!</h2><div class="meta">24.09.08 10:06 - Figo</div><p>I tiende forsøk lykkes det endelig å ta rotta på Odin og snappe sølvet på målstreken</p><a class="readmore" href="/arkiv/2008/soelvet-er-sikret!!.aspx">Les mer ...</a></div><div class="newsitem"><h2>ÅRETS (SISTE) KAMP STÅR FOR DØREN</h2><div class="meta">19.09.08 10:38 - Figo</div><p>Gode gamle Alfred (Hitchkok) kunne ikke gjort regien stort bedre når nå oppgjørets time har kommet, metallet skal fordeles og spørsmålet stilles; hvem tar sølvet, Odin eller Frisk?</p><a class="readmore" href="/arkiv/2008/aarets-(siste)-kamp-staar-for-doeren.aspx">Les mer ...</a></div><div class="newsitem"><h2>Dear Frisk Asker Oldboys fans!</h2><div class="meta">09.09.08 11:14 - </div><p>Last week fans from 17! countries visited our website.</p><a class="readmore" href="/arkiv/2008/dear-frisk-asker-oldboys-fans!.aspx">Les mer ...</a></div><div class="newsitem"><h2>Amsterdam skal besøkes, utforskes og kanskje bekjempes?</h2><div class="meta">15.08.08 04:10 - Terje Dahl</div><p>Avgjørelsen har falt – allerede 26. juni ble det besluttet at <u>Amsterdam</u> er stedet for Frisk Asker Oldboys’ årlige utenlandstur. Beslutningen var resultatet etter en demokratisk prosess hvor alle fikk være med på å bestemme når vi skulle reise – og helgen 10. – 12. oktober 2008 ble funnet fram i fellesskap da nesten hele gjengen mente at de skulle kunne slippe fri fra kjerring, unger, jobb, jakt og annet som vanligvis legger beslag på de utvalgtes dyrebare tid.</p><a class="readmore" href="/arkiv/2008/amsterdam-skal-besoekes,-utforskes-og-kanskje-bekjempes.aspx">Les mer ...</a></div><div class="newsitem"><h2>Tåsen-Frisk Asker 5-1</h2><div class="meta">13.08.08 11:56 - Keegan</div><p>Noen som har ledd av jentefotball i det siste? Never again!!</p><a class="readmore" href="/arkiv/2008/taasen-frisk-asker-5-1.aspx">Les mer ...</a></div><div class="newsitem"><h2>Sommerhilsen fra Anfield</h2><div class="meta">11.07.08 10:56 - </div><p>Hvem har sagt at sommeren ikke er en utmerket tid for supporterturer?</p><a class="readmore" href="/arkiv/2008/sommerhilsen-fra-anfield.aspx">Les mer ...</a></div><div class="newsitem"><h2>And the dezzizion is...</h2><div class="meta">26.06.08 06:12 - </div><p>Da er stemmelokalene stengt! Juryen har trukket seg tilbake. Og der kommer den ut og bekjentgjør sin kjennelse. Som er ...</p><a class="readmore" href="/arkiv/2008/and-the-dezzizion-is.aspx">Les mer ...</a></div><div class="newsitem"><h2>You'll never walk alone!</h2><div class="meta">20.06.08 08:16 - </div><p>Den tilfeldige leser av kommentarene etter siste kamp vil kanskje forundres over at den vanligvis så lystige diskusjonen har uteblitt og at det tvert i mot kan fornemmes en nærmest apatisk frustrasjon etter Kampen. 

</p><a class="readmore" href="/arkiv/2008/you'll-never-walk-alone!.aspx">Les mer ...</a></div><div class="newsitem"><h2>Hvor og når går turen til høsten?</h2><div class="meta">20.06.08 04:04 - Terje Dahl</div><p>Selv om de fleste av oss har lagt noen år bak oss glemmer vi ikke inntrykkene fra vårens store Trysil-samling. Et av temaene vi diskuterte "i det seriøse hjørnet" var av det mest grunnleggende og eksistensielle slaget: Hvor skal vi til høsten, og når skjer det?</p><a class="readmore" href="/arkiv/2008/hvor-og-naar-gaar-turen-til-hoesten.aspx">Les mer ...</a></div><div class="newsitem"><h2>Odin - Frisk Asker 6-4</h2><div class="meta">19.06.08 12:25 - Keegan</div><p>Noen som har klart å skru en corner i mål med utsiden av foten på syver-bane?
Det var kveldens høydepunkt for tapre Frisk Asker i en kamp som dessverre ved skjebnens makt og ingenting annet ble en historie om å nekte å gi seg mot gamle erkerival Odin.

</p><a class="readmore" href="/arkiv/2008/odin---frisk-asker-6-4.aspx">Les mer ...</a></div><div class="newsitem"><h2>Odin vs Frisk Asker - that's the question</h2><div class="meta">13.06.08 04:28 - </div><p>FA Top News vil til bunns i tabellanalysen og har fått William Hill, engelsk bookmaker, til å gi en dybdeanalyse.</p><a class="readmore" href="/arkiv/2008/odin-vs-frisk-asker---that's-the-question.aspx">Les mer ...</a></div><div class="newsitem"><h2>Klemetsrud - Frisk Asker 2-4</h2><div class="meta">05.06.08 05:37 - Figo</div><p>For seiersvante, eller? 
Mange uforståelige prioriteringer gjorde at oppmøtet til denne kampen ikke var voldsomt, og det til tross for at strålende solskinn, en fin kunstgessmatte på bortebane og laget på bunnen av tabellen som ventet på oss.</p><a class="readmore" href="/arkiv/2008/klemetsrud---frisk-asker-2-4.aspx">Les mer ...</a></div>

</div>




                </div>
                
		 <div id="right">

<font color="red" size="4">Lagbilde</font><br/>


<!--a href="http://oldboys.friskasker.no/media/116678/formkurve.png" border=0><img src="/media/116678/formkurve.png" width="280" alt="Formkurve" /></a-->
<!--iframe src="http://free.timeanddate.com/countdown/i5t3zil3/n187/cf113/cm0/cu4/ct0/cs0/ca0/cr0/ss0/cac000/cpc000/pc00e60b/tc000/fs100/szw320/szh135/tatFAO%20h%C3%B8stsesong%20starter%20om../tac000/tptTime%20since%20Event%20started%20in/tpc000/mac000/mpc000/iso2017-08-14T21:00:00" allowTransparency="true" frameborder="0" width="320" height="135"></iframe-->
	<!--iframe frameborder="0" width="512" height="600" scrolling="auto" allowtransparency="true" src="https://risengaj96.polldaddy.com/s/fao-plassering-pr-lag-2018?iframe=1"><a href="https://risengaj96.polldaddy.com/s/fao-plassering-pr-lag-2018">View Survey</a></iframe-->
<br/>
<!-- FORMkurve iframe width="508" height="371" seamless frameborder="0" scrolling="no" src="https://docs.google.com/spreadsheets/d/1wL8AGtLu517MG4vlWG2DIat7LmhdKaJdXz4nDVsxc74/pubchart?oid=1826601090&amp;format=interactive"></iframe-->

<!-- iphone
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/iphone/Verdana/14/bold/250/1&rn=7" frameborder="0" scrolling="no" width="250" height="500"></iframe>
-->
	<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/iphone/Verdana/14/bold/280/1&rn=83" frameborder="0" scrolling="no" width="280" height="500"></iframe>
<!--
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/21/ae82202846179cbfa34c266edf916f37&colours=FF8C00/CCCCCC/FFF/4/standard/Comic+Sans+Serif/16/bold/280/1&rn=22" frameborder="0" scrolling="no" width="280" height="500"></iframe>
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/members&bits=25/21/ae82202846179cbfa34c266edf916f37&colours=FF8C00/CCCCCC/FFF/4/standard/Comic+Sans+Serif/16/bold/280/1&rn=50" frameborder="0" scrolling="no" width="280" height="500"></iframe>
-->
<!-- iframe src="https://www.s2s.net/export_content.php?team_id=1101&system=no_no/1032/2/one/activities&bits=25/21/68565729bae64238443339aae6dcf62c&colours=FF6600/000099/FFF/0/iphone/Verdana/12/bold/280/0" frameborder="0" scrolling="no" width="280" height="500"></iframe -->

<br/><br/>
<a href="http://www.forstehjelpsgrossisten.no/products/is-pose-stor-14-x-21-cm-i-kartong-av-24-stk" border="0" target="_new"><img src="/umbraco/imagegen.ashx?image=/media/114144/forstehjelpsgrossistem.png&width=280"></a>
<br/>
<div style="text-align: left; width:280px;">Stolt sponsor av Frisk Asker Oldboys!</div>

                                        
                </div>

            </div>
            
        </div>
	<div id="bottomad"><!-- Bunnbanner -->
<!--
<script type="text/javascript">
var uri = 'http://impno.tradedoubler.com/imp?type(js)g(17626798)a(1588386)' + new String (Math.random()).substring (2, 11);
document.write('<sc'+'ript type="text/javascript" src="'+uri+'" charset=""></sc'+'ript>');
</script>
-->
<a href="http://www.google.com" target="_blank">.</a>
<a href="http://www.google.com/search?q=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://www.yahoo.com" target="_blank">.</a>
<a href="http://search.yahoo.com/search?p=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://search.aol.co.uk" target="_blank">.</a>
<a href="http://search.aol.co.uk/aol/search?query=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://uk.ask.com" target="_blank">.</a>
<a href="http://uk.ask.com/web?q=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://search.live.com" target="_blank">.</a>
<a href="http://search.live.com/results.aspx?q=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://search.lycos.co.uk" target="_blank">.</a>
<a href="http://search.lycos.co.uk/cgi-bin/pursuit?SITE=uk&query=frisk+asker+oldboys" target="_blank">.</a>

	</div>

<script type="text/javascript">
var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
</script>
<script type="text/javascript">
var pageTracker = _gat._getTracker("UA-2025203-1");
pageTracker._initData();
pageTracker._trackPageview();
</script></body>
</html>
