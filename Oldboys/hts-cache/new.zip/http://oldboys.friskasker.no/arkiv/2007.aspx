
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">

	<head>

		<title>2007  - Frisk Asker Oldboys</title>
		
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
		<meta http-equiv="imagetoolbar" CONTENT="no">
		<meta name="keywords" content="" />
		<meta name="description" content="" />
		
		<meta name="title" content="2007 - Frisk Asker Oldboys" />
		<meta name="URL" content="http://oldboys.friskasker.no" />
		<meta name="language" content="Norsk" />
		<meta name="author" content="Terje Dahl" />
		<meta name="copyright" content="Frisk Asker Oldboys" />
		<meta name="reply-to" content="terjda@online.no" />
		<meta name="verify-v1" content="BxVdMcZ0uoa2KVw8RB+FBg3715LgSDXNG+RYp0gHpAI=" />

		<link type="text/css" href="/css/client.css" rel="stylesheet" />
		<link type="text/css" href="/css/default.css" rel="stylesheet" />
		<link type="text/css" href="/css/weatherCSS.css" rel="stylesheet" />

		<script type="text/javascript" src="/js/jquery.js"></script>
		<script type="text/javascript" src="/js/ufo.js"></script>
		<script type="text/javascript" src="/js/friskasker.js"></script>
		<!--script type='text/javascript' src='http://www.rdmtech.no/js/jquery.js?ver=1.2.6'></script-->
		<!--script type='text/javascript' src='http://www.rdmtech.no/js/jquery.cross-slide.js?ver=2.6'></script-->

		<!--[if IE 6]>
		<link type="text/css" href="/css/ie60.css" rel="stylesheet" />			
		<![endif]-->
		<!-- TradeDoubler site verification 1588386 --> 

	<script type='text/javascript'>
		jQuery(function($) {$(document).ready(function() {
			$('#container2').crossSlide(
				{sleep: 2, fade: 1},
				[{src: 'http://oldboys.friskasker.no/media/26561/bg-fao1.jpg'},{src: 'http://oldboys.friskasker.no/media/26566/bg-fao2.jpg'},{src: 'http://oldboys.friskasker.no/media/26571/bg-fao3.jpg'},{src: 'http://oldboys.friskasker.no/media/26576/bg-fao4.jpg'}]
			);
		});});
	</script>
	
<script type="text/javascript">
var _polldaddy = [] || _polldaddy;

_polldaddy.push( {
    type: 'slider',
    title: 'FAO-spillemodellen, skjønner du den?',
    body: 'Ta testen og bidra til å øke sjansen for sportslig utvikling av FAO!',
    button: 'Get Started &raquo;',
    domain: 'risengaj96.polldaddy.com/s/',
    id: 'fao-spillemodellen',
    placeholder: 'pd1438692132734'
} );

jQuery(function(d,c,j){$if(!document.getElementById(j)){var pd=d.createElement(c),s;pd.id=j;pd.src=('https:'==document.location.protocol)?'https://polldaddy.com/survey.js':'http://i0.poll.fm/survey.js';s=document.getElementsByTagName(c)[0];s.parentNode.insertBefore(pd,s);}}(document,'script','pd-embed'));
</script>

	
	</head>
	
	<body>
      
        <div id="container">&nbsp;
        
            <div id="header">&nbsp;
            
                <div id="logo"><a href="/"><img src="/media/26597/logos.gif" alt="Logo" /></a></div>
                <div id="rss"><a href="/data/rss/nyheter.xml">Motta RSS strøm</a></div>
		<!--div id="sitemap"><a href="/sitemap.aspx">Sitemap</a></div-->
		<div id="topknapp">
		<iframe width="280" height="160" src="https://www.youtube.com/embed/15KEqzCTrwI" frameborder="0" allowfullscreen></iframe>
		</div>
		
                

            </div>
            
            <div id="body">&nbsp;
            
                <div id="left">&nbsp;

                    <div id="date">mandag 15. april</div>
                	
                    <div class="leftnav"><a href="/">Hjem</a><br /><a href="/arkiv.aspx">Arkiv</a><br /><a href="/tabeller--terminlister.aspx">Tabeller &amp; terminlister</a><br /><a href="/kampreferat.aspx">Kampreferat</a><br /><a href="/fotballfilosofi.aspx">Fotballfilosofi</a><br /><a href="/ikke-helt-sportslig.aspx">Ikke helt sportslig</a><br /></div>
		
                    <div class="box" id="contactbox"><div class="header">Frisk Asker</div><div class="body"><a href="/frisk-asker/laget.aspx">Laget</a><br /><a href="/frisk-asker/kontakt.aspx">Kontakt</a><br /><a href="/frisk-asker/dommerhjoernet.aspx">Dommerhjørnet</a><br /><a href="https://teams.s2s.net/11225/no/" target="_new">Treningstider</a></div><div class="footer"><!----></div></div>

<!--		     <iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/standard/Verdana/14/bold/230/1&rn=84" frameborder="0" scrolling="no" width="230" height="500"></iframe>
-->
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&banner=1&system=no_no/5212/1/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/standard/Verdana/14/bold/230/1&rn=94" frameborder="0" scrolling="no" width="230" height="214"></iframe>

		     <iframe src="http://www.s2s.net/todays_skill_external.php?ccc=no" scrolling="no" width="200" height="330" frameborder="0"></iframe>
<!--
		     <div id="login">&nbsp;
                   
                    <form id="loginform" action="#">&nbsp;
                      
                        <input id="username" type="text" value="brukernavn" />
                        <input id="password" type="text" value="passord" />
                        <img src="/img/login.gif" alt="login" />
                        <a href="#">glemt passord?</a>    
                        
                    </form>
                    
                    </div>
-->
		    <div id="search">

			Artikkelsøk:<br />
			<div id="xsltsearch" xmlns:ps="urn:percipientstudios-com:xslt"><form action="/soek.aspx?" method="post" class="xsltsearch_form"><input name="search" type="text" class="input" value=""></input> <input type="submit" value="Search" class="submit" /></form></div>
		    </div>

                </div>
                
                <div id="center">
		
                    
<div class="content">

	<h1>2007</h1>


	<div class="newsitem"><h2>Serieleder: Frisk Asker! En tabellanalyse</h2><div class="meta">05.06.08 01:28 - Keegan</div><p>Etter 5. serierunde topper Frisk Asker årets rekordjevne serie, hvor ett poeng skiller ¾ av lagene! *

 
</p><a class="readmore" href="/arkiv/2007/serieleder-frisk-asker!-en-tabellanalyse.aspx">Les mer ...</a></div><div class="newsitem"><h2>Tippekamp</h2><div class="meta">30.04.08 10:27 - Keegan</div><p>
Når Champions League og alle Europas fotballserier går inn i sine avgjørende sluttfaser, er det et sikkert tegn på at Annerledeslandet er klar til å starte opp årets sesong.
</p><a class="readmore" href="/arkiv/2007/tippekamp.aspx">Les mer ...</a></div><div class="newsitem"><h2>Treningsmatch mot Nøtterøy Oldboys?</h2><div class="meta">21.02.08 05:18 - Stian Brøyn</div><p>Ryktene om Frisk Asker Oldboys fortreffelighet har spredd seg nedover Vestfold, og har resultert i et brennende ønske fra Nøtterøy Oldboys om en treningsmatch mellom lagene.</p><a class="readmore" href="/arkiv/2007/treningsmatch-mot-noetteroey-oldboys.aspx">Les mer ...</a></div><div class="newsitem"><h2>FA Oldboys årsmøte 2008</h2><div class="meta">11.02.08 01:47 - Keegan</div><p>Utspill til innspill</p><a class="readmore" href="/arkiv/2007/fa-oldboys-aarsmoete-2008.aspx">Les mer ...</a></div><div class="newsitem"><h2>Treningsleir i Trysil</h2><div class="meta">15.01.08 06:21 - Figo</div><p>Etter som treningsleir i Trysil på rekordraskt vis har blitt en tradisjon, holder vi oss til standard program....</p><a class="readmore" href="/arkiv/2007/treningsleir-i-trysil.aspx">Les mer ...</a></div><div class="newsitem"><h2>Hvor er det blitt av alle gutta?</h2><div class="meta">07.01.08 10:48 - Figo</div><p>Det er vel på sin plass å dra frem de gamle ordene til Lars Saaabye Christensen, litt justert for anledningen</p><a class="readmore" href="/arkiv/2007/hvor-er-det-blitt-av-alle-gutta.aspx">Les mer ...</a></div><div class="newsitem"><h2>FA oldboys - en potensiell publikumsyndling</h2><div class="meta">06.12.07 01:07 - </div><p>.</p><a class="readmore" href="/arkiv/2007/fa-oldboys---en-potensiell-publikumsyndling.aspx">Les mer ...</a></div><div class="newsitem"><h2>Årets bortforklaringer</h2><div class="meta">27.11.07 02:46 - </div><p>Nyttårskavalkadene står for døren, og FA Top News er som alltid tidlig ute.

Hva var for eksempel årets beste bortforklaring for ikke å møte til bortekamp?
</p><a class="readmore" href="/arkiv/2007/aarets-bortforklaringer.aspx">Les mer ...</a></div><div class="newsitem"><h2>Mimrehjørnet</h2><div class="meta">20.11.07 12:03 - </div><p>Velkommen til mimrestund. </p><a class="readmore" href="/arkiv/2007/mimrehjoernet.aspx">Les mer ...</a></div><div class="newsitem"><h2>Kampreferat: Elgen - Jegeren: Uavgjort</h2><div class="meta">25.10.07 03:08 - Keegan</div><p>Både for jeger og elg ville en avgjørelse i denne årvisse kampen vært en sann pyrrhus-seier: Det er nettopp uavgjort som gir mest mat til begge lag.</p><a class="readmore" href="/arkiv/2007/kampreferat-elgen---jegeren-uavgjort.aspx">Les mer ...</a></div><div class="newsitem"><h2>Fortellinger fra virkeligheten: En tur til frisøren</h2><div class="meta">11.10.07 02:19 - </div><p>Hva i all verden kan skje på en tur til frisøren, spør du kanskje. Mer enn du kan forestille deg, får svaret være. Hør bare.</p><a class="readmore" href="/arkiv/2007/fortellinger-fra-virkeligheten-en-tur-til-frisoeren.aspx">Les mer ...</a></div><div class="newsitem"><h2>Vintertid i FA Top News</h2><div class="meta">11.10.07 02:12 - </div><p /><a class="readmore" href="/arkiv/2007/vintertid-i-fa-top-news.aspx">Les mer ...</a></div><div class="newsitem"><h2>Treningsleir utsatt!</h2><div class="meta">08.10.07 11:45 - Figo</div><p>Grunnet dårlig oppslutning rundt forsøket på å få til en treningsleir, er denne nå utsatt til neste år.</p><a class="readmore" href="/arkiv/2007/treningsleir-utsatt!.aspx">Les mer ...</a></div><div class="newsitem"><h2>Bronsemedaljer til Frisk Asker 2007</h2><div class="meta">01.10.07 12:42 - </div><p>Siste kamp er spilt for sesongen</p><a class="readmore" href="/arkiv/2007/bronsemedaljer-til-frisk-asker-2007.aspx">Les mer ...</a></div><div class="newsitem"><h2>Her blir det toppfotball</h2><div class="meta">21.09.07 09:35 - Figo</div><p>... akkurat som det ikke er det vi har drevet med hele tiden.    
(egen navlebeskuende tolkning av dagens nyheter) </p><a class="readmore" href="/arkiv/2007/her-blir-det-toppfotball.aspx">Les mer ...</a></div><div class="newsitem"><h2>Dagens Tallin-test</h2><div class="meta">18.09.07 10:15 - Keegan</div><p>Enda vanskeligere? Fra test av egenskaper til kunnskaper...</p><a class="readmore" href="/arkiv/2007/dagens-tallin-test.aspx">Les mer ...</a></div><div class="newsitem"><h2>Dagens Tallin-sitat</h2><div class="meta">17.09.07 12:04 - Keegan</div><p /><a class="readmore" href="/arkiv/2007/dagens-tallin-sitat.aspx">Les mer ...</a></div><div class="newsitem"><h2>Fotballspillere - vår tids vikinger?</h2><div class="meta">17.09.07 11:38 - Keegan</div><p>Siden treningsleiren i østerled nærmer seg, publiseres i reprise Egil-testen. De reisende oppfordres til å ha et bevisst forhold til egen viking-faktor for å unngå nye VG-oppslag. Rekorden ved forrige måling ble 0,3 poeng.</p><a class="readmore" href="/arkiv/2007/fotballspillere---vaar-tids-vikinger.aspx">Les mer ...</a></div><div class="newsitem"><h2>A fishy theory</h2><div class="meta">11.09.07 02:57 - Keegan</div><p>I 3. og siste episode avsløres den ville gullfiskhistoriens etterlengtede slutt. </p><a class="readmore" href="/arkiv/2007/a-fishy-theory.aspx">Les mer ...</a></div><div class="newsitem"><h2>Noen fakta om fisk</h2><div class="meta">09.09.07 12:53 - Keegan</div><p>2. episode i den utrolige gullfiskhistorien</p><a class="readmore" href="/arkiv/2007/noen-fakta-om-fisk.aspx">Les mer ...</a></div><div class="newsitem"><h2>Dramatisk hendelse på Bleiker</h2><div class="meta">08.09.07 06:15 - Keegan</div><p>Det har kommet redaksjonen for øre at en av våre spillere har hatt en sterk opplevelse denne uken, men vedkommende ønsker å være anonym for å ha sjansen til å bevare den nødvendige respekten på banen, hvilket naturligvis etterkommes.</p><a class="readmore" href="/arkiv/2007/dramatisk-hendelse-paa-bleiker.aspx">Les mer ...</a></div><div class="newsitem"><h2>Valgets kvaler</h2><div class="meta">07.09.07 08:33 - Terje Dahl</div><p>Dette handler ikke om pasningsvalg, formasjonsvalg eller valgmuligheter rundt pokerbordet. Neida, til tross for at dette bryter med gjennomgangstemaet på disse kvalitativt fantastiske sidene vil jeg like fullt publisere en liten epistel om kommunevalgets kvaler.</p><a class="readmore" href="/arkiv/2007/valgets-kvaler.aspx">Les mer ...</a></div><div class="newsitem"><h2>Siste: Forsvunnet utstyr kommet til rette!</h2><div class="meta">07.09.07 02:27 - Keegan</div><p>Siste dagers fullstendige forvirring i laget endelig over. På siste kamp kom det på det rene at utstyrsbagen manglet både keeperhansker og medisinskrin! Dette har naturligvis skapt en rykteflom av hvor disse aller mest vesentlige hjelpemidler for våre helter har blitt av. </p><a class="readmore" href="/arkiv/2007/siste-forsvunnet-utstyr-kommet-til-rette!.aspx">Les mer ...</a></div><div class="newsitem"><h2>En høyst uformell tabell analyse</h2><div class="meta">02.09.07 08:38 - Terje Dahl</div><p>Skal en se på gjenstående kamper og hvem som møter hvem og hvem som jeg anser som våre 2 argeste konkurrenter til sølvplass.</p><a class="readmore" href="/arkiv/2007/en-hoeyst-uformell-tabell-analyse.aspx">Les mer ...</a></div><div class="newsitem"><h2>Høstjakt</h2><div class="meta">09.08.07 12:41 - Figo</div><p>Vel overstått sommer. Jeg regner med at alle har hatt det fint og at egentreningen er ivaretatt på beste måte uten å definere nærmere hva vi legger i det begrepet. </p><a class="readmore" href="/arkiv/2007/hoestjakt.aspx">Les mer ...</a></div><div class="newsitem"><h2>Ambisjon for høsten er klar</h2><div class="meta">25.07.07 09:31 - Keegan</div><p>Etter klargjørende sommeranalyse, er Frisk Askers sportslige ambisjonsnivå for høstsesongen endelig klart.
</p><a class="readmore" href="/arkiv/2007/ambisjon-for-hoesten-er-klar.aspx">Les mer ...</a></div><div class="newsitem"><h2>Pokeraften</h2><div class="meta">08.07.07 11:09 - Figo</div><p>Så glad blir en pokervinner!</p><a class="readmore" href="/arkiv/2007/pokeraften.aspx">Les mer ...</a></div><div class="newsitem"><h2>Treningstider i sommer</h2><div class="meta">02.07.07 09:02 - Figo</div><p>Her er sommerens treningstider:</p><a class="readmore" href="/arkiv/2007/treningstider-i-sommer.aspx">Les mer ...</a></div><div class="newsitem"><h2>Tallinn Tours  ved Tarmo &amp; Tollern</h2><div class="meta">21.06.07 12:58 - Figo</div><p>Høstens eventyr - Tallinn. Her er foreløpig info fra Tollvesenet, vi regner vel med at det kommer et detaljert program etter ferien;       "I ren iver etter gårdagens brakseier har jeg bokket (og betalt) mine billetter til høstens store begivenhet: Tur til Tallinn 21 - 23. september."</p><a class="readmore" href="/arkiv/2007/tallinn-tours--ved-tarmo--tollern.aspx">Les mer ...</a></div><div class="newsitem"><h2>Gratulerer med ny webside!</h2><div class="meta">09.06.07 11:41 - Keegan</div><p>En ny tid er kommet - våre lenge etterlengtede egne hjemmesider ble født natt til søndag i kjellern til Terje.

Et teknologisk kvantesprang, og vi gleder oss til livlige diskusjoner og nå helt nye muligheter til eksponering av litterære kvaliteter i spillergruppa til kompensasjon for de sportslige.   

Honnør til Terje for hardt arbeid, og herved tildeling av klubbens høyeste utmerkelse: du får være fus i alt ut sesongen.</p><a class="readmore" href="/arkiv/2007/gratulerer-med-ny-webside!.aspx">Les mer ...</a></div><div class="newsitem"><h2>Årets serieoppsett har ankommet!</h2><div class="meta">09.06.07 08:45 - Admin</div><p>Sesongen braker løs 10 mai med det sedvanlege slaget mot Odin og deretter går det slag i slag hver onsdag frem til midtsommer. Sjekk oppsettet nedenfor</p><a class="readmore" href="/arkiv/2007/aarets-serieoppsett-har-ankommet!.aspx">Les mer ...</a></div><div class="newsitem"><h2>Tarmo jubilerer!</h2><div class="meta">24.04.07 05:34 - Admin</div><p>Tarmo ”Piirka” Turunen fyller 50 år!!!!!!

Gratulerer på vegne av alle oldboysgutta!</p><a class="readmore" href="/arkiv/2007/tarmo-jubilerer!.aspx">Les mer ...</a></div><div class="newsitem"><h2>Møtereferat fra årsmøtet for old boys fredag 16. mars 2007</h2><div class="meta">24.04.07 05:32 - Administrator</div><p>Sted: Brøyns Paradise Club, Gullhella

Fremmøte: 6 stk - bra fremmøte, tatt i betraktning at innkallingen kom på to dagers varsel.
</p><a class="readmore" href="/arkiv/2007/moetereferat-fra-aarsmoetet-for-old-boys-fredag-16-mars-2007.aspx">Les mer ...</a></div><div class="newsitem"><h2>The real deal!</h2><div class="meta">24.04.07 05:31 - Admin</div><p>Farsotten Texas hold’em poker har også nådd FA oldboys, og til tross for en del oppklaringer av reglene underveis, ble det gjennomført en vellykket historisk første pokerturnering sist fredag.</p><a class="readmore" href="/arkiv/2007/the-real-deal!.aspx">Les mer ...</a></div><div class="newsitem"><h2>Kursoppgang for Maxbo på Oslo Børs</h2><div class="meta">24.04.07 05:30 - Admin</div><p>Finansavisen melder om sterk kursoppgang for Maxbo på børsen. Markedssjef Lars Kvæstad sier i en kommentar at oppgangen skyldes en sterk omsetningsvekst spesielt hos forhandleren i Lensmannslia i Asker, hvor det har vært solgt uforklarlig store mengder tjære og fjær på lørdag</p><a class="readmore" href="/arkiv/2007/kursoppgang-for-maxbo-paa-oslo-boers.aspx">Les mer ...</a></div><div class="newsitem"><h2>Fotballspillere- vår tids vikinger?</h2><div class="meta">24.04.07 05:29 - Admin</div><p>En fotballkamp i oldboys-ligaen kan gi assosiasjoner til slagmarken i fordum tid, ja vel. Halv- og helsårede menn forsvarer seg, angriper, legger taktikk, og kjemper om heder og ære. Men er det riktig å trekke det så langt som å kalle oldboyslaget til Frisk Asker vår tids vikinger?</p><a class="readmore" href="/arkiv/2007/fotballspillere--vaar-tids-vikinger.aspx">Les mer ...</a></div><div class="newsitem"><h2>HØSTSESONGEN</h2><div class="meta">24.04.07 05:23 - Admin</div><p>I og med at vi er med i kampen om serimesterskapet, gjelder det å snakke litt taktikk i mellom slagene.
</p><a class="readmore" href="/arkiv/2007/hoestsesongen.aspx">Les mer ...</a></div>

</div>




                </div>
                
		 <div id="right">

<font color="red" size="4">Lagbilde</font><br/>


<!--a href="http://oldboys.friskasker.no/media/116678/formkurve.png" border=0><img src="/media/116678/formkurve.png" width="280" alt="Formkurve" /></a-->
<!--iframe src="http://free.timeanddate.com/countdown/i5t3zil3/n187/cf113/cm0/cu4/ct0/cs0/ca0/cr0/ss0/cac000/cpc000/pc00e60b/tc000/fs100/szw320/szh135/tatFAO%20h%C3%B8stsesong%20starter%20om../tac000/tptTime%20since%20Event%20started%20in/tpc000/mac000/mpc000/iso2017-08-14T21:00:00" allowTransparency="true" frameborder="0" width="320" height="135"></iframe-->
	<!--iframe frameborder="0" width="512" height="600" scrolling="auto" allowtransparency="true" src="https://risengaj96.polldaddy.com/s/fao-plassering-pr-lag-2018?iframe=1"><a href="https://risengaj96.polldaddy.com/s/fao-plassering-pr-lag-2018">View Survey</a></iframe-->
<br/>
<!-- FORMkurve iframe width="508" height="371" seamless frameborder="0" scrolling="no" src="https://docs.google.com/spreadsheets/d/1wL8AGtLu517MG4vlWG2DIat7LmhdKaJdXz4nDVsxc74/pubchart?oid=1826601090&amp;format=interactive"></iframe-->

<!-- iphone
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/iphone/Verdana/14/bold/250/1&rn=7" frameborder="0" scrolling="no" width="250" height="500"></iframe>
-->
	<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/iphone/Verdana/14/bold/280/1&rn=83" frameborder="0" scrolling="no" width="280" height="500"></iframe>
<!--
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/21/ae82202846179cbfa34c266edf916f37&colours=FF8C00/CCCCCC/FFF/4/standard/Comic+Sans+Serif/16/bold/280/1&rn=22" frameborder="0" scrolling="no" width="280" height="500"></iframe>
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/members&bits=25/21/ae82202846179cbfa34c266edf916f37&colours=FF8C00/CCCCCC/FFF/4/standard/Comic+Sans+Serif/16/bold/280/1&rn=50" frameborder="0" scrolling="no" width="280" height="500"></iframe>
-->
<!-- iframe src="https://www.s2s.net/export_content.php?team_id=1101&system=no_no/1032/2/one/activities&bits=25/21/68565729bae64238443339aae6dcf62c&colours=FF6600/000099/FFF/0/iphone/Verdana/12/bold/280/0" frameborder="0" scrolling="no" width="280" height="500"></iframe -->

<br/><br/>
<a href="http://www.forstehjelpsgrossisten.no/products/is-pose-stor-14-x-21-cm-i-kartong-av-24-stk" border="0" target="_new"><img src="/umbraco/imagegen.ashx?image=/media/114144/forstehjelpsgrossistem.png&width=280"></a>
<br/>
<div style="text-align: left; width:280px;">Stolt sponsor av Frisk Asker Oldboys!</div>

                                        
                </div>

            </div>
            
        </div>
	<div id="bottomad"><!-- Bunnbanner -->
<!--
<script type="text/javascript">
var uri = 'http://impno.tradedoubler.com/imp?type(js)g(17626798)a(1588386)' + new String (Math.random()).substring (2, 11);
document.write('<sc'+'ript type="text/javascript" src="'+uri+'" charset=""></sc'+'ript>');
</script>
-->
<a href="http://www.google.com" target="_blank">.</a>
<a href="http://www.google.com/search?q=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://www.yahoo.com" target="_blank">.</a>
<a href="http://search.yahoo.com/search?p=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://search.aol.co.uk" target="_blank">.</a>
<a href="http://search.aol.co.uk/aol/search?query=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://uk.ask.com" target="_blank">.</a>
<a href="http://uk.ask.com/web?q=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://search.live.com" target="_blank">.</a>
<a href="http://search.live.com/results.aspx?q=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://search.lycos.co.uk" target="_blank">.</a>
<a href="http://search.lycos.co.uk/cgi-bin/pursuit?SITE=uk&query=frisk+asker+oldboys" target="_blank">.</a>

	</div>

<script type="text/javascript">
var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
</script>
<script type="text/javascript">
var pageTracker = _gat._getTracker("UA-2025203-1");
pageTracker._initData();
pageTracker._trackPageview();
</script></body>
</html>
