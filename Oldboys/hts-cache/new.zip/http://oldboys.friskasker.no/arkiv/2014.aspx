
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">

	<head>

		<title>2014  - Frisk Asker Oldboys</title>
		
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
		<meta http-equiv="imagetoolbar" CONTENT="no">
		<meta name="keywords" content="" />
		<meta name="description" content="" />
		
		<meta name="title" content="2014 - Frisk Asker Oldboys" />
		<meta name="URL" content="http://oldboys.friskasker.no" />
		<meta name="language" content="Norsk" />
		<meta name="author" content="Terje Dahl" />
		<meta name="copyright" content="Frisk Asker Oldboys" />
		<meta name="reply-to" content="terjda@online.no" />
		<meta name="verify-v1" content="BxVdMcZ0uoa2KVw8RB+FBg3715LgSDXNG+RYp0gHpAI=" />

		<link type="text/css" href="/css/client.css" rel="stylesheet" />
		<link type="text/css" href="/css/default.css" rel="stylesheet" />
		<link type="text/css" href="/css/weatherCSS.css" rel="stylesheet" />

		<script type="text/javascript" src="/js/jquery.js"></script>
		<script type="text/javascript" src="/js/ufo.js"></script>
		<script type="text/javascript" src="/js/friskasker.js"></script>
		<!--script type='text/javascript' src='http://www.rdmtech.no/js/jquery.js?ver=1.2.6'></script-->
		<!--script type='text/javascript' src='http://www.rdmtech.no/js/jquery.cross-slide.js?ver=2.6'></script-->

		<!--[if IE 6]>
		<link type="text/css" href="/css/ie60.css" rel="stylesheet" />			
		<![endif]-->
		<!-- TradeDoubler site verification 1588386 --> 

	<script type='text/javascript'>
		jQuery(function($) {$(document).ready(function() {
			$('#container2').crossSlide(
				{sleep: 2, fade: 1},
				[{src: 'http://oldboys.friskasker.no/media/26561/bg-fao1.jpg'},{src: 'http://oldboys.friskasker.no/media/26566/bg-fao2.jpg'},{src: 'http://oldboys.friskasker.no/media/26571/bg-fao3.jpg'},{src: 'http://oldboys.friskasker.no/media/26576/bg-fao4.jpg'}]
			);
		});});
	</script>
	
<script type="text/javascript">
var _polldaddy = [] || _polldaddy;

_polldaddy.push( {
    type: 'slider',
    title: 'FAO-spillemodellen, skjønner du den?',
    body: 'Ta testen og bidra til å øke sjansen for sportslig utvikling av FAO!',
    button: 'Get Started &raquo;',
    domain: 'risengaj96.polldaddy.com/s/',
    id: 'fao-spillemodellen',
    placeholder: 'pd1438692132734'
} );

jQuery(function(d,c,j){$if(!document.getElementById(j)){var pd=d.createElement(c),s;pd.id=j;pd.src=('https:'==document.location.protocol)?'https://polldaddy.com/survey.js':'http://i0.poll.fm/survey.js';s=document.getElementsByTagName(c)[0];s.parentNode.insertBefore(pd,s);}}(document,'script','pd-embed'));
</script>

	
	</head>
	
	<body>
      
        <div id="container">&nbsp;
        
            <div id="header">&nbsp;
            
                <div id="logo"><a href="/"><img src="/media/26597/logos.gif" alt="Logo" /></a></div>
                <div id="rss"><a href="/data/rss/nyheter.xml">Motta RSS strøm</a></div>
		<!--div id="sitemap"><a href="/sitemap.aspx">Sitemap</a></div-->
		<div id="topknapp">
		<iframe width="280" height="160" src="https://www.youtube.com/embed/15KEqzCTrwI" frameborder="0" allowfullscreen></iframe>
		</div>
		
                

            </div>
            
            <div id="body">&nbsp;
            
                <div id="left">&nbsp;

                    <div id="date">mandag 15. april</div>
                	
                    <div class="leftnav"><a href="/">Hjem</a><br /><a href="/arkiv.aspx">Arkiv</a><br /><a href="/tabeller--terminlister.aspx">Tabeller &amp; terminlister</a><br /><a href="/kampreferat.aspx">Kampreferat</a><br /><a href="/fotballfilosofi.aspx">Fotballfilosofi</a><br /><a href="/ikke-helt-sportslig.aspx">Ikke helt sportslig</a><br /></div>
		
                    <div class="box" id="contactbox"><div class="header">Frisk Asker</div><div class="body"><a href="/frisk-asker/laget.aspx">Laget</a><br /><a href="/frisk-asker/kontakt.aspx">Kontakt</a><br /><a href="/frisk-asker/dommerhjoernet.aspx">Dommerhjørnet</a><br /><a href="https://teams.s2s.net/11225/no/" target="_new">Treningstider</a></div><div class="footer"><!----></div></div>

<!--		     <iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/standard/Verdana/14/bold/230/1&rn=84" frameborder="0" scrolling="no" width="230" height="500"></iframe>
-->
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&banner=1&system=no_no/5212/1/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/standard/Verdana/14/bold/230/1&rn=94" frameborder="0" scrolling="no" width="230" height="214"></iframe>

		     <iframe src="http://www.s2s.net/todays_skill_external.php?ccc=no" scrolling="no" width="200" height="330" frameborder="0"></iframe>
<!--
		     <div id="login">&nbsp;
                   
                    <form id="loginform" action="#">&nbsp;
                      
                        <input id="username" type="text" value="brukernavn" />
                        <input id="password" type="text" value="passord" />
                        <img src="/img/login.gif" alt="login" />
                        <a href="#">glemt passord?</a>    
                        
                    </form>
                    
                    </div>
-->
		    <div id="search">

			Artikkelsøk:<br />
			<div id="xsltsearch" xmlns:ps="urn:percipientstudios-com:xslt"><form action="/soek.aspx?" method="post" class="xsltsearch_form"><input name="search" type="text" class="input" value=""></input> <input type="submit" value="Search" class="submit" /></form></div>
		    </div>

                </div>
                
                <div id="center">
		
                    
<div class="content">

	<h1>2014</h1>


	<div class="newsitem"><h2>God jul og godt nytt år!</h2><div class="meta">15.12.14 12:26 - Figo</div><p /><a class="readmore" href="/arkiv/2014/god-jul-og-godt-nytt-aar!.aspx">Les mer ...</a></div><div class="newsitem"><h2>Oldboys blues</h2><div class="meta">08.12.14 02:10 - Figo</div><p>Dette er historien om hvordan en kampdag for oldboys kan oppleves...</p><a class="readmore" href="/arkiv/2014/oldboys-blues.aspx">Les mer ...</a></div><div class="newsitem"><h2>Oppsummering av sesongen 2014</h2><div class="meta">20.11.14 01:37 - Figo</div><p>Vi eeer de aller beste ...</p><a class="readmore" href="/arkiv/2014/oppsummering-av-sesongen-2014.aspx">Les mer ...</a></div><div class="newsitem"><h2>Og hvordan har vi det i dag...</h2><div class="meta">06.11.14 06:28 - Keegan</div><p>Analyseavdelingen presenterer: Skadestatistikken 2014</p><a class="readmore" href="/arkiv/2014/og-hvordan-har-vi-det-i-dag.aspx">Les mer ...</a></div><div class="newsitem"><h2>Ti små dugnadsgutter ... (Fritt etter Agatha Christie)</h2><div class="meta">12.10.14 08:55 - Figo</div><p>En hyllest til fem staute karer ...</p><a class="readmore" href="/arkiv/2014/ti-smaa-dugnadsgutter--(fritt-etter-agatha-christie).aspx">Les mer ...</a></div><div class="newsitem"><h2>Seriemestere 2014!</h2><div class="meta">24.09.14 03:17 - Figo</div><p>En bragd for historiebøkene - Frisk Asker oldboys er årets seriemestere!</p><a class="readmore" href="/arkiv/2014/seriemestere-2014!.aspx">Les mer ...</a></div><div class="newsitem"><h2>Oppladning</h2><div class="meta">21.09.14 01:15 - Keegan</div><p>Medaljer gull verdt</p><a class="readmore" href="/arkiv/2014/oppladning.aspx">Les mer ...</a></div><div class="newsitem"><h2>A dream of an unmerited</h2><div class="meta">19.09.14 03:50 - Keegan</div><p>I have a dream</p><a class="readmore" href="/arkiv/2014/a-dream-of-an-unmerited.aspx">Les mer ...</a></div><div class="newsitem"><h2>Sannsynlighetsregning</h2><div class="meta">07.09.14 06:20 - Keegan</div><p>Analyseavdelingen kan ikke dy seg...</p><a class="readmore" href="/arkiv/2014/sannsynlighetsregning.aspx">Les mer ...</a></div><div class="newsitem"><h2>Aldersbestemt fotball - et spørsmål om idrettsglede</h2><div class="meta">04.09.14 12:47 - Keegan</div><p>En verdivurdering i Frisk Asker Oldboys</p><a class="readmore" href="/arkiv/2014/aldersbestemt-fotball---et-spoersmaal-om-idrettsglede.aspx">Les mer ...</a></div><div class="newsitem"><h2>Hvem er Frisk Asker Oldboys?</h2><div class="meta">24.08.14 01:57 - Keegan</div><p>FAO har blitt stilt spørsmålet som så mange andre har stilt seg før.</p><a class="readmore" href="/arkiv/2014/hvem-er-frisk-asker-oldboys.aspx">Les mer ...</a></div><div class="newsitem"><h2>Høstfesten 2014</h2><div class="meta">17.08.14 05:51 - Keegan</div><p>FAOs høstfest lørdag 25. oktober</p><a class="readmore" href="/arkiv/2014/hoestfesten-2014.aspx">Les mer ...</a></div><div class="newsitem"><h2>FAOs første gentleman</h2><div class="meta">17.08.14 02:16 - Keegan</div><p>Gentlemen in action</p><a class="readmore" href="/arkiv/2014/faos-foerste-gentleman.aspx">Les mer ...</a></div><div class="newsitem"><h2>Gjettekonkurranse</h2><div class="meta">15.08.14 01:50 - Keegan</div><p>Med lov skal landet bygges</p><a class="readmore" href="/arkiv/2014/gjettekonkurranse.aspx">Les mer ...</a></div><div class="newsitem"><h2>Models at work</h2><div class="meta">12.08.14 09:43 - Keegan</div><p>Frisk Asker Oldboys på modelloppdrag</p><a class="readmore" href="/arkiv/2014/models-at-work.aspx">Les mer ...</a></div><div class="newsitem"><h2>A man's got to do what a man's got to do</h2><div class="meta">07.07.14 10:20 - Keegan</div><p>Dommerutvikling</p><a class="readmore" href="/arkiv/2014/a-man's-got-to-do-what-a-man's-got-to-do.aspx">Les mer ...</a></div><div class="newsitem"><h2>Et fotballdraktsetts fortelling</h2><div class="meta">02.07.14 10:32 - Keegan</div><p>Historien bak FAOs siste radikale kamprutine.</p><a class="readmore" href="/arkiv/2014/et-fotballdraktsetts-fortelling.aspx">Les mer ...</a></div><div class="newsitem"><h2>Resultatliste FAO VM-tippekonkurranse</h2><div class="meta">28.06.14 04:38 - </div><p>Resultatliste FAO VM-tippekonkurranse 2014</p><a class="readmore" href="/arkiv/2014/resultatliste-fao-vm-tippekonkurranse.aspx">Les mer ...</a></div><div class="newsitem"><h2>Kampreferat M40 Frisk Asker vs Simensbråten </h2><div class="meta">13.06.14 09:12 - Figo</div><p>På en strålende sommerdag var det duket for den spennende forkampen til VM hvor Frisk Asker og Simenbråtens utvalgte skulle varme opp publikum. </p><a class="readmore" href="/arkiv/2014/kampreferat-m40-frisk-asker-vs-simensbraaten-.aspx">Les mer ...</a></div><div class="newsitem"><h2>We can't wait!!</h2><div class="meta">06.06.14 07:11 - Keegan</div><p>Mens vi venter...</p><a class="readmore" href="/arkiv/2014/we-can't-wait!!.aspx">Les mer ...</a></div><div class="newsitem"><h2>Spillet som forener verden</h2><div class="meta">27.05.14 02:12 - </div><p>Ventetiden er over! VM er her! Og selvsagt også FAOs tippekonkurranse!</p><a class="readmore" href="/arkiv/2014/spillet-som-forener-verden.aspx">Les mer ...</a></div><div class="newsitem"><h2>Referat fra treningsleir 2014</h2><div class="meta">20.05.14 04:31 - Figo</div><p>En treningsleir med 11 oldboys spillere er en utfordring som krever sin lagleder og i så måte var årets mønstring intet unntak. Men enten man tror det eller ei så er det en viss struktur og baktanke med det meste selv om det på overflaten virker rimelig kaotisk…</p><a class="readmore" href="/arkiv/2014/referat-fra-treningsleir-2014.aspx">Les mer ...</a></div><div class="newsitem"><h2>El Classico Week</h2><div class="meta">16.05.14 11:36 - Keegan</div><p>Real Madrid - Barcelona. Frisk Asker - Vålerenga. Tomaito tomato.</p><a class="readmore" href="/arkiv/2014/el-classico-week.aspx">Les mer ...</a></div><div class="newsitem"><h2>Sommerfest!</h2><div class="meta">09.05.14 11:40 - Keegan</div><p>Tid:   Fredag 20. juni.
Sted: Brøyn Paradise Club.</p><a class="readmore" href="/arkiv/2014/sommerfest!.aspx">Les mer ...</a></div><div class="newsitem"><h2>Nedtelling: en uke igjen til treningsleir</h2><div class="meta">18.04.14 12:46 - Keegan</div><p>Rekapitulering - til gruglede for nye deltakere.</p><a class="readmore" href="/arkiv/2014/nedtelling-en-uke-igjen-til-treningsleir.aspx">Les mer ...</a></div><div class="newsitem"><h2>M40: Treningskamp mot VUL</h2><div class="meta">03.04.14 01:02 - Keegan</div><p>Er det noen veteraner her!</p><a class="readmore" href="/arkiv/2014/m40-treningskamp-mot-vul.aspx">Les mer ...</a></div><div class="newsitem"><h2>Historisk lokalderby!</h2><div class="meta">02.04.14 11:00 - Keegan</div><p>Gjør klar til vennskapskamp!</p><a class="readmore" href="/arkiv/2014/historisk-lokalderby!.aspx">Les mer ...</a></div><div class="newsitem"><h2>Uttakstrening</h2><div class="meta">01.04.14 01:24 - Keegan</div><p>Obligatorisk uttakstrening</p><a class="readmore" href="/arkiv/2014/uttakstrening.aspx">Les mer ...</a></div><div class="newsitem"><h2>Tidenes oldboyslag</h2><div class="meta">23.03.14 10:23 - Keegan</div><p>Tabellen lyver aldri</p><a class="readmore" href="/arkiv/2014/tidenes-oldboyslag.aspx">Les mer ...</a></div><div class="newsitem"><h2>Terminlista 2014</h2><div class="meta">21.03.14 11:35 - Keegan</div><p>Svaret er onsdag 7. mai, borte mot Siggerud.</p><a class="readmore" href="/arkiv/2014/terminlista-2014.aspx">Les mer ...</a></div><div class="newsitem"><h2>Treningsleir 25-27 april 2014</h2><div class="meta">06.03.14 10:30 - Figo</div><p>Det blir som vanlig treningsleir i Trysil i forkant av seriestart og i år er datoen satt til 25-27.april.<br>

</p><a class="readmore" href="/arkiv/2014/treningsleir-25-27-april-2014.aspx">Les mer ...</a></div><div class="newsitem"><h2>Godt nytt år!</h2><div class="meta">03.01.14 10:27 - Figo</div><p /><a class="readmore" href="/arkiv/2014/godt-nytt-aar!.aspx">Les mer ...</a></div>

</div>




                </div>
                
		 <div id="right">

<font color="red" size="4">Lagbilde</font><br/>


<!--a href="http://oldboys.friskasker.no/media/116678/formkurve.png" border=0><img src="/media/116678/formkurve.png" width="280" alt="Formkurve" /></a-->
<!--iframe src="http://free.timeanddate.com/countdown/i5t3zil3/n187/cf113/cm0/cu4/ct0/cs0/ca0/cr0/ss0/cac000/cpc000/pc00e60b/tc000/fs100/szw320/szh135/tatFAO%20h%C3%B8stsesong%20starter%20om../tac000/tptTime%20since%20Event%20started%20in/tpc000/mac000/mpc000/iso2017-08-14T21:00:00" allowTransparency="true" frameborder="0" width="320" height="135"></iframe-->
	<!--iframe frameborder="0" width="512" height="600" scrolling="auto" allowtransparency="true" src="https://risengaj96.polldaddy.com/s/fao-plassering-pr-lag-2018?iframe=1"><a href="https://risengaj96.polldaddy.com/s/fao-plassering-pr-lag-2018">View Survey</a></iframe-->
<br/>
<!-- FORMkurve iframe width="508" height="371" seamless frameborder="0" scrolling="no" src="https://docs.google.com/spreadsheets/d/1wL8AGtLu517MG4vlWG2DIat7LmhdKaJdXz4nDVsxc74/pubchart?oid=1826601090&amp;format=interactive"></iframe-->

<!-- iphone
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/iphone/Verdana/14/bold/250/1&rn=7" frameborder="0" scrolling="no" width="250" height="500"></iframe>
-->
	<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/iphone/Verdana/14/bold/280/1&rn=83" frameborder="0" scrolling="no" width="280" height="500"></iframe>
<!--
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/21/ae82202846179cbfa34c266edf916f37&colours=FF8C00/CCCCCC/FFF/4/standard/Comic+Sans+Serif/16/bold/280/1&rn=22" frameborder="0" scrolling="no" width="280" height="500"></iframe>
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/members&bits=25/21/ae82202846179cbfa34c266edf916f37&colours=FF8C00/CCCCCC/FFF/4/standard/Comic+Sans+Serif/16/bold/280/1&rn=50" frameborder="0" scrolling="no" width="280" height="500"></iframe>
-->
<!-- iframe src="https://www.s2s.net/export_content.php?team_id=1101&system=no_no/1032/2/one/activities&bits=25/21/68565729bae64238443339aae6dcf62c&colours=FF6600/000099/FFF/0/iphone/Verdana/12/bold/280/0" frameborder="0" scrolling="no" width="280" height="500"></iframe -->

<br/><br/>
<a href="http://www.forstehjelpsgrossisten.no/products/is-pose-stor-14-x-21-cm-i-kartong-av-24-stk" border="0" target="_new"><img src="/umbraco/imagegen.ashx?image=/media/114144/forstehjelpsgrossistem.png&width=280"></a>
<br/>
<div style="text-align: left; width:280px;">Stolt sponsor av Frisk Asker Oldboys!</div>

                                        
                </div>

            </div>
            
        </div>
	<div id="bottomad"><!-- Bunnbanner -->
<!--
<script type="text/javascript">
var uri = 'http://impno.tradedoubler.com/imp?type(js)g(17626798)a(1588386)' + new String (Math.random()).substring (2, 11);
document.write('<sc'+'ript type="text/javascript" src="'+uri+'" charset=""></sc'+'ript>');
</script>
-->
<a href="http://www.google.com" target="_blank">.</a>
<a href="http://www.google.com/search?q=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://www.yahoo.com" target="_blank">.</a>
<a href="http://search.yahoo.com/search?p=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://search.aol.co.uk" target="_blank">.</a>
<a href="http://search.aol.co.uk/aol/search?query=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://uk.ask.com" target="_blank">.</a>
<a href="http://uk.ask.com/web?q=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://search.live.com" target="_blank">.</a>
<a href="http://search.live.com/results.aspx?q=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://search.lycos.co.uk" target="_blank">.</a>
<a href="http://search.lycos.co.uk/cgi-bin/pursuit?SITE=uk&query=frisk+asker+oldboys" target="_blank">.</a>

	</div>

<script type="text/javascript">
var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
</script>
<script type="text/javascript">
var pageTracker = _gat._getTracker("UA-2025203-1");
pageTracker._initData();
pageTracker._trackPageview();
</script></body>
</html>
