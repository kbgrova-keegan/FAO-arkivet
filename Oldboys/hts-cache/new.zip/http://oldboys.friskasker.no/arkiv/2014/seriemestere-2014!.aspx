
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">

	<head>

		<title>Seriemestere 2014!  - Frisk Asker Oldboys</title>
		
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
		<meta http-equiv="imagetoolbar" CONTENT="no">
		<meta name="keywords" content="seriemester, oldboys, kunstgress, idrettshøyskolen" />
		<meta name="description" content="En bragd for historiebøkene - Frisk Asker oldboys er årets seriemestere!" />
		
		<meta name="title" content="Seriemestere 2014! - Frisk Asker Oldboys" />
		<meta name="URL" content="http://oldboys.friskasker.no" />
		<meta name="language" content="Norsk" />
		<meta name="author" content="Terje Dahl" />
		<meta name="copyright" content="Frisk Asker Oldboys" />
		<meta name="reply-to" content="terjda@online.no" />
		<meta name="verify-v1" content="BxVdMcZ0uoa2KVw8RB+FBg3715LgSDXNG+RYp0gHpAI=" />

		<link type="text/css" href="/css/client.css" rel="stylesheet" />
		<link type="text/css" href="/css/default.css" rel="stylesheet" />
		<link type="text/css" href="/css/weatherCSS.css" rel="stylesheet" />

		<script type="text/javascript" src="/js/jquery.js"></script>
		<script type="text/javascript" src="/js/ufo.js"></script>
		<script type="text/javascript" src="/js/friskasker.js"></script>
		<!--script type='text/javascript' src='http://www.rdmtech.no/js/jquery.js?ver=1.2.6'></script-->
		<!--script type='text/javascript' src='http://www.rdmtech.no/js/jquery.cross-slide.js?ver=2.6'></script-->

		<!--[if IE 6]>
		<link type="text/css" href="/css/ie60.css" rel="stylesheet" />			
		<![endif]-->
		<!-- TradeDoubler site verification 1588386 --> 

	<script type='text/javascript'>
		jQuery(function($) {$(document).ready(function() {
			$('#container2').crossSlide(
				{sleep: 2, fade: 1},
				[{src: 'http://oldboys.friskasker.no/media/26561/bg-fao1.jpg'},{src: 'http://oldboys.friskasker.no/media/26566/bg-fao2.jpg'},{src: 'http://oldboys.friskasker.no/media/26571/bg-fao3.jpg'},{src: 'http://oldboys.friskasker.no/media/26576/bg-fao4.jpg'}]
			);
		});});
	</script>
	
<script type="text/javascript">
var _polldaddy = [] || _polldaddy;

_polldaddy.push( {
    type: 'slider',
    title: 'FAO-spillemodellen, skjønner du den?',
    body: 'Ta testen og bidra til å øke sjansen for sportslig utvikling av FAO!',
    button: 'Get Started &raquo;',
    domain: 'risengaj96.polldaddy.com/s/',
    id: 'fao-spillemodellen',
    placeholder: 'pd1438692132734'
} );

jQuery(function(d,c,j){$if(!document.getElementById(j)){var pd=d.createElement(c),s;pd.id=j;pd.src=('https:'==document.location.protocol)?'https://polldaddy.com/survey.js':'http://i0.poll.fm/survey.js';s=document.getElementsByTagName(c)[0];s.parentNode.insertBefore(pd,s);}}(document,'script','pd-embed'));
</script>

	
	</head>
	
	<body>
      
        <div id="container">&nbsp;
        
            <div id="header">&nbsp;
            
                <div id="logo"><a href="/"><img src="/media/26597/logos.gif" alt="Logo" /></a></div>
                <div id="rss"><a href="/data/rss/nyheter.xml">Motta RSS strøm</a></div>
		<!--div id="sitemap"><a href="/sitemap.aspx">Sitemap</a></div-->
		<div id="topknapp">
		<iframe width="280" height="160" src="https://www.youtube.com/embed/15KEqzCTrwI" frameborder="0" allowfullscreen></iframe>
		</div>
		
                

            </div>
            
            <div id="body">&nbsp;
            
                <div id="left">&nbsp;

                    <div id="date">mandag 15. april</div>
                	
                    <div class="leftnav"><a href="/">Hjem</a><br /><a href="/arkiv.aspx">Arkiv</a><br /><a href="/tabeller--terminlister.aspx">Tabeller &amp; terminlister</a><br /><a href="/kampreferat.aspx">Kampreferat</a><br /><a href="/fotballfilosofi.aspx">Fotballfilosofi</a><br /><a href="/ikke-helt-sportslig.aspx">Ikke helt sportslig</a><br /></div>
		
                    <div class="box" id="contactbox"><div class="header">Frisk Asker</div><div class="body"><a href="/frisk-asker/laget.aspx">Laget</a><br /><a href="/frisk-asker/kontakt.aspx">Kontakt</a><br /><a href="/frisk-asker/dommerhjoernet.aspx">Dommerhjørnet</a><br /><a href="https://teams.s2s.net/11225/no/" target="_new">Treningstider</a></div><div class="footer"><!----></div></div>

<!--		     <iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/standard/Verdana/14/bold/230/1&rn=84" frameborder="0" scrolling="no" width="230" height="500"></iframe>
-->
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&banner=1&system=no_no/5212/1/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/standard/Verdana/14/bold/230/1&rn=94" frameborder="0" scrolling="no" width="230" height="214"></iframe>

		     <iframe src="http://www.s2s.net/todays_skill_external.php?ccc=no" scrolling="no" width="200" height="330" frameborder="0"></iframe>
<!--
		     <div id="login">&nbsp;
                   
                    <form id="loginform" action="#">&nbsp;
                      
                        <input id="username" type="text" value="brukernavn" />
                        <input id="password" type="text" value="passord" />
                        <img src="/img/login.gif" alt="login" />
                        <a href="#">glemt passord?</a>    
                        
                    </form>
                    
                    </div>
-->
		    <div id="search">

			Artikkelsøk:<br />
			<div id="xsltsearch" xmlns:ps="urn:percipientstudios-com:xslt"><form action="/soek.aspx?" method="post" class="xsltsearch_form"><input name="search" type="text" class="input" value=""></input> <input type="submit" value="Search" class="submit" /></form></div>
		    </div>

                </div>
                
                <div id="center">
		
                    
<div class="content">

	<h1>Seriemestere 2014!</h1><div class="meta">24.09.14 15:17 - Figo</div><div class="abstract"><img src="/umbraco/imagegen.ashx?image=/media/93586/3462.jpg&amp;width=500" alt="" align="left" />En bragd for historiebøkene - Frisk Asker oldboys er årets seriemestere!</div>
<div id="_mcePaste"
style="position: absolute; left: -10000px; top: 0px; width: 1px; height: 1px; overflow: hidden;">
</div>

<div id="_mcePaste"
style="position: absolute; left: -10000px; top: 0px; width: 1px; height: 1px; overflow: hidden;">
</div>

<div id="_mcePaste"
style="position: absolute; left: -10000px; top: 0px; width: 1px; height: 1px; overflow: hidden;">
Spenningen som hadde bygget seg opp de siste ukene skulle endelig
forløses og hvor passet det bedre å avgjøre hvilket lag som er best
i 1.divisjon for oldboys enn på idrettshøyskolens kunstgressbane
rett ved Olympiatoppens lokaler.</div>

<div id="_mcePaste"
style="position: absolute; left: -10000px; top: 0px; width: 1px; height: 1px; overflow: hidden;">
</div>

<div id="_mcePaste"
style="position: absolute; left: -10000px; top: 0px; width: 1px; height: 1px; overflow: hidden;">
Vår argeste rival og eneste reelle utfordrer hadde allerede vunnet
sin siste kamp så alt press var på skuldrene til våre 12 utvalgte
menn. Vi måtte ha poeng men det holdt med ett eneste...</div>

<div id="_mcePaste"
style="position: absolute; left: -10000px; top: 0px; width: 1px; height: 1px; overflow: hidden;">
</div>

<div id="_mcePaste"
style="position: absolute; left: -10000px; top: 0px; width: 1px; height: 1px; overflow: hidden;">
Happi tok ansvar, lot det "briste" og bære (tok du den?) og stilte
opp mellom stengene. Anders, Megler1 og Bønna rullerte i forsvaret
mens midtbanen bestod av følgende parsammensetting; Turbo/Moa
-Snurre/Mads - Klausen/Waleed. På topp vekslet Ardilles og Alexey
på å gjøre livet surt for lokomotivførerne fra Oslo.</div>

<div id="_mcePaste"
style="position: absolute; left: -10000px; top: 0px; width: 1px; height: 1px; overflow: hidden;">
Figo hadde for kvelden tatt på seg oppgaven med å holde resten av
verden oppdatert der de satt med neglebånd som kreppapir,</div>

<div id="_mcePaste"
style="position: absolute; left: -10000px; top: 0px; width: 1px; height: 1px; overflow: hidden;">
</div>

<div id="_mcePaste"
style="position: absolute; left: -10000px; top: 0px; width: 1px; height: 1px; overflow: hidden;">
Kampen begynte som en jevn batalje før FA gradvis tok over mer og
mer av banespillet og begynte å skape sjanser på løpende bånd. Det
føltes som kun et tidsspørsmål før vi skulle stikke hull på byllen
og alle de åtte fremmøtte tilskuerne tenkte at dette trykket kunne
ikke Lokomotivet stå i mot lenge.</div>

<div id="_mcePaste"
style="position: absolute; left: -10000px; top: 0px; width: 1px; height: 1px; overflow: hidden;">
</div>

<div id="_mcePaste"
style="position: absolute; left: -10000px; top: 0px; width: 1px; height: 1px; overflow: hidden;">
Den ene avslutningen etter den andre gikk i keeper, stenger og
utenfor så at det stod 0-0 til pause var overraskende.
Sjansestatistikken viste 8-1 til Frisk Asker og flere av disse var
så store at selv bestemoren til Davy Watne hadde satt de.</div>

<div id="_mcePaste"
style="position: absolute; left: -10000px; top: 0px; width: 1px; height: 1px; overflow: hidden;">
Stemningen i pausen var elektrisk og selv om vi var frustrerte var
vi likefullt sikre på at dette måtte gå veien.</div>

<div id="_mcePaste"
style="position: absolute; left: -10000px; top: 0px; width: 1px; height: 1px; overflow: hidden;">
</div>

<div id="_mcePaste"
style="position: absolute; left: -10000px; top: 0px; width: 1px; height: 1px; overflow: hidden;">
Andre omgang startet som den første sluttet, med nye store
muligheter til FA's hærskare og uttrykket "skyte keeper'n god" kom
til sin rett da samtlige dro til alt man hadde og forsøkte å skyte
motstanderens sisteskanse inn i nettet.</div>

<div id="_mcePaste"
style="position: absolute; left: -10000px; top: 0px; width: 1px; height: 1px; overflow: hidden;">
Hvor typisk er det da ikke at det glipper litt i forsvaret og at
motstanderens spiss får til den helvolley'en han har drømt om siden
lilleputtlaget ... Nåttsåverrihæppiænnimår var rett og slett
sjanseløs der kula føyk inn ved stolpen fra tre meters hold, 0-1
var et faktum.</div>

<div id="_mcePaste"
style="position: absolute; left: -10000px; top: 0px; width: 1px; height: 1px; overflow: hidden;">
</div>

<div id="_mcePaste"
style="position: absolute; left: -10000px; top: 0px; width: 1px; height: 1px; overflow: hidden;">
Lignende potteran hadde ikke skjedd i manns minne ("manns minne" er
for en gjennomsnittlig oldboys ca. 21 dager - red. Anm.) og alle
fryktet det verste, at pokalen skulle glippe ut av hendene på
overtid.</div>

<div id="_mcePaste"
style="position: absolute; left: -10000px; top: 0px; width: 1px; height: 1px; overflow: hidden;">
Det ble stille rundt kjøkkenbordene i mange Askerhjem og ryktet
forteller at selv hardbarkede elgjegere satt med klump i halsen og
ventet i spenning på slutten.</div>

<div id="_mcePaste"
style="position: absolute; left: -10000px; top: 0px; width: 1px; height: 1px; overflow: hidden;">
</div>

<div id="_mcePaste"
style="position: absolute; left: -10000px; top: 0px; width: 1px; height: 1px; overflow: hidden;">
Vi fortsatte der vi slapp og selv om desperasjonen steg og vi
forsøkte den velkjente taktikken "alle mann i angrep" ville det seg
ikke. Målene på NIH's kunstgressbane ble bulkete og skjeve da
Klausen og Moa traff de hardt for femte og sjette gangen, men selv
ikke lagledelsens taktikk med å lyve på tiden og sende Happi i
angrep førte frem.</div>

<div id="_mcePaste"
style="position: absolute; left: -10000px; top: 0px; width: 1px; height: 1px; overflow: hidden;">
I riktig bergensk tradisjon skrev Alex seg inn i historiebøkene på
linje med Ole Bull og Kniksen Jensen da han smalt inn
utligningsmålet to minutter før slutt noe som utløste voldsomme
jubelscener som statens filmkontroll nok ville gitt 18-års grense
om det hadde blitt filmet.</div>

<div id="_mcePaste"
style="position: absolute; left: -10000px; top: 0px; width: 1px; height: 1px; overflow: hidden;">
</div>

<div id="_mcePaste"
style="position: absolute; left: -10000px; top: 0px; width: 1px; height: 1px; overflow: hidden;">
Når ballen omsider rullet igjen var selvtilliten på topp og
plutselig satt pasninger og finter som de skulle. Den største
spenningen nå var om batteriet på mobilen skulle holde helt til
dommeren blåste av kampen ... Minuttene snegler av gårde men nå var
det vi som hadde all verdens tid og konduktørene som løp og hentet
baller utenfor banen.</div>

<div id="_mcePaste"
style="position: absolute; left: -10000px; top: 0px; width: 1px; height: 1px; overflow: hidden;">
</div>

<div id="_mcePaste"
style="position: absolute; left: -10000px; top: 0px; width: 1px; height: 1px; overflow: hidden;">
Kampen blåses av, alle jubler, champagnen sprettes og mobilen går i
svart - flomlys har vel aldri vært vakrere, kunstgress aldri
grønnere og oransje menn i sin beste alder har nok aldri vist mer
glede enn denne kvelden ...</div>

<div id="_mcePaste"
style="position: absolute; left: -10000px; top: 0px; width: 1px; height: 1px; overflow: hidden;">
</div>

<div id="_mcePaste"
style="position: absolute; left: -10000px; top: 0px; width: 1px; height: 1px; overflow: hidden;">
</div>

<p>Spenningen som hadde bygget seg opp de siste ukene skulle
endelig forløses og hvor passet det bedre å avgjøre hvilket lag som
er best i 1.divisjon for oldboys enn på idrettshøyskolens
kunstgressbane rett ved Olympiatoppens lokaler.</p>

<p>Vår argeste rival og eneste reelle utfordrer hadde allerede
vunnet sin siste kamp så alt press var på skuldrene til våre 12
utvalgte menn. Vi måtte ha poeng men det holdt med ett
eneste...</p>

<p>Happi tok ansvar, lot det "briste" og bære (tok du den?) og
stilte opp mellom stengene. Anders, Megler1 og Bønna rullerte i
forsvaret mens midtbanen bestod av følgende parsammensetting;
Turbo/Moa -Snurre/Mads - Klausen/Waleed. På topp vekslet Ardilles
og Alexey på å gjøre livet surt for lokomotivførerne fra Oslo.</p>

<p>Figo hadde for kvelden tatt på seg oppgaven med å holde resten
av verden oppdatert der de satt med neglebånd som kreppapir,</p>

<p>Kampen begynte som en jevn batalje før FA gradvis tok over mer
og mer av banespillet og begynte å skape sjanser på løpende bånd.
Det føltes som kun et tidsspørsmål før vi skulle stikke hull på
byllen og alle de åtte fremmøtte tilskuerne tenkte at dette trykket
kunne ikke Lokomotivet stå i mot lenge.</p>

<p>Den ene avslutningen etter den andre gikk i keeper, stenger og
utenfor så at det stod 0-0 til pause var overraskende.
Sjansestatistikken viste 8-1 til Frisk Asker og flere av disse var
så store at selv bestemoren til Davy Watne hadde satt de.</p>

<p>Stemningen i pausen var elektrisk og selv om vi var frustrerte
var vi likefullt sikre på at dette måtte gå veien.</p>

<p><img src="/media/93730/2014-09-25_093330_499x345.jpg"  width="499"  height="345" alt="2014-09-25_093330"/></p>

<p>Andre omgang startet som den første sluttet, med nye store
muligheter til FA's hærskare og uttrykket "skyte keeper'n god" kom
til sin rett da samtlige dro til alt man hadde og forsøkte å skyte
motstanderens sisteskanse inn i nettet.</p>

<p>Hvor typisk er det da ikke at det glipper litt i forsvaret og at
motstanderens spiss får til den helvolley'en han har drømt om siden
lilleputtlaget ... Nåttsåverrihæppiænnimår var rett og slett
sjanseløs der kula føyk inn ved stolpen fra tre meters hold, 0-1
var et faktum.</p>

<p>&nbsp;</p>

<p><em>Hjemmesittergruppen tar mer og mer</em> <em>over
kommenteringen:</em></p>

<p><img src="/media/93776/4_500x294.jpg"  width="500"  height="294" alt="Kommentarer"/></p>

<p>Lignende potteran hadde ikke skjedd i manns minne ("manns minne"
er for en gjennomsnittlig oldboys ca. 21 dager - red. Anm.) og alle
fryktet det verste, at pokalen skulle glippe ut av hendene på
overtid.</p>

<p>Det ble stille rundt kjøkkenbordene i mange Askerhjem og ryktet
forteller at selv hardbarkede elgjegere satt med klump i halsen og
ventet i spenning på slutten.</p>

<p>Vi fortsatte der vi slapp og selv om desperasjonen steg og vi
forsøkte den velkjente taktikken "alle mann i angrep" ville det seg
ikke. Målene på NIH's kunstgressbane ble bulkete og skjeve da
Klausen og Moa traff de hardt for femte og sjette gangen, men selv
ikke lagledelsens taktikk med å lyve på tiden og sende Happi i
angrep førte frem.</p>

<p><em>Nok en 100% sjanse som bestemora til Davy hadde
putta:</em></p>

<p><img src="/media/93846/2014-09-25_093234_500x294.jpg"  width="500"  height="294" alt="100%"/></p>

<p>I riktig bergensk tradisjon skrev Alex seg inn i historiebøkene
på linje med Ole Bull og Kniksen Jensen da han smalt inn
utligningsmålet to minutter før slutt noe som utløste voldsomme
jubelscener som statens filmkontroll nok ville gitt 18-års grense
om det hadde blitt filmet.</p>

<p>Når ballen omsider rullet igjen var selvtilliten på topp og
plutselig satt pasninger og finter som de skulle. Den største
spenningen nå var om batteriet på mobilen skulle holde helt til
dommeren blåste av kampen ... Minuttene snegler av gårde men nå var
det vi som hadde all verdens tid og konduktørene som løp og hentet
baller utenfor banen.</p>

<p><img src="/media/93841/5_500x244.jpg"  width="500"  height="244" alt="slutt"/></p>

<p>&nbsp;</p>

<p><strong>Kampen blåses av, alle jubler, champagnen sprettes og
mobilen går i svart - flomlys har vel aldri vært vakrere,
kunstgress aldri grønnere og oransje menn i sin beste alder har nok
aldri vist mer glede enn denne kvelden ...</strong></p>

<p><strong><br />
</strong></p>

<p><img src="/media/93897/seriemester 2014_499x208.jpg"  width="499"  height="208" alt="Seriemester 2014"/></p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>&nbsp;</p>



<div class="addthis_toolbox addthis_default_style">
<a href="http://www.addthis.com/bookmark.php?v=250&amp;username=xa-4be09cd0025b8da5" class="addthis_button_compact">Share</a>
<span class="addthis_separator">|</span>
<a class="addthis_button_facebook"></a>
<a class="addthis_button_myspace"></a>
<a class="addthis_button_google"></a>
<a class="addthis_button_twitter"></a>
</div>
<script type="text/javascript" src="http://s7.addthis.com/js/250/addthis_widget.js#username=xa-4be09cd0025b8da5"></script>
<!-- AddThis Button END -->

<hr>
<h2>Kommentarer:</h2>
	<div class="newsitem"><i><b>24.09.14 22:53 - <a href="mailto:">Bønna</a></b></i><p>Jesssssszzzz!</p></div><div class="newsitem"><i><b>24.09.14 23:18 - <a href="mailto:">Turbo</a></b></i><p>mer nervepirrende enn dette burde kun være lovlig på blå resept!</p></div><div class="newsitem"><i><b>25.09.14 7:05 - <a href="mailto:">Keegan</a></b></i><p>Det vakreste bildet jeg noen sinne har sett!</p></div><div class="newsitem"><i><b>25.09.14 8:00 - <a href="mailto:">Einar</a></b></i><p>Fantastisk, bare å gratulere!</p></div><div class="newsitem"><i><b>25.09.14 8:40 - <a href="mailto:">Turbo</a></b></i><p>Fantastisk referat. Akkurat slik var det! :)</p></div><div class="newsitem"><i><b>25.09.14 9:11 - <a href="mailto:">StianK</a></b></i><p>Glimrende lesning...</p></div><div class="newsitem"><i><b>25.09.14 9:23 - <a href="mailto:">Alfie</a></b></i><p>Gratulerer gutter. Nok en anledning å bøye seg i hatten. Blir denne datoen en offentlig flaggdag i noen eleverte hjem i Askerregionen?</p></div><div class="newsitem"><i><b>25.09.14 11:53 - <a href="mailto:">Ardiles</a></b></i><p>Vi har verdens beste bergenser!</p></div><div class="newsitem"><i><b>25.09.14 15:23 - <a href="mailto:">Davy Wathne</a></b></i><p>... og min bestemor </p></div><div class="newsitem"><i><b>26.10.14 16:31 - <a href="mailto:">Lokfører</a></b></i><p>Lokets lagleder Audun sitt sporty fest-telegram til banketten:<br/>
<br/>
Kjære Asker-friskuser,
gratulerer med seriemesterskapet. Det var fullt fortjent. Dere har et godt lag, en diabolsk innstilling og en sammenleggbar, transportabel innbytterbenk. Sånt lukter det gull av.<br/><br/>

Vi i Lokomotiv Oslo var faktisk nær å spolere hele festen for dere, da vi ledet 1-0 til et par minutter gjensto. Jeg må innrømme, at siden vi ikke hadde innbyttere i denne kampen, var jeg så sliten på slutten at jeg nesten ikke husker. Jeg erindrer at vi ledet mot spillets gang, etter en fantastisk scoring fra vår mann. Så ble presset for stort. Det føltes som jeg var i ringen med Mike Tyson, jeg følte meg sjanseløs. Vi rotet bort ballen idet vi var i ferd med å kontre. Dere, Frisk Asker, gikk alle mann i angrep, og kjempet ballen i mål. Ikke noe å si på det. Jeg mener han som scoret var en lang, skallet bergenser. Sånt svir. 
<br/><br/>
Det suste en colaflaske ut på banen, det sprutet sukkervann overalt, folk jublet og koste og klemte som gale. Det var galskap. Jeg tror til og med den kjære benken deres veltet. Håper det går bra med den, den kan ikke ha vært billig.<br/><br/>

Men, dere skal ha det; dere var best. Gratulerer igjen. Kos dere i kveld, det er dere vel unt. Virkelig.<br/><br/>

Husk bare at dere er et år eldre neste sesong. Da kommer Lokomotivet og kjører over dere. Det lover jeg.<br/><br/>

Alt godt, gleder oss til neste år.<br/><br/>

Fotballhilsen,<br/>
Audun Roe Grimstad, lagleder Lokomotiv Oslo.
</p></div><div class="newsitem"><i><b>27.10.14 19:06 - <a href="mailto:">ThomaS</a></b></i><p>Nå unner jeg Lokomotiv medalje til neste år!</p></div>
<!--
<p>
<b>Kommentering er midlertidig steng pga SPAM!</b>
</p>
-->
<form method="post" action="seriemestere-2014!.aspx" id="aspnetForm">
<div>
<input type="hidden" name="__EVENTTARGET" id="__EVENTTARGET" value="" />
<input type="hidden" name="__EVENTARGUMENT" id="__EVENTARGUMENT" value="" />
<input type="hidden" name="__VIEWSTATE" id="__VIEWSTATE" value="/wEPDwUENTM4MQ9kFgJmD2QWAmYPZBYCZg9kFgJmD2QWAgIPD2QWAgIFD2QWAgIBD2QWAmYPZBYCAgIPZBYCAgEPFgIeBFRleHQFF0RpbiBrb21tZW50YXIgZXIgcG9zdGV0ZGTP3+kahhm7HkFLDJ1eDASlO9mxvA==" />
</div>

<script type="text/javascript">
//<![CDATA[
var theForm = document.forms['aspnetForm'];
if (!theForm) {
    theForm = document.aspnetForm;
}
function __doPostBack(eventTarget, eventArgument) {
    if (!theForm.onsubmit || (theForm.onsubmit() != false)) {
        theForm.__EVENTTARGET.value = eventTarget;
        theForm.__EVENTARGUMENT.value = eventArgument;
        theForm.submit();
    }
}
//]]>
</script>


<script src="/WebResource.axd?d=RhJRe7vAQjxLvd0VTiPlJ3ItrtWKNnlC5ndUOdQ1oQE84Jw0mmyu8t9423FKr6Sh25O1JfgygCRLDXncXNuX2rijfWY1&amp;t=635737087099672665" type="text/javascript"></script>


<script type="text/javascript">
//<![CDATA[
function insertLink(element) {var theLink = prompt('Enter URL for link here:','http://');insertTag(element, 'a', ' href="' + theLink + '"')}
            function insertTag(element, tag, param) {
            start = '<' + tag + param + '>';
            eind = '</' + tag + '>';
             /* element = document.getElementById(element); */
              if (document.selection) {
                element.focus();
                sel = document.selection.createRange();
                sel.text = start + sel.text + eind;
              } else if (element.selectionStart || element.selectionStart == '0') {
                element.focus();
                var startPos = element.selectionStart;
                var endPos = element.selectionEnd;
                element.value = element.value.substring(0, startPos) + start + element.value.substring(startPos, endPos) + eind + element.value.substring(endPos, element.value.length);
              } else {
                element.value += start + eind;
              }
            }
            //]]>
</script>

<h2>Post en kommentar:</h2>
<div id="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_PanelInput">
	
	<div id="umbracoAutoForm">
	
  <fieldset>
			<p><label for="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_navn">Navn:</label><input name="ctl00$ctl00$ctl00$ContentPlaceHolderDefault$MainContentPlaceHolder$AutoForm_7$navn" type="text" id="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_navn" class="umbEditorTextField" /></p><p><label for="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_epost">Epost:</label><input name="ctl00$ctl00$ctl00$ContentPlaceHolderDefault$MainContentPlaceHolder$AutoForm_7$epost" type="text" id="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_epost" class="umbEditorTextField" /></p><p><label for="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_kommentar">Kommentar:</label><table border="0" cellspacing="0" cellpadding="0"><tr><td>
	<p align="right" style="margin: 0px; padding:0px"><a href="javascript:insertLink(document.getElementById('ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_kommentar'))"><img src="/umbraco_client/simpleEditor/images/link.gif" border="0" align="right" /></a><a href="javascript:insertTag(document.getElementById('ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_kommentar'), 'em', '')"><img src="/umbraco_client/simpleEditor/images/italic.gif" border="0" style="margin-left: 3px; margin-right: 3px;" align="right" /></a> <a href="javascript:insertTag(document.getElementById('ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_kommentar'), 'strong', '')"><img src="/umbraco_client/simpleEditor/images/bold.gif" border="0" align="right" /></a><br/></p>
	<textarea name="ctl00$ctl00$ctl00$ContentPlaceHolderDefault$MainContentPlaceHolder$AutoForm_7$kommentar" rows="8" cols="20" id="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_kommentar" class="umbEditorTextField"></textarea></td></tr></table>
	</p><p><label for="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_captcha">Captcha:</label><input name="ctl00$ctl00$ctl00$ContentPlaceHolderDefault$MainContentPlaceHolder$AutoForm_7$captcha" type="text" id="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_captcha" class="umbEditorNumberField" /><br/><span class="umbracoAutoFormRowDescription">Hva er elleve pluss åtte?<br/></span></p>
		<p><input type="submit" name="ctl00$ctl00$ctl00$ContentPlaceHolderDefault$MainContentPlaceHolder$AutoForm_7$Button1" value="Post kommentar" onclick="javascript:WebForm_DoPostBackWithOptions(new WebForm_PostBackOptions(&quot;ctl00$ctl00$ctl00$ContentPlaceHolderDefault$MainContentPlaceHolder$AutoForm_7$Button1&quot;, &quot;&quot;, true, &quot;&quot;, &quot;&quot;, false, false))" id="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_Button1" class="umbracoAutoFormButton" /></p>
	</fieldset>		
	</div>

</div>

		

<div>

	<input type="hidden" name="__VIEWSTATEGENERATOR" id="__VIEWSTATEGENERATOR" value="CA0B0334" />
</div></form>

<a class="readmore" href="/arkiv/2021/frisk-asker---covid-19-19-.aspx">Frisk Asker - Covid 19-19 </a> - 17.03.2021 8:41<br /><a class="readmore" href="/arkiv/2016/faos-sommerkrim.aspx">FAOs sommerkrim</a> - 29.04.2020 12:32<br /><a class="readmore" href="/arkiv/2019/fao-med-kupp-paa-overgangsmarkedet!.aspx">FAO med kupp på overgangsmarkedet!</a> - 30.07.2019 19:24<br /><a class="readmore" href="/arkiv/2019/dag-ansatt-som-fast-lagleder-paa-frisk-asker-m33.aspx">Dag ansatt som fast lagleder på Frisk Asker M33</a> - 29.07.2019 12:28<br /><a class="readmore" href="/arkiv/2019/askermesterskapet-i-oldboysfotball.aspx">Askermesterskapet i oldboysfotball</a> - 07.05.2019 16:49<br /><a class="readmore" href="/arkiv/2019/frisk-asker-oldgirls!.aspx">Frisk Asker OldGIRLS!</a> - 05.04.2019 14:14<br /><a class="readmore" href="/arkiv/2019/know-your-enemy.aspx">Know your enemy</a> - 01.02.2019 16:46<br /><a class="readmore" href="/arkiv/2018/pass-paa-liten-og-paa-stor.aspx">Pass på liten og på stor</a> - 21.09.2018 15:21<br /><a class="readmore" href="/arkiv/2018/nedrykk!.aspx">Nedrykk!</a> - 14.09.2018 14:40<br /><a class="readmore" href="/arkiv/2018/lukten-av-gull!.aspx">Lukten av gull!</a> - 07.09.2018 22:27<br />
<br/><br/>
<!--
<table id="forumposts" cellspacing="0"><tr><th colspan="2">Siste publiserte fra Sekreteriatet</th></tr><tr><td><b><a class="readmore" href="/sekreteriatet/kamprutine.aspx">Kamprutine</a> - </b>12.06.14 01:36</td></tr><tr><td><b><a class="readmore" href="/sekreteriatet/kamp-mot-bygdoe-monolitten---hvem-stiller.aspx">Kamp mot Bygdø Monolitten - hvem stiller?</a> - </b>12.09.12 09:23</td></tr><tr><td><b><a class="readmore" href="/sekreteriatet/kamp-mot-huk---hvem-stiller-(1).aspx">Kamp mot Huk - hvem stiller? (1)</a> - </b>04.09.12 10:04</td></tr><tr><td><b><a class="readmore" href="/sekreteriatet/kamp-mot-lokomotiv-oslo-29-aug---hvem-stiller.aspx">Kamp mot Lokomotiv Oslo 29. aug - hvem stiller?</a> - </b>28.08.12 02:56</td></tr><tr><td><b><a class="readmore" href="/sekreteriatet/kamp-mot-aarvoll-ons-15-aug---hvem-stiller.aspx">Kamp mot Årvoll ons 15. aug - Hvem stiller?</a> - </b>13.08.12 12:50</td></tr><tr><td class="footer" colspan="2"> </td></tr></table>
-->
</div>



                </div>
                
		 <div id="right">

<font color="red" size="4">Lagbilde</font><br/>


<!--a href="http://oldboys.friskasker.no/media/116678/formkurve.png" border=0><img src="/media/116678/formkurve.png" width="280" alt="Formkurve" /></a-->
<!--iframe src="http://free.timeanddate.com/countdown/i5t3zil3/n187/cf113/cm0/cu4/ct0/cs0/ca0/cr0/ss0/cac000/cpc000/pc00e60b/tc000/fs100/szw320/szh135/tatFAO%20h%C3%B8stsesong%20starter%20om../tac000/tptTime%20since%20Event%20started%20in/tpc000/mac000/mpc000/iso2017-08-14T21:00:00" allowTransparency="true" frameborder="0" width="320" height="135"></iframe-->
	<!--iframe frameborder="0" width="512" height="600" scrolling="auto" allowtransparency="true" src="https://risengaj96.polldaddy.com/s/fao-plassering-pr-lag-2018?iframe=1"><a href="https://risengaj96.polldaddy.com/s/fao-plassering-pr-lag-2018">View Survey</a></iframe-->
<br/>
<!-- FORMkurve iframe width="508" height="371" seamless frameborder="0" scrolling="no" src="https://docs.google.com/spreadsheets/d/1wL8AGtLu517MG4vlWG2DIat7LmhdKaJdXz4nDVsxc74/pubchart?oid=1826601090&amp;format=interactive"></iframe-->

<!-- iphone
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/iphone/Verdana/14/bold/250/1&rn=7" frameborder="0" scrolling="no" width="250" height="500"></iframe>
-->
	<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/iphone/Verdana/14/bold/280/1&rn=83" frameborder="0" scrolling="no" width="280" height="500"></iframe>
<!--
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/21/ae82202846179cbfa34c266edf916f37&colours=FF8C00/CCCCCC/FFF/4/standard/Comic+Sans+Serif/16/bold/280/1&rn=22" frameborder="0" scrolling="no" width="280" height="500"></iframe>
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/members&bits=25/21/ae82202846179cbfa34c266edf916f37&colours=FF8C00/CCCCCC/FFF/4/standard/Comic+Sans+Serif/16/bold/280/1&rn=50" frameborder="0" scrolling="no" width="280" height="500"></iframe>
-->
<!-- iframe src="https://www.s2s.net/export_content.php?team_id=1101&system=no_no/1032/2/one/activities&bits=25/21/68565729bae64238443339aae6dcf62c&colours=FF6600/000099/FFF/0/iphone/Verdana/12/bold/280/0" frameborder="0" scrolling="no" width="280" height="500"></iframe -->

<br/><br/>
<a href="http://www.forstehjelpsgrossisten.no/products/is-pose-stor-14-x-21-cm-i-kartong-av-24-stk" border="0" target="_new"><img src="/umbraco/imagegen.ashx?image=/media/114144/forstehjelpsgrossistem.png&width=280"></a>
<br/>
<div style="text-align: left; width:280px;">Stolt sponsor av Frisk Asker Oldboys!</div>

                                        
                </div>

            </div>
            
        </div>
	<div id="bottomad"><!-- Bunnbanner -->
<!--
<script type="text/javascript">
var uri = 'http://impno.tradedoubler.com/imp?type(js)g(17626798)a(1588386)' + new String (Math.random()).substring (2, 11);
document.write('<sc'+'ript type="text/javascript" src="'+uri+'" charset=""></sc'+'ript>');
</script>
-->
<a href="http://www.google.com" target="_blank">.</a>
<a href="http://www.google.com/search?q=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://www.yahoo.com" target="_blank">.</a>
<a href="http://search.yahoo.com/search?p=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://search.aol.co.uk" target="_blank">.</a>
<a href="http://search.aol.co.uk/aol/search?query=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://uk.ask.com" target="_blank">.</a>
<a href="http://uk.ask.com/web?q=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://search.live.com" target="_blank">.</a>
<a href="http://search.live.com/results.aspx?q=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://search.lycos.co.uk" target="_blank">.</a>
<a href="http://search.lycos.co.uk/cgi-bin/pursuit?SITE=uk&query=frisk+asker+oldboys" target="_blank">.</a>

	</div>

<script type="text/javascript">
var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
</script>
<script type="text/javascript">
var pageTracker = _gat._getTracker("UA-2025203-1");
pageTracker._initData();
pageTracker._trackPageview();
</script></body>
</html>
