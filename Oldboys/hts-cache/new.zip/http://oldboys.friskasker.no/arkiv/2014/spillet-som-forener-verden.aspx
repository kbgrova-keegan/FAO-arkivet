
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">

	<head>

		<title>Spillet som forener verden  - Frisk Asker Oldboys</title>
		
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
		<meta http-equiv="imagetoolbar" CONTENT="no">
		<meta name="keywords" content="" />
		<meta name="description" content="Ventetiden er over! VM er her! Og selvsagt også FAOs tippekonkurranse!" />
		
		<meta name="title" content="Spillet som forener verden - Frisk Asker Oldboys" />
		<meta name="URL" content="http://oldboys.friskasker.no" />
		<meta name="language" content="Norsk" />
		<meta name="author" content="Terje Dahl" />
		<meta name="copyright" content="Frisk Asker Oldboys" />
		<meta name="reply-to" content="terjda@online.no" />
		<meta name="verify-v1" content="BxVdMcZ0uoa2KVw8RB+FBg3715LgSDXNG+RYp0gHpAI=" />

		<link type="text/css" href="/css/client.css" rel="stylesheet" />
		<link type="text/css" href="/css/default.css" rel="stylesheet" />
		<link type="text/css" href="/css/weatherCSS.css" rel="stylesheet" />

		<script type="text/javascript" src="/js/jquery.js"></script>
		<script type="text/javascript" src="/js/ufo.js"></script>
		<script type="text/javascript" src="/js/friskasker.js"></script>
		<!--script type='text/javascript' src='http://www.rdmtech.no/js/jquery.js?ver=1.2.6'></script-->
		<!--script type='text/javascript' src='http://www.rdmtech.no/js/jquery.cross-slide.js?ver=2.6'></script-->

		<!--[if IE 6]>
		<link type="text/css" href="/css/ie60.css" rel="stylesheet" />			
		<![endif]-->
		<!-- TradeDoubler site verification 1588386 --> 

	<script type='text/javascript'>
		jQuery(function($) {$(document).ready(function() {
			$('#container2').crossSlide(
				{sleep: 2, fade: 1},
				[{src: 'http://oldboys.friskasker.no/media/26561/bg-fao1.jpg'},{src: 'http://oldboys.friskasker.no/media/26566/bg-fao2.jpg'},{src: 'http://oldboys.friskasker.no/media/26571/bg-fao3.jpg'},{src: 'http://oldboys.friskasker.no/media/26576/bg-fao4.jpg'}]
			);
		});});
	</script>
	
<script type="text/javascript">
var _polldaddy = [] || _polldaddy;

_polldaddy.push( {
    type: 'slider',
    title: 'FAO-spillemodellen, skjønner du den?',
    body: 'Ta testen og bidra til å øke sjansen for sportslig utvikling av FAO!',
    button: 'Get Started &raquo;',
    domain: 'risengaj96.polldaddy.com/s/',
    id: 'fao-spillemodellen',
    placeholder: 'pd1438692132734'
} );

jQuery(function(d,c,j){$if(!document.getElementById(j)){var pd=d.createElement(c),s;pd.id=j;pd.src=('https:'==document.location.protocol)?'https://polldaddy.com/survey.js':'http://i0.poll.fm/survey.js';s=document.getElementsByTagName(c)[0];s.parentNode.insertBefore(pd,s);}}(document,'script','pd-embed'));
</script>

	
	</head>
	
	<body>
      
        <div id="container">&nbsp;
        
            <div id="header">&nbsp;
            
                <div id="logo"><a href="/"><img src="/media/26597/logos.gif" alt="Logo" /></a></div>
                <div id="rss"><a href="/data/rss/nyheter.xml">Motta RSS strøm</a></div>
		<!--div id="sitemap"><a href="/sitemap.aspx">Sitemap</a></div-->
		<div id="topknapp">
		<iframe width="280" height="160" src="https://www.youtube.com/embed/15KEqzCTrwI" frameborder="0" allowfullscreen></iframe>
		</div>
		
                

            </div>
            
            <div id="body">&nbsp;
            
                <div id="left">&nbsp;

                    <div id="date">mandag 15. april</div>
                	
                    <div class="leftnav"><a href="/">Hjem</a><br /><a href="/arkiv.aspx">Arkiv</a><br /><a href="/tabeller--terminlister.aspx">Tabeller &amp; terminlister</a><br /><a href="/kampreferat.aspx">Kampreferat</a><br /><a href="/fotballfilosofi.aspx">Fotballfilosofi</a><br /><a href="/ikke-helt-sportslig.aspx">Ikke helt sportslig</a><br /></div>
		
                    <div class="box" id="contactbox"><div class="header">Frisk Asker</div><div class="body"><a href="/frisk-asker/laget.aspx">Laget</a><br /><a href="/frisk-asker/kontakt.aspx">Kontakt</a><br /><a href="/frisk-asker/dommerhjoernet.aspx">Dommerhjørnet</a><br /><a href="https://teams.s2s.net/11225/no/" target="_new">Treningstider</a></div><div class="footer"><!----></div></div>

<!--		     <iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/standard/Verdana/14/bold/230/1&rn=84" frameborder="0" scrolling="no" width="230" height="500"></iframe>
-->
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&banner=1&system=no_no/5212/1/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/standard/Verdana/14/bold/230/1&rn=94" frameborder="0" scrolling="no" width="230" height="214"></iframe>

		     <iframe src="http://www.s2s.net/todays_skill_external.php?ccc=no" scrolling="no" width="200" height="330" frameborder="0"></iframe>
<!--
		     <div id="login">&nbsp;
                   
                    <form id="loginform" action="#">&nbsp;
                      
                        <input id="username" type="text" value="brukernavn" />
                        <input id="password" type="text" value="passord" />
                        <img src="/img/login.gif" alt="login" />
                        <a href="#">glemt passord?</a>    
                        
                    </form>
                    
                    </div>
-->
		    <div id="search">

			Artikkelsøk:<br />
			<div id="xsltsearch" xmlns:ps="urn:percipientstudios-com:xslt"><form action="/soek.aspx?" method="post" class="xsltsearch_form"><input name="search" type="text" class="input" value=""></input> <input type="submit" value="Search" class="submit" /></form></div>
		    </div>

                </div>
                
                <div id="center">
		
                    
 <div class="content">

	<h1>Spillet som forener verden</h1>
	<p><b>Ventetiden er over! VM er her! Og selvsagt også FAOs tippekonkurranse!</b></p>

<!--<h1>Spillet som forener verden</h1><div class="meta">27.05.14 14:12</div><div class="abstract"><img src="/umbraco/imagegen.ashx?image=/media/89247/zambia.jpg&amp;width=80" alt="" align="left" />Ventetiden er over! VM er her! Og selvsagt også FAOs tippekonkurranse!</div>
<p>&nbsp;</p>

<p><a
href="https://docs.google.com/spreadsheets/d/1T5C1tchA8icRxw5vwLACjxBSL76FDYvU9vuOZRN31jU/edit?usp=sharing">
Mobilversjon</a></p>

<p>&nbsp;</p>

<p>Spilleregler, overordnet:</p>

<p>Først vedder man på alle kampresultater i innledende puljespill,
<span>innen 6. juni.</span><br />
 26. juni er puljespillet slutt, og man vedder <span>innen 27.
juni</span> på kampresultatene i de oppsatte åttendedelsfinalene,
samt vinnere av alle kamper i sluttspillet.</p>

<p>FAO Bookmaking departement's Houndini Betting Engine vil
dynamisk rapportere hvordan resultatlisten ser ut, etter følgende
regler:</p>

<p>&nbsp;</p>

<p>Spilleregler, detaljert:</p>

<p>Tipp først innledende puljespill, med kampresultat i alle
kamper.</p>

<p>Riktig vinner (HUB): 1 poeng<br />
 Riktig resultat: 1 ekstra poeng<br />
 Ett puljelag riktig tippet videre til sluttspill: 2 poeng<br />
 To puljelag riktig tippet videre til sluttspill, men i feil
rekkefølge: 3 poeng<br />
 To puljelag riktig tippet videre til sluttspill, og riktig
rekkefølge på nr 1&amp;2: 4 poeng</p>

<p>Antall mulig poeng i innledende puljespill:</p>

<p>6*2 + 4= 16 poeng pr pulje. 8 puljer * 16 = 128 poeng</p>

<p>&nbsp;</p>

<p><span>Etter</span> ferdigspilt puljespill, tippes
sluttspillet:</p>

<p>Riktig vinner i 1/8-delsfinale: 2 poeng<br />
 Riktig resultat etter ordinær tid i 1/8-delsfinale: 2 ekstra
poeng<br />
 Riktig vinner kvartfinale: 4 poeng<br />
 Riktig vinner semifinale: 8 poeng<br />
 Riktig vinner finale: 16 poeng</p>

<p>Antall mulig poeng i sluttspill:</p>

<p>8*4 + 4*4 + 2*8* + 16 = 80 poeng</p>

<p>Vinneren er den med flest poeng sammenlagt.</p>

<p>&nbsp;</p>

<p>Veddemålet må være satt innen 6. juni, ved innbetaling av kr
200,- til kasserers konto 9710.42.83938 merket "VM" og spillers
navn, og innlevering av puljeresultatene til sekretariatet.</p>

<p>Last ned skjema <a href="/media/89187/tippeskjema.xlsx">her</a>,
fyll ut, og send til Turbo: terje.dahl@gmail.com</p>

<p>Det holder å tippe kampresultatene, som utleder
puljeplasseringen.</p>

<p>&nbsp;</p>

<p>Vinneren får hele potten, og ved eventuell poenglikhet vinner
den som har flest rette hendelser senest i spillet (for eksempel
vinner en spiller med to riktige finalelag foran en spiller med ett
riktig finalelag).<br />
 For øvrig gjelder bare én regel: Sekretariatet bestemmer.</p>

<p>&nbsp;</p>

<p>PS: Og lurte du på hvor det fantastiske lagbildet kommer
fra?<br />
 Jo, det er stolte Frisk Livingstone G12, med ett av FAs utskiftede
draktsett, etter en lang reise via mange gode krefter.</p>

<p>&nbsp;</p>
-->

<!--iframe width="1000" height="750" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://docs.google.com/spreadsheets/d/1wgGG-tZ1xZpEKf3YW-FYU6Nt3BU2xBIjHxIikjTn7vQ/edit#gid=1811222117"></iframe-->
<iframe width="527" height="1100" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://docs.google.com/spreadsheets/d/1xVcEwcTlThIzxLDtypdJuLWpn1pciSwicNbwxB_7T1w/edit#gid=831837418"></iframe>

<p><p>&nbsp;</p>

<p><a
href="https://docs.google.com/spreadsheets/d/1T5C1tchA8icRxw5vwLACjxBSL76FDYvU9vuOZRN31jU/edit?usp=sharing">
Mobilversjon</a></p>

<p>&nbsp;</p>

<p>Spilleregler, overordnet:</p>

<p>Først vedder man på alle kampresultater i innledende puljespill,
<span>innen 6. juni.</span><br />
 26. juni er puljespillet slutt, og man vedder <span>innen 27.
juni</span> på kampresultatene i de oppsatte åttendedelsfinalene,
samt vinnere av alle kamper i sluttspillet.</p>

<p>FAO Bookmaking departement's Houndini Betting Engine vil
dynamisk rapportere hvordan resultatlisten ser ut, etter følgende
regler:</p>

<p>&nbsp;</p>

<p>Spilleregler, detaljert:</p>

<p>Tipp først innledende puljespill, med kampresultat i alle
kamper.</p>

<p>Riktig vinner (HUB): 1 poeng<br />
 Riktig resultat: 1 ekstra poeng<br />
 Ett puljelag riktig tippet videre til sluttspill: 2 poeng<br />
 To puljelag riktig tippet videre til sluttspill, men i feil
rekkefølge: 3 poeng<br />
 To puljelag riktig tippet videre til sluttspill, og riktig
rekkefølge på nr 1&amp;2: 4 poeng</p>

<p>Antall mulig poeng i innledende puljespill:</p>

<p>6*2 + 4= 16 poeng pr pulje. 8 puljer * 16 = 128 poeng</p>

<p>&nbsp;</p>

<p><span>Etter</span> ferdigspilt puljespill, tippes
sluttspillet:</p>

<p>Riktig vinner i 1/8-delsfinale: 2 poeng<br />
 Riktig resultat etter ordinær tid i 1/8-delsfinale: 2 ekstra
poeng<br />
 Riktig vinner kvartfinale: 4 poeng<br />
 Riktig vinner semifinale: 8 poeng<br />
 Riktig vinner finale: 16 poeng</p>

<p>Antall mulig poeng i sluttspill:</p>

<p>8*4 + 4*4 + 2*8* + 16 = 80 poeng</p>

<p>Vinneren er den med flest poeng sammenlagt.</p>

<p>&nbsp;</p>

<p>Veddemålet må være satt innen 6. juni, ved innbetaling av kr
200,- til kasserers konto 9710.42.83938 merket "VM" og spillers
navn, og innlevering av puljeresultatene til sekretariatet.</p>

<p>Last ned skjema <a href="/media/89187/tippeskjema.xlsx">her</a>,
fyll ut, og send til Turbo: terje.dahl@gmail.com</p>

<p>Det holder å tippe kampresultatene, som utleder
puljeplasseringen.</p>

<p>&nbsp;</p>

<p>Vinneren får hele potten, og ved eventuell poenglikhet vinner
den som har flest rette hendelser senest i spillet (for eksempel
vinner en spiller med to riktige finalelag foran en spiller med ett
riktig finalelag).<br />
 For øvrig gjelder bare én regel: Sekretariatet bestemmer.</p>

<p>&nbsp;</p>

<p>PS: Og lurte du på hvor det fantastiske lagbildet kommer
fra?<br />
 Jo, det er stolte Frisk Livingstone G12, med ett av FAs utskiftede
draktsett, etter en lang reise via mange gode krefter.</p>

<p>&nbsp;</p></p>

<!-- AddThis Button BEGIN -->
<div class="addthis_toolbox addthis_default_style">
<a href="http://www.addthis.com/bookmark.php?v=250&amp;username=xa-4be09cd0025b8da5" class="addthis_button_compact">Share</a>
<span class="addthis_separator">|</span>
<a class="addthis_button_facebook"></a>
<a class="addthis_button_myspace"></a>
<a class="addthis_button_google"></a>
<a class="addthis_button_twitter"></a>
</div>
<script type="text/javascript" src="http://s7.addthis.com/js/250/addthis_widget.js#username=xa-4be09cd0025b8da5"></script>
<!-- AddThis Button END -->

<hr>
<h2>Kommentarer:</h2>
	<div class="newsitem"><i><b>28.05.14 7:48 - <a href="mailto:">onkel skrue</a></b></i><p>- og auksjonen da? burde ikke den tatt hele potten uansett?</p></div><div class="newsitem"><i><b>01.06.14 15:12 - <a href="mailto:">Sekretariatet</a></b></i><p>Nytt og forbedret resultatskjema.
Nå kan man se puljetabellene bli generert samtidig med at man legger inn kampresultatene, sånn at man kan prøve seg frem med resultater frem til en ønsket sluttabell. </p></div><div class="newsitem"><i><b>01.06.14 20:29 - <a href="mailto:">Keegan</a></b></i><p>Veddemål er satt.
Gjorde følgende:
i) Lastet ned skjemaet ved å trykke på linken i teksten over
ii) Gikk inn i excel-skjemaet og trykket "Aktiver redigering", som kom opp på en gul linje øverst på skjemaet
iii) Lekte meg med kampresultater inntil pulje-tabellene samsvarte med magefølelsen
iv) Sendte skjemaet til Turbo
v) Overførte 200 kr til kontonummer 9710.42.83938, og merket betalingen med "VM" pluss mitt navn
vi) La inn en kommentar her på at veddemålet er satt</p></div><div class="newsitem"><i><b>04.06.14 10:41 - <a href="mailto:amir.zunic@gmail.com">Amir</a></b></i><p>Da er fasitten på innledende puljespill levert :)</p></div><div class="newsitem"><i><b>04.06.14 12:37 - <a href="mailto:">ThomasD</a></b></i><p>Innlevert og betalt</p></div><div class="newsitem"><i><b>04.06.14 22:53 - <a href="mailto:">ReodoR</a></b></i><p>Veddemål er satt</p></div><div class="newsitem"><i><b>04.06.14 23:31 - <a href="mailto:">StB</a></b></i><p>Nå må dere bare sette veddemålene folkens, jeg vil bli rik nå som jeg har tatt meg bryet med å levere.</p></div><div class="newsitem"><i><b>05.06.14 15:01 - <a href="mailto:">Figo</a></b></i><p>All in - ready to roll</p></div><div class="newsitem"><i><b>07.06.14 0:21 - <a href="mailto:">Bookie</a></b></i><p>Første frist for plassering av bets passert.
Bets aksepteres ved innbetaling av 300 kr og innsendelse av tippekupong frem til alle veddemål plutselig publiseres. </p></div><div class="newsitem"><i><b>09.06.14 23:12 - <a href="mailto:">Turbo</a></b></i><p>ja, da er det bare å vente til torsdag. Syns dog det er litt laber oppslutning..
<a href="/media/89187/tippeskjema.xlsx">Her </a>er tippekupongen, for den som leter.</p></div><div class="newsitem"><i><b>11.06.14 23:37 - <a href="mailto:">Bookie</a></b></i><p>Let the game begin!</p></div><div class="newsitem"><i><b>12.06.14 7:59 - <a href="mailto:">mistenksom</a></b></i><p>AhA - her har vel sekretariatet foregrepet begivenhetenes gang?? Final Result  i to kamper som ennå ikke er spilt! ... ikke rart det finnes mange spekulasjoner om kamfiksing.</p></div><div class="newsitem"><i><b>13.06.14 22:58 - <a href="mailto:">- og vi venter på oppdatering fra sekretariatet</a></b></i><p>når Nl har overrasket hele verden, og Mexico har vunnet 1-0; hva gjør så dette med de innbyrdes resultatene her?? - vi venter på døgnbemanning i sekretariatet</p></div><div class="newsitem"><i><b>14.06.14 19:55 - <a href="mailto:">StB</a></b></i><p>nei, nei, nei .... hvorfor leste jeg ikke de detaljerte reglene før jeg tippet? Å tippe uavgjort resultat gir svært så dårlig score.</p></div>

<!--p>
<b>Kommentering er midlertidig steng pga SPAM!</b>
</p-->


<form method="post" action="spillet-som-forener-verden.aspx" id="aspnetForm">
<div>
<input type="hidden" name="__EVENTTARGET" id="__EVENTTARGET" value="" />
<input type="hidden" name="__EVENTARGUMENT" id="__EVENTARGUMENT" value="" />
<input type="hidden" name="__VIEWSTATE" id="__VIEWSTATE" value="/wEPDwUENTM4MQ9kFgJmD2QWAmYPZBYCZg9kFgJmD2QWAgIPD2QWAgILD2QWAgIBD2QWAmYPZBYCAgIPZBYCAgEPFgIeBFRleHQFF0RpbiBrb21tZW50YXIgZXIgcG9zdGV0ZGQWQv4zPSp8xElt1zaTFgveGenDIQ==" />
</div>

<script type="text/javascript">
//<![CDATA[
var theForm = document.forms['aspnetForm'];
if (!theForm) {
    theForm = document.aspnetForm;
}
function __doPostBack(eventTarget, eventArgument) {
    if (!theForm.onsubmit || (theForm.onsubmit() != false)) {
        theForm.__EVENTTARGET.value = eventTarget;
        theForm.__EVENTARGUMENT.value = eventArgument;
        theForm.submit();
    }
}
//]]>
</script>


<script src="/WebResource.axd?d=RhJRe7vAQjxLvd0VTiPlJ3ItrtWKNnlC5ndUOdQ1oQE84Jw0mmyu8t9423FKr6Sh25O1JfgygCRLDXncXNuX2rijfWY1&amp;t=635737087099672665" type="text/javascript"></script>


<script type="text/javascript">
//<![CDATA[
function insertLink(element) {var theLink = prompt('Enter URL for link here:','http://');insertTag(element, 'a', ' href="' + theLink + '"')}
            function insertTag(element, tag, param) {
            start = '<' + tag + param + '>';
            eind = '</' + tag + '>';
             /* element = document.getElementById(element); */
              if (document.selection) {
                element.focus();
                sel = document.selection.createRange();
                sel.text = start + sel.text + eind;
              } else if (element.selectionStart || element.selectionStart == '0') {
                element.focus();
                var startPos = element.selectionStart;
                var endPos = element.selectionEnd;
                element.value = element.value.substring(0, startPos) + start + element.value.substring(startPos, endPos) + eind + element.value.substring(endPos, element.value.length);
              } else {
                element.value += start + eind;
              }
            }
            //]]>
</script>

<h2>Post en kommentar:</h2>
<div id="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_PanelInput">
	
	<div id="umbracoAutoForm">
	
  <fieldset>
			<p><label for="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_navn">Navn:</label><input name="ctl00$ctl00$ctl00$ContentPlaceHolderDefault$MainContentPlaceHolder$AutoForm_7$navn" type="text" id="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_navn" class="umbEditorTextField" /></p><p><label for="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_epost">Epost:</label><input name="ctl00$ctl00$ctl00$ContentPlaceHolderDefault$MainContentPlaceHolder$AutoForm_7$epost" type="text" id="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_epost" class="umbEditorTextField" /></p><p><label for="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_kommentar">Kommentar:</label><table border="0" cellspacing="0" cellpadding="0"><tr><td>
	<p align="right" style="margin: 0px; padding:0px"><a href="javascript:insertLink(document.getElementById('ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_kommentar'))"><img src="/umbraco_client/simpleEditor/images/link.gif" border="0" align="right" /></a><a href="javascript:insertTag(document.getElementById('ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_kommentar'), 'em', '')"><img src="/umbraco_client/simpleEditor/images/italic.gif" border="0" style="margin-left: 3px; margin-right: 3px;" align="right" /></a> <a href="javascript:insertTag(document.getElementById('ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_kommentar'), 'strong', '')"><img src="/umbraco_client/simpleEditor/images/bold.gif" border="0" align="right" /></a><br/></p>
	<textarea name="ctl00$ctl00$ctl00$ContentPlaceHolderDefault$MainContentPlaceHolder$AutoForm_7$kommentar" rows="8" cols="20" id="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_kommentar" class="umbEditorTextField"></textarea></td></tr></table>
	</p><p><label for="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_captcha">Captcha:</label><input name="ctl00$ctl00$ctl00$ContentPlaceHolderDefault$MainContentPlaceHolder$AutoForm_7$captcha" type="text" id="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_captcha" class="umbEditorNumberField" /><br/><span class="umbracoAutoFormRowDescription">Hva er elleve pluss åtte?<br/></span></p>
		<p><input type="submit" name="ctl00$ctl00$ctl00$ContentPlaceHolderDefault$MainContentPlaceHolder$AutoForm_7$Button1" value="Post kommentar" onclick="javascript:WebForm_DoPostBackWithOptions(new WebForm_PostBackOptions(&quot;ctl00$ctl00$ctl00$ContentPlaceHolderDefault$MainContentPlaceHolder$AutoForm_7$Button1&quot;, &quot;&quot;, true, &quot;&quot;, &quot;&quot;, false, false))" id="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_Button1" class="umbracoAutoFormButton" /></p>
	</fieldset>		
	</div>

</div>

		

<div>

	<input type="hidden" name="__VIEWSTATEGENERATOR" id="__VIEWSTATEGENERATOR" value="CA0B0334" />
</div></form>

</div>

                </div>
                
		 <div id="right">
<!--
<font color="red" size="4">NB!</font><br/>
<b>Ut på tur?</b><br/>

-->

<br/>

<!--
	<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/iphone/Verdana/14/bold/280/1&rn=83" frameborder="0" scrolling="no" width="280" height="500"></iframe>
-->

                                        
                </div>

            </div>
            
        </div>
	<div id="bottomad"><!-- Bunnbanner -->
<!--
<script type="text/javascript">
var uri = 'http://impno.tradedoubler.com/imp?type(js)g(17626798)a(1588386)' + new String (Math.random()).substring (2, 11);
document.write('<sc'+'ript type="text/javascript" src="'+uri+'" charset=""></sc'+'ript>');
</script>
-->
<a href="http://www.google.com" target="_blank">.</a>
<a href="http://www.google.com/search?q=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://www.yahoo.com" target="_blank">.</a>
<a href="http://search.yahoo.com/search?p=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://search.aol.co.uk" target="_blank">.</a>
<a href="http://search.aol.co.uk/aol/search?query=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://uk.ask.com" target="_blank">.</a>
<a href="http://uk.ask.com/web?q=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://search.live.com" target="_blank">.</a>
<a href="http://search.live.com/results.aspx?q=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://search.lycos.co.uk" target="_blank">.</a>
<a href="http://search.lycos.co.uk/cgi-bin/pursuit?SITE=uk&query=frisk+asker+oldboys" target="_blank">.</a>

	</div>

<script type="text/javascript">
var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
</script>
<script type="text/javascript">
var pageTracker = _gat._getTracker("UA-2025203-1");
pageTracker._initData();
pageTracker._trackPageview();
</script></body>
</html>
