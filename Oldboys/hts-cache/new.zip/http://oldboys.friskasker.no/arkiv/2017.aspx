
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">

	<head>

		<title>2017  - Frisk Asker Oldboys</title>
		
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
		<meta http-equiv="imagetoolbar" CONTENT="no">
		<meta name="keywords" content="" />
		<meta name="description" content="" />
		
		<meta name="title" content="2017 - Frisk Asker Oldboys" />
		<meta name="URL" content="http://oldboys.friskasker.no" />
		<meta name="language" content="Norsk" />
		<meta name="author" content="Terje Dahl" />
		<meta name="copyright" content="Frisk Asker Oldboys" />
		<meta name="reply-to" content="terjda@online.no" />
		<meta name="verify-v1" content="BxVdMcZ0uoa2KVw8RB+FBg3715LgSDXNG+RYp0gHpAI=" />

		<link type="text/css" href="/css/client.css" rel="stylesheet" />
		<link type="text/css" href="/css/default.css" rel="stylesheet" />
		<link type="text/css" href="/css/weatherCSS.css" rel="stylesheet" />

		<script type="text/javascript" src="/js/jquery.js"></script>
		<script type="text/javascript" src="/js/ufo.js"></script>
		<script type="text/javascript" src="/js/friskasker.js"></script>
		<!--script type='text/javascript' src='http://www.rdmtech.no/js/jquery.js?ver=1.2.6'></script-->
		<!--script type='text/javascript' src='http://www.rdmtech.no/js/jquery.cross-slide.js?ver=2.6'></script-->

		<!--[if IE 6]>
		<link type="text/css" href="/css/ie60.css" rel="stylesheet" />			
		<![endif]-->
		<!-- TradeDoubler site verification 1588386 --> 

	<script type='text/javascript'>
		jQuery(function($) {$(document).ready(function() {
			$('#container2').crossSlide(
				{sleep: 2, fade: 1},
				[{src: 'http://oldboys.friskasker.no/media/26561/bg-fao1.jpg'},{src: 'http://oldboys.friskasker.no/media/26566/bg-fao2.jpg'},{src: 'http://oldboys.friskasker.no/media/26571/bg-fao3.jpg'},{src: 'http://oldboys.friskasker.no/media/26576/bg-fao4.jpg'}]
			);
		});});
	</script>
	
<script type="text/javascript">
var _polldaddy = [] || _polldaddy;

_polldaddy.push( {
    type: 'slider',
    title: 'FAO-spillemodellen, skjønner du den?',
    body: 'Ta testen og bidra til å øke sjansen for sportslig utvikling av FAO!',
    button: 'Get Started &raquo;',
    domain: 'risengaj96.polldaddy.com/s/',
    id: 'fao-spillemodellen',
    placeholder: 'pd1438692132734'
} );

jQuery(function(d,c,j){$if(!document.getElementById(j)){var pd=d.createElement(c),s;pd.id=j;pd.src=('https:'==document.location.protocol)?'https://polldaddy.com/survey.js':'http://i0.poll.fm/survey.js';s=document.getElementsByTagName(c)[0];s.parentNode.insertBefore(pd,s);}}(document,'script','pd-embed'));
</script>

	
	</head>
	
	<body>
      
        <div id="container">&nbsp;
        
            <div id="header">&nbsp;
            
                <div id="logo"><a href="/"><img src="/media/26597/logos.gif" alt="Logo" /></a></div>
                <div id="rss"><a href="/data/rss/nyheter.xml">Motta RSS strøm</a></div>
		<!--div id="sitemap"><a href="/sitemap.aspx">Sitemap</a></div-->
		<div id="topknapp">
		<iframe width="280" height="160" src="https://www.youtube.com/embed/15KEqzCTrwI" frameborder="0" allowfullscreen></iframe>
		</div>
		
                

            </div>
            
            <div id="body">&nbsp;
            
                <div id="left">&nbsp;

                    <div id="date">mandag 15. april</div>
                	
                    <div class="leftnav"><a href="/">Hjem</a><br /><a href="/arkiv.aspx">Arkiv</a><br /><a href="/tabeller--terminlister.aspx">Tabeller &amp; terminlister</a><br /><a href="/kampreferat.aspx">Kampreferat</a><br /><a href="/fotballfilosofi.aspx">Fotballfilosofi</a><br /><a href="/ikke-helt-sportslig.aspx">Ikke helt sportslig</a><br /></div>
		
                    <div class="box" id="contactbox"><div class="header">Frisk Asker</div><div class="body"><a href="/frisk-asker/laget.aspx">Laget</a><br /><a href="/frisk-asker/kontakt.aspx">Kontakt</a><br /><a href="/frisk-asker/dommerhjoernet.aspx">Dommerhjørnet</a><br /><a href="https://teams.s2s.net/11225/no/" target="_new">Treningstider</a></div><div class="footer"><!----></div></div>

<!--		     <iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/standard/Verdana/14/bold/230/1&rn=84" frameborder="0" scrolling="no" width="230" height="500"></iframe>
-->
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&banner=1&system=no_no/5212/1/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/standard/Verdana/14/bold/230/1&rn=94" frameborder="0" scrolling="no" width="230" height="214"></iframe>

		     <iframe src="http://www.s2s.net/todays_skill_external.php?ccc=no" scrolling="no" width="200" height="330" frameborder="0"></iframe>
<!--
		     <div id="login">&nbsp;
                   
                    <form id="loginform" action="#">&nbsp;
                      
                        <input id="username" type="text" value="brukernavn" />
                        <input id="password" type="text" value="passord" />
                        <img src="/img/login.gif" alt="login" />
                        <a href="#">glemt passord?</a>    
                        
                    </form>
                    
                    </div>
-->
		    <div id="search">

			Artikkelsøk:<br />
			<div id="xsltsearch" xmlns:ps="urn:percipientstudios-com:xslt"><form action="/soek.aspx?" method="post" class="xsltsearch_form"><input name="search" type="text" class="input" value=""></input> <input type="submit" value="Search" class="submit" /></form></div>
		    </div>

                </div>
                
                <div id="center">
		
                    
<div class="content">

	<h1>2017</h1>


	<div class="newsitem"><h2>FAOs dommerprosjekt</h2><div class="meta">31.12.17 05:15 - Keegan</div><p>FAO Dommerlaug rapporterer</p><a class="readmore" href="/arkiv/2017/faos-dommerprosjekt.aspx">Les mer ...</a></div><div class="newsitem"><h2>Årets Spiller 2017</h2><div class="meta">25.12.17 02:58 - Keegan</div><p>Hederspris til hedersmann</p><a class="readmore" href="/arkiv/2017/aarets-spiller-2017.aspx">Les mer ...</a></div><div class="newsitem"><h2>Åtte glass!</h2><div class="meta">19.12.17 07:19 - Keegan</div><p>2017 coming to an end.
<br>2018 rising!</p><a class="readmore" href="/arkiv/2017/aatte-glass!.aspx">Les mer ...</a></div><div class="newsitem"><h2>Hvalstrand boots</h2><div class="meta">19.11.17 01:04 - Keegan</div><p>En sann (epost-)historie</p><a class="readmore" href="/arkiv/2017/hvalstrand-boots.aspx">Les mer ...</a></div><div class="newsitem"><h2>Høystemt sesongavslutning</h2><div class="meta">23.10.17 08:13 - Keegan</div><p>Sesongen er over, gå i fred.  FAO være med deg.</p><a class="readmore" href="/arkiv/2017/hoeystemt-sesongavslutning.aspx">Les mer ...</a></div><div class="newsitem"><h2>Sit-rapp II </h2><div class="meta">22.09.17 01:23 - Figo</div><p>Hvilken fantastisk serieinnspurt det blir- fire lag som alle har kurs mot medaljer!</p><a class="readmore" href="/arkiv/2017/sit-rapp-ii-.aspx">Les mer ...</a></div><div class="newsitem"><h2>Sit-rapp</h2><div class="meta">03.09.17 02:42 - Keegan</div><p>Vi teller opp...</p><a class="readmore" href="/arkiv/2017/sit-rapp.aspx">Les mer ...</a></div><div class="newsitem"><h2>Ledig stilling</h2><div class="meta">17.08.17 11:47 - Keegan</div><p>FAO søker ny tillitsvalgt</p><a class="readmore" href="/arkiv/2017/ledig-stilling.aspx">Les mer ...</a></div><div class="newsitem"><h2>Bright and alert!</h2><div class="meta">12.08.17 05:40 - Keegan</div><p>TROPP - RETT!</p><a class="readmore" href="/arkiv/2017/bright-and-alert!.aspx">Les mer ...</a></div><div class="newsitem"><h2>Last man standing</h2><div class="meta">07.08.17 10:16 - Keegan</div><p>Analyseavdelingen presenterer: Skadestatistikken 2017</p><a class="readmore" href="/arkiv/2017/last-man-standing.aspx">Les mer ...</a></div><div class="newsitem"><h2>Over takst</h2><div class="meta">04.08.17 04:45 - Keegan</div><p>.</p><a class="readmore" href="/arkiv/2017/over-takst.aspx">Les mer ...</a></div><div class="newsitem"><h2>Say less, do more</h2><div class="meta">28.07.17 11:29 - Keegan</div><p>Menn av få ord - det er FAO, det. Eller...?</p><a class="readmore" href="/arkiv/2017/say-less,-do-more.aspx">Les mer ...</a></div><div class="newsitem"><h2>FAOs motivasjonsavdeling presenterer</h2><div class="meta">25.07.17 12:05 - Administrator</div><p>I'm here to help collect your debt...</p><a class="readmore" href="/arkiv/2017/faos-motivasjonsavdeling-presenterer.aspx">Les mer ...</a></div><div class="newsitem"><h2>Det beste er godt nok</h2><div class="meta">24.07.17 06:29 - Keegan</div><p>Kanskje...</p><a class="readmore" href="/arkiv/2017/det-beste-er-godt-nok.aspx">Les mer ...</a></div><div class="newsitem"><h2>Visst var det bedre, men det var ikke bra</h2><div class="meta">19.07.17 09:25 - </div><p>.</p><a class="readmore" href="/arkiv/2017/visst-var-det-bedre,-men-det-var-ikke-bra.aspx">Les mer ...</a></div><div class="newsitem"><h2>En hverdagslig historie</h2><div class="meta">15.07.17 05:57 - </div><p>Learning by reading</p><a class="readmore" href="/arkiv/2017/en-hverdagslig-historie.aspx">Les mer ...</a></div><div class="newsitem"><h2>Once upon a time...</h2><div class="meta">30.06.17 10:19 - Keegan</div><p>Har du hørt den om...</p><a class="readmore" href="/arkiv/2017/once-upon-a-time.aspx">Les mer ...</a></div><div class="newsitem"><h2>Summertime!</h2><div class="meta">23.06.17 10:08 - Keegan</div><p>Gimme a break!</p><a class="readmore" href="/arkiv/2017/summertime!.aspx">Les mer ...</a></div><div class="newsitem"><h2>Hei, hvor det går!</h2><div class="meta">03.06.17 01:20 - Keegan</div><p>OBS-varsel for Risenga uke 23</p><a class="readmore" href="/arkiv/2017/hei,-hvor-det-gaar!.aspx">Les mer ...</a></div><div class="newsitem"><h2>Frisk Asker krysser Grønland</h2><div class="meta">23.05.17 10:24 - </div><p /><a class="readmore" href="/arkiv/2017/frisk-asker-krysser-groenland.aspx">Les mer ...</a></div><div class="newsitem"><h2>Vårens trend</h2><div class="meta">12.05.17 12:56 - Keegan</div><p>11 kamper 11. mai</p><a class="readmore" href="/arkiv/2017/vaarens-trend.aspx">Les mer ...</a></div><div class="newsitem"><h2>Oldboyscup!</h2><div class="meta">07.05.17 02:43 - </div><p>Same same, only different</p><a class="readmore" href="/arkiv/2017/oldboyscup!.aspx">Les mer ...</a></div><div class="newsitem"><h2>M42: KFUM - FAO 6-6 </h2><div class="meta">29.04.17 11:22 - </div><p>Still confused? Also after this episode...</p><a class="readmore" href="/arkiv/2017/m42-kfum---fao-6-6-.aspx">Les mer ...</a></div><div class="newsitem"><h2>Fjellhamar - FAO M48 3-9</h2><div class="meta">26.04.17 07:51 - </div><p>Sunny, can you hear us!</p><a class="readmore" href="/arkiv/2017/fjellhamar---fao-m48-3-9.aspx">Les mer ...</a></div><div class="newsitem"><h2>Debut med FAO M42!</h2><div class="meta">25.04.17 07:22 - </div><p>FAO selger aldri skinnet før bjørnen er skutt!</p><a class="readmore" href="/arkiv/2017/debut-med-fao-m42!.aspx">Les mer ...</a></div><div class="newsitem"><h2>Frisk Asker Oldboys krysser Grønland!</h2><div class="meta">20.04.17 11:17 - </div><p>FAOs tøffeste kamp!</p><a class="readmore" href="/arkiv/2017/frisk-asker-oldboys-krysser-groenland!.aspx">Les mer ...</a></div><div class="newsitem"><h2>We can't wait any longer!</h2><div class="meta">10.04.17 01:06 - </div><p>Kan vi se å få blåst igang!</p><a class="readmore" href="/arkiv/2017/we-can't-wait-any-longer!.aspx">Les mer ...</a></div><div class="newsitem"><h2>Give credit where credit is due</h2><div class="meta">21.03.17 10:20 - </div><p>Har jeg fortalt om den gangen</p><a class="readmore" href="/arkiv/2017/give-credit-where-credit-is-due.aspx">Les mer ...</a></div><div class="newsitem"><h2>FAO-familien utvider!</h2><div class="meta">15.03.17 10:01 - </div><p>Så var vi på tjukka igjen, gitt</p><a class="readmore" href="/arkiv/2017/fao-familien-utvider!.aspx">Les mer ...</a></div><div class="newsitem"><h2>Utrydningstruet?</h2><div class="meta">14.03.17 02:00 - </div><p>Om tigerens underarter, og andre abstraksjoner</p><a class="readmore" href="/arkiv/2017/utrydningstruet.aspx">Les mer ...</a></div><div class="newsitem"><h2>Hvorfor velger man å bli pappatrener?</h2><div class="meta">06.03.17 03:39 - </div><p>Time for reflection</p><a class="readmore" href="/arkiv/2017/hvorfor-velger-man-aa-bli-pappatrener.aspx">Les mer ...</a></div><div class="newsitem"><h2>Endringer? Nei det driver vi ikke med her</h2><div class="meta">23.02.17 08:31 - </div><p>Noe nytt, sa du?</p><a class="readmore" href="/arkiv/2017/endringer-nei-det-driver-vi-ikke-med-her.aspx">Les mer ...</a></div><div class="newsitem"><h2>Én for alle, alle for én</h2><div class="meta">17.02.17 06:59 - </div><p>Skarru værra virru værra FAO! </p><a class="readmore" href="/arkiv/2017/én-for-alle,-alle-for-én.aspx">Les mer ...</a></div><div class="newsitem"><h2>Prognose 2017</h2><div class="meta">11.02.17 02:54 - </div><p>Keeping up with the FAO</p><a class="readmore" href="/arkiv/2017/prognose-2017.aspx">Les mer ...</a></div><div class="newsitem"><h2>Angst und Spader</h2><div class="meta">26.01.17 06:24 - </div><p>Midtvintersdystopi</p><a class="readmore" href="/arkiv/2017/angst-und-spader.aspx">Les mer ...</a></div><div class="newsitem"><h2>Puljeoppsettet 2017</h2><div class="meta">19.01.17 08:40 - Keegan</div><p>Lev og dø med samme sinn!</p><a class="readmore" href="/arkiv/2017/puljeoppsettet-2017.aspx">Les mer ...</a></div><div class="newsitem"><h2>Fremad!</h2><div class="meta">06.01.17 11:40 - Keegan</div><p>2017, her kommer vi!</p><a class="readmore" href="/arkiv/2017/fremad!.aspx">Les mer ...</a></div>

</div>




                </div>
                
		 <div id="right">

<font color="red" size="4">Lagbilde</font><br/>


<!--a href="http://oldboys.friskasker.no/media/116678/formkurve.png" border=0><img src="/media/116678/formkurve.png" width="280" alt="Formkurve" /></a-->
<!--iframe src="http://free.timeanddate.com/countdown/i5t3zil3/n187/cf113/cm0/cu4/ct0/cs0/ca0/cr0/ss0/cac000/cpc000/pc00e60b/tc000/fs100/szw320/szh135/tatFAO%20h%C3%B8stsesong%20starter%20om../tac000/tptTime%20since%20Event%20started%20in/tpc000/mac000/mpc000/iso2017-08-14T21:00:00" allowTransparency="true" frameborder="0" width="320" height="135"></iframe-->
	<!--iframe frameborder="0" width="512" height="600" scrolling="auto" allowtransparency="true" src="https://risengaj96.polldaddy.com/s/fao-plassering-pr-lag-2018?iframe=1"><a href="https://risengaj96.polldaddy.com/s/fao-plassering-pr-lag-2018">View Survey</a></iframe-->
<br/>
<!-- FORMkurve iframe width="508" height="371" seamless frameborder="0" scrolling="no" src="https://docs.google.com/spreadsheets/d/1wL8AGtLu517MG4vlWG2DIat7LmhdKaJdXz4nDVsxc74/pubchart?oid=1826601090&amp;format=interactive"></iframe-->

<!-- iphone
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/iphone/Verdana/14/bold/250/1&rn=7" frameborder="0" scrolling="no" width="250" height="500"></iframe>
-->
	<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/iphone/Verdana/14/bold/280/1&rn=83" frameborder="0" scrolling="no" width="280" height="500"></iframe>
<!--
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/21/ae82202846179cbfa34c266edf916f37&colours=FF8C00/CCCCCC/FFF/4/standard/Comic+Sans+Serif/16/bold/280/1&rn=22" frameborder="0" scrolling="no" width="280" height="500"></iframe>
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/members&bits=25/21/ae82202846179cbfa34c266edf916f37&colours=FF8C00/CCCCCC/FFF/4/standard/Comic+Sans+Serif/16/bold/280/1&rn=50" frameborder="0" scrolling="no" width="280" height="500"></iframe>
-->
<!-- iframe src="https://www.s2s.net/export_content.php?team_id=1101&system=no_no/1032/2/one/activities&bits=25/21/68565729bae64238443339aae6dcf62c&colours=FF6600/000099/FFF/0/iphone/Verdana/12/bold/280/0" frameborder="0" scrolling="no" width="280" height="500"></iframe -->

<br/><br/>
<a href="http://www.forstehjelpsgrossisten.no/products/is-pose-stor-14-x-21-cm-i-kartong-av-24-stk" border="0" target="_new"><img src="/umbraco/imagegen.ashx?image=/media/114144/forstehjelpsgrossistem.png&width=280"></a>
<br/>
<div style="text-align: left; width:280px;">Stolt sponsor av Frisk Asker Oldboys!</div>

                                        
                </div>

            </div>
            
        </div>
	<div id="bottomad"><!-- Bunnbanner -->
<!--
<script type="text/javascript">
var uri = 'http://impno.tradedoubler.com/imp?type(js)g(17626798)a(1588386)' + new String (Math.random()).substring (2, 11);
document.write('<sc'+'ript type="text/javascript" src="'+uri+'" charset=""></sc'+'ript>');
</script>
-->
<a href="http://www.google.com" target="_blank">.</a>
<a href="http://www.google.com/search?q=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://www.yahoo.com" target="_blank">.</a>
<a href="http://search.yahoo.com/search?p=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://search.aol.co.uk" target="_blank">.</a>
<a href="http://search.aol.co.uk/aol/search?query=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://uk.ask.com" target="_blank">.</a>
<a href="http://uk.ask.com/web?q=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://search.live.com" target="_blank">.</a>
<a href="http://search.live.com/results.aspx?q=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://search.lycos.co.uk" target="_blank">.</a>
<a href="http://search.lycos.co.uk/cgi-bin/pursuit?SITE=uk&query=frisk+asker+oldboys" target="_blank">.</a>

	</div>

<script type="text/javascript">
var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
</script>
<script type="text/javascript">
var pageTracker = _gat._getTracker("UA-2025203-1");
pageTracker._initData();
pageTracker._trackPageview();
</script></body>
</html>
