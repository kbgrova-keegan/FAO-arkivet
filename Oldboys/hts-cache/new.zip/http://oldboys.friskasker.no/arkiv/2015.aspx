
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">

	<head>

		<title>2015  - Frisk Asker Oldboys</title>
		
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
		<meta http-equiv="imagetoolbar" CONTENT="no">
		<meta name="keywords" content="" />
		<meta name="description" content="" />
		
		<meta name="title" content="2015 - Frisk Asker Oldboys" />
		<meta name="URL" content="http://oldboys.friskasker.no" />
		<meta name="language" content="Norsk" />
		<meta name="author" content="Terje Dahl" />
		<meta name="copyright" content="Frisk Asker Oldboys" />
		<meta name="reply-to" content="terjda@online.no" />
		<meta name="verify-v1" content="BxVdMcZ0uoa2KVw8RB+FBg3715LgSDXNG+RYp0gHpAI=" />

		<link type="text/css" href="/css/client.css" rel="stylesheet" />
		<link type="text/css" href="/css/default.css" rel="stylesheet" />
		<link type="text/css" href="/css/weatherCSS.css" rel="stylesheet" />

		<script type="text/javascript" src="/js/jquery.js"></script>
		<script type="text/javascript" src="/js/ufo.js"></script>
		<script type="text/javascript" src="/js/friskasker.js"></script>
		<!--script type='text/javascript' src='http://www.rdmtech.no/js/jquery.js?ver=1.2.6'></script-->
		<!--script type='text/javascript' src='http://www.rdmtech.no/js/jquery.cross-slide.js?ver=2.6'></script-->

		<!--[if IE 6]>
		<link type="text/css" href="/css/ie60.css" rel="stylesheet" />			
		<![endif]-->
		<!-- TradeDoubler site verification 1588386 --> 

	<script type='text/javascript'>
		jQuery(function($) {$(document).ready(function() {
			$('#container2').crossSlide(
				{sleep: 2, fade: 1},
				[{src: 'http://oldboys.friskasker.no/media/26561/bg-fao1.jpg'},{src: 'http://oldboys.friskasker.no/media/26566/bg-fao2.jpg'},{src: 'http://oldboys.friskasker.no/media/26571/bg-fao3.jpg'},{src: 'http://oldboys.friskasker.no/media/26576/bg-fao4.jpg'}]
			);
		});});
	</script>
	
<script type="text/javascript">
var _polldaddy = [] || _polldaddy;

_polldaddy.push( {
    type: 'slider',
    title: 'FAO-spillemodellen, skjønner du den?',
    body: 'Ta testen og bidra til å øke sjansen for sportslig utvikling av FAO!',
    button: 'Get Started &raquo;',
    domain: 'risengaj96.polldaddy.com/s/',
    id: 'fao-spillemodellen',
    placeholder: 'pd1438692132734'
} );

jQuery(function(d,c,j){$if(!document.getElementById(j)){var pd=d.createElement(c),s;pd.id=j;pd.src=('https:'==document.location.protocol)?'https://polldaddy.com/survey.js':'http://i0.poll.fm/survey.js';s=document.getElementsByTagName(c)[0];s.parentNode.insertBefore(pd,s);}}(document,'script','pd-embed'));
</script>

	
	</head>
	
	<body>
      
        <div id="container">&nbsp;
        
            <div id="header">&nbsp;
            
                <div id="logo"><a href="/"><img src="/media/26597/logos.gif" alt="Logo" /></a></div>
                <div id="rss"><a href="/data/rss/nyheter.xml">Motta RSS strøm</a></div>
		<!--div id="sitemap"><a href="/sitemap.aspx">Sitemap</a></div-->
		<div id="topknapp">
		<iframe width="280" height="160" src="https://www.youtube.com/embed/15KEqzCTrwI" frameborder="0" allowfullscreen></iframe>
		</div>
		
                

            </div>
            
            <div id="body">&nbsp;
            
                <div id="left">&nbsp;

                    <div id="date">mandag 15. april</div>
                	
                    <div class="leftnav"><a href="/">Hjem</a><br /><a href="/arkiv.aspx">Arkiv</a><br /><a href="/tabeller--terminlister.aspx">Tabeller &amp; terminlister</a><br /><a href="/kampreferat.aspx">Kampreferat</a><br /><a href="/fotballfilosofi.aspx">Fotballfilosofi</a><br /><a href="/ikke-helt-sportslig.aspx">Ikke helt sportslig</a><br /></div>
		
                    <div class="box" id="contactbox"><div class="header">Frisk Asker</div><div class="body"><a href="/frisk-asker/laget.aspx">Laget</a><br /><a href="/frisk-asker/kontakt.aspx">Kontakt</a><br /><a href="/frisk-asker/dommerhjoernet.aspx">Dommerhjørnet</a><br /><a href="https://teams.s2s.net/11225/no/" target="_new">Treningstider</a></div><div class="footer"><!----></div></div>

<!--		     <iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/standard/Verdana/14/bold/230/1&rn=84" frameborder="0" scrolling="no" width="230" height="500"></iframe>
-->
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&banner=1&system=no_no/5212/1/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/standard/Verdana/14/bold/230/1&rn=94" frameborder="0" scrolling="no" width="230" height="214"></iframe>

		     <iframe src="http://www.s2s.net/todays_skill_external.php?ccc=no" scrolling="no" width="200" height="330" frameborder="0"></iframe>
<!--
		     <div id="login">&nbsp;
                   
                    <form id="loginform" action="#">&nbsp;
                      
                        <input id="username" type="text" value="brukernavn" />
                        <input id="password" type="text" value="passord" />
                        <img src="/img/login.gif" alt="login" />
                        <a href="#">glemt passord?</a>    
                        
                    </form>
                    
                    </div>
-->
		    <div id="search">

			Artikkelsøk:<br />
			<div id="xsltsearch" xmlns:ps="urn:percipientstudios-com:xslt"><form action="/soek.aspx?" method="post" class="xsltsearch_form"><input name="search" type="text" class="input" value=""></input> <input type="submit" value="Search" class="submit" /></form></div>
		    </div>

                </div>
                
                <div id="center">
		
                    
<div class="content">

	<h1>2015</h1>


	<div class="newsitem"><h2>2016: FAO Strikes Back</h2><div class="meta">28.12.15 06:58 - Keegan</div><p>Utviklingen fortsetter</p><a class="readmore" href="/arkiv/2015/2016-fao-strikes-back.aspx">Les mer ...</a></div><div class="newsitem"><h2>Nytt år - nye muligheter</h2><div class="meta">21.12.15 01:26 - Keegan</div><p>Nyttårsquiz!</p><a class="readmore" href="/arkiv/2015/nytt-aar---nye-muligheter.aspx">Les mer ...</a></div><div class="newsitem"><h2>FAO-evangeliet</h2><div class="meta">08.12.15 09:57 - Keegan</div><p>Det skjedde i de dager, at vi meldte på et M48-lag.</p><a class="readmore" href="/arkiv/2015/fao-evangeliet.aspx">Les mer ...</a></div><div class="newsitem"><h2>Sannhetens time</h2><div class="meta">06.11.15 01:54 - Keegan</div><p>Us and them</p><a class="readmore" href="/arkiv/2015/sannhetens-time.aspx">Les mer ...</a></div><div class="newsitem"><h2>Sesongavslutning</h2><div class="meta">25.10.15 02:36 - Keegan</div><p>It ain't over till the FAO sings</p><a class="readmore" href="/arkiv/2015/sesongavslutning.aspx">Les mer ...</a></div><div class="newsitem"><h2>You can't always get what you want</h2><div class="meta">30.09.15 11:18 - Keegan</div><p>.</p><a class="readmore" href="/arkiv/2015/you-can't-always-get-what-you-want.aspx">Les mer ...</a></div><div class="newsitem"><h2>Snipp, snapp, snute</h2><div class="meta">18.09.15 10:14 - Keegan</div><p>M33: fjerdeplass, ned fra første - M40: fjerdeplass, opp fra 7.</p><a class="readmore" href="/arkiv/2015/snipp,-snapp,-snute.aspx">Les mer ...</a></div><div class="newsitem"><h2>FAO har funnet seg sjæl!</h2><div class="meta">04.09.15 09:07 - Keegan</div><p>Skal det være noe mer før vi stenger?</p><a class="readmore" href="/arkiv/2015/fao-har-funnet-seg-sjael!.aspx">Les mer ...</a></div><div class="newsitem"><h2>The winners take it all</h2><div class="meta">30.08.15 10:38 - Keegan</div><p>Oppsiktsvekkende resultater på green'en</p><a class="readmore" href="/arkiv/2015/the-winners-take-it-all.aspx">Les mer ...</a></div><div class="newsitem"><h2>FIFA tar grep!</h2><div class="meta">25.08.15 01:16 - Keegan</div><p>Opprydning i ukultur</p><a class="readmore" href="/arkiv/2015/fifa-tar-grep!.aspx">Les mer ...</a></div><div class="newsitem"><h2>WTF?!</h2><div class="meta">23.08.15 01:09 - Keegan</div><p>Ytterligere forsterkninger i FAOs lagbyggingsutvalg</p><a class="readmore" href="/arkiv/2015/wtf!.aspx">Les mer ...</a></div><div class="newsitem"><h2>Fotomodeller</h2><div class="meta">19.08.15 09:51 - Keegan</div><p>Årets lagbilde er begått</p><a class="readmore" href="/arkiv/2015/fotomodeller.aspx">Les mer ...</a></div><div class="newsitem"><h2>Creapy news</h2><div class="meta">11.08.15 01:24 - Keegan</div><p>Consider this a warning</p><a class="readmore" href="/arkiv/2015/creapy-news.aspx">Les mer ...</a></div><div class="newsitem"><h2>Fotballgolf </h2><div class="meta">25.07.15 09:32 - Keegan</div><p>Så var det på'n igjen</p><a class="readmore" href="/arkiv/2015/fotballgolf-.aspx">Les mer ...</a></div><div class="newsitem"><h2>Størst av alt er kjærligheten</h2><div class="meta">14.07.15 01:51 - Keegan</div><p>A love story</p><a class="readmore" href="/arkiv/2015/stoerst-av-alt-er-kjaerligheten.aspx">Les mer ...</a></div><div class="newsitem"><h2>Lagbygging</h2><div class="meta">14.07.15 01:58 - Keegan</div><p>En sjørøvercapt'n, av den gode, gamle sorten</p><a class="readmore" href="/arkiv/2015/lagbygging.aspx">Les mer ...</a></div><div class="newsitem"><h2>Analyseavdelingen rapporterer</h2><div class="meta">25.06.15 12:57 - Keegan</div><p>For spesielt interesserte; En sommertabellanalyse</p><a class="readmore" href="/arkiv/2015/analyseavdelingen-rapporterer.aspx">Les mer ...</a></div><div class="newsitem"><h2>Frisk de kan bedåre!</h2><div class="meta">23.06.15 10:18 - Keegan</div><p>♫... har dom fått seg nye skor?</p><a class="readmore" href="/arkiv/2015/frisk-de-kan-bedaare!.aspx">Les mer ...</a></div><div class="newsitem"><h2>FAO-spillemodellen</h2><div class="meta">16.06.15 10:25 - Keegan</div><p>FAO satt i system</p><a class="readmore" href="/arkiv/2015/fao-spillemodellen.aspx">Les mer ...</a></div><div class="newsitem"><h2>4/4 Overgangsspill</h2><div class="meta">15.06.15 02:17 - Keegan</div><p>Kontringsløp</p><a class="readmore" href="/arkiv/2015/44-overgangsspill.aspx">Les mer ...</a></div><div class="newsitem"><h2>3/4 Faste situasjoner</h2><div class="meta">06.06.15 03:33 - Keegan</div><p>Dødballspill</p><a class="readmore" href="/arkiv/2015/34-faste-situasjoner.aspx">Les mer ...</a></div><div class="newsitem"><h2>Crisis? What crisis?</h2><div class="meta">06.06.15 02:02 - Keegan</div><p>Attention! FAO Krisesenter melder</p><a class="readmore" href="/arkiv/2015/crisis-what-crisis.aspx">Les mer ...</a></div><div class="newsitem"><h2>2/4 Kryssende løp</h2><div class="meta">02.06.15 12:22 - Keegan</div><p>Trafikalt grunnkurs del 2</p><a class="readmore" href="/arkiv/2015/24-kryssende-loep.aspx">Les mer ...</a></div><div class="newsitem"><h2>1/4 Samla press</h2><div class="meta">26.05.15 10:41 - Keegan</div><p>Taktikkprat</p><a class="readmore" href="/arkiv/2015/14-samla-press.aspx">Les mer ...</a></div><div class="newsitem"><h2>Sommerfesten</h2><div class="meta">14.05.15 10:33 - Keegan</div><p>Sosialarbeid coming up</p><a class="readmore" href="/arkiv/2015/sommerfesten.aspx">Les mer ...</a></div><div class="newsitem"><h2>3 - 2 - 1 - ....</h2><div class="meta">04.05.15 09:46 - Keegan</div><p>We have ignition!</p><a class="readmore" href="/arkiv/2015/3---2---1---.aspx">Les mer ...</a></div><div class="newsitem"><h2>Maktens menn i 2015</h2><div class="meta">30.04.15 02:56 - Keegan</div><p>Kurs i overlevelsesteknikk</p><a class="readmore" href="/arkiv/2015/maktens-menn-i-2015.aspx">Les mer ...</a></div><div class="newsitem"><h2>Treningskamp oldboys</h2><div class="meta">22.04.15 01:26 - Keegan</div><p>Treningskamp Bygdø Monolitten - Frisk Asker M33!</p><a class="readmore" href="/arkiv/2015/treningskamp-oldboys.aspx">Les mer ...</a></div><div class="newsitem"><h2>Kampropet gjaller!</h2><div class="meta">15.04.15 03:53 - Keegan</div><p>Vets, can you hear the call!</p><a class="readmore" href="/arkiv/2015/kampropet-gjaller!.aspx">Les mer ...</a></div><div class="newsitem"><h2>Når ringer sluttes</h2><div class="meta">13.04.15 08:47 - Keegan</div><p>FAOs forskningsavdeling presenterer</p><a class="readmore" href="/arkiv/2015/naar-ringer-sluttes.aspx">Les mer ...</a></div><div class="newsitem"><h2>Terminlister 2015</h2><div class="meta">20.03.15 02:24 - Keegan</div><p>Terminlister for 2015-sesongen finnes nå i venstremenyen.
</p><a class="readmore" href="/arkiv/2015/terminlister-2015.aspx">Les mer ...</a></div><div class="newsitem"><h2>3. FAO Sportslig Utvalg presenterer!</h2><div class="meta">17.02.15 01:55 - Keegan</div><p>For aller første gang: FAO satt i system!</p><a class="readmore" href="/arkiv/2015/3-fao-sportslig-utvalg-presenterer!.aspx">Les mer ...</a></div><div class="newsitem"><h2>2. Rehab</h2><div class="meta">17.02.15 12:59 - Keegan</div><p>Teorien bak FAOs radikale rehab-program</p><a class="readmore" href="/arkiv/2015/2-rehab.aspx">Les mer ...</a></div><div class="newsitem"><h2>1. The Rise and Fall of FAO</h2><div class="meta">16.02.15 11:01 - Keegan</div><p>Wakeup call!</p><a class="readmore" href="/arkiv/2015/1-the-rise-and-fall-of-fao.aspx">Les mer ...</a></div>

</div>




                </div>
                
		 <div id="right">

<font color="red" size="4">Lagbilde</font><br/>


<!--a href="http://oldboys.friskasker.no/media/116678/formkurve.png" border=0><img src="/media/116678/formkurve.png" width="280" alt="Formkurve" /></a-->
<!--iframe src="http://free.timeanddate.com/countdown/i5t3zil3/n187/cf113/cm0/cu4/ct0/cs0/ca0/cr0/ss0/cac000/cpc000/pc00e60b/tc000/fs100/szw320/szh135/tatFAO%20h%C3%B8stsesong%20starter%20om../tac000/tptTime%20since%20Event%20started%20in/tpc000/mac000/mpc000/iso2017-08-14T21:00:00" allowTransparency="true" frameborder="0" width="320" height="135"></iframe-->
	<!--iframe frameborder="0" width="512" height="600" scrolling="auto" allowtransparency="true" src="https://risengaj96.polldaddy.com/s/fao-plassering-pr-lag-2018?iframe=1"><a href="https://risengaj96.polldaddy.com/s/fao-plassering-pr-lag-2018">View Survey</a></iframe-->
<br/>
<!-- FORMkurve iframe width="508" height="371" seamless frameborder="0" scrolling="no" src="https://docs.google.com/spreadsheets/d/1wL8AGtLu517MG4vlWG2DIat7LmhdKaJdXz4nDVsxc74/pubchart?oid=1826601090&amp;format=interactive"></iframe-->

<!-- iphone
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/iphone/Verdana/14/bold/250/1&rn=7" frameborder="0" scrolling="no" width="250" height="500"></iframe>
-->
	<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/iphone/Verdana/14/bold/280/1&rn=83" frameborder="0" scrolling="no" width="280" height="500"></iframe>
<!--
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/21/ae82202846179cbfa34c266edf916f37&colours=FF8C00/CCCCCC/FFF/4/standard/Comic+Sans+Serif/16/bold/280/1&rn=22" frameborder="0" scrolling="no" width="280" height="500"></iframe>
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/members&bits=25/21/ae82202846179cbfa34c266edf916f37&colours=FF8C00/CCCCCC/FFF/4/standard/Comic+Sans+Serif/16/bold/280/1&rn=50" frameborder="0" scrolling="no" width="280" height="500"></iframe>
-->
<!-- iframe src="https://www.s2s.net/export_content.php?team_id=1101&system=no_no/1032/2/one/activities&bits=25/21/68565729bae64238443339aae6dcf62c&colours=FF6600/000099/FFF/0/iphone/Verdana/12/bold/280/0" frameborder="0" scrolling="no" width="280" height="500"></iframe -->

<br/><br/>
<a href="http://www.forstehjelpsgrossisten.no/products/is-pose-stor-14-x-21-cm-i-kartong-av-24-stk" border="0" target="_new"><img src="/umbraco/imagegen.ashx?image=/media/114144/forstehjelpsgrossistem.png&width=280"></a>
<br/>
<div style="text-align: left; width:280px;">Stolt sponsor av Frisk Asker Oldboys!</div>

                                        
                </div>

            </div>
            
        </div>
	<div id="bottomad"><!-- Bunnbanner -->
<!--
<script type="text/javascript">
var uri = 'http://impno.tradedoubler.com/imp?type(js)g(17626798)a(1588386)' + new String (Math.random()).substring (2, 11);
document.write('<sc'+'ript type="text/javascript" src="'+uri+'" charset=""></sc'+'ript>');
</script>
-->
<a href="http://www.google.com" target="_blank">.</a>
<a href="http://www.google.com/search?q=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://www.yahoo.com" target="_blank">.</a>
<a href="http://search.yahoo.com/search?p=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://search.aol.co.uk" target="_blank">.</a>
<a href="http://search.aol.co.uk/aol/search?query=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://uk.ask.com" target="_blank">.</a>
<a href="http://uk.ask.com/web?q=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://search.live.com" target="_blank">.</a>
<a href="http://search.live.com/results.aspx?q=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://search.lycos.co.uk" target="_blank">.</a>
<a href="http://search.lycos.co.uk/cgi-bin/pursuit?SITE=uk&query=frisk+asker+oldboys" target="_blank">.</a>

	</div>

<script type="text/javascript">
var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
</script>
<script type="text/javascript">
var pageTracker = _gat._getTracker("UA-2025203-1");
pageTracker._initData();
pageTracker._trackPageview();
</script></body>
</html>
