
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">

	<head>

		<title>10 ting som kjennetegner oldboysspillere  - Frisk Asker Oldboys</title>
		
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
		<meta http-equiv="imagetoolbar" CONTENT="no">
		<meta name="keywords" content="" />
		<meta name="description" content="En guide til idrettsgleden i Frisk Asker Oldboys" />
		
		<meta name="title" content="10 ting som kjennetegner oldboysspillere - Frisk Asker Oldboys" />
		<meta name="URL" content="http://oldboys.friskasker.no" />
		<meta name="language" content="Norsk" />
		<meta name="author" content="Terje Dahl" />
		<meta name="copyright" content="Frisk Asker Oldboys" />
		<meta name="reply-to" content="terjda@online.no" />
		<meta name="verify-v1" content="BxVdMcZ0uoa2KVw8RB+FBg3715LgSDXNG+RYp0gHpAI=" />

		<link type="text/css" href="/css/client.css" rel="stylesheet" />
		<link type="text/css" href="/css/default.css" rel="stylesheet" />
		<link type="text/css" href="/css/weatherCSS.css" rel="stylesheet" />

		<script type="text/javascript" src="/js/jquery.js"></script>
		<script type="text/javascript" src="/js/ufo.js"></script>
		<script type="text/javascript" src="/js/friskasker.js"></script>
		<!--script type='text/javascript' src='http://www.rdmtech.no/js/jquery.js?ver=1.2.6'></script-->
		<!--script type='text/javascript' src='http://www.rdmtech.no/js/jquery.cross-slide.js?ver=2.6'></script-->

		<!--[if IE 6]>
		<link type="text/css" href="/css/ie60.css" rel="stylesheet" />			
		<![endif]-->
		<!-- TradeDoubler site verification 1588386 --> 

	<script type='text/javascript'>
		jQuery(function($) {$(document).ready(function() {
			$('#container2').crossSlide(
				{sleep: 2, fade: 1},
				[{src: 'http://oldboys.friskasker.no/media/26561/bg-fao1.jpg'},{src: 'http://oldboys.friskasker.no/media/26566/bg-fao2.jpg'},{src: 'http://oldboys.friskasker.no/media/26571/bg-fao3.jpg'},{src: 'http://oldboys.friskasker.no/media/26576/bg-fao4.jpg'}]
			);
		});});
	</script>
	
<script type="text/javascript">
var _polldaddy = [] || _polldaddy;

_polldaddy.push( {
    type: 'slider',
    title: 'FAO-spillemodellen, skjønner du den?',
    body: 'Ta testen og bidra til å øke sjansen for sportslig utvikling av FAO!',
    button: 'Get Started &raquo;',
    domain: 'risengaj96.polldaddy.com/s/',
    id: 'fao-spillemodellen',
    placeholder: 'pd1438692132734'
} );

jQuery(function(d,c,j){$if(!document.getElementById(j)){var pd=d.createElement(c),s;pd.id=j;pd.src=('https:'==document.location.protocol)?'https://polldaddy.com/survey.js':'http://i0.poll.fm/survey.js';s=document.getElementsByTagName(c)[0];s.parentNode.insertBefore(pd,s);}}(document,'script','pd-embed'));
</script>

	
	</head>
	
	<body>
      
        <div id="container">&nbsp;
        
            <div id="header">&nbsp;
            
                <div id="logo"><a href="/"><img src="/media/26597/logos.gif" alt="Logo" /></a></div>
                <div id="rss"><a href="/data/rss/nyheter.xml">Motta RSS strøm</a></div>
		<!--div id="sitemap"><a href="/sitemap.aspx">Sitemap</a></div-->
		<div id="topknapp">
		<iframe width="280" height="160" src="https://www.youtube.com/embed/15KEqzCTrwI" frameborder="0" allowfullscreen></iframe>
		</div>
		
                

            </div>
            
            <div id="body">&nbsp;
            
                <div id="left">&nbsp;

                    <div id="date">mandag 15. april</div>
                	
                    <div class="leftnav"><a href="/">Hjem</a><br /><a href="/arkiv.aspx">Arkiv</a><br /><a href="/tabeller--terminlister.aspx">Tabeller &amp; terminlister</a><br /><a href="/kampreferat.aspx">Kampreferat</a><br /><a href="/fotballfilosofi.aspx">Fotballfilosofi</a><br /><a href="/ikke-helt-sportslig.aspx">Ikke helt sportslig</a><br /></div>
		
                    <div class="box" id="contactbox"><div class="header">Frisk Asker</div><div class="body"><a href="/frisk-asker/laget.aspx">Laget</a><br /><a href="/frisk-asker/kontakt.aspx">Kontakt</a><br /><a href="/frisk-asker/dommerhjoernet.aspx">Dommerhjørnet</a><br /><a href="https://teams.s2s.net/11225/no/" target="_new">Treningstider</a></div><div class="footer"><!----></div></div>

<!--		     <iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/standard/Verdana/14/bold/230/1&rn=84" frameborder="0" scrolling="no" width="230" height="500"></iframe>
-->
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&banner=1&system=no_no/5212/1/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/standard/Verdana/14/bold/230/1&rn=94" frameborder="0" scrolling="no" width="230" height="214"></iframe>

		     <iframe src="http://www.s2s.net/todays_skill_external.php?ccc=no" scrolling="no" width="200" height="330" frameborder="0"></iframe>
<!--
		     <div id="login">&nbsp;
                   
                    <form id="loginform" action="#">&nbsp;
                      
                        <input id="username" type="text" value="brukernavn" />
                        <input id="password" type="text" value="passord" />
                        <img src="/img/login.gif" alt="login" />
                        <a href="#">glemt passord?</a>    
                        
                    </form>
                    
                    </div>
-->
		    <div id="search">

			Artikkelsøk:<br />
			<div id="xsltsearch" xmlns:ps="urn:percipientstudios-com:xslt"><form action="/soek.aspx?" method="post" class="xsltsearch_form"><input name="search" type="text" class="input" value=""></input> <input type="submit" value="Search" class="submit" /></form></div>
		    </div>

                </div>
                
                <div id="center">
		
                    
<div class="content">

	<h1>10 ting som kjennetegner oldboysspillere</h1><div class="meta">13.01.18 17:49 - Keegan</div><div class="abstract"><img src="/umbraco/imagegen.ashx?image=/media/130248/blind.jpg&amp;width=500" alt="" align="left" />En guide til idrettsgleden i Frisk Asker Oldboys</div>
<p>&nbsp;</p>

<p>&nbsp;</p>

<p><strong>10 ting som kjennetegner oldboysspillere</strong></p>

<p>
<!--[if gte mso 9]><xml> <o:OfficeDocumentSettings> <o:AllowPNG /> </o:OfficeDocumentSettings> </xml><![endif]--></p>

<p>
<!--[if gte mso 9]><xml> <w:WordDocument> <w:View>Normal</w:View> <w:Zoom>0</w:Zoom> <w:TrackMoves /> <w:TrackFormatting /> <w:HyphenationZone>21</w:HyphenationZone> <w:PunctuationKerning /> <w:ValidateAgainstSchemas /> <w:SaveIfXMLInvalid>false</w:SaveIfXMLInvalid> <w:IgnoreMixedContent>false</w:IgnoreMixedContent> <w:AlwaysShowPlaceholderText>false</w:AlwaysShowPlaceholderText> <w:DoNotPromoteQF /> <w:LidThemeOther>NO-BOK</w:LidThemeOther> <w:LidThemeAsian>X-NONE</w:LidThemeAsian> <w:LidThemeComplexScript>NE</w:LidThemeComplexScript> <w:Compatibility> <w:BreakWrappedTables /> <w:SnapToGridInCell /> <w:WrapTextWithPunct /> <w:UseAsianBreakRules /> <w:DontGrowAutofit /> <w:SplitPgBreakAndParaMark /> <w:EnableOpenTypeKerning /> <w:DontFlipMirrorIndents /> <w:OverrideTableStyleHps /> </w:Compatibility> <m:mathPr> <m:mathFont m:val="Cambria Math" /> <m:brkBin m:val="before" /> <m:brkBinSub m:val="&#45;-" /> <m:smallFrac m:val="off" /> <m:dispDef /> <m:lMargin m:val="0" /> <m:rMargin m:val="0" /> <m:defJc m:val="centerGroup" /> <m:wrapIndent m:val="1440" /> <m:intLim m:val="subSup" /> <m:naryLim m:val="undOvr" /> </m:mathPr></w:WordDocument> </xml><![endif]--><!--[if gte mso 9]><xml> <w:LatentStyles DefLockedState="false" DefUnhideWhenUsed="false"   DefSemiHidden="false" DefQFormat="false" DefPriority="99"   LatentStyleCount="371"> <w:LsdException Locked="false" Priority="0" QFormat="true" Name="Normal" /> <w:LsdException Locked="false" Priority="9" QFormat="true" Name="heading 1" /> <w:LsdException Locked="false" Priority="9" SemiHidden="true"    UnhideWhenUsed="true" QFormat="true" Name="heading 2" /> <w:LsdException Locked="false" Priority="9" SemiHidden="true"    UnhideWhenUsed="true" QFormat="true" Name="heading 3" /> <w:LsdException Locked="false" Priority="9" SemiHidden="true"    UnhideWhenUsed="true" QFormat="true" Name="heading 4" /> <w:LsdException Locked="false" Priority="9" SemiHidden="true"    UnhideWhenUsed="true" QFormat="true" Name="heading 5" /> <w:LsdException Locked="false" Priority="9" SemiHidden="true"    UnhideWhenUsed="true" QFormat="true" Name="heading 6" /> <w:LsdException Locked="false" Priority="9" SemiHidden="true"    UnhideWhenUsed="true" QFormat="true" Name="heading 7" /> <w:LsdException Locked="false" Priority="9" SemiHidden="true"    UnhideWhenUsed="true" QFormat="true" Name="heading 8" /> <w:LsdException Locked="false" Priority="9" SemiHidden="true"    UnhideWhenUsed="true" QFormat="true" Name="heading 9" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="index 1" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="index 2" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="index 3" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="index 4" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="index 5" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="index 6" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="index 7" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="index 8" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="index 9" /> <w:LsdException Locked="false" Priority="39" SemiHidden="true"    UnhideWhenUsed="true" Name="toc 1" /> <w:LsdException Locked="false" Priority="39" SemiHidden="true"    UnhideWhenUsed="true" Name="toc 2" /> <w:LsdException Locked="false" Priority="39" SemiHidden="true"    UnhideWhenUsed="true" Name="toc 3" /> <w:LsdException Locked="false" Priority="39" SemiHidden="true"    UnhideWhenUsed="true" Name="toc 4" /> <w:LsdException Locked="false" Priority="39" SemiHidden="true"    UnhideWhenUsed="true" Name="toc 5" /> <w:LsdException Locked="false" Priority="39" SemiHidden="true"    UnhideWhenUsed="true" Name="toc 6" /> <w:LsdException Locked="false" Priority="39" SemiHidden="true"    UnhideWhenUsed="true" Name="toc 7" /> <w:LsdException Locked="false" Priority="39" SemiHidden="true"    UnhideWhenUsed="true" Name="toc 8" /> <w:LsdException Locked="false" Priority="39" SemiHidden="true"    UnhideWhenUsed="true" Name="toc 9" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Normal Indent" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="footnote text" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="annotation text" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="header" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="footer" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="index heading" /> <w:LsdException Locked="false" Priority="35" SemiHidden="true"    UnhideWhenUsed="true" QFormat="true" Name="caption" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="table of figures" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="envelope address" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="envelope return" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="footnote reference" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="annotation reference" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="line number" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="page number" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="endnote reference" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="endnote text" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="table of authorities" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="macro" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="toa heading" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="List" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="List Bullet" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="List Number" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="List 2" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="List 3" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="List 4" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="List 5" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="List Bullet 2" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="List Bullet 3" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="List Bullet 4" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="List Bullet 5" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="List Number 2" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="List Number 3" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="List Number 4" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="List Number 5" /> <w:LsdException Locked="false" Priority="10" QFormat="true" Name="Title" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Closing" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Signature" /> <w:LsdException Locked="false" Priority="1" SemiHidden="true"    UnhideWhenUsed="true" Name="Default Paragraph Font" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Body Text" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Body Text Indent" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="List Continue" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="List Continue 2" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="List Continue 3" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="List Continue 4" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="List Continue 5" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Message Header" /> <w:LsdException Locked="false" Priority="11" QFormat="true" Name="Subtitle" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Salutation" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Date" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Body Text First Indent" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Body Text First Indent 2" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Note Heading" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Body Text 2" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Body Text 3" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Body Text Indent 2" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Body Text Indent 3" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Block Text" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Hyperlink" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="FollowedHyperlink" /> <w:LsdException Locked="false" Priority="22" QFormat="true" Name="Strong" /> <w:LsdException Locked="false" Priority="20" QFormat="true" Name="Emphasis" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Document Map" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Plain Text" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="E-mail Signature" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="HTML Top of Form" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="HTML Bottom of Form" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Normal (Web)" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="HTML Acronym" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="HTML Address" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="HTML Cite" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="HTML Code" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="HTML Definition" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="HTML Keyboard" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="HTML Preformatted" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="HTML Sample" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="HTML Typewriter" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="HTML Variable" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Normal Table" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="annotation subject" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="No List" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Outline List 1" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Outline List 2" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Outline List 3" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Table Simple 1" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Table Simple 2" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Table Simple 3" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Table Classic 1" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Table Classic 2" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Table Classic 3" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Table Classic 4" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Table Colorful 1" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Table Colorful 2" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Table Colorful 3" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Table Columns 1" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Table Columns 2" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Table Columns 3" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Table Columns 4" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Table Columns 5" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Table Grid 1" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Table Grid 2" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Table Grid 3" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Table Grid 4" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Table Grid 5" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Table Grid 6" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Table Grid 7" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Table Grid 8" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Table List 1" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Table List 2" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Table List 3" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Table List 4" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Table List 5" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Table List 6" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Table List 7" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Table List 8" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Table 3D effects 1" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Table 3D effects 2" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Table 3D effects 3" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Table Contemporary" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Table Elegant" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Table Professional" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Table Subtle 1" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Table Subtle 2" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Table Web 1" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Table Web 2" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Table Web 3" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Balloon Text" /> <w:LsdException Locked="false" Priority="39" Name="Table Grid" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Table Theme" /> <w:LsdException Locked="false" SemiHidden="true" Name="Placeholder Text" /> <w:LsdException Locked="false" Priority="1" QFormat="true" Name="No Spacing" /> <w:LsdException Locked="false" Priority="60" Name="Light Shading" /> <w:LsdException Locked="false" Priority="61" Name="Light List" /> <w:LsdException Locked="false" Priority="62" Name="Light Grid" /> <w:LsdException Locked="false" Priority="63" Name="Medium Shading 1" /> <w:LsdException Locked="false" Priority="64" Name="Medium Shading 2" /> <w:LsdException Locked="false" Priority="65" Name="Medium List 1" /> <w:LsdException Locked="false" Priority="66" Name="Medium List 2" /> <w:LsdException Locked="false" Priority="67" Name="Medium Grid 1" /> <w:LsdException Locked="false" Priority="68" Name="Medium Grid 2" /> <w:LsdException Locked="false" Priority="69" Name="Medium Grid 3" /> <w:LsdException Locked="false" Priority="70" Name="Dark List" /> <w:LsdException Locked="false" Priority="71" Name="Colorful Shading" /> <w:LsdException Locked="false" Priority="72" Name="Colorful List" /> <w:LsdException Locked="false" Priority="73" Name="Colorful Grid" /> <w:LsdException Locked="false" Priority="60" Name="Light Shading Accent 1" /> <w:LsdException Locked="false" Priority="61" Name="Light List Accent 1" /> <w:LsdException Locked="false" Priority="62" Name="Light Grid Accent 1" /> <w:LsdException Locked="false" Priority="63" Name="Medium Shading 1 Accent 1" /> <w:LsdException Locked="false" Priority="64" Name="Medium Shading 2 Accent 1" /> <w:LsdException Locked="false" Priority="65" Name="Medium List 1 Accent 1" /> <w:LsdException Locked="false" SemiHidden="true" Name="Revision" /> <w:LsdException Locked="false" Priority="34" QFormat="true"    Name="List Paragraph" /> <w:LsdException Locked="false" Priority="29" QFormat="true" Name="Quote" /> <w:LsdException Locked="false" Priority="30" QFormat="true"    Name="Intense Quote" /> <w:LsdException Locked="false" Priority="66" Name="Medium List 2 Accent 1" /> <w:LsdException Locked="false" Priority="67" Name="Medium Grid 1 Accent 1" /> <w:LsdException Locked="false" Priority="68" Name="Medium Grid 2 Accent 1" /> <w:LsdException Locked="false" Priority="69" Name="Medium Grid 3 Accent 1" /> <w:LsdException Locked="false" Priority="70" Name="Dark List Accent 1" /> <w:LsdException Locked="false" Priority="71" Name="Colorful Shading Accent 1" /> <w:LsdException Locked="false" Priority="72" Name="Colorful List Accent 1" /> <w:LsdException Locked="false" Priority="73" Name="Colorful Grid Accent 1" /> <w:LsdException Locked="false" Priority="60" Name="Light Shading Accent 2" /> <w:LsdException Locked="false" Priority="61" Name="Light List Accent 2" /> <w:LsdException Locked="false" Priority="62" Name="Light Grid Accent 2" /> <w:LsdException Locked="false" Priority="63" Name="Medium Shading 1 Accent 2" /> <w:LsdException Locked="false" Priority="64" Name="Medium Shading 2 Accent 2" /> <w:LsdException Locked="false" Priority="65" Name="Medium List 1 Accent 2" /> <w:LsdException Locked="false" Priority="66" Name="Medium List 2 Accent 2" /> <w:LsdException Locked="false" Priority="67" Name="Medium Grid 1 Accent 2" /> <w:LsdException Locked="false" Priority="68" Name="Medium Grid 2 Accent 2" /> <w:LsdException Locked="false" Priority="69" Name="Medium Grid 3 Accent 2" /> <w:LsdException Locked="false" Priority="70" Name="Dark List Accent 2" /> <w:LsdException Locked="false" Priority="71" Name="Colorful Shading Accent 2" /> <w:LsdException Locked="false" Priority="72" Name="Colorful List Accent 2" /> <w:LsdException Locked="false" Priority="73" Name="Colorful Grid Accent 2" /> <w:LsdException Locked="false" Priority="60" Name="Light Shading Accent 3" /> <w:LsdException Locked="false" Priority="61" Name="Light List Accent 3" /> <w:LsdException Locked="false" Priority="62" Name="Light Grid Accent 3" /> <w:LsdException Locked="false" Priority="63" Name="Medium Shading 1 Accent 3" /> <w:LsdException Locked="false" Priority="64" Name="Medium Shading 2 Accent 3" /> <w:LsdException Locked="false" Priority="65" Name="Medium List 1 Accent 3" /> <w:LsdException Locked="false" Priority="66" Name="Medium List 2 Accent 3" /> <w:LsdException Locked="false" Priority="67" Name="Medium Grid 1 Accent 3" /> <w:LsdException Locked="false" Priority="68" Name="Medium Grid 2 Accent 3" /> <w:LsdException Locked="false" Priority="69" Name="Medium Grid 3 Accent 3" /> <w:LsdException Locked="false" Priority="70" Name="Dark List Accent 3" /> <w:LsdException Locked="false" Priority="71" Name="Colorful Shading Accent 3" /> <w:LsdException Locked="false" Priority="72" Name="Colorful List Accent 3" /> <w:LsdException Locked="false" Priority="73" Name="Colorful Grid Accent 3" /> <w:LsdException Locked="false" Priority="60" Name="Light Shading Accent 4" /> <w:LsdException Locked="false" Priority="61" Name="Light List Accent 4" /> <w:LsdException Locked="false" Priority="62" Name="Light Grid Accent 4" /> <w:LsdException Locked="false" Priority="63" Name="Medium Shading 1 Accent 4" /> <w:LsdException Locked="false" Priority="64" Name="Medium Shading 2 Accent 4" /> <w:LsdException Locked="false" Priority="65" Name="Medium List 1 Accent 4" /> <w:LsdException Locked="false" Priority="66" Name="Medium List 2 Accent 4" /> <w:LsdException Locked="false" Priority="67" Name="Medium Grid 1 Accent 4" /> <w:LsdException Locked="false" Priority="68" Name="Medium Grid 2 Accent 4" /> <w:LsdException Locked="false" Priority="69" Name="Medium Grid 3 Accent 4" /> <w:LsdException Locked="false" Priority="70" Name="Dark List Accent 4" /> <w:LsdException Locked="false" Priority="71" Name="Colorful Shading Accent 4" /> <w:LsdException Locked="false" Priority="72" Name="Colorful List Accent 4" /> <w:LsdException Locked="false" Priority="73" Name="Colorful Grid Accent 4" /> <w:LsdException Locked="false" Priority="60" Name="Light Shading Accent 5" /> <w:LsdException Locked="false" Priority="61" Name="Light List Accent 5" /> <w:LsdException Locked="false" Priority="62" Name="Light Grid Accent 5" /> <w:LsdException Locked="false" Priority="63" Name="Medium Shading 1 Accent 5" /> <w:LsdException Locked="false" Priority="64" Name="Medium Shading 2 Accent 5" /> <w:LsdException Locked="false" Priority="65" Name="Medium List 1 Accent 5" /> <w:LsdException Locked="false" Priority="66" Name="Medium List 2 Accent 5" /> <w:LsdException Locked="false" Priority="67" Name="Medium Grid 1 Accent 5" /> <w:LsdException Locked="false" Priority="68" Name="Medium Grid 2 Accent 5" /> <w:LsdException Locked="false" Priority="69" Name="Medium Grid 3 Accent 5" /> <w:LsdException Locked="false" Priority="70" Name="Dark List Accent 5" /> <w:LsdException Locked="false" Priority="71" Name="Colorful Shading Accent 5" /> <w:LsdException Locked="false" Priority="72" Name="Colorful List Accent 5" /> <w:LsdException Locked="false" Priority="73" Name="Colorful Grid Accent 5" /> <w:LsdException Locked="false" Priority="60" Name="Light Shading Accent 6" /> <w:LsdException Locked="false" Priority="61" Name="Light List Accent 6" /> <w:LsdException Locked="false" Priority="62" Name="Light Grid Accent 6" /> <w:LsdException Locked="false" Priority="63" Name="Medium Shading 1 Accent 6" /> <w:LsdException Locked="false" Priority="64" Name="Medium Shading 2 Accent 6" /> <w:LsdException Locked="false" Priority="65" Name="Medium List 1 Accent 6" /> <w:LsdException Locked="false" Priority="66" Name="Medium List 2 Accent 6" /> <w:LsdException Locked="false" Priority="67" Name="Medium Grid 1 Accent 6" /> <w:LsdException Locked="false" Priority="68" Name="Medium Grid 2 Accent 6" /> <w:LsdException Locked="false" Priority="69" Name="Medium Grid 3 Accent 6" /> <w:LsdException Locked="false" Priority="70" Name="Dark List Accent 6" /> <w:LsdException Locked="false" Priority="71" Name="Colorful Shading Accent 6" /> <w:LsdException Locked="false" Priority="72" Name="Colorful List Accent 6" /> <w:LsdException Locked="false" Priority="73" Name="Colorful Grid Accent 6" /> <w:LsdException Locked="false" Priority="19" QFormat="true"    Name="Subtle Emphasis" /> <w:LsdException Locked="false" Priority="21" QFormat="true"    Name="Intense Emphasis" /> <w:LsdException Locked="false" Priority="31" QFormat="true"    Name="Subtle Reference" /> <w:LsdException Locked="false" Priority="32" QFormat="true"    Name="Intense Reference" /> <w:LsdException Locked="false" Priority="33" QFormat="true" Name="Book Title" /> <w:LsdException Locked="false" Priority="37" SemiHidden="true"    UnhideWhenUsed="true" Name="Bibliography" /> <w:LsdException Locked="false" Priority="39" SemiHidden="true"    UnhideWhenUsed="true" QFormat="true" Name="TOC Heading" /> <w:LsdException Locked="false" Priority="41" Name="Plain Table 1" /> <w:LsdException Locked="false" Priority="42" Name="Plain Table 2" /> <w:LsdException Locked="false" Priority="43" Name="Plain Table 3" /> <w:LsdException Locked="false" Priority="44" Name="Plain Table 4" /> <w:LsdException Locked="false" Priority="45" Name="Plain Table 5" /> <w:LsdException Locked="false" Priority="40" Name="Grid Table Light" /> <w:LsdException Locked="false" Priority="46" Name="Grid Table 1 Light" /> <w:LsdException Locked="false" Priority="47" Name="Grid Table 2" /> <w:LsdException Locked="false" Priority="48" Name="Grid Table 3" /> <w:LsdException Locked="false" Priority="49" Name="Grid Table 4" /> <w:LsdException Locked="false" Priority="50" Name="Grid Table 5 Dark" /> <w:LsdException Locked="false" Priority="51" Name="Grid Table 6 Colorful" /> <w:LsdException Locked="false" Priority="52" Name="Grid Table 7 Colorful" /> <w:LsdException Locked="false" Priority="46"    Name="Grid Table 1 Light Accent 1" /> <w:LsdException Locked="false" Priority="47" Name="Grid Table 2 Accent 1" /> <w:LsdException Locked="false" Priority="48" Name="Grid Table 3 Accent 1" /> <w:LsdException Locked="false" Priority="49" Name="Grid Table 4 Accent 1" /> <w:LsdException Locked="false" Priority="50" Name="Grid Table 5 Dark Accent 1" /> <w:LsdException Locked="false" Priority="51"    Name="Grid Table 6 Colorful Accent 1" /> <w:LsdException Locked="false" Priority="52"    Name="Grid Table 7 Colorful Accent 1" /> <w:LsdException Locked="false" Priority="46"    Name="Grid Table 1 Light Accent 2" /> <w:LsdException Locked="false" Priority="47" Name="Grid Table 2 Accent 2" /> <w:LsdException Locked="false" Priority="48" Name="Grid Table 3 Accent 2" /> <w:LsdException Locked="false" Priority="49" Name="Grid Table 4 Accent 2" /> <w:LsdException Locked="false" Priority="50" Name="Grid Table 5 Dark Accent 2" /> <w:LsdException Locked="false" Priority="51"    Name="Grid Table 6 Colorful Accent 2" /> <w:LsdException Locked="false" Priority="52"    Name="Grid Table 7 Colorful Accent 2" /> <w:LsdException Locked="false" Priority="46"    Name="Grid Table 1 Light Accent 3" /> <w:LsdException Locked="false" Priority="47" Name="Grid Table 2 Accent 3" /> <w:LsdException Locked="false" Priority="48" Name="Grid Table 3 Accent 3" /> <w:LsdException Locked="false" Priority="49" Name="Grid Table 4 Accent 3" /> <w:LsdException Locked="false" Priority="50" Name="Grid Table 5 Dark Accent 3" /> <w:LsdException Locked="false" Priority="51"    Name="Grid Table 6 Colorful Accent 3" /> <w:LsdException Locked="false" Priority="52"    Name="Grid Table 7 Colorful Accent 3" /> <w:LsdException Locked="false" Priority="46"    Name="Grid Table 1 Light Accent 4" /> <w:LsdException Locked="false" Priority="47" Name="Grid Table 2 Accent 4" /> <w:LsdException Locked="false" Priority="48" Name="Grid Table 3 Accent 4" /> <w:LsdException Locked="false" Priority="49" Name="Grid Table 4 Accent 4" /> <w:LsdException Locked="false" Priority="50" Name="Grid Table 5 Dark Accent 4" /> <w:LsdException Locked="false" Priority="51"    Name="Grid Table 6 Colorful Accent 4" /> <w:LsdException Locked="false" Priority="52"    Name="Grid Table 7 Colorful Accent 4" /> <w:LsdException Locked="false" Priority="46"    Name="Grid Table 1 Light Accent 5" /> <w:LsdException Locked="false" Priority="47" Name="Grid Table 2 Accent 5" /> <w:LsdException Locked="false" Priority="48" Name="Grid Table 3 Accent 5" /> <w:LsdException Locked="false" Priority="49" Name="Grid Table 4 Accent 5" /> <w:LsdException Locked="false" Priority="50" Name="Grid Table 5 Dark Accent 5" /> <w:LsdException Locked="false" Priority="51"    Name="Grid Table 6 Colorful Accent 5" /> <w:LsdException Locked="false" Priority="52"    Name="Grid Table 7 Colorful Accent 5" /> <w:LsdException Locked="false" Priority="46"    Name="Grid Table 1 Light Accent 6" /> <w:LsdException Locked="false" Priority="47" Name="Grid Table 2 Accent 6" /> <w:LsdException Locked="false" Priority="48" Name="Grid Table 3 Accent 6" /> <w:LsdException Locked="false" Priority="49" Name="Grid Table 4 Accent 6" /> <w:LsdException Locked="false" Priority="50" Name="Grid Table 5 Dark Accent 6" /> <w:LsdException Locked="false" Priority="51"    Name="Grid Table 6 Colorful Accent 6" /> <w:LsdException Locked="false" Priority="52"    Name="Grid Table 7 Colorful Accent 6" /> <w:LsdException Locked="false" Priority="46" Name="List Table 1 Light" /> <w:LsdException Locked="false" Priority="47" Name="List Table 2" /> <w:LsdException Locked="false" Priority="48" Name="List Table 3" /> <w:LsdException Locked="false" Priority="49" Name="List Table 4" /> <w:LsdException Locked="false" Priority="50" Name="List Table 5 Dark" /> <w:LsdException Locked="false" Priority="51" Name="List Table 6 Colorful" /> <w:LsdException Locked="false" Priority="52" Name="List Table 7 Colorful" /> <w:LsdException Locked="false" Priority="46"    Name="List Table 1 Light Accent 1" /> <w:LsdException Locked="false" Priority="47" Name="List Table 2 Accent 1" /> <w:LsdException Locked="false" Priority="48" Name="List Table 3 Accent 1" /> <w:LsdException Locked="false" Priority="49" Name="List Table 4 Accent 1" /> <w:LsdException Locked="false" Priority="50" Name="List Table 5 Dark Accent 1" /> <w:LsdException Locked="false" Priority="51"    Name="List Table 6 Colorful Accent 1" /> <w:LsdException Locked="false" Priority="52"    Name="List Table 7 Colorful Accent 1" /> <w:LsdException Locked="false" Priority="46"    Name="List Table 1 Light Accent 2" /> <w:LsdException Locked="false" Priority="47" Name="List Table 2 Accent 2" /> <w:LsdException Locked="false" Priority="48" Name="List Table 3 Accent 2" /> <w:LsdException Locked="false" Priority="49" Name="List Table 4 Accent 2" /> <w:LsdException Locked="false" Priority="50" Name="List Table 5 Dark Accent 2" /> <w:LsdException Locked="false" Priority="51"    Name="List Table 6 Colorful Accent 2" /> <w:LsdException Locked="false" Priority="52"    Name="List Table 7 Colorful Accent 2" /> <w:LsdException Locked="false" Priority="46"    Name="List Table 1 Light Accent 3" /> <w:LsdException Locked="false" Priority="47" Name="List Table 2 Accent 3" /> <w:LsdException Locked="false" Priority="48" Name="List Table 3 Accent 3" /> <w:LsdException Locked="false" Priority="49" Name="List Table 4 Accent 3" /> <w:LsdException Locked="false" Priority="50" Name="List Table 5 Dark Accent 3" /> <w:LsdException Locked="false" Priority="51"    Name="List Table 6 Colorful Accent 3" /> <w:LsdException Locked="false" Priority="52"    Name="List Table 7 Colorful Accent 3" /> <w:LsdException Locked="false" Priority="46"    Name="List Table 1 Light Accent 4" /> <w:LsdException Locked="false" Priority="47" Name="List Table 2 Accent 4" /> <w:LsdException Locked="false" Priority="48" Name="List Table 3 Accent 4" /> <w:LsdException Locked="false" Priority="49" Name="List Table 4 Accent 4" /> <w:LsdException Locked="false" Priority="50" Name="List Table 5 Dark Accent 4" /> <w:LsdException Locked="false" Priority="51"    Name="List Table 6 Colorful Accent 4" /> <w:LsdException Locked="false" Priority="52"    Name="List Table 7 Colorful Accent 4" /> <w:LsdException Locked="false" Priority="46"    Name="List Table 1 Light Accent 5" /> <w:LsdException Locked="false" Priority="47" Name="List Table 2 Accent 5" /> <w:LsdException Locked="false" Priority="48" Name="List Table 3 Accent 5" /> <w:LsdException Locked="false" Priority="49" Name="List Table 4 Accent 5" /> <w:LsdException Locked="false" Priority="50" Name="List Table 5 Dark Accent 5" /> <w:LsdException Locked="false" Priority="51"    Name="List Table 6 Colorful Accent 5" /> <w:LsdException Locked="false" Priority="52"    Name="List Table 7 Colorful Accent 5" /> <w:LsdException Locked="false" Priority="46"    Name="List Table 1 Light Accent 6" /> <w:LsdException Locked="false" Priority="47" Name="List Table 2 Accent 6" /> <w:LsdException Locked="false" Priority="48" Name="List Table 3 Accent 6" /> <w:LsdException Locked="false" Priority="49" Name="List Table 4 Accent 6" /> <w:LsdException Locked="false" Priority="50" Name="List Table 5 Dark Accent 6" /> <w:LsdException Locked="false" Priority="51"    Name="List Table 6 Colorful Accent 6" /> <w:LsdException Locked="false" Priority="52"    Name="List Table 7 Colorful Accent 6" /> </w:LatentStyles> </xml><![endif]--><!--[if gte mso 10]> <mce:style><!   /* Style Definitions */  table.MsoNormalTable     {mso-style-name:"Vanlig tabell";     mso-tstyle-rowband-size:0;     mso-tstyle-colband-size:0;     mso-style-noshow:yes;     mso-style-priority:99;     mso-style-parent:"";     mso-padding-alt:0cm 5.4pt 0cm 5.4pt;     mso-para-margin:0cm;     mso-para-margin-bottom:.0001pt;     mso-pagination:widow-orphan;     font-size:10.0pt;     font-family:"Times New Roman",serif;     mso-bidi-language:NE;} -->
<!--[endif] --><span>-</span> en guide til idrettsgleden i Frisk
Asker Oldboys</p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p><strong>1.&nbsp;&nbsp;&nbsp; Å droppe oppvarming</strong><br />
 Oppvarming av lårmuskulaturen før kampen gjøres enten ved å stå og
skyte så hardt man klarer på mål, eller ved at én spiller slår
innlegg, som de andre mæler på direkten så hardt de klarer opp i
skogen.<br />
 15 minutter, så er vi klare.<br />
<br />
 <strong>2.&nbsp;&nbsp;&nbsp; Å ikke vite hvem motstanderlaget
er</strong><br />
 Når vi ser draktene, eller kjenner igjen banen, så skjønner vi det
jo, men før det aner vi ikke hvem vi skal spille mot.<br />
<br />
 <strong>3.&nbsp;&nbsp;&nbsp; Å ikke vite hvor vi ligger på
tabellen</strong><br />
 Skulle vi en sjelden gang av uforståelige grunner ligge veldig
godt an, så er det alltids en eller annen som har sett tabellen og
kan opplyse om det. Før det, vet ingen hvordan vi ligger an.<br />
<br />
 <strong>4.&nbsp;&nbsp;&nbsp; Det er ny mann i mål</strong><br />
 Den forrige som sto ble mest sannsynlig skada, eller så dukket
ikke den egentlige keeperen opp i tide fordi Liverpoolkampen på TV
ikke var ferdig.<br />
<br />
 <strong>5.&nbsp;&nbsp;&nbsp; Vi ligger under til
pause</strong><br />
 Siden vi alltid har vunnet kampen på forhånd, så starter vi ikke å
spille før vi skjønner at vi må.<br />
<br />
 <strong>6.&nbsp;&nbsp;&nbsp; Vi gjør ingen grep i
pausen</strong><br />
 Når vi står der med 0-2 i pausen, snakker alle i munnen på
hverandre om hva som er feil, men som er ting vi alle vet at vi
enten ikke <em>kan</em> gjøre noe med (vi må få opp presisjonen!),
eller er ting vi ikke <em>vil</em> gjøre noe med (vi må ta
returløpene!).<br />
<br />
 <strong>7.&nbsp;&nbsp;&nbsp; Vi trener ikke på noe</strong><br />
 Fotballtrening er fotballspill, ferdig med det.<br />
 Enten har man det morsomt med å spille, eller kjedelig med å trene
på et moment i spillet. Ordene i de to setningene kan ikke settes
sammen på noen annen måte.<br />
<br />
 <strong>8.&nbsp;&nbsp;&nbsp; Vi bytter ikke ut</strong><br />
 Jo flere innbyttere det er, jo lenger vil det bli til man får
komme innpå igjen.<br />
<br />
 <strong>9.&nbsp;&nbsp;&nbsp; Vi liker bedre å vinne enn å
tape</strong><br />
 Alle seire har utelukkende med vårt gode spill å gjøre, alle tap
har med uflaks å gjøre.<br />
<br />
 <strong>10.&nbsp;&nbsp;&nbsp; Vi gir oss aldri</strong><br />
 Gjennomtrekket i spillerstallen pr sesong, rundet av til nærmeste
femprosent, er 0.<br />
<br />
<br />
 Andre kjennetegn?</p>

<p>Legg dem til i kommentarfeltet.</p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<div
style="position: absolute; left: -10000px; top: 0px; width: 1px; height: 1px; overflow: hidden;"
 id="_mcePaste">
<!--[if gte mso 9]><xml> <o:OfficeDocumentSettings> <o:AllowPNG /> </o:OfficeDocumentSettings> </xml><![endif]-->
<p class="MsoNormal">10 ting som kjennetegner oldboysspillere</p>

<p class="MsoNormal">&nbsp;</p>

<p class="MsoNormal">Den ultimate guiden til idrettsgleden i Frisk
Asker Oldboys</p>

<p class="MsoNormal">&nbsp;</p>

<p class="MsoNormal">&nbsp;</p>

<p style="text-indent:-18.0pt;mso-list:l0 level1 lfo1"
class="MsoListParagraphCxSpFirst"><span>1. <span></span></span>Å
droppe oppvarming.</p>

<p class="MsoListParagraphCxSpMiddle">Oppvarming av lårmuskulaturen
gjøres ved enten å stå og skyte så hardt man kan på mål, eller at
én spiller slår innlegg, som de andre mæler til så hardt de kan på
direkten opp i skogen.</p>

<p class="MsoListParagraphCxSpMiddle">15 minutter, så er vi
klare.</p>

<p class="MsoListParagraphCxSpMiddle">&nbsp;</p>

<p style="text-indent:-18.0pt;mso-list:l0 level1 lfo1"
class="MsoListParagraphCxSpMiddle"><span>2. <span></span></span>Å
ikke vite hvem motstanderen er.</p>

<p class="MsoListParagraphCxSpMiddle">Når vi ser draktene, eller
kjenner igjen banen, så skjønner vi det jo, men før det aner vi
ikke hvem vi skal spille mot.</p>

<p class="MsoListParagraphCxSpMiddle">&nbsp;</p>

<p style="text-indent:-18.0pt;mso-list:l0 level1 lfo1"
class="MsoListParagraphCxSpMiddle"><span>3. <span></span></span>Å
ikke vite hvor vi ligger på tabellen.</p>

<p class="MsoListParagraphCxSpMiddle">Skulle vi en sjelden gang av
uforståelige grunner ligge veldig godt an, så er det alltids en
eller annen som har sett tabellen og kan opplyse om det. Før det,
vet ingen hvordan vi ligger an.</p>

<p class="MsoListParagraphCxSpMiddle">&nbsp;</p>

<p style="text-indent:-18.0pt;mso-list:l0 level1 lfo1"
class="MsoListParagraphCxSpMiddle"><span>4. <span></span></span>Det
er en ny mann i mål.</p>

<p class="MsoListParagraphCxSpMiddle">Den forrige keeperen ble mest
sannsynlig skada, eller så dukket ikke den egentlige keeperen opp i
tide fordi Liverpoolkampen på TV ikke var ferdig.</p>

<p class="MsoListParagraphCxSpMiddle">&nbsp;</p>

<p style="text-indent:-18.0pt;mso-list:l0 level1 lfo1"
class="MsoListParagraphCxSpMiddle"><span>5. <span></span></span>Vi
ligger under til pause.</p>

<p class="MsoListParagraphCxSpMiddle">Siden vi alltid har vunnet
kampen på forhånd, så starter vi ikke å spille før vi skjønner at
vi må.</p>

<p class="MsoListParagraphCxSpMiddle">&nbsp;</p>

<p style="text-indent:-18.0pt;mso-list:l0 level1 lfo1"
class="MsoListParagraphCxSpMiddle"><span>6. <span></span></span>Vi
gjør ingen grep i pausen.</p>

<p class="MsoListParagraphCxSpMiddle">Når vi står der med 0-2 i
pausen, snakker alle i munnen på hverandre om hva som er feil, men
som er ting vi alle vet at vi enten ikke <em
style="mso-bidi-font-style: normal;">kan gjøre noe med (vi må få
opp presisjonen!), eller er ting vi ikke <em
style="mso-bidi-font-style: normal;">vil gjøre noe med (vi må ta
returløpene!).</em></em></p>

<p class="MsoListParagraphCxSpMiddle"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"></em></em></em></em></em></em></em></em></em></em></em></em></em></em></p>

<p style="text-indent:-18.0pt;mso-list:l0 level1 lfo1"
class="MsoListParagraphCxSpMiddle"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><span>7.
<span></span></span>Vi trener ikke på
noe.</em></em></em></em></em></em></em></em></em></em></em></em></em></em></p>

<p class="MsoListParagraphCxSpMiddle"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;">Fotballtrening er
fotballspill, ferdig med det. Holdningen er at enten har man det
morsomt med å spille, eller kjedelig med å trene på et moment i
spillet. De to setningene kan ikke settes sammen på noen annen
måte.</em></em></em></em></em></em></em></em></em></em></em></em></em></p>

<p class="MsoListParagraphCxSpMiddle"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"></em></em></em></em></em></em></em></em></em></em></em></em></em></p>

<p style="text-indent:-18.0pt;mso-list:l0 level1 lfo1"
class="MsoListParagraphCxSpMiddle"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><span>8.
<span></span></span>Vi bytter ikke
ut.</em></em></em></em></em></em></em></em></em></em></em></em></em></p>

<p class="MsoListParagraphCxSpMiddle"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;">Jo flere innbyttere det er, jo
lenger vil det jo bli til man kommer innpå
igjen.</em></em></em></em></em></em></em></em></em></em></em></em></p>

<p class="MsoListParagraphCxSpMiddle"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"></em></em></em></em></em></em></em></em></em></em></em></em></p>

<p style="text-indent:-18.0pt;mso-list:l0 level1 lfo1"
class="MsoListParagraphCxSpMiddle"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><span>9.</span> Vi liker bedre
å vinne enn å
tape.</em></em></em></em></em></em></em></em></em></em></em></em></p>

<p class="MsoListParagraphCxSpMiddle"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;">Alle seire har utelukkende med
vårt gode spill å gjøre, alle tap har med uflaks å
gjøre.</em></em></em></em></em></em></em></em></em></em></em></p>

<p style="text-indent:-18.0pt;mso-list:l0 level1 lfo1"
class="MsoListParagraphCxSpMiddle"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><span>10.</span> Vi slutter
aldri.</em></em></em></em></em></em></em></em></em></em></em></p>

<p class="MsoListParagraphCxSpMiddle"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;">Gjennomtrekket i
spillerstallen pr sesong, rundet av til nærmeste femprosent, er
0.</em></em></em></em></em></em></em></em></em></em></p>

<p class="MsoListParagraphCxSpLast"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;">Andre kjennetegn?<br />
 Legg dem til i
kommentarfeltet.</em></em></em></em></em></em></em></em></em></em></p>

<em style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;"><em
style="mso-bidi-font-style: normal;">
<!--[if gte mso 9]><xml> <w:WordDocument> <w:View>Normal</w:View> <w:Zoom>0</w:Zoom> <w:TrackMoves /> <w:TrackFormatting /> <w:HyphenationZone>21</w:HyphenationZone> <w:PunctuationKerning /> <w:ValidateAgainstSchemas /> <w:SaveIfXMLInvalid>false</w:SaveIfXMLInvalid> <w:IgnoreMixedContent>false</w:IgnoreMixedContent> <w:AlwaysShowPlaceholderText>false</w:AlwaysShowPlaceholderText> <w:DoNotPromoteQF /> <w:LidThemeOther>NO-BOK</w:LidThemeOther> <w:LidThemeAsian>X-NONE</w:LidThemeAsian> <w:LidThemeComplexScript>NE</w:LidThemeComplexScript> <w:Compatibility> <w:BreakWrappedTables /> <w:SnapToGridInCell /> <w:WrapTextWithPunct /> <w:UseAsianBreakRules /> <w:DontGrowAutofit /> <w:SplitPgBreakAndParaMark /> <w:EnableOpenTypeKerning /> <w:DontFlipMirrorIndents /> <w:OverrideTableStyleHps /> </w:Compatibility> <m:mathPr> <m:mathFont m:val="Cambria Math" /> <m:brkBin m:val="before" /> <m:brkBinSub m:val="&#45;-" /> <m:smallFrac m:val="off" /> <m:dispDef /> <m:lMargin m:val="0" /> <m:rMargin m:val="0" /> <m:defJc m:val="centerGroup" /> <m:wrapIndent m:val="1440" /> <m:intLim m:val="subSup" /> <m:naryLim m:val="undOvr" /> </m:mathPr></w:WordDocument> </xml><![endif]--><!--[if gte mso 9]><xml> <w:LatentStyles DefLockedState="false" DefUnhideWhenUsed="false"   DefSemiHidden="false" DefQFormat="false" DefPriority="99"   LatentStyleCount="371"> <w:LsdException Locked="false" Priority="0" QFormat="true" Name="Normal" /> <w:LsdException Locked="false" Priority="9" QFormat="true" Name="heading 1" /> <w:LsdException Locked="false" Priority="9" SemiHidden="true"    UnhideWhenUsed="true" QFormat="true" Name="heading 2" /> <w:LsdException Locked="false" Priority="9" SemiHidden="true"    UnhideWhenUsed="true" QFormat="true" Name="heading 3" /> <w:LsdException Locked="false" Priority="9" SemiHidden="true"    UnhideWhenUsed="true" QFormat="true" Name="heading 4" /> <w:LsdException Locked="false" Priority="9" SemiHidden="true"    UnhideWhenUsed="true" QFormat="true" Name="heading 5" /> <w:LsdException Locked="false" Priority="9" SemiHidden="true"    UnhideWhenUsed="true" QFormat="true" Name="heading 6" /> <w:LsdException Locked="false" Priority="9" SemiHidden="true"    UnhideWhenUsed="true" QFormat="true" Name="heading 7" /> <w:LsdException Locked="false" Priority="9" SemiHidden="true"    UnhideWhenUsed="true" QFormat="true" Name="heading 8" /> <w:LsdException Locked="false" Priority="9" SemiHidden="true"    UnhideWhenUsed="true" QFormat="true" Name="heading 9" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="index 1" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="index 2" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="index 3" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="index 4" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="index 5" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="index 6" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="index 7" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="index 8" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="index 9" /> <w:LsdException Locked="false" Priority="39" SemiHidden="true"    UnhideWhenUsed="true" Name="toc 1" /> <w:LsdException Locked="false" Priority="39" SemiHidden="true"    UnhideWhenUsed="true" Name="toc 2" /> <w:LsdException Locked="false" Priority="39" SemiHidden="true"    UnhideWhenUsed="true" Name="toc 3" /> <w:LsdException Locked="false" Priority="39" SemiHidden="true"    UnhideWhenUsed="true" Name="toc 4" /> <w:LsdException Locked="false" Priority="39" SemiHidden="true"    UnhideWhenUsed="true" Name="toc 5" /> <w:LsdException Locked="false" Priority="39" SemiHidden="true"    UnhideWhenUsed="true" Name="toc 6" /> <w:LsdException Locked="false" Priority="39" SemiHidden="true"    UnhideWhenUsed="true" Name="toc 7" /> <w:LsdException Locked="false" Priority="39" SemiHidden="true"    UnhideWhenUsed="true" Name="toc 8" /> <w:LsdException Locked="false" Priority="39" SemiHidden="true"    UnhideWhenUsed="true" Name="toc 9" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Normal Indent" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="footnote text" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="annotation text" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="header" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="footer" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="index heading" /> <w:LsdException Locked="false" Priority="35" SemiHidden="true"    UnhideWhenUsed="true" QFormat="true" Name="caption" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="table of figures" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="envelope address" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="envelope return" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="footnote reference" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="annotation reference" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="line number" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="page number" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="endnote reference" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="endnote text" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="table of authorities" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="macro" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="toa heading" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="List" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="List Bullet" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="List Number" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="List 2" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="List 3" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="List 4" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="List 5" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="List Bullet 2" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="List Bullet 3" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="List Bullet 4" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="List Bullet 5" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="List Number 2" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="List Number 3" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="List Number 4" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="List Number 5" /> <w:LsdException Locked="false" Priority="10" QFormat="true" Name="Title" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Closing" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Signature" /> <w:LsdException Locked="false" Priority="1" SemiHidden="true"    UnhideWhenUsed="true" Name="Default Paragraph Font" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Body Text" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Body Text Indent" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="List Continue" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="List Continue 2" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="List Continue 3" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="List Continue 4" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="List Continue 5" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Message Header" /> <w:LsdException Locked="false" Priority="11" QFormat="true" Name="Subtitle" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Salutation" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Date" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Body Text First Indent" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Body Text First Indent 2" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Note Heading" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Body Text 2" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Body Text 3" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Body Text Indent 2" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Body Text Indent 3" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Block Text" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Hyperlink" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="FollowedHyperlink" /> <w:LsdException Locked="false" Priority="22" QFormat="true" Name="Strong" /> <w:LsdException Locked="false" Priority="20" QFormat="true" Name="Emphasis" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Document Map" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Plain Text" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="E-mail Signature" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="HTML Top of Form" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="HTML Bottom of Form" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Normal (Web)" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="HTML Acronym" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="HTML Address" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="HTML Cite" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="HTML Code" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="HTML Definition" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="HTML Keyboard" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="HTML Preformatted" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="HTML Sample" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="HTML Typewriter" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="HTML Variable" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Normal Table" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="annotation subject" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="No List" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Outline List 1" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Outline List 2" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Outline List 3" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Table Simple 1" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Table Simple 2" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Table Simple 3" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Table Classic 1" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Table Classic 2" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Table Classic 3" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Table Classic 4" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Table Colorful 1" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Table Colorful 2" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Table Colorful 3" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Table Columns 1" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Table Columns 2" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Table Columns 3" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Table Columns 4" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Table Columns 5" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Table Grid 1" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Table Grid 2" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Table Grid 3" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Table Grid 4" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Table Grid 5" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Table Grid 6" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Table Grid 7" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Table Grid 8" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Table List 1" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Table List 2" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Table List 3" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Table List 4" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Table List 5" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Table List 6" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Table List 7" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Table List 8" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Table 3D effects 1" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Table 3D effects 2" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Table 3D effects 3" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Table Contemporary" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Table Elegant" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Table Professional" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Table Subtle 1" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Table Subtle 2" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Table Web 1" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Table Web 2" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Table Web 3" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Balloon Text" /> <w:LsdException Locked="false" Priority="39" Name="Table Grid" /> <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"    Name="Table Theme" /> <w:LsdException Locked="false" SemiHidden="true" Name="Placeholder Text" /> <w:LsdException Locked="false" Priority="1" QFormat="true" Name="No Spacing" /> <w:LsdException Locked="false" Priority="60" Name="Light Shading" /> <w:LsdException Locked="false" Priority="61" Name="Light List" /> <w:LsdException Locked="false" Priority="62" Name="Light Grid" /> <w:LsdException Locked="false" Priority="63" Name="Medium Shading 1" /> <w:LsdException Locked="false" Priority="64" Name="Medium Shading 2" /> <w:LsdException Locked="false" Priority="65" Name="Medium List 1" /> <w:LsdException Locked="false" Priority="66" Name="Medium List 2" /> <w:LsdException Locked="false" Priority="67" Name="Medium Grid 1" /> <w:LsdException Locked="false" Priority="68" Name="Medium Grid 2" /> <w:LsdException Locked="false" Priority="69" Name="Medium Grid 3" /> <w:LsdException Locked="false" Priority="70" Name="Dark List" /> <w:LsdException Locked="false" Priority="71" Name="Colorful Shading" /> <w:LsdException Locked="false" Priority="72" Name="Colorful List" /> <w:LsdException Locked="false" Priority="73" Name="Colorful Grid" /> <w:LsdException Locked="false" Priority="60" Name="Light Shading Accent 1" /> <w:LsdException Locked="false" Priority="61" Name="Light List Accent 1" /> <w:LsdException Locked="false" Priority="62" Name="Light Grid Accent 1" /> <w:LsdException Locked="false" Priority="63" Name="Medium Shading 1 Accent 1" /> <w:LsdException Locked="false" Priority="64" Name="Medium Shading 2 Accent 1" /> <w:LsdException Locked="false" Priority="65" Name="Medium List 1 Accent 1" /> <w:LsdException Locked="false" SemiHidden="true" Name="Revision" /> <w:LsdException Locked="false" Priority="34" QFormat="true"    Name="List Paragraph" /> <w:LsdException Locked="false" Priority="29" QFormat="true" Name="Quote" /> <w:LsdException Locked="false" Priority="30" QFormat="true"    Name="Intense Quote" /> <w:LsdException Locked="false" Priority="66" Name="Medium List 2 Accent 1" /> <w:LsdException Locked="false" Priority="67" Name="Medium Grid 1 Accent 1" /> <w:LsdException Locked="false" Priority="68" Name="Medium Grid 2 Accent 1" /> <w:LsdException Locked="false" Priority="69" Name="Medium Grid 3 Accent 1" /> <w:LsdException Locked="false" Priority="70" Name="Dark List Accent 1" /> <w:LsdException Locked="false" Priority="71" Name="Colorful Shading Accent 1" /> <w:LsdException Locked="false" Priority="72" Name="Colorful List Accent 1" /> <w:LsdException Locked="false" Priority="73" Name="Colorful Grid Accent 1" /> <w:LsdException Locked="false" Priority="60" Name="Light Shading Accent 2" /> <w:LsdException Locked="false" Priority="61" Name="Light List Accent 2" /> <w:LsdException Locked="false" Priority="62" Name="Light Grid Accent 2" /> <w:LsdException Locked="false" Priority="63" Name="Medium Shading 1 Accent 2" /> <w:LsdException Locked="false" Priority="64" Name="Medium Shading 2 Accent 2" /> <w:LsdException Locked="false" Priority="65" Name="Medium List 1 Accent 2" /> <w:LsdException Locked="false" Priority="66" Name="Medium List 2 Accent 2" /> <w:LsdException Locked="false" Priority="67" Name="Medium Grid 1 Accent 2" /> <w:LsdException Locked="false" Priority="68" Name="Medium Grid 2 Accent 2" /> <w:LsdException Locked="false" Priority="69" Name="Medium Grid 3 Accent 2" /> <w:LsdException Locked="false" Priority="70" Name="Dark List Accent 2" /> <w:LsdException Locked="false" Priority="71" Name="Colorful Shading Accent 2" /> <w:LsdException Locked="false" Priority="72" Name="Colorful List Accent 2" /> <w:LsdException Locked="false" Priority="73" Name="Colorful Grid Accent 2" /> <w:LsdException Locked="false" Priority="60" Name="Light Shading Accent 3" /> <w:LsdException Locked="false" Priority="61" Name="Light List Accent 3" /> <w:LsdException Locked="false" Priority="62" Name="Light Grid Accent 3" /> <w:LsdException Locked="false" Priority="63" Name="Medium Shading 1 Accent 3" /> <w:LsdException Locked="false" Priority="64" Name="Medium Shading 2 Accent 3" /> <w:LsdException Locked="false" Priority="65" Name="Medium List 1 Accent 3" /> <w:LsdException Locked="false" Priority="66" Name="Medium List 2 Accent 3" /> <w:LsdException Locked="false" Priority="67" Name="Medium Grid 1 Accent 3" /> <w:LsdException Locked="false" Priority="68" Name="Medium Grid 2 Accent 3" /> <w:LsdException Locked="false" Priority="69" Name="Medium Grid 3 Accent 3" /> <w:LsdException Locked="false" Priority="70" Name="Dark List Accent 3" /> <w:LsdException Locked="false" Priority="71" Name="Colorful Shading Accent 3" /> <w:LsdException Locked="false" Priority="72" Name="Colorful List Accent 3" /> <w:LsdException Locked="false" Priority="73" Name="Colorful Grid Accent 3" /> <w:LsdException Locked="false" Priority="60" Name="Light Shading Accent 4" /> <w:LsdException Locked="false" Priority="61" Name="Light List Accent 4" /> <w:LsdException Locked="false" Priority="62" Name="Light Grid Accent 4" /> <w:LsdException Locked="false" Priority="63" Name="Medium Shading 1 Accent 4" /> <w:LsdException Locked="false" Priority="64" Name="Medium Shading 2 Accent 4" /> <w:LsdException Locked="false" Priority="65" Name="Medium List 1 Accent 4" /> <w:LsdException Locked="false" Priority="66" Name="Medium List 2 Accent 4" /> <w:LsdException Locked="false" Priority="67" Name="Medium Grid 1 Accent 4" /> <w:LsdException Locked="false" Priority="68" Name="Medium Grid 2 Accent 4" /> <w:LsdException Locked="false" Priority="69" Name="Medium Grid 3 Accent 4" /> <w:LsdException Locked="false" Priority="70" Name="Dark List Accent 4" /> <w:LsdException Locked="false" Priority="71" Name="Colorful Shading Accent 4" /> <w:LsdException Locked="false" Priority="72" Name="Colorful List Accent 4" /> <w:LsdException Locked="false" Priority="73" Name="Colorful Grid Accent 4" /> <w:LsdException Locked="false" Priority="60" Name="Light Shading Accent 5" /> <w:LsdException Locked="false" Priority="61" Name="Light List Accent 5" /> <w:LsdException Locked="false" Priority="62" Name="Light Grid Accent 5" /> <w:LsdException Locked="false" Priority="63" Name="Medium Shading 1 Accent 5" /> <w:LsdException Locked="false" Priority="64" Name="Medium Shading 2 Accent 5" /> <w:LsdException Locked="false" Priority="65" Name="Medium List 1 Accent 5" /> <w:LsdException Locked="false" Priority="66" Name="Medium List 2 Accent 5" /> <w:LsdException Locked="false" Priority="67" Name="Medium Grid 1 Accent 5" /> <w:LsdException Locked="false" Priority="68" Name="Medium Grid 2 Accent 5" /> <w:LsdException Locked="false" Priority="69" Name="Medium Grid 3 Accent 5" /> <w:LsdException Locked="false" Priority="70" Name="Dark List Accent 5" /> <w:LsdException Locked="false" Priority="71" Name="Colorful Shading Accent 5" /> <w:LsdException Locked="false" Priority="72" Name="Colorful List Accent 5" /> <w:LsdException Locked="false" Priority="73" Name="Colorful Grid Accent 5" /> <w:LsdException Locked="false" Priority="60" Name="Light Shading Accent 6" /> <w:LsdException Locked="false" Priority="61" Name="Light List Accent 6" /> <w:LsdException Locked="false" Priority="62" Name="Light Grid Accent 6" /> <w:LsdException Locked="false" Priority="63" Name="Medium Shading 1 Accent 6" /> <w:LsdException Locked="false" Priority="64" Name="Medium Shading 2 Accent 6" /> <w:LsdException Locked="false" Priority="65" Name="Medium List 1 Accent 6" /> <w:LsdException Locked="false" Priority="66" Name="Medium List 2 Accent 6" /> <w:LsdException Locked="false" Priority="67" Name="Medium Grid 1 Accent 6" /> <w:LsdException Locked="false" Priority="68" Name="Medium Grid 2 Accent 6" /> <w:LsdException Locked="false" Priority="69" Name="Medium Grid 3 Accent 6" /> <w:LsdException Locked="false" Priority="70" Name="Dark List Accent 6" /> <w:LsdException Locked="false" Priority="71" Name="Colorful Shading Accent 6" /> <w:LsdException Locked="false" Priority="72" Name="Colorful List Accent 6" /> <w:LsdException Locked="false" Priority="73" Name="Colorful Grid Accent 6" /> <w:LsdException Locked="false" Priority="19" QFormat="true"    Name="Subtle Emphasis" /> <w:LsdException Locked="false" Priority="21" QFormat="true"    Name="Intense Emphasis" /> <w:LsdException Locked="false" Priority="31" QFormat="true"    Name="Subtle Reference" /> <w:LsdException Locked="false" Priority="32" QFormat="true"    Name="Intense Reference" /> <w:LsdException Locked="false" Priority="33" QFormat="true" Name="Book Title" /> <w:LsdException Locked="false" Priority="37" SemiHidden="true"    UnhideWhenUsed="true" Name="Bibliography" /> <w:LsdException Locked="false" Priority="39" SemiHidden="true"    UnhideWhenUsed="true" QFormat="true" Name="TOC Heading" /> <w:LsdException Locked="false" Priority="41" Name="Plain Table 1" /> <w:LsdException Locked="false" Priority="42" Name="Plain Table 2" /> <w:LsdException Locked="false" Priority="43" Name="Plain Table 3" /> <w:LsdException Locked="false" Priority="44" Name="Plain Table 4" /> <w:LsdException Locked="false" Priority="45" Name="Plain Table 5" /> <w:LsdException Locked="false" Priority="40" Name="Grid Table Light" /> <w:LsdException Locked="false" Priority="46" Name="Grid Table 1 Light" /> <w:LsdException Locked="false" Priority="47" Name="Grid Table 2" /> <w:LsdException Locked="false" Priority="48" Name="Grid Table 3" /> <w:LsdException Locked="false" Priority="49" Name="Grid Table 4" /> <w:LsdException Locked="false" Priority="50" Name="Grid Table 5 Dark" /> <w:LsdException Locked="false" Priority="51" Name="Grid Table 6 Colorful" /> <w:LsdException Locked="false" Priority="52" Name="Grid Table 7 Colorful" /> <w:LsdException Locked="false" Priority="46"    Name="Grid Table 1 Light Accent 1" /> <w:LsdException Locked="false" Priority="47" Name="Grid Table 2 Accent 1" /> <w:LsdException Locked="false" Priority="48" Name="Grid Table 3 Accent 1" /> <w:LsdException Locked="false" Priority="49" Name="Grid Table 4 Accent 1" /> <w:LsdException Locked="false" Priority="50" Name="Grid Table 5 Dark Accent 1" /> <w:LsdException Locked="false" Priority="51"    Name="Grid Table 6 Colorful Accent 1" /> <w:LsdException Locked="false" Priority="52"    Name="Grid Table 7 Colorful Accent 1" /> <w:LsdException Locked="false" Priority="46"    Name="Grid Table 1 Light Accent 2" /> <w:LsdException Locked="false" Priority="47" Name="Grid Table 2 Accent 2" /> <w:LsdException Locked="false" Priority="48" Name="Grid Table 3 Accent 2" /> <w:LsdException Locked="false" Priority="49" Name="Grid Table 4 Accent 2" /> <w:LsdException Locked="false" Priority="50" Name="Grid Table 5 Dark Accent 2" /> <w:LsdException Locked="false" Priority="51"    Name="Grid Table 6 Colorful Accent 2" /> <w:LsdException Locked="false" Priority="52"    Name="Grid Table 7 Colorful Accent 2" /> <w:LsdException Locked="false" Priority="46"    Name="Grid Table 1 Light Accent 3" /> <w:LsdException Locked="false" Priority="47" Name="Grid Table 2 Accent 3" /> <w:LsdException Locked="false" Priority="48" Name="Grid Table 3 Accent 3" /> <w:LsdException Locked="false" Priority="49" Name="Grid Table 4 Accent 3" /> <w:LsdException Locked="false" Priority="50" Name="Grid Table 5 Dark Accent 3" /> <w:LsdException Locked="false" Priority="51"    Name="Grid Table 6 Colorful Accent 3" /> <w:LsdException Locked="false" Priority="52"    Name="Grid Table 7 Colorful Accent 3" /> <w:LsdException Locked="false" Priority="46"    Name="Grid Table 1 Light Accent 4" /> <w:LsdException Locked="false" Priority="47" Name="Grid Table 2 Accent 4" /> <w:LsdException Locked="false" Priority="48" Name="Grid Table 3 Accent 4" /> <w:LsdException Locked="false" Priority="49" Name="Grid Table 4 Accent 4" /> <w:LsdException Locked="false" Priority="50" Name="Grid Table 5 Dark Accent 4" /> <w:LsdException Locked="false" Priority="51"    Name="Grid Table 6 Colorful Accent 4" /> <w:LsdException Locked="false" Priority="52"    Name="Grid Table 7 Colorful Accent 4" /> <w:LsdException Locked="false" Priority="46"    Name="Grid Table 1 Light Accent 5" /> <w:LsdException Locked="false" Priority="47" Name="Grid Table 2 Accent 5" /> <w:LsdException Locked="false" Priority="48" Name="Grid Table 3 Accent 5" /> <w:LsdException Locked="false" Priority="49" Name="Grid Table 4 Accent 5" /> <w:LsdException Locked="false" Priority="50" Name="Grid Table 5 Dark Accent 5" /> <w:LsdException Locked="false" Priority="51"    Name="Grid Table 6 Colorful Accent 5" /> <w:LsdException Locked="false" Priority="52"    Name="Grid Table 7 Colorful Accent 5" /> <w:LsdException Locked="false" Priority="46"    Name="Grid Table 1 Light Accent 6" /> <w:LsdException Locked="false" Priority="47" Name="Grid Table 2 Accent 6" /> <w:LsdException Locked="false" Priority="48" Name="Grid Table 3 Accent 6" /> <w:LsdException Locked="false" Priority="49" Name="Grid Table 4 Accent 6" /> <w:LsdException Locked="false" Priority="50" Name="Grid Table 5 Dark Accent 6" /> <w:LsdException Locked="false" Priority="51"    Name="Grid Table 6 Colorful Accent 6" /> <w:LsdException Locked="false" Priority="52"    Name="Grid Table 7 Colorful Accent 6" /> <w:LsdException Locked="false" Priority="46" Name="List Table 1 Light" /> <w:LsdException Locked="false" Priority="47" Name="List Table 2" /> <w:LsdException Locked="false" Priority="48" Name="List Table 3" /> <w:LsdException Locked="false" Priority="49" Name="List Table 4" /> <w:LsdException Locked="false" Priority="50" Name="List Table 5 Dark" /> <w:LsdException Locked="false" Priority="51" Name="List Table 6 Colorful" /> <w:LsdException Locked="false" Priority="52" Name="List Table 7 Colorful" /> <w:LsdException Locked="false" Priority="46"    Name="List Table 1 Light Accent 1" /> <w:LsdException Locked="false" Priority="47" Name="List Table 2 Accent 1" /> <w:LsdException Locked="false" Priority="48" Name="List Table 3 Accent 1" /> <w:LsdException Locked="false" Priority="49" Name="List Table 4 Accent 1" /> <w:LsdException Locked="false" Priority="50" Name="List Table 5 Dark Accent 1" /> <w:LsdException Locked="false" Priority="51"    Name="List Table 6 Colorful Accent 1" /> <w:LsdException Locked="false" Priority="52"    Name="List Table 7 Colorful Accent 1" /> <w:LsdException Locked="false" Priority="46"    Name="List Table 1 Light Accent 2" /> <w:LsdException Locked="false" Priority="47" Name="List Table 2 Accent 2" /> <w:LsdException Locked="false" Priority="48" Name="List Table 3 Accent 2" /> <w:LsdException Locked="false" Priority="49" Name="List Table 4 Accent 2" /> <w:LsdException Locked="false" Priority="50" Name="List Table 5 Dark Accent 2" /> <w:LsdException Locked="false" Priority="51"    Name="List Table 6 Colorful Accent 2" /> <w:LsdException Locked="false" Priority="52"    Name="List Table 7 Colorful Accent 2" /> <w:LsdException Locked="false" Priority="46"    Name="List Table 1 Light Accent 3" /> <w:LsdException Locked="false" Priority="47" Name="List Table 2 Accent 3" /> <w:LsdException Locked="false" Priority="48" Name="List Table 3 Accent 3" /> <w:LsdException Locked="false" Priority="49" Name="List Table 4 Accent 3" /> <w:LsdException Locked="false" Priority="50" Name="List Table 5 Dark Accent 3" /> <w:LsdException Locked="false" Priority="51"    Name="List Table 6 Colorful Accent 3" /> <w:LsdException Locked="false" Priority="52"    Name="List Table 7 Colorful Accent 3" /> <w:LsdException Locked="false" Priority="46"    Name="List Table 1 Light Accent 4" /> <w:LsdException Locked="false" Priority="47" Name="List Table 2 Accent 4" /> <w:LsdException Locked="false" Priority="48" Name="List Table 3 Accent 4" /> <w:LsdException Locked="false" Priority="49" Name="List Table 4 Accent 4" /> <w:LsdException Locked="false" Priority="50" Name="List Table 5 Dark Accent 4" /> <w:LsdException Locked="false" Priority="51"    Name="List Table 6 Colorful Accent 4" /> <w:LsdException Locked="false" Priority="52"    Name="List Table 7 Colorful Accent 4" /> <w:LsdException Locked="false" Priority="46"    Name="List Table 1 Light Accent 5" /> <w:LsdException Locked="false" Priority="47" Name="List Table 2 Accent 5" /> <w:LsdException Locked="false" Priority="48" Name="List Table 3 Accent 5" /> <w:LsdException Locked="false" Priority="49" Name="List Table 4 Accent 5" /> <w:LsdException Locked="false" Priority="50" Name="List Table 5 Dark Accent 5" /> <w:LsdException Locked="false" Priority="51"    Name="List Table 6 Colorful Accent 5" /> <w:LsdException Locked="false" Priority="52"    Name="List Table 7 Colorful Accent 5" /> <w:LsdException Locked="false" Priority="46"    Name="List Table 1 Light Accent 6" /> <w:LsdException Locked="false" Priority="47" Name="List Table 2 Accent 6" /> <w:LsdException Locked="false" Priority="48" Name="List Table 3 Accent 6" /> <w:LsdException Locked="false" Priority="49" Name="List Table 4 Accent 6" /> <w:LsdException Locked="false" Priority="50" Name="List Table 5 Dark Accent 6" /> <w:LsdException Locked="false" Priority="51"    Name="List Table 6 Colorful Accent 6" /> <w:LsdException Locked="false" Priority="52"    Name="List Table 7 Colorful Accent 6" /> </w:LatentStyles> </xml><![endif]--><!--[if gte mso 10]> <mce:style><!   /* Style Definitions */  table.MsoNormalTable    {mso-style-name:"Vanlig tabell";    mso-tstyle-rowband-size:0;  mso-tstyle-colband-size:0;  mso-style-noshow:yes;   mso-style-priority:99;  mso-style-parent:"";    mso-padding-alt:0cm 5.4pt 0cm 5.4pt;    mso-para-margin:0cm;    mso-para-margin-bottom:.0001pt;     mso-pagination:widow-orphan;    font-size:10.0pt;   font-family:"Times New Roman",serif;    mso-bidi-language:NE;} --><!--[endif] --></em></em></em></em></em></em></em></em></em></em></em></em></em></em></em></em></em></em></em></em></em></em></em></em></div>



<div class="addthis_toolbox addthis_default_style">
<a href="http://www.addthis.com/bookmark.php?v=250&amp;username=xa-4be09cd0025b8da5" class="addthis_button_compact">Share</a>
<span class="addthis_separator">|</span>
<a class="addthis_button_facebook"></a>
<a class="addthis_button_myspace"></a>
<a class="addthis_button_google"></a>
<a class="addthis_button_twitter"></a>
</div>
<script type="text/javascript" src="http://s7.addthis.com/js/250/addthis_widget.js#username=xa-4be09cd0025b8da5"></script>
<!-- AddThis Button END -->

<hr>
<h2>Kommentarer:</h2>
	<div class="newsitem"><i><b>13.01.18 18:53 - <a href="mailto:">Figo</a></b></i><p>Samtlige spillere har bedre syn og hørsel enn dommer’n ...</p></div><div class="newsitem"><i><b>14.01.18 9:54 - <a href="mailto:">Sunny</a></b></i><p>Innbytterne har alle svar på hva som er galt og hvordan vi skal spille bedre. Helt inntil de selv er byttet innpå</p></div><div class="newsitem"><i><b>02.03.18 14:55 - <a href="mailto:">StianK</a></b></i><p>Alle holder track på stillingen i kampen når de har vært innpå (gitt at det er i egen favør) </p></div><div class="newsitem"><i><b>17.04.18 10:46 - <a href="mailto:">Ardiles</a></b></i><p>Når man bytter ut får man alltid spørsmålet "Hvor spiller du?"av spilleren som bytter inn, og man svarer feil.</p></div><div class="newsitem"><i><b>12.09.18 14:46 - <a href="mailto:espens.skyseth.olsen@tnt.no">Espen</a></b></i><p>Denne var så nydelig at den frekt nok er stjålet til Holmen +40 sin nettside. Takk ! Vårt kjennetegn er at det ALDRI finnes noe som er ferdigscora. Ballen skal dyttes de siste 20cm over linja, og overaskende ofte viser det seg vanskelig(les:umulig).</p></div>
<!--
<p>
<b>Kommentering er midlertidig steng pga SPAM!</b>
</p>
-->
<form method="post" action="10-ting-som-kjennetegner-oldboysspillere.aspx" id="aspnetForm">
<div>
<input type="hidden" name="__EVENTTARGET" id="__EVENTTARGET" value="" />
<input type="hidden" name="__EVENTARGUMENT" id="__EVENTARGUMENT" value="" />
<input type="hidden" name="__VIEWSTATE" id="__VIEWSTATE" value="/wEPDwUENTM4MQ9kFgJmD2QWAmYPZBYCZg9kFgJmD2QWAgIPD2QWAgIFD2QWAgIBD2QWAmYPZBYCAgIPZBYCAgEPFgIeBFRleHQFF0RpbiBrb21tZW50YXIgZXIgcG9zdGV0ZGTP3+kahhm7HkFLDJ1eDASlO9mxvA==" />
</div>

<script type="text/javascript">
//<![CDATA[
var theForm = document.forms['aspnetForm'];
if (!theForm) {
    theForm = document.aspnetForm;
}
function __doPostBack(eventTarget, eventArgument) {
    if (!theForm.onsubmit || (theForm.onsubmit() != false)) {
        theForm.__EVENTTARGET.value = eventTarget;
        theForm.__EVENTARGUMENT.value = eventArgument;
        theForm.submit();
    }
}
//]]>
</script>


<script src="/WebResource.axd?d=RhJRe7vAQjxLvd0VTiPlJ3ItrtWKNnlC5ndUOdQ1oQE84Jw0mmyu8t9423FKr6Sh25O1JfgygCRLDXncXNuX2rijfWY1&amp;t=635737087099672665" type="text/javascript"></script>


<script type="text/javascript">
//<![CDATA[
function insertLink(element) {var theLink = prompt('Enter URL for link here:','http://');insertTag(element, 'a', ' href="' + theLink + '"')}
            function insertTag(element, tag, param) {
            start = '<' + tag + param + '>';
            eind = '</' + tag + '>';
             /* element = document.getElementById(element); */
              if (document.selection) {
                element.focus();
                sel = document.selection.createRange();
                sel.text = start + sel.text + eind;
              } else if (element.selectionStart || element.selectionStart == '0') {
                element.focus();
                var startPos = element.selectionStart;
                var endPos = element.selectionEnd;
                element.value = element.value.substring(0, startPos) + start + element.value.substring(startPos, endPos) + eind + element.value.substring(endPos, element.value.length);
              } else {
                element.value += start + eind;
              }
            }
            //]]>
</script>

<h2>Post en kommentar:</h2>
<div id="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_PanelInput">
	
	<div id="umbracoAutoForm">
	
  <fieldset>
			<p><label for="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_navn">Navn:</label><input name="ctl00$ctl00$ctl00$ContentPlaceHolderDefault$MainContentPlaceHolder$AutoForm_7$navn" type="text" id="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_navn" class="umbEditorTextField" /></p><p><label for="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_epost">Epost:</label><input name="ctl00$ctl00$ctl00$ContentPlaceHolderDefault$MainContentPlaceHolder$AutoForm_7$epost" type="text" id="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_epost" class="umbEditorTextField" /></p><p><label for="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_kommentar">Kommentar:</label><table border="0" cellspacing="0" cellpadding="0"><tr><td>
	<p align="right" style="margin: 0px; padding:0px"><a href="javascript:insertLink(document.getElementById('ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_kommentar'))"><img src="/umbraco_client/simpleEditor/images/link.gif" border="0" align="right" /></a><a href="javascript:insertTag(document.getElementById('ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_kommentar'), 'em', '')"><img src="/umbraco_client/simpleEditor/images/italic.gif" border="0" style="margin-left: 3px; margin-right: 3px;" align="right" /></a> <a href="javascript:insertTag(document.getElementById('ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_kommentar'), 'strong', '')"><img src="/umbraco_client/simpleEditor/images/bold.gif" border="0" align="right" /></a><br/></p>
	<textarea name="ctl00$ctl00$ctl00$ContentPlaceHolderDefault$MainContentPlaceHolder$AutoForm_7$kommentar" rows="8" cols="20" id="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_kommentar" class="umbEditorTextField"></textarea></td></tr></table>
	</p><p><label for="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_captcha">Captcha:</label><input name="ctl00$ctl00$ctl00$ContentPlaceHolderDefault$MainContentPlaceHolder$AutoForm_7$captcha" type="text" id="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_captcha" class="umbEditorNumberField" /><br/><span class="umbracoAutoFormRowDescription">Hva er elleve pluss åtte?<br/></span></p>
		<p><input type="submit" name="ctl00$ctl00$ctl00$ContentPlaceHolderDefault$MainContentPlaceHolder$AutoForm_7$Button1" value="Post kommentar" onclick="javascript:WebForm_DoPostBackWithOptions(new WebForm_PostBackOptions(&quot;ctl00$ctl00$ctl00$ContentPlaceHolderDefault$MainContentPlaceHolder$AutoForm_7$Button1&quot;, &quot;&quot;, true, &quot;&quot;, &quot;&quot;, false, false))" id="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_Button1" class="umbracoAutoFormButton" /></p>
	</fieldset>		
	</div>

</div>

		

<div>

	<input type="hidden" name="__VIEWSTATEGENERATOR" id="__VIEWSTATEGENERATOR" value="CA0B0334" />
</div></form>

<a class="readmore" href="/arkiv/2021/frisk-asker---covid-19-19-.aspx">Frisk Asker - Covid 19-19 </a> - 17.03.2021 8:41<br /><a class="readmore" href="/arkiv/2016/faos-sommerkrim.aspx">FAOs sommerkrim</a> - 29.04.2020 12:32<br /><a class="readmore" href="/arkiv/2019/fao-med-kupp-paa-overgangsmarkedet!.aspx">FAO med kupp på overgangsmarkedet!</a> - 30.07.2019 19:24<br /><a class="readmore" href="/arkiv/2019/dag-ansatt-som-fast-lagleder-paa-frisk-asker-m33.aspx">Dag ansatt som fast lagleder på Frisk Asker M33</a> - 29.07.2019 12:28<br /><a class="readmore" href="/arkiv/2019/askermesterskapet-i-oldboysfotball.aspx">Askermesterskapet i oldboysfotball</a> - 07.05.2019 16:49<br /><a class="readmore" href="/arkiv/2019/frisk-asker-oldgirls!.aspx">Frisk Asker OldGIRLS!</a> - 05.04.2019 14:14<br /><a class="readmore" href="/arkiv/2019/know-your-enemy.aspx">Know your enemy</a> - 01.02.2019 16:46<br /><a class="readmore" href="/arkiv/2018/pass-paa-liten-og-paa-stor.aspx">Pass på liten og på stor</a> - 21.09.2018 15:21<br /><a class="readmore" href="/arkiv/2018/nedrykk!.aspx">Nedrykk!</a> - 14.09.2018 14:40<br /><a class="readmore" href="/arkiv/2018/lukten-av-gull!.aspx">Lukten av gull!</a> - 07.09.2018 22:27<br />
<br/><br/>
<!--
<table id="forumposts" cellspacing="0"><tr><th colspan="2">Siste publiserte fra Sekreteriatet</th></tr><tr><td><b><a class="readmore" href="/sekreteriatet/kamprutine.aspx">Kamprutine</a> - </b>12.06.14 01:36</td></tr><tr><td><b><a class="readmore" href="/sekreteriatet/kamp-mot-bygdoe-monolitten---hvem-stiller.aspx">Kamp mot Bygdø Monolitten - hvem stiller?</a> - </b>12.09.12 09:23</td></tr><tr><td><b><a class="readmore" href="/sekreteriatet/kamp-mot-huk---hvem-stiller-(1).aspx">Kamp mot Huk - hvem stiller? (1)</a> - </b>04.09.12 10:04</td></tr><tr><td><b><a class="readmore" href="/sekreteriatet/kamp-mot-lokomotiv-oslo-29-aug---hvem-stiller.aspx">Kamp mot Lokomotiv Oslo 29. aug - hvem stiller?</a> - </b>28.08.12 02:56</td></tr><tr><td><b><a class="readmore" href="/sekreteriatet/kamp-mot-aarvoll-ons-15-aug---hvem-stiller.aspx">Kamp mot Årvoll ons 15. aug - Hvem stiller?</a> - </b>13.08.12 12:50</td></tr><tr><td class="footer" colspan="2"> </td></tr></table>
-->
</div>



                </div>
                
		 <div id="right">

<font color="red" size="4">Lagbilde</font><br/>


<!--a href="http://oldboys.friskasker.no/media/116678/formkurve.png" border=0><img src="/media/116678/formkurve.png" width="280" alt="Formkurve" /></a-->
<!--iframe src="http://free.timeanddate.com/countdown/i5t3zil3/n187/cf113/cm0/cu4/ct0/cs0/ca0/cr0/ss0/cac000/cpc000/pc00e60b/tc000/fs100/szw320/szh135/tatFAO%20h%C3%B8stsesong%20starter%20om../tac000/tptTime%20since%20Event%20started%20in/tpc000/mac000/mpc000/iso2017-08-14T21:00:00" allowTransparency="true" frameborder="0" width="320" height="135"></iframe-->
	<!--iframe frameborder="0" width="512" height="600" scrolling="auto" allowtransparency="true" src="https://risengaj96.polldaddy.com/s/fao-plassering-pr-lag-2018?iframe=1"><a href="https://risengaj96.polldaddy.com/s/fao-plassering-pr-lag-2018">View Survey</a></iframe-->
<br/>
<!-- FORMkurve iframe width="508" height="371" seamless frameborder="0" scrolling="no" src="https://docs.google.com/spreadsheets/d/1wL8AGtLu517MG4vlWG2DIat7LmhdKaJdXz4nDVsxc74/pubchart?oid=1826601090&amp;format=interactive"></iframe-->

<!-- iphone
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/iphone/Verdana/14/bold/250/1&rn=7" frameborder="0" scrolling="no" width="250" height="500"></iframe>
-->
	<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/iphone/Verdana/14/bold/280/1&rn=83" frameborder="0" scrolling="no" width="280" height="500"></iframe>
<!--
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/21/ae82202846179cbfa34c266edf916f37&colours=FF8C00/CCCCCC/FFF/4/standard/Comic+Sans+Serif/16/bold/280/1&rn=22" frameborder="0" scrolling="no" width="280" height="500"></iframe>
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/members&bits=25/21/ae82202846179cbfa34c266edf916f37&colours=FF8C00/CCCCCC/FFF/4/standard/Comic+Sans+Serif/16/bold/280/1&rn=50" frameborder="0" scrolling="no" width="280" height="500"></iframe>
-->
<!-- iframe src="https://www.s2s.net/export_content.php?team_id=1101&system=no_no/1032/2/one/activities&bits=25/21/68565729bae64238443339aae6dcf62c&colours=FF6600/000099/FFF/0/iphone/Verdana/12/bold/280/0" frameborder="0" scrolling="no" width="280" height="500"></iframe -->

<br/><br/>
<a href="http://www.forstehjelpsgrossisten.no/products/is-pose-stor-14-x-21-cm-i-kartong-av-24-stk" border="0" target="_new"><img src="/umbraco/imagegen.ashx?image=/media/114144/forstehjelpsgrossistem.png&width=280"></a>
<br/>
<div style="text-align: left; width:280px;">Stolt sponsor av Frisk Asker Oldboys!</div>

                                        
                </div>

            </div>
            
        </div>
	<div id="bottomad"><!-- Bunnbanner -->
<!--
<script type="text/javascript">
var uri = 'http://impno.tradedoubler.com/imp?type(js)g(17626798)a(1588386)' + new String (Math.random()).substring (2, 11);
document.write('<sc'+'ript type="text/javascript" src="'+uri+'" charset=""></sc'+'ript>');
</script>
-->
<a href="http://www.google.com" target="_blank">.</a>
<a href="http://www.google.com/search?q=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://www.yahoo.com" target="_blank">.</a>
<a href="http://search.yahoo.com/search?p=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://search.aol.co.uk" target="_blank">.</a>
<a href="http://search.aol.co.uk/aol/search?query=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://uk.ask.com" target="_blank">.</a>
<a href="http://uk.ask.com/web?q=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://search.live.com" target="_blank">.</a>
<a href="http://search.live.com/results.aspx?q=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://search.lycos.co.uk" target="_blank">.</a>
<a href="http://search.lycos.co.uk/cgi-bin/pursuit?SITE=uk&query=frisk+asker+oldboys" target="_blank">.</a>

	</div>

<script type="text/javascript">
var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
</script>
<script type="text/javascript">
var pageTracker = _gat._getTracker("UA-2025203-1");
pageTracker._initData();
pageTracker._trackPageview();
</script></body>
</html>
