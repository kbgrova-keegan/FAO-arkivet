
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">

	<head>

		<title>Farmen 2012 – referat fra årets treningsleir i Trysil  - Frisk Asker Oldboys</title>
		
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
		<meta http-equiv="imagetoolbar" CONTENT="no">
		<meta name="keywords" content="Trysil, fotball, treningsleir, oldboys, mesternes mester" />
		<meta name="description" content="Like sikkert som det går mot vår så reiser Frisk Asker Oldboys på sin tradisjonsrike treningsleir i Trysils dype skoger og forstyrrer freden, fuglelivet og lokalbefolkningen så godt vi kan, det står ikke på oss nei." />
		
		<meta name="title" content="Farmen 2012 – referat fra årets treningsleir i Trysil - Frisk Asker Oldboys" />
		<meta name="URL" content="http://oldboys.friskasker.no" />
		<meta name="language" content="Norsk" />
		<meta name="author" content="Terje Dahl" />
		<meta name="copyright" content="Frisk Asker Oldboys" />
		<meta name="reply-to" content="terjda@online.no" />
		<meta name="verify-v1" content="BxVdMcZ0uoa2KVw8RB+FBg3715LgSDXNG+RYp0gHpAI=" />

		<link type="text/css" href="/css/client.css" rel="stylesheet" />
		<link type="text/css" href="/css/default.css" rel="stylesheet" />
		<link type="text/css" href="/css/weatherCSS.css" rel="stylesheet" />

		<script type="text/javascript" src="/js/jquery.js"></script>
		<script type="text/javascript" src="/js/ufo.js"></script>
		<script type="text/javascript" src="/js/friskasker.js"></script>
		<!--script type='text/javascript' src='http://www.rdmtech.no/js/jquery.js?ver=1.2.6'></script-->
		<!--script type='text/javascript' src='http://www.rdmtech.no/js/jquery.cross-slide.js?ver=2.6'></script-->

		<!--[if IE 6]>
		<link type="text/css" href="/css/ie60.css" rel="stylesheet" />			
		<![endif]-->
		<!-- TradeDoubler site verification 1588386 --> 

	<script type='text/javascript'>
		jQuery(function($) {$(document).ready(function() {
			$('#container2').crossSlide(
				{sleep: 2, fade: 1},
				[{src: 'http://oldboys.friskasker.no/media/26561/bg-fao1.jpg'},{src: 'http://oldboys.friskasker.no/media/26566/bg-fao2.jpg'},{src: 'http://oldboys.friskasker.no/media/26571/bg-fao3.jpg'},{src: 'http://oldboys.friskasker.no/media/26576/bg-fao4.jpg'}]
			);
		});});
	</script>
	
<script type="text/javascript">
var _polldaddy = [] || _polldaddy;

_polldaddy.push( {
    type: 'slider',
    title: 'FAO-spillemodellen, skjønner du den?',
    body: 'Ta testen og bidra til å øke sjansen for sportslig utvikling av FAO!',
    button: 'Get Started &raquo;',
    domain: 'risengaj96.polldaddy.com/s/',
    id: 'fao-spillemodellen',
    placeholder: 'pd1438692132734'
} );

jQuery(function(d,c,j){$if(!document.getElementById(j)){var pd=d.createElement(c),s;pd.id=j;pd.src=('https:'==document.location.protocol)?'https://polldaddy.com/survey.js':'http://i0.poll.fm/survey.js';s=document.getElementsByTagName(c)[0];s.parentNode.insertBefore(pd,s);}}(document,'script','pd-embed'));
</script>

	
	</head>
	
	<body>
      
        <div id="container">&nbsp;
        
            <div id="header">&nbsp;
            
                <div id="logo"><a href="/"><img src="/media/26597/logos.gif" alt="Logo" /></a></div>
                <div id="rss"><a href="/data/rss/nyheter.xml">Motta RSS strøm</a></div>
		<!--div id="sitemap"><a href="/sitemap.aspx">Sitemap</a></div-->
		<div id="topknapp">
		<iframe width="280" height="160" src="https://www.youtube.com/embed/15KEqzCTrwI" frameborder="0" allowfullscreen></iframe>
		</div>
		
                

            </div>
            
            <div id="body">&nbsp;
            
                <div id="left">&nbsp;

                    <div id="date">mandag 15. april</div>
                	
                    <div class="leftnav"><a href="/">Hjem</a><br /><a href="/arkiv.aspx">Arkiv</a><br /><a href="/tabeller--terminlister.aspx">Tabeller &amp; terminlister</a><br /><a href="/kampreferat.aspx">Kampreferat</a><br /><a href="/fotballfilosofi.aspx">Fotballfilosofi</a><br /><a href="/ikke-helt-sportslig.aspx">Ikke helt sportslig</a><br /></div>
		
                    <div class="box" id="contactbox"><div class="header">Frisk Asker</div><div class="body"><a href="/frisk-asker/laget.aspx">Laget</a><br /><a href="/frisk-asker/kontakt.aspx">Kontakt</a><br /><a href="/frisk-asker/dommerhjoernet.aspx">Dommerhjørnet</a><br /><a href="https://teams.s2s.net/11225/no/" target="_new">Treningstider</a></div><div class="footer"><!----></div></div>

<!--		     <iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/standard/Verdana/14/bold/230/1&rn=84" frameborder="0" scrolling="no" width="230" height="500"></iframe>
-->
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&banner=1&system=no_no/5212/1/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/standard/Verdana/14/bold/230/1&rn=94" frameborder="0" scrolling="no" width="230" height="214"></iframe>

		     <iframe src="http://www.s2s.net/todays_skill_external.php?ccc=no" scrolling="no" width="200" height="330" frameborder="0"></iframe>
<!--
		     <div id="login">&nbsp;
                   
                    <form id="loginform" action="#">&nbsp;
                      
                        <input id="username" type="text" value="brukernavn" />
                        <input id="password" type="text" value="passord" />
                        <img src="/img/login.gif" alt="login" />
                        <a href="#">glemt passord?</a>    
                        
                    </form>
                    
                    </div>
-->
		    <div id="search">

			Artikkelsøk:<br />
			<div id="xsltsearch" xmlns:ps="urn:percipientstudios-com:xslt"><form action="/soek.aspx?" method="post" class="xsltsearch_form"><input name="search" type="text" class="input" value=""></input> <input type="submit" value="Search" class="submit" /></form></div>
		    </div>

                </div>
                
                <div id="center">
		
                    
<div class="content">

	<h1>Farmen 2012 – referat fra årets treningsleir i Trysil</h1><div class="meta">25.05.12 8:31 - Figo</div><div class="abstract"><img src="/umbraco/imagegen.ashx?image=/media/60533/farmen.jpg&amp;width=500" alt="" align="left" />Like sikkert som det går mot vår så reiser Frisk Asker Oldboys på sin tradisjonsrike treningsleir i Trysils dype skoger og forstyrrer freden, fuglelivet og lokalbefolkningen så godt vi kan, det står ikke på oss nei.</div>
<p>&nbsp;</p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>Hvis man spør den jevne Tryslingen om hvilke vårtegn som kommer
igjen hvert år, vil de nok nevne ting som at skiheisene stenger,
Nybergsund har sesongstart, Bamsefar som kryper ut av hiet,
turistene som trekker sørover og andre lignende saker. Men når de
nå får sveiseblink av å passere badstua en lørdag formiddag rundt
1.mai har de begynt å mumle "hoisann, er'e den tida igjen allerede,
nå ja ..." før de rusler bort på butikken for å høre om noen vet
hva de merkelige byfolka har funnet på i år, et sikkert vårtegn
<em>med andre ord</em> (lokal dialekt = me are ol).</p>

<p><img src="/media/60631/img_0222_335x250.jpg"  width="335"  height="250" alt="IMG_0222"/></p>

<p>Bilen med unge lovende Gunnerød kan godt starte dagen før om de
ønsker, de kommer like fullt sist opp til setra etter som alle
orienteringsposter som er funnet opp gjennom årene skal etterses og
vedlikeholdes.</p>

<p>Etter diverse utflukter på små grusveier og enkelte besøk i
Sverige var alle tre bilene på plass på tunet fredag ettermiddag og
spillerne ble installert på sine respektive rom. Resten av kvelden
bestod av god mat og drikke, før det gikk over i kortspill, godt
akkompagnert av den nystartede gruppen Gitarukulelekameratenes
falske, men dog lystige, toner fra sofakroken.</p>

<p><img src="/media/60611/gitarkameratene_340x255.jpg"  width="340"  height="255" alt="Gitarkameratene"/></p>

<p>Lørdag morgen opprant og gårsdagens pissregn var byttet med sol
og pent vær. Trampe og Figo tok morgenkaffen på verandaen før det
sakte men sikkert dukket opp en etter en søvndrukken kar fra
lokalene i 2.etage.</p>

<p>Etter hvert duftet det som vanlig av Bønnas bacon og
konsentrasjonen ble gradvis flyttet over til mat og spekulasjoner
om dagens øvelser.</p>

<p><img src="/media/60636/img_0274_340x254.jpg"  width="340"  height="254" alt="IMG_0274"/></p>

<p><em>Mesternes mester</em> startet som vanlig, med en
<strong>Trysil quiz</strong> i rolige omgivelser. Antall poeng
kunne som alltid regnes ut på en hånd og det kom fort frem at
junior hadde store ambisjoner om å trampe på de gamles enemerker og
yppet seg fra første stund med knepen seier i quiz'en.</p>

<p>At deltagerne ble <em>avvalsvolin</em> og <em>tavva</em> fælt
når de skulle beskrive ord som <em>ringisle</em> og
<em>skravvaråkk</em> sier seg selv, det var ganske
<em>halbalint</em> ja.</p>

<p><img src="/media/60561/img_0205_340x254.jpg"  width="340"  height="254" alt="sag1"/></p>

<p>Deretter bar det ut i friluft, med utdeling av de vanlige
håndsagene, og med beskjed om å lage ved av stablene med tømmer som
lå og ventet. Fantastisk innsats av alle mann har sikret varm
badestamp neste vinter :-) Vinnerlaget gjorde opp internt, med
presisjonskasting og Brøyn stod igjen som vinner av delkonkurransen
"<strong>vedkapping med sløv sag</strong>", selv om dagens sagfører
nok må sies å være Bønna, som med halvt avsagd finger ristet på
skuldrene og ga uttrykk for at "slikt skjer i tøffe konkurranser -
the show must go on!"</p>

<p><img src="/media/60566/img_0207_340x254.jpg"  width="340"  height="254" alt="sag2"/></p>

<p>Neste post på programmet, <strong>melkespannkasting på glatt
underlag</strong> (nytt av året), bød på noen artige varianter av
kasteteknikk og resultatet var helt åpent til siste kast før Keegan
kunne kåres som vinner. Hvem som snurret mest og lengst ble ikke
holdt rede på, men jeg holder en knapp på Megler2.</p>

<p><img src="/media/60571/img_0213_340x254.jpg"  width="340"  height="254" alt="IMG_0213"/></p>

<p>Så var det klart for nyvinning nummer to i år;
<strong>vardebygging</strong>. Stein ble plukket, båret og stablet
… og stablet og stablet … den gjennomsnittlige varde raste omtrent
ti ganger før den ble stående, mens en suveren vinner (Bønna)
strategisk hadde hentet fem steiner som ble satt direkte opp og
dermed ferdig en lang stund før nestemann. At dette var den eneste
varden som fortsatt stod neste dag vitner om en profesjonalitet man
ikke er vant med i Oldboys-miljøet.</p>

<p><img src="/media/60576/img_0215_224x167.jpg"  width="224"  height="167" alt="varde1"/> <img src="/media/60581/img_0220_230x172.jpg"  width="230"  height="172" alt="IMG_0220"/></p>

<p><strong>Fotballgolf</strong> var såpass populært i fjor at det
måtte med på programmet også i år. Nytt i år var den kraftige
reduksjonen i antall protester, antageligvis fordi alle var enig i
at "litt juks" var greit så lenge alle gjorde det … og det er jo
ikke så greit å se hva som skjer under grankvister og bak
steinhauger. Etter innbyrdes presisjon-konkurranse i det suverene
vinnerlaget ble det Klausen som fikk full pott.</p>

<p><img src="/media/60586/img_0229_340x254.jpg"  width="340"  height="254" alt="Fotballgolf"/></p>

<p>Etter fem konkurranser var det klart for pølsepause før
transportetappen til Østby. Foreløpige utregninger viste at Bønna
hadde en klar ledelse, men alle var samtidig klar over at den som
leder halvveis aldri har vunnet mesternes mester på slutten av
dagen, noe som skulle vise seg å slå til også i år.<img src="/media/60536/img_0231_340x254.jpg"  width="340"  height="254" alt="Pølsepause"/></p>

<p>Ferdig med transportetappen og klart for dagens
<strong>løpekonkurranse</strong>. Turen gikk rundt "Sagene ring",
forbi kirke, sagbruk og butikk før de returnerte til skoleplassen.
Det skulle vise seg at de unge fortsatt er yngst og Trampe tok
dermed sin andre seier for dagen. Det ble litt ventetid før Stian x
2 kom i mål, dessverre uten gevinst fra kakelotteriet på
Samvirkelaget.</p>

<p><img src="/media/60591/img_0240_340x254.jpg"  width="340"  height="254" alt="IMG_0240"/></p>

<p><strong>Fotballkampen</strong> som fulgte var en intens affære,
med god innsats fra begge lag. Brøyn inntok dommerrollen med glans
og da vinnerlaget var bestemt måtte den interne vinneren kåres med
snøballkasting mot flaggstang.</p>

<p><img src="/media/60596/img_0246_340x254.jpg"  width="340"  height="254" alt="IMG_0246"/></p>

<p><strong>Retur på idealtid</strong> var en øvelse som viste en
utrolig imponerende presisjon, noe som kom helt uventet på
overdommer. Fire sekunders avvik holdt ikke engang til plass på
pallen og Keegan traff nøyaktig på sekundet samme tid som første
gang.</p>

<p>Stian'ene ble her slått grundig av gamle frøken Støheim, som
passerte målstreken med sin rullator 45 sekunder før disse kom i
mål.</p>

<p><img src="/media/60601/img_0249_340x254.jpg"  width="340"  height="254" alt="badstu"/></p>

<p>Badstu med påfølgende besøk på ljugarbenken var like hyggelig
som alltid, selv om det resulterte i at COOP'en ble rekordraskt
utsolgt på solbriller, noe en måpende betjening stadig snakker om
når jeg stikker innom …</p>

<p><img src="/media/60606/img_0251_340x254.jpg"  width="340"  height="254" alt="badstu2"/></p>

<p>Det var nå klart for semifinaler og som i fjor hadde
"slowstarter Sundfør" atter avansert akkurat nok til å bli med i
det gode selskap. Dermed var det de fire forhåndsfavorittene som
skulle gjøre opp seg i mellom.</p>

<p>Først ble Bønna sendt ut etter <strong>straffespark</strong> før
Junioren Trampe røyk ut i dagens <strong>hinderløype</strong>, hvor
for øvrig Megler1 sin tidligere militærkarriere kom til syne i et
17 sekunder kort glimt.</p>

<p>For ordens skyld må vi ta med at Trampe var den eneste med seier
i tre deløvelser, mens Bønna var den eneste som tok poeng i
samtlige øvelser.</p>

<p><img src="/media/60616/img_0255_340x254.jpg"  width="340"  height="254" alt="IMG_0255"/></p>

<p>Dermed var det klart for nok en finale mellom Keegan og Megler1.
Årets avgjørende konkurranse var <strong>vedkløyving</strong> med
færrest mulig hugg. Imponerende innsats fra begge to, men hvor en
liten feilberegning fra Keegan ble avgjørende og Megler1 kunne
sette inn det avgjørende støtet som, med en imponerende kraft,
delte både stubben og øksa.</p>

<p><img src="/media/60626/img_0263_340x254.jpg"  width="340"  height="254" alt="IMG_0263"/></p>

<p>Megler-1 kunne dermed innkassere sin andre seier på to forsøk -
imponerende!</p>

<p>Hvis dette gjentar seg neste år vil Lene Conradi overrekke
Mesterbrevet som gir løyve til å drive med ubegrenset selvskryt og
hovering mot samtlige Askerbøringer. Det vil også bli sendt inn en
nominasjon til St.Hans Fortjenestemedalje i titan og 17.mai toget i
Asker vil høyst sannsynlig dirigeres om Bleikeråsen for all
fremtid.</p>

<p><img src="/media/60621/img_0269_246x329.jpg"  width="246"  height="329" alt="vedkløv"/></p>

<p>Når jubelen la seg var det tid for tidenes første årsmøte i AIL.
Dette ble avholdt i verdige former, riktignok med en rekke
kommentarer av varierende kvalitet, men kort oppsummert står
utsagnet "jeg er stolt av å være medlem i en slik klubb" tilbake
som en grei beskrivelse av stemningen i idrettslaget på
årsmøtet.</p>

<p><img src="/media/60541/img_0270_340x254.jpg"  width="340"  height="254" alt="Årsmøte AIL"/></p>

<p>Dagens middag bestod tradisjonelt nok av Bacalao og en mett og
trett forsamling roet seg kraftig ned utover kvelden, etter at
premieutdeling og hyllest av mesteren var unnagjort.</p>

<p><img src="/media/60546/bilde (4)_340x255.jpg"  width="340"  height="255" alt="Premieutdeling"/></p>

<p>Årets vinner av MGP senior måtte riktignok fremføre
vinnermelodien en gang til. Årets melodi var for øvrig en ballade
med et visst populistisk innhold.</p>

<p><img src="/media/60551/ukulele_250x301.jpg"  width="250"  height="301" alt="ukulele"/></p>

<p>Når månemannen bukket pent og stilig og flesteparten hadde
sluknet fikk Gitarukulelekameratene, med manager, en tur i
badestampen som holdt veldig god temperatur … på overflaten …</p>

<p><img src="/media/60556/dsc00889_339x190.jpg"  width="339"  height="190" alt="Stamp"/></p>

<p>&nbsp;</p>

<p>Takk for nok en hyggelig treningsleir - Hilsen Figo</p>

<p>Alltid - (blid) Uansett</p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p><img src="/media/60641/lagbilden smal_499x245.jpg"  width="499"  height="245" alt="Lagbilden smal"/></p>



<div class="addthis_toolbox addthis_default_style">
<a href="http://www.addthis.com/bookmark.php?v=250&amp;username=xa-4be09cd0025b8da5" class="addthis_button_compact">Share</a>
<span class="addthis_separator">|</span>
<a class="addthis_button_facebook"></a>
<a class="addthis_button_myspace"></a>
<a class="addthis_button_google"></a>
<a class="addthis_button_twitter"></a>
</div>
<script type="text/javascript" src="http://s7.addthis.com/js/250/addthis_widget.js#username=xa-4be09cd0025b8da5"></script>
<!-- AddThis Button END -->

<hr>
<h2>Kommentarer:</h2>
	
<!--
<p>
<b>Kommentering er midlertidig steng pga SPAM!</b>
</p>
-->
<form method="post" action="farmen-2012-%E2%80%93-referat-fra-aarets-treningsleir-i-trysil.aspx" id="aspnetForm">
<div>
<input type="hidden" name="__EVENTTARGET" id="__EVENTTARGET" value="" />
<input type="hidden" name="__EVENTARGUMENT" id="__EVENTARGUMENT" value="" />
<input type="hidden" name="__VIEWSTATE" id="__VIEWSTATE" value="/wEPDwUENTM4MQ9kFgJmD2QWAmYPZBYCZg9kFgJmD2QWAgIPD2QWAgIFD2QWAgIBD2QWAmYPZBYCAgIPZBYCAgEPFgIeBFRleHQFF0RpbiBrb21tZW50YXIgZXIgcG9zdGV0ZGTP3+kahhm7HkFLDJ1eDASlO9mxvA==" />
</div>

<script type="text/javascript">
//<![CDATA[
var theForm = document.forms['aspnetForm'];
if (!theForm) {
    theForm = document.aspnetForm;
}
function __doPostBack(eventTarget, eventArgument) {
    if (!theForm.onsubmit || (theForm.onsubmit() != false)) {
        theForm.__EVENTTARGET.value = eventTarget;
        theForm.__EVENTARGUMENT.value = eventArgument;
        theForm.submit();
    }
}
//]]>
</script>


<script src="/WebResource.axd?d=RhJRe7vAQjxLvd0VTiPlJ3ItrtWKNnlC5ndUOdQ1oQE84Jw0mmyu8t9423FKr6Sh25O1JfgygCRLDXncXNuX2rijfWY1&amp;t=635737087099672665" type="text/javascript"></script>


<script type="text/javascript">
//<![CDATA[
function insertLink(element) {var theLink = prompt('Enter URL for link here:','http://');insertTag(element, 'a', ' href="' + theLink + '"')}
            function insertTag(element, tag, param) {
            start = '<' + tag + param + '>';
            eind = '</' + tag + '>';
             /* element = document.getElementById(element); */
              if (document.selection) {
                element.focus();
                sel = document.selection.createRange();
                sel.text = start + sel.text + eind;
              } else if (element.selectionStart || element.selectionStart == '0') {
                element.focus();
                var startPos = element.selectionStart;
                var endPos = element.selectionEnd;
                element.value = element.value.substring(0, startPos) + start + element.value.substring(startPos, endPos) + eind + element.value.substring(endPos, element.value.length);
              } else {
                element.value += start + eind;
              }
            }
            //]]>
</script>

<h2>Post en kommentar:</h2>
<div id="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_PanelInput">
	
	<div id="umbracoAutoForm">
	
  <fieldset>
			<p><label for="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_navn">Navn:</label><input name="ctl00$ctl00$ctl00$ContentPlaceHolderDefault$MainContentPlaceHolder$AutoForm_7$navn" type="text" id="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_navn" class="umbEditorTextField" /></p><p><label for="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_epost">Epost:</label><input name="ctl00$ctl00$ctl00$ContentPlaceHolderDefault$MainContentPlaceHolder$AutoForm_7$epost" type="text" id="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_epost" class="umbEditorTextField" /></p><p><label for="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_kommentar">Kommentar:</label><table border="0" cellspacing="0" cellpadding="0"><tr><td>
	<p align="right" style="margin: 0px; padding:0px"><a href="javascript:insertLink(document.getElementById('ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_kommentar'))"><img src="/umbraco_client/simpleEditor/images/link.gif" border="0" align="right" /></a><a href="javascript:insertTag(document.getElementById('ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_kommentar'), 'em', '')"><img src="/umbraco_client/simpleEditor/images/italic.gif" border="0" style="margin-left: 3px; margin-right: 3px;" align="right" /></a> <a href="javascript:insertTag(document.getElementById('ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_kommentar'), 'strong', '')"><img src="/umbraco_client/simpleEditor/images/bold.gif" border="0" align="right" /></a><br/></p>
	<textarea name="ctl00$ctl00$ctl00$ContentPlaceHolderDefault$MainContentPlaceHolder$AutoForm_7$kommentar" rows="8" cols="20" id="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_kommentar" class="umbEditorTextField"></textarea></td></tr></table>
	</p><p><label for="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_captcha">Captcha:</label><input name="ctl00$ctl00$ctl00$ContentPlaceHolderDefault$MainContentPlaceHolder$AutoForm_7$captcha" type="text" id="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_captcha" class="umbEditorNumberField" /><br/><span class="umbracoAutoFormRowDescription">Hva er elleve pluss åtte?<br/></span></p>
		<p><input type="submit" name="ctl00$ctl00$ctl00$ContentPlaceHolderDefault$MainContentPlaceHolder$AutoForm_7$Button1" value="Post kommentar" onclick="javascript:WebForm_DoPostBackWithOptions(new WebForm_PostBackOptions(&quot;ctl00$ctl00$ctl00$ContentPlaceHolderDefault$MainContentPlaceHolder$AutoForm_7$Button1&quot;, &quot;&quot;, true, &quot;&quot;, &quot;&quot;, false, false))" id="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_Button1" class="umbracoAutoFormButton" /></p>
	</fieldset>		
	</div>

</div>

		

<div>

	<input type="hidden" name="__VIEWSTATEGENERATOR" id="__VIEWSTATEGENERATOR" value="CA0B0334" />
</div></form>

<a class="readmore" href="/arkiv/2021/frisk-asker---covid-19-19-.aspx">Frisk Asker - Covid 19-19 </a> - 17.03.2021 8:41<br /><a class="readmore" href="/arkiv/2016/faos-sommerkrim.aspx">FAOs sommerkrim</a> - 29.04.2020 12:32<br /><a class="readmore" href="/arkiv/2019/fao-med-kupp-paa-overgangsmarkedet!.aspx">FAO med kupp på overgangsmarkedet!</a> - 30.07.2019 19:24<br /><a class="readmore" href="/arkiv/2019/dag-ansatt-som-fast-lagleder-paa-frisk-asker-m33.aspx">Dag ansatt som fast lagleder på Frisk Asker M33</a> - 29.07.2019 12:28<br /><a class="readmore" href="/arkiv/2019/askermesterskapet-i-oldboysfotball.aspx">Askermesterskapet i oldboysfotball</a> - 07.05.2019 16:49<br /><a class="readmore" href="/arkiv/2019/frisk-asker-oldgirls!.aspx">Frisk Asker OldGIRLS!</a> - 05.04.2019 14:14<br /><a class="readmore" href="/arkiv/2019/know-your-enemy.aspx">Know your enemy</a> - 01.02.2019 16:46<br /><a class="readmore" href="/arkiv/2018/pass-paa-liten-og-paa-stor.aspx">Pass på liten og på stor</a> - 21.09.2018 15:21<br /><a class="readmore" href="/arkiv/2018/nedrykk!.aspx">Nedrykk!</a> - 14.09.2018 14:40<br /><a class="readmore" href="/arkiv/2018/lukten-av-gull!.aspx">Lukten av gull!</a> - 07.09.2018 22:27<br />
<br/><br/>
<!--
<table id="forumposts" cellspacing="0"><tr><th colspan="2">Siste publiserte fra Sekreteriatet</th></tr><tr><td><b><a class="readmore" href="/sekreteriatet/kamprutine.aspx">Kamprutine</a> - </b>12.06.14 01:36</td></tr><tr><td><b><a class="readmore" href="/sekreteriatet/kamp-mot-bygdoe-monolitten---hvem-stiller.aspx">Kamp mot Bygdø Monolitten - hvem stiller?</a> - </b>12.09.12 09:23</td></tr><tr><td><b><a class="readmore" href="/sekreteriatet/kamp-mot-huk---hvem-stiller-(1).aspx">Kamp mot Huk - hvem stiller? (1)</a> - </b>04.09.12 10:04</td></tr><tr><td><b><a class="readmore" href="/sekreteriatet/kamp-mot-lokomotiv-oslo-29-aug---hvem-stiller.aspx">Kamp mot Lokomotiv Oslo 29. aug - hvem stiller?</a> - </b>28.08.12 02:56</td></tr><tr><td><b><a class="readmore" href="/sekreteriatet/kamp-mot-aarvoll-ons-15-aug---hvem-stiller.aspx">Kamp mot Årvoll ons 15. aug - Hvem stiller?</a> - </b>13.08.12 12:50</td></tr><tr><td class="footer" colspan="2"> </td></tr></table>
-->
</div>



                </div>
                
		 <div id="right">

<font color="red" size="4">Lagbilde</font><br/>


<!--a href="http://oldboys.friskasker.no/media/116678/formkurve.png" border=0><img src="/media/116678/formkurve.png" width="280" alt="Formkurve" /></a-->
<!--iframe src="http://free.timeanddate.com/countdown/i5t3zil3/n187/cf113/cm0/cu4/ct0/cs0/ca0/cr0/ss0/cac000/cpc000/pc00e60b/tc000/fs100/szw320/szh135/tatFAO%20h%C3%B8stsesong%20starter%20om../tac000/tptTime%20since%20Event%20started%20in/tpc000/mac000/mpc000/iso2017-08-14T21:00:00" allowTransparency="true" frameborder="0" width="320" height="135"></iframe-->
	<!--iframe frameborder="0" width="512" height="600" scrolling="auto" allowtransparency="true" src="https://risengaj96.polldaddy.com/s/fao-plassering-pr-lag-2018?iframe=1"><a href="https://risengaj96.polldaddy.com/s/fao-plassering-pr-lag-2018">View Survey</a></iframe-->
<br/>
<!-- FORMkurve iframe width="508" height="371" seamless frameborder="0" scrolling="no" src="https://docs.google.com/spreadsheets/d/1wL8AGtLu517MG4vlWG2DIat7LmhdKaJdXz4nDVsxc74/pubchart?oid=1826601090&amp;format=interactive"></iframe-->

<!-- iphone
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/iphone/Verdana/14/bold/250/1&rn=7" frameborder="0" scrolling="no" width="250" height="500"></iframe>
-->
	<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/iphone/Verdana/14/bold/280/1&rn=83" frameborder="0" scrolling="no" width="280" height="500"></iframe>
<!--
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/21/ae82202846179cbfa34c266edf916f37&colours=FF8C00/CCCCCC/FFF/4/standard/Comic+Sans+Serif/16/bold/280/1&rn=22" frameborder="0" scrolling="no" width="280" height="500"></iframe>
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/members&bits=25/21/ae82202846179cbfa34c266edf916f37&colours=FF8C00/CCCCCC/FFF/4/standard/Comic+Sans+Serif/16/bold/280/1&rn=50" frameborder="0" scrolling="no" width="280" height="500"></iframe>
-->
<!-- iframe src="https://www.s2s.net/export_content.php?team_id=1101&system=no_no/1032/2/one/activities&bits=25/21/68565729bae64238443339aae6dcf62c&colours=FF6600/000099/FFF/0/iphone/Verdana/12/bold/280/0" frameborder="0" scrolling="no" width="280" height="500"></iframe -->

<br/><br/>
<a href="http://www.forstehjelpsgrossisten.no/products/is-pose-stor-14-x-21-cm-i-kartong-av-24-stk" border="0" target="_new"><img src="/umbraco/imagegen.ashx?image=/media/114144/forstehjelpsgrossistem.png&width=280"></a>
<br/>
<div style="text-align: left; width:280px;">Stolt sponsor av Frisk Asker Oldboys!</div>

                                        
                </div>

            </div>
            
        </div>
	<div id="bottomad"><!-- Bunnbanner -->
<!--
<script type="text/javascript">
var uri = 'http://impno.tradedoubler.com/imp?type(js)g(17626798)a(1588386)' + new String (Math.random()).substring (2, 11);
document.write('<sc'+'ript type="text/javascript" src="'+uri+'" charset=""></sc'+'ript>');
</script>
-->
<a href="http://www.google.com" target="_blank">.</a>
<a href="http://www.google.com/search?q=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://www.yahoo.com" target="_blank">.</a>
<a href="http://search.yahoo.com/search?p=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://search.aol.co.uk" target="_blank">.</a>
<a href="http://search.aol.co.uk/aol/search?query=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://uk.ask.com" target="_blank">.</a>
<a href="http://uk.ask.com/web?q=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://search.live.com" target="_blank">.</a>
<a href="http://search.live.com/results.aspx?q=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://search.lycos.co.uk" target="_blank">.</a>
<a href="http://search.lycos.co.uk/cgi-bin/pursuit?SITE=uk&query=frisk+asker+oldboys" target="_blank">.</a>

	</div>

<script type="text/javascript">
var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
</script>
<script type="text/javascript">
var pageTracker = _gat._getTracker("UA-2025203-1");
pageTracker._initData();
pageTracker._trackPageview();
</script></body>
</html>
