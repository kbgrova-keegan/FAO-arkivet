
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">

	<head>

		<title>2010  - Frisk Asker Oldboys</title>
		
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
		<meta http-equiv="imagetoolbar" CONTENT="no">
		<meta name="keywords" content="" />
		<meta name="description" content="" />
		
		<meta name="title" content="2010 - Frisk Asker Oldboys" />
		<meta name="URL" content="http://oldboys.friskasker.no" />
		<meta name="language" content="Norsk" />
		<meta name="author" content="Terje Dahl" />
		<meta name="copyright" content="Frisk Asker Oldboys" />
		<meta name="reply-to" content="terjda@online.no" />
		<meta name="verify-v1" content="BxVdMcZ0uoa2KVw8RB+FBg3715LgSDXNG+RYp0gHpAI=" />

		<link type="text/css" href="/css/client.css" rel="stylesheet" />
		<link type="text/css" href="/css/default.css" rel="stylesheet" />
		<link type="text/css" href="/css/weatherCSS.css" rel="stylesheet" />

		<script type="text/javascript" src="/js/jquery.js"></script>
		<script type="text/javascript" src="/js/ufo.js"></script>
		<script type="text/javascript" src="/js/friskasker.js"></script>
		<!--script type='text/javascript' src='http://www.rdmtech.no/js/jquery.js?ver=1.2.6'></script-->
		<!--script type='text/javascript' src='http://www.rdmtech.no/js/jquery.cross-slide.js?ver=2.6'></script-->

		<!--[if IE 6]>
		<link type="text/css" href="/css/ie60.css" rel="stylesheet" />			
		<![endif]-->
		<!-- TradeDoubler site verification 1588386 --> 

	<script type='text/javascript'>
		jQuery(function($) {$(document).ready(function() {
			$('#container2').crossSlide(
				{sleep: 2, fade: 1},
				[{src: 'http://oldboys.friskasker.no/media/26561/bg-fao1.jpg'},{src: 'http://oldboys.friskasker.no/media/26566/bg-fao2.jpg'},{src: 'http://oldboys.friskasker.no/media/26571/bg-fao3.jpg'},{src: 'http://oldboys.friskasker.no/media/26576/bg-fao4.jpg'}]
			);
		});});
	</script>
	
<script type="text/javascript">
var _polldaddy = [] || _polldaddy;

_polldaddy.push( {
    type: 'slider',
    title: 'FAO-spillemodellen, skjønner du den?',
    body: 'Ta testen og bidra til å øke sjansen for sportslig utvikling av FAO!',
    button: 'Get Started &raquo;',
    domain: 'risengaj96.polldaddy.com/s/',
    id: 'fao-spillemodellen',
    placeholder: 'pd1438692132734'
} );

jQuery(function(d,c,j){$if(!document.getElementById(j)){var pd=d.createElement(c),s;pd.id=j;pd.src=('https:'==document.location.protocol)?'https://polldaddy.com/survey.js':'http://i0.poll.fm/survey.js';s=document.getElementsByTagName(c)[0];s.parentNode.insertBefore(pd,s);}}(document,'script','pd-embed'));
</script>

	
	</head>
	
	<body>
      
        <div id="container">&nbsp;
        
            <div id="header">&nbsp;
            
                <div id="logo"><a href="/"><img src="/media/26597/logos.gif" alt="Logo" /></a></div>
                <div id="rss"><a href="/data/rss/nyheter.xml">Motta RSS strøm</a></div>
		<!--div id="sitemap"><a href="/sitemap.aspx">Sitemap</a></div-->
		<div id="topknapp">
		<iframe width="280" height="160" src="https://www.youtube.com/embed/15KEqzCTrwI" frameborder="0" allowfullscreen></iframe>
		</div>
		
                

            </div>
            
            <div id="body">&nbsp;
            
                <div id="left">&nbsp;

                    <div id="date">mandag 15. april</div>
                	
                    <div class="leftnav"><a href="/">Hjem</a><br /><a href="/arkiv.aspx">Arkiv</a><br /><a href="/tabeller--terminlister.aspx">Tabeller &amp; terminlister</a><br /><a href="/kampreferat.aspx">Kampreferat</a><br /><a href="/fotballfilosofi.aspx">Fotballfilosofi</a><br /><a href="/ikke-helt-sportslig.aspx">Ikke helt sportslig</a><br /></div>
		
                    <div class="box" id="contactbox"><div class="header">Frisk Asker</div><div class="body"><a href="/frisk-asker/laget.aspx">Laget</a><br /><a href="/frisk-asker/kontakt.aspx">Kontakt</a><br /><a href="/frisk-asker/dommerhjoernet.aspx">Dommerhjørnet</a><br /><a href="https://teams.s2s.net/11225/no/" target="_new">Treningstider</a></div><div class="footer"><!----></div></div>

<!--		     <iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/standard/Verdana/14/bold/230/1&rn=84" frameborder="0" scrolling="no" width="230" height="500"></iframe>
-->
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&banner=1&system=no_no/5212/1/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/standard/Verdana/14/bold/230/1&rn=94" frameborder="0" scrolling="no" width="230" height="214"></iframe>

		     <iframe src="http://www.s2s.net/todays_skill_external.php?ccc=no" scrolling="no" width="200" height="330" frameborder="0"></iframe>
<!--
		     <div id="login">&nbsp;
                   
                    <form id="loginform" action="#">&nbsp;
                      
                        <input id="username" type="text" value="brukernavn" />
                        <input id="password" type="text" value="passord" />
                        <img src="/img/login.gif" alt="login" />
                        <a href="#">glemt passord?</a>    
                        
                    </form>
                    
                    </div>
-->
		    <div id="search">

			Artikkelsøk:<br />
			<div id="xsltsearch" xmlns:ps="urn:percipientstudios-com:xslt"><form action="/soek.aspx?" method="post" class="xsltsearch_form"><input name="search" type="text" class="input" value=""></input> <input type="submit" value="Search" class="submit" /></form></div>
		    </div>

                </div>
                
                <div id="center">
		
                    
<div class="content">

	<h1>2010</h1>


	<div class="newsitem"><h2>julenissens toppfart?</h2><div class="meta">14.12.10 09:59 - Figo</div><p>Farten må opp hvis julenissen skal rekke over hele verden og komme med gaver til alle snille barn.<br/>

Denne teksten er gammel, god og fortsatt artig lesing i adventstiden...</p><a class="readmore" href="/arkiv/2010/julenissens-toppfart.aspx">Les mer ...</a></div><div class="newsitem"><h2>De gamle er fortsatt eldst ...</h2><div class="meta">19.11.10 09:31 - Figo</div><p>De gamle er fortsatt eldst … men nå har jammen de unge blitt best
<br/><br/>
Det regelmessige prestisjeoppgjøret mellom oldboys og juniorene viste at erfaring og pondus ikke er nok, her ble både den fysiske og aerobe kapasiteten satt på knallharde prøver.

</p><a class="readmore" href="/arkiv/2010/de-gamle-er-fortsatt-eldst-.aspx">Les mer ...</a></div><div class="newsitem"><h2>Dagens fremmedord: Trenerkontinuitet</h2><div class="meta">29.10.10 08:26 - Figo</div><p>Mens trenere skifter klubber som andre skifter truser, blir gjerne klubbledelsen sittende i styrerommet år etter år ...</p><a class="readmore" href="/arkiv/2010/dagens-fremmedord-trenerkontinuitet.aspx">Les mer ...</a></div><div class="newsitem"><h2>Asker FH er klar for Adecco</h2><div class="meta">16.10.10 08:55 - Figo</div><p>Frisk Asker oldboys gratulerer Asker Fotball Herrer med opprykk til Adecco ligaen etter 3-1 seier over Notodden i den avgjørende kampen. </p><a class="readmore" href="/arkiv/2010/asker-fh-er-klar-for-adecco.aspx">Les mer ...</a></div><div class="newsitem"><h2>Futsal i vinter!</h2><div class="meta">24.09.10 11:07 - Figo</div><p>Det blir futsal hver mandag fra og med 11.oktober. Dette skjer på Blakstad skole kl.20:30 etter at alle veloppdratte unger har lagt seg for kvelden og ditto fedre har valget mellom fjernkontroll og ballkontroll.</p><a class="readmore" href="/arkiv/2010/futsal-i-vinter!.aspx">Les mer ...</a></div><div class="newsitem"><h2>Årets utenlandstur utgår og går istedet til..</h2><div class="meta">31.08.10 01:49 - Administrator</div><p>da har reisekomiteen sett gjennom innkommende besvarelser og ønsker og konkludert med at årets reisemål er EUs hovedstad, sete for Europakommisjonen og Europaparlamentet. I tillegg ligger NATOs hovedkvarter i byen. Byen har også vært vertsby for verdensutstillinger i 1897, 1910, 1935 og 1958. Til utstillingen i 1958 ble Atomium bygd.</p><a class="readmore" href="/arkiv/2010/aarets-utenlandstur-utgaar-og-gaar-istedet-til.aspx">Les mer ...</a></div><div class="newsitem"><h2>KARANBA!</h2><div class="meta">19.08.10 02:02 - Figo</div><p>En del av Frisk Askers medlemmer har støttet dette fantastiske prosjektet i flere år og nå kan man se selv hvordan det går i Rio – på norsk TV. Spre budskapet til venner og bekjente slik at vi kan få flere støttespillere på banen.</p><a class="readmore" href="/arkiv/2010/karanba!.aspx">Les mer ...</a></div><div class="newsitem"><h2>En superhelt på banen!</h2><div class="meta">28.07.10 04:07 - Administrator</div><p>I en moderne tid som er preget av karrierejag og prestasjonskrav må man ikke glemme at det finnes andre verdier og ekte hverdagshelter, og det å spille fotball på oldboys nivå er ingenting å kimse av. Så, vær stolt, les mer og finn ut hvorfor akkurat du er en superhelt.</p><a class="readmore" href="/arkiv/2010/en-superhelt-paa-banen!.aspx">Les mer ...</a></div><div class="newsitem"><h2>VIVA BAFANA BAFANA….</h2><div class="meta">25.06.10 09:30 - Figo</div><p>Nå som gruppespillet er på det nærmeste ferdig og sjarmerende nasjoner som Slovenia, Nord Korea og Serbia har satt seg på flyet hjem, er det på tide å ta et lite tilbakeblikk før de skikkelige lekene begynner.</p><a class="readmore" href="/arkiv/2010/viva-bafana-bafana….aspx">Les mer ...</a></div><div class="newsitem"><h2>Norges tøffeste oldboys = Keegan</h2><div class="meta">03.05.10 10:57 - Figo</div><p>Etter å ha vært gjennom ti krevende og varierte konkurranser som strakk seg over hele lørdagen ble Mesternes Mester 2010 kåret. Karl Bernhard "Keegan" Grova stakk i år fortjent av med pokalen, mens Bønna og Stian K. fylte opp resten av seierspallen og får med seg heder og ære som kan benyttes vilt og uhemmet i hele 2010 sesongen</p><a class="readmore" href="/arkiv/2010/norges-toeffeste-oldboys-=-keegan.aspx">Les mer ...</a></div><div class="newsitem"><h2>Mesternes Mester!</h2><div class="meta">28.04.10 09:05 - Figo</div><p>Konseptet er velkjent; vi samler en gjeng tøffinger og sender de til ”Figo-Farmen” som venter ved 61 grader nord og hvor vi kårer Norges tøffeste oldboys.
</p><a class="readmore" href="/arkiv/2010/mesternes-mester!.aspx">Les mer ...</a></div><div class="newsitem"><h2>Årets terminliste er klar!</h2><div class="meta">22.03.10 10:02 - Figo</div><p>Årets sesong er rett rundt hjørnet og oppsettet er klart;
Som alltid er det bare å krysse av i kalenderen, gi beskjed til sjefen hjemme at onsdagene er okkupert og begynn å lete etter fotballskoene.</p><a class="readmore" href="/arkiv/2010/aarets-terminliste-er-klar!.aspx">Les mer ...</a></div><div class="newsitem"><h2>Trysilsmellen 2010</h2><div class="meta">17.03.10 08:12 - Figo</div><p>Det begynner å nærme seg tiden for den årvisse og tradisjonelle treningsleiren i Trysil.
Finn ut hvilken helg du får lov av kona til å reise og legg inn din stemme.</p><a class="readmore" href="/arkiv/2010/trysilsmellen-2010.aspx">Les mer ...</a></div><div class="newsitem"><h2>Årsmøte FAO!</h2><div class="meta">07.03.10 09:53 - Keegan</div><p>Årsmøteprotokoll 2009</p><a class="readmore" href="/arkiv/2010/aarsmoete-fao!.aspx">Les mer ...</a></div><div class="newsitem"><h2>OL ilden har sluknet...</h2><div class="meta">01.03.10 04:35 - Figo</div><p>Så var leken over for denne gang, bålet er slukket og Petter har tatt med seg Pølsa hjem. Nå kan Oddbjørn plukke ut isen av rubben og putte den i glasset der is skal være.</p><a class="readmore" href="/arkiv/2010/ol-ilden-har-sluknet.aspx">Les mer ...</a></div><div class="newsitem"><h2>Alt for Reidar!</h2><div class="meta">19.01.10 09:57 - Keegan</div><p>Vi gratulerer Reidar med jobben som ny leder av Frisk Asker Fotball!
</p><a class="readmore" href="/arkiv/2010/alt-for-reidar!.aspx">Les mer ...</a></div>

</div>




                </div>
                
		 <div id="right">

<font color="red" size="4">Lagbilde</font><br/>


<!--a href="http://oldboys.friskasker.no/media/116678/formkurve.png" border=0><img src="/media/116678/formkurve.png" width="280" alt="Formkurve" /></a-->
<!--iframe src="http://free.timeanddate.com/countdown/i5t3zil3/n187/cf113/cm0/cu4/ct0/cs0/ca0/cr0/ss0/cac000/cpc000/pc00e60b/tc000/fs100/szw320/szh135/tatFAO%20h%C3%B8stsesong%20starter%20om../tac000/tptTime%20since%20Event%20started%20in/tpc000/mac000/mpc000/iso2017-08-14T21:00:00" allowTransparency="true" frameborder="0" width="320" height="135"></iframe-->
	<!--iframe frameborder="0" width="512" height="600" scrolling="auto" allowtransparency="true" src="https://risengaj96.polldaddy.com/s/fao-plassering-pr-lag-2018?iframe=1"><a href="https://risengaj96.polldaddy.com/s/fao-plassering-pr-lag-2018">View Survey</a></iframe-->
<br/>
<!-- FORMkurve iframe width="508" height="371" seamless frameborder="0" scrolling="no" src="https://docs.google.com/spreadsheets/d/1wL8AGtLu517MG4vlWG2DIat7LmhdKaJdXz4nDVsxc74/pubchart?oid=1826601090&amp;format=interactive"></iframe-->

<!-- iphone
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/iphone/Verdana/14/bold/250/1&rn=7" frameborder="0" scrolling="no" width="250" height="500"></iframe>
-->
	<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/iphone/Verdana/14/bold/280/1&rn=83" frameborder="0" scrolling="no" width="280" height="500"></iframe>
<!--
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/21/ae82202846179cbfa34c266edf916f37&colours=FF8C00/CCCCCC/FFF/4/standard/Comic+Sans+Serif/16/bold/280/1&rn=22" frameborder="0" scrolling="no" width="280" height="500"></iframe>
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/members&bits=25/21/ae82202846179cbfa34c266edf916f37&colours=FF8C00/CCCCCC/FFF/4/standard/Comic+Sans+Serif/16/bold/280/1&rn=50" frameborder="0" scrolling="no" width="280" height="500"></iframe>
-->
<!-- iframe src="https://www.s2s.net/export_content.php?team_id=1101&system=no_no/1032/2/one/activities&bits=25/21/68565729bae64238443339aae6dcf62c&colours=FF6600/000099/FFF/0/iphone/Verdana/12/bold/280/0" frameborder="0" scrolling="no" width="280" height="500"></iframe -->

<br/><br/>
<a href="http://www.forstehjelpsgrossisten.no/products/is-pose-stor-14-x-21-cm-i-kartong-av-24-stk" border="0" target="_new"><img src="/umbraco/imagegen.ashx?image=/media/114144/forstehjelpsgrossistem.png&width=280"></a>
<br/>
<div style="text-align: left; width:280px;">Stolt sponsor av Frisk Asker Oldboys!</div>

                                        
                </div>

            </div>
            
        </div>
	<div id="bottomad"><!-- Bunnbanner -->
<!--
<script type="text/javascript">
var uri = 'http://impno.tradedoubler.com/imp?type(js)g(17626798)a(1588386)' + new String (Math.random()).substring (2, 11);
document.write('<sc'+'ript type="text/javascript" src="'+uri+'" charset=""></sc'+'ript>');
</script>
-->
<a href="http://www.google.com" target="_blank">.</a>
<a href="http://www.google.com/search?q=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://www.yahoo.com" target="_blank">.</a>
<a href="http://search.yahoo.com/search?p=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://search.aol.co.uk" target="_blank">.</a>
<a href="http://search.aol.co.uk/aol/search?query=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://uk.ask.com" target="_blank">.</a>
<a href="http://uk.ask.com/web?q=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://search.live.com" target="_blank">.</a>
<a href="http://search.live.com/results.aspx?q=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://search.lycos.co.uk" target="_blank">.</a>
<a href="http://search.lycos.co.uk/cgi-bin/pursuit?SITE=uk&query=frisk+asker+oldboys" target="_blank">.</a>

	</div>

<script type="text/javascript">
var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
</script>
<script type="text/javascript">
var pageTracker = _gat._getTracker("UA-2025203-1");
pageTracker._initData();
pageTracker._trackPageview();
</script></body>
</html>
