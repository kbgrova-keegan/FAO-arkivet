
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">

	<head>

		<title>M40: Vollen - Frisk Asker 4-4  - Frisk Asker Oldboys</title>
		
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
		<meta http-equiv="imagetoolbar" CONTENT="no">
		<meta name="keywords" content="" />
		<meta name="description" content="Hang down your head, Tom Dooley" />
		
		<meta name="title" content="M40: Vollen - Frisk Asker 4-4 - Frisk Asker Oldboys" />
		<meta name="URL" content="http://oldboys.friskasker.no" />
		<meta name="language" content="Norsk" />
		<meta name="author" content="Terje Dahl" />
		<meta name="copyright" content="Frisk Asker Oldboys" />
		<meta name="reply-to" content="terjda@online.no" />
		<meta name="verify-v1" content="BxVdMcZ0uoa2KVw8RB+FBg3715LgSDXNG+RYp0gHpAI=" />

		<link type="text/css" href="/css/client.css" rel="stylesheet" />
		<link type="text/css" href="/css/default.css" rel="stylesheet" />
		<link type="text/css" href="/css/weatherCSS.css" rel="stylesheet" />

		<script type="text/javascript" src="/js/jquery.js"></script>
		<script type="text/javascript" src="/js/ufo.js"></script>
		<script type="text/javascript" src="/js/friskasker.js"></script>
		<!--script type='text/javascript' src='http://www.rdmtech.no/js/jquery.js?ver=1.2.6'></script-->
		<!--script type='text/javascript' src='http://www.rdmtech.no/js/jquery.cross-slide.js?ver=2.6'></script-->

		<!--[if IE 6]>
		<link type="text/css" href="/css/ie60.css" rel="stylesheet" />			
		<![endif]-->
		<!-- TradeDoubler site verification 1588386 --> 

	<script type='text/javascript'>
		jQuery(function($) {$(document).ready(function() {
			$('#container2').crossSlide(
				{sleep: 2, fade: 1},
				[{src: 'http://oldboys.friskasker.no/media/26561/bg-fao1.jpg'},{src: 'http://oldboys.friskasker.no/media/26566/bg-fao2.jpg'},{src: 'http://oldboys.friskasker.no/media/26571/bg-fao3.jpg'},{src: 'http://oldboys.friskasker.no/media/26576/bg-fao4.jpg'}]
			);
		});});
	</script>
	
<script type="text/javascript">
var _polldaddy = [] || _polldaddy;

_polldaddy.push( {
    type: 'slider',
    title: 'FAO-spillemodellen, skjønner du den?',
    body: 'Ta testen og bidra til å øke sjansen for sportslig utvikling av FAO!',
    button: 'Get Started &raquo;',
    domain: 'risengaj96.polldaddy.com/s/',
    id: 'fao-spillemodellen',
    placeholder: 'pd1438692132734'
} );

jQuery(function(d,c,j){$if(!document.getElementById(j)){var pd=d.createElement(c),s;pd.id=j;pd.src=('https:'==document.location.protocol)?'https://polldaddy.com/survey.js':'http://i0.poll.fm/survey.js';s=document.getElementsByTagName(c)[0];s.parentNode.insertBefore(pd,s);}}(document,'script','pd-embed'));
</script>

	
	</head>
	
	<body>
      
        <div id="container">&nbsp;
        
            <div id="header">&nbsp;
            
                <div id="logo"><a href="/"><img src="/media/26597/logos.gif" alt="Logo" /></a></div>
                <div id="rss"><a href="/data/rss/nyheter.xml">Motta RSS strøm</a></div>
		<!--div id="sitemap"><a href="/sitemap.aspx">Sitemap</a></div-->
		<div id="topknapp">
		<iframe width="280" height="160" src="https://www.youtube.com/embed/15KEqzCTrwI" frameborder="0" allowfullscreen></iframe>
		</div>
		
                

            </div>
            
            <div id="body">&nbsp;
            
                <div id="left">&nbsp;

                    <div id="date">mandag 15. april</div>
                	
                    <div class="leftnav"><a href="/">Hjem</a><br /><a href="/arkiv.aspx">Arkiv</a><br /><a href="/tabeller--terminlister.aspx">Tabeller &amp; terminlister</a><br /><a href="/kampreferat.aspx">Kampreferat</a><br /><a href="/fotballfilosofi.aspx">Fotballfilosofi</a><br /><a href="/ikke-helt-sportslig.aspx">Ikke helt sportslig</a><br /></div>
		
                    <div class="box" id="contactbox"><div class="header">Frisk Asker</div><div class="body"><a href="/frisk-asker/laget.aspx">Laget</a><br /><a href="/frisk-asker/kontakt.aspx">Kontakt</a><br /><a href="/frisk-asker/dommerhjoernet.aspx">Dommerhjørnet</a><br /><a href="https://teams.s2s.net/11225/no/" target="_new">Treningstider</a></div><div class="footer"><!----></div></div>

<!--		     <iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/standard/Verdana/14/bold/230/1&rn=84" frameborder="0" scrolling="no" width="230" height="500"></iframe>
-->
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&banner=1&system=no_no/5212/1/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/standard/Verdana/14/bold/230/1&rn=94" frameborder="0" scrolling="no" width="230" height="214"></iframe>

		     <iframe src="http://www.s2s.net/todays_skill_external.php?ccc=no" scrolling="no" width="200" height="330" frameborder="0"></iframe>
<!--
		     <div id="login">&nbsp;
                   
                    <form id="loginform" action="#">&nbsp;
                      
                        <input id="username" type="text" value="brukernavn" />
                        <input id="password" type="text" value="passord" />
                        <img src="/img/login.gif" alt="login" />
                        <a href="#">glemt passord?</a>    
                        
                    </form>
                    
                    </div>
-->
		    <div id="search">

			Artikkelsøk:<br />
			<div id="xsltsearch" xmlns:ps="urn:percipientstudios-com:xslt"><form action="/soek.aspx?" method="post" class="xsltsearch_form"><input name="search" type="text" class="input" value=""></input> <input type="submit" value="Search" class="submit" /></form></div>
		    </div>

                </div>
                
                <div id="center">
		
                    
<div class="content">

	<h1>M40: Vollen - Frisk Asker 4-4</h1><div class="meta">12.05.16 21:35 - Keegan</div><div class="abstract"><img src="/umbraco/imagegen.ashx?image=/media/110869/depressed team.jpg&amp;width=500" alt="" align="left" />Hang down your head, Tom Dooley</div>
<p>Da har alle våre tre lag sesongstartet, tjohei.</p>

<p>Og alle spillere sitter nå og depper, tjohoi.</p>

<p>Det er bare ett spørsmål vi nå stiller oss, etter vårt første
møte med oss selv......; <em></em></p>

<p>Har jeg virkelig blitt <strong><span>så</span></strong>
dårlig?</p>

<p><br />
 Vi vil grave oss ned, siden sesongstarten ikke ble sånn som vi
selv hadde hauset den opp.</p>

<p>Men før vi tar frem spaden, la oss tenke på det Mads er flink
til å minne oss på:<br />
 Vi har jo faktisk ikke trent sammen på veldig lenge.<br />
 Mange har ikke trent i det hele tatt.<br />
 Da er det lurt av oss å akseptere at sånn <em>er</em> faktisk
situasjonen, og så tar vi det herfra.<br />
 Ekstra treningsøkter slår graveøkter.</p>

<p><br />
 La oss rekke hverandre hendene, og bruke vårt uslåelige knep for å
bygge teamspiriten; vi lager en fest.<br />
 Og mens vi venter på sommerfesten, kan vi spørre en medspiller om
det går bra med ham.</p>

<p>Og hvis du skulle bli spurt selv, så kan det være greit å kunne
svare helt presist.</p>

<p><a
href="https://www.google.no/url?sa=t&amp;rct=j&amp;q=&amp;esrc=s&amp;source=web&amp;cd=2&amp;ved=0ahUKEwjDobaLydXMAhXDVywKHYHkDSIQFgglMAE&amp;url=http%3A%2F%2Fwww.bymisjon.no%2Fupload%2FBDI_BECK.doc&amp;usg=AFQjCNFrgGdwJv-Kkr9JbGxhKIwl6pbKmg&amp;sig2=q_zYtCzUp8-xQh9BcZ-cwQ&amp;cad=rja">
Becks Oldboys-allmenntilstandstest:</a><em><br />
</em> <span class="smaller1">Score: 0-9: I'm fine, 10-15 Takk som
spør!, 16-19 Ikke spør!, 20-29 Kjeften!, 30+ !<br />
</span></p>

<table border="0" cellspacing="0" cellpadding="0" align="left"
style="height: 1762px; width: 500px;">
<tbody>
<tr height="21" style="height: 15.6pt;">
<td class="xl66" width="22" height="21"
style="height: 15.6pt; width: 16pt;">1</td>
<td class="xl65" width="609" style="width: 457pt;">Etter kampen var
jeg lei meg og følte meg trist</td>
<td width="14" align="right" style="width: 11pt;">1</td>
</tr>

<tr height="21" style="height: 15.6pt;">
<td class="xl66" height="21" style="height: 15.6pt;"></td>
<td class="xl65">Jeg var lei meg eller trist lenger enn bare etter
kampen</td>
<td align="right">2</td>
</tr>

<tr height="21" style="height: 15.6pt;">
<td class="xl66" height="21" style="height: 15.6pt;"></td>
<td class="xl65">Jeg er så trist og ulykkelig at jeg ikke holder
det ut</td>
<td align="right">3</td>
</tr>

<tr height="21" style="height: 15.6pt;">
<td class="xl66" height="21" style="height: 15.6pt;"></td>
<td class="xl65">Etter kampen, følte jeg meg ikke trist</td>
<td align="right">0</td>
</tr>

<tr height="21" style="height: 15.6pt;">
<td class="xl66" height="21" style="height: 15.6pt;">2</td>
<td class="xl65">Etter kampen følte jeg meg motløs i forhold til
resten av sesongen</td>
<td align="right">1</td>
</tr>

<tr height="21" style="height: 15.6pt;">
<td class="xl66" height="21" style="height: 15.6pt;"></td>
<td class="xl65">Jeg føler at jeg ikke har noen kamper å se fram
til denne sesongen</td>
<td align="right">2</td>
</tr>

<tr height="21" style="height: 15.6pt;">
<td class="xl66" height="21" style="height: 15.6pt;"></td>
<td class="xl65">Jeg føler at sesongen er håpløs og at spillet ikke
kan bedre seg</td>
<td align="right">3</td>
</tr>

<tr height="21" style="height: 15.6pt;">
<td class="xl66" height="21" style="height: 15.6pt;"></td>
<td class="xl65">Jeg er ikke særlig pessimistisk eller motløs i
forhold til sesongen</td>
<td align="right">0</td>
</tr>

<tr height="21" style="height: 15.6pt;">
<td class="xl66" height="21" style="height: 15.6pt;">3</td>
<td class="xl65">Etter kampen følte jeg at jeg hadde mislyktes mer
enn de andre spillerne</td>
<td align="right">1</td>
</tr>

<tr height="21" style="height: 15.6pt;">
<td class="xl66" height="21" style="height: 15.6pt;"></td>
<td class="xl65">Når jeg ser tilbake på karrieren, ser jeg ikke
annet enn mislykkethet</td>
<td align="right">2</td>
</tr>

<tr height="21" style="height: 15.6pt;">
<td class="xl66" height="21" style="height: 15.6pt;"></td>
<td class="xl65">Jeg føler at jeg har mislykkes fullstendig som
fotballspiller</td>
<td align="right">3</td>
</tr>

<tr height="21" style="height: 15.6pt;">
<td class="xl66" height="21" style="height: 15.6pt;"></td>
<td class="xl65">Jeg føler meg ikke som en mislykket
fotballspiller</td>
<td align="right">0</td>
</tr>

<tr height="21" style="height: 15.6pt;">
<td class="xl66" height="21" style="height: 15.6pt;">4</td>
<td class="xl65">Jeg nøt ikke kampen på samme måte som før</td>
<td align="right">1</td>
</tr>

<tr height="21" style="height: 15.6pt;">
<td class="xl66" height="21" style="height: 15.6pt;"></td>
<td class="xl65">Jeg nyter ikke noen kamper lenger</td>
<td align="right">2</td>
</tr>

<tr height="21" style="height: 15.6pt;">
<td class="xl66" height="21" style="height: 15.6pt;"></td>
<td class="xl65">Jeg er misfornøyd med alle kamper</td>
<td align="right">3</td>
</tr>

<tr height="21" style="height: 15.6pt;">
<td class="xl66" height="21" style="height: 15.6pt;"></td>
<td class="xl65">Jeg nyter kamper som før</td>
<td align="right">0</td>
</tr>

<tr height="21" style="height: 15.6pt;">
<td class="xl66" height="21" style="height: 15.6pt;">5</td>
<td class="xl65">Etter kampen følte jeg skyld for en stor del av
resultatet</td>
<td align="right">1</td>
</tr>

<tr height="21" style="height: 15.6pt;">
<td class="xl66" height="21" style="height: 15.6pt;"></td>
<td class="xl65">Jeg føler skyld i mesteparten av kampene</td>
<td align="right">2</td>
</tr>

<tr height="21" style="height: 15.6pt;">
<td class="xl66" height="21" style="height: 15.6pt;"></td>
<td class="xl65">Jeg føler skyld i alle kamper</td>
<td align="right">3</td>
</tr>

<tr height="21" style="height: 15.6pt;">
<td class="xl66" height="21" style="height: 15.6pt;"></td>
<td class="xl65">Jeg føler ikke særlig skyld for resultatet</td>
<td align="right">0</td>
</tr>

<tr height="21" style="height: 15.6pt;">
<td class="xl66" height="21" style="height: 15.6pt;">6</td>
<td class="xl65">På kampen følte jeg at jeg kunne fått kjeft</td>
<td align="right">1</td>
</tr>

<tr height="21" style="height: 15.6pt;">
<td class="xl66" height="21" style="height: 15.6pt;"></td>
<td class="xl65">Jeg forventet å få kjeft</td>
<td align="right">2</td>
</tr>

<tr height="21" style="height: 15.6pt;">
<td class="xl66" height="21" style="height: 15.6pt;"></td>
<td class="xl65">Jeg føler at jeg fikk kjeft</td>
<td align="right">3</td>
</tr>

<tr height="21" style="height: 15.6pt;">
<td class="xl66" height="21" style="height: 15.6pt;"></td>
<td class="xl65">Jeg har ikke følelsen av at jeg fikk kjeft</td>
<td align="right">0</td>
</tr>

<tr height="21" style="height: 15.6pt;">
<td class="xl66" height="21" style="height: 15.6pt;">7</td>
<td class="xl65">Etter kampen var jeg skuffet over meg selv</td>
<td align="right">1</td>
</tr>

<tr height="21" style="height: 15.6pt;">
<td class="xl66" height="21" style="height: 15.6pt;"></td>
<td class="xl65">Jeg avskydde meg selv</td>
<td align="right">2</td>
</tr>

<tr height="21" style="height: 15.6pt;">
<td class="xl66" height="21" style="height: 15.6pt;"></td>
<td class="xl65">Jeg hatet meg selv</td>
<td align="right">3</td>
</tr>

<tr height="21" style="height: 15.6pt;">
<td class="xl66" height="21" style="height: 15.6pt;"></td>
<td class="xl65">Jeg følte meg ikke skuffet over meg selv</td>
<td align="right">0</td>
</tr>

<tr height="21" style="height: 15.6pt;">
<td class="xl66" height="21" style="height: 15.6pt;">8</td>
<td class="xl65">Etter kampen kritiserte jeg meg selv for teknisk
utførelse eller gale valg</td>
<td align="right">1</td>
</tr>

<tr height="21" style="height: 15.6pt;">
<td class="xl66" height="21" style="height: 15.6pt;"></td>
<td class="xl65">Jeg bebreider meg selv for å være i dårlig
form</td>
<td align="right">2</td>
</tr>

<tr height="21" style="height: 15.6pt;">
<td class="xl66" height="21" style="height: 15.6pt;"></td>
<td class="xl65">Jeg gir meg selv skylden for at vi ikke
vinner</td>
<td align="right">3</td>
</tr>

<tr height="21" style="height: 15.6pt;">
<td class="xl66" height="21" style="height: 15.6pt;"></td>
<td class="xl65">Jeg føler ikke at jeg spiller noe dårligere enn de
andre</td>
<td align="right">0</td>
</tr>

<tr height="21" style="height: 15.6pt;">
<td class="xl66" height="21" style="height: 15.6pt;">9</td>
<td class="xl65">Etter kampen hadde jeg tanker om å legge opp, men
jeg vil ikke omsette dem i handling</td>
<td align="right">1</td>
</tr>

<tr height="21" style="height: 15.6pt;">
<td class="xl66" height="21" style="height: 15.6pt;"></td>
<td class="xl65">Jeg ønsker å legge opp</td>
<td align="right">2</td>
</tr>

<tr height="21" style="height: 15.6pt;">
<td class="xl66" height="21" style="height: 15.6pt;"></td>
<td class="xl65">Jeg ville lagt opp om jeg fikk sjansen til
det</td>
<td align="right">3</td>
</tr>

<tr height="21" style="height: 15.6pt;">
<td class="xl66" height="21" style="height: 15.6pt;"></td>
<td class="xl65">Jeg har ikke tanker om å legge opp</td>
<td align="right">0</td>
</tr>

<tr height="21" style="height: 15.6pt;">
<td class="xl66" height="21" style="height: 15.6pt;">10</td>
<td class="xl65">Jeg gråt mer etter kampen enn jeg gjorde før</td>
<td align="right">1</td>
</tr>

<tr height="21" style="height: 15.6pt;">
<td class="xl66" height="21" style="height: 15.6pt;"></td>
<td class="xl65">Jeg gråter etter hver kamp nå</td>
<td align="right">2</td>
</tr>

<tr height="21" style="height: 15.6pt;">
<td class="xl66" height="21" style="height: 15.6pt;"></td>
<td class="xl65">Jeg pleide å kunne gråte, men nå kan jeg ikke
gråte selv om jeg gjerne ville</td>
<td align="right">3</td>
</tr>

<tr height="21" style="height: 15.6pt;">
<td class="xl66" height="21" style="height: 15.6pt;"></td>
<td class="xl65">Jeg gråter ikke etter flere kamper enn vanlig</td>
<td align="right">0</td>
</tr>

<tr height="21" style="height: 15.6pt;">
<td class="xl66" height="21" style="height: 15.6pt;">11</td>
<td class="xl65">På kampen ble jeg lettere irritert enn før</td>
<td align="right">1</td>
</tr>

<tr height="21" style="height: 15.6pt;">
<td class="xl66" height="21" style="height: 15.6pt;"></td>
<td class="xl65">Jeg føler meg irritert på alle kamper</td>
<td align="right">2</td>
</tr>

<tr height="21" style="height: 15.6pt;">
<td class="xl66" height="21" style="height: 15.6pt;"></td>
<td class="xl65">Jeg blir ikke irritert i det hele tatt over
situasjoner som pleide å irritere meg</td>
<td align="right">3</td>
</tr>

<tr height="21" style="height: 15.6pt;">
<td class="xl66" height="21" style="height: 15.6pt;"></td>
<td class="xl65">Jeg er ikke mer irritert på kamp nå enn
ellers</td>
<td align="right">0</td>
</tr>

<tr height="21" style="height: 15.6pt;">
<td class="xl66" height="21" style="height: 15.6pt;">12</td>
<td class="xl65">På kampen var jeg mindre interessert i
medspillerne enn jeg pleide å være</td>
<td align="right">1</td>
</tr>

<tr height="21" style="height: 15.6pt;">
<td class="xl66" height="21" style="height: 15.6pt;"></td>
<td class="xl65">Jeg har mistet det meste av interessen for
medspillerne på kamp</td>
<td align="right">2</td>
</tr>

<tr height="21" style="height: 15.6pt;">
<td class="xl66" height="21" style="height: 15.6pt;"></td>
<td class="xl65">Jeg har mistet all interesse for medspillerne på
kamp</td>
<td align="right">3</td>
</tr>

<tr height="21" style="height: 15.6pt;">
<td class="xl66" height="21" style="height: 15.6pt;"></td>
<td class="xl65">Jeg har ikke mistet interessen for medspillerne på
kamp</td>
<td align="right">0</td>
</tr>

<tr height="21" style="height: 15.6pt;">
<td class="xl66" height="21" style="height: 15.6pt;">13</td>
<td class="xl65">På kampen utsatte jeg å sentre mer enn
tidligere</td>
<td align="right">1</td>
</tr>

<tr height="21" style="height: 15.6pt;">
<td class="xl66" height="21" style="height: 15.6pt;"></td>
<td class="xl65">Jeg har større vanskeligheter med å sentre enn
før</td>
<td align="right">2</td>
</tr>

<tr height="21" style="height: 15.6pt;">
<td class="xl66" height="21" style="height: 15.6pt;"></td>
<td class="xl65">Jeg sentrer ikke i det hele tatt lenger</td>
<td align="right">3</td>
</tr>

<tr height="21" style="height: 15.6pt;">
<td class="xl66" height="21" style="height: 15.6pt;"></td>
<td class="xl65">Jeg sentrer omtrent like raskt som jeg alltid har
gjort</td>
<td align="right">0</td>
</tr>

<tr height="21" style="height: 15.6pt;">
<td class="xl66" height="21" style="height: 15.6pt;">14</td>
<td class="xl65">På kampen var jeg bekymret for at jeg så gammel
ut</td>
<td align="right">1</td>
</tr>

<tr height="21" style="height: 15.6pt;">
<td class="xl66" height="21" style="height: 15.6pt;"></td>
<td class="xl65">Jeg føler at det er varige forandringer i mitt
utseende som får meg til å se lite tiltrekkende ut</td>
<td align="right">2</td>
</tr>

<tr height="21" style="height: 15.6pt;">
<td class="xl66" height="21" style="height: 15.6pt;"></td>
<td class="xl65">Jeg tror jeg ser tjukk ut</td>
<td align="right">3</td>
</tr>

<tr height="21" style="height: 15.6pt;">
<td class="xl66" height="21" style="height: 15.6pt;"></td>
<td class="xl65">Jeg føler ikke at jeg ser dårligere ut enn jeg
pleide å gjøre</td>
<td align="right">0</td>
</tr>

<tr height="21" style="height: 15.6pt;">
<td class="xl66" height="21" style="height: 15.6pt;">15</td>
<td class="xl65">På kampen krevde det en ekstra anstrengelse å ta
returløp</td>
<td align="right">1</td>
</tr>

<tr height="21" style="height: 15.6pt;">
<td class="xl66" height="21" style="height: 15.6pt;"></td>
<td class="xl65">Jeg må presse meg selv meget hardt for å ta
returløp</td>
<td align="right">2</td>
</tr>

<tr height="21" style="height: 15.6pt;">
<td class="xl66" height="21" style="height: 15.6pt;"></td>
<td class="xl65">Jeg klarer ikke å ta returløp i det hele tatt</td>
<td align="right">3</td>
</tr>

<tr height="21" style="height: 15.6pt;">
<td class="xl66" height="21" style="height: 15.6pt;"></td>
<td class="xl65">Jeg kan ta returløp omtrent like godt som før</td>
<td align="right">0</td>
</tr>

<tr height="21" style="height: 15.6pt;">
<td class="xl66" height="21" style="height: 15.6pt;">16</td>
<td class="xl65">Etter kampen sov jeg ikke så godt som før</td>
<td align="right">1</td>
</tr>

<tr height="21" style="height: 15.6pt;">
<td class="xl66" height="21" style="height: 15.6pt;"></td>
<td class="xl65">Dagen etter kamp våkner jeg 1-2 timer tidligere
enn ellers, og har vanskelig for å sovne igjen</td>
<td align="right">2</td>
</tr>

<tr height="21" style="height: 15.6pt;">
<td class="xl66" height="21" style="height: 15.6pt;"></td>
<td class="xl65">Dagen etter kamp våkner jeg flere timer tidligere
enn jeg pleide, og får ikke sove igjen</td>
<td align="right">3</td>
</tr>

<tr height="21" style="height: 15.6pt;">
<td class="xl66" height="21" style="height: 15.6pt;"></td>
<td class="xl65">Jeg sover like godt etter kamp som ellers</td>
<td align="right">0</td>
</tr>

<tr height="21" style="height: 15.6pt;">
<td class="xl66" height="21" style="height: 15.6pt;">17</td>
<td class="xl65">På kampen ble jeg fortere sliten enn før</td>
<td align="right">1</td>
</tr>

<tr height="21" style="height: 15.6pt;">
<td class="xl66" height="21" style="height: 15.6pt;"></td>
<td class="xl65">Nesten hver gang jeg løp, ble jeg sliten</td>
<td align="right">2</td>
</tr>

<tr height="21" style="height: 15.6pt;">
<td class="xl66" height="21" style="height: 15.6pt;"></td>
<td class="xl65">Jeg var for sliten til å løpe noe som helst</td>
<td align="right">3</td>
</tr>

<tr height="21" style="height: 15.6pt;">
<td class="xl66" height="21" style="height: 15.6pt;"></td>
<td class="xl65">Jeg ble ikke fortere sliten enn ellers</td>
<td align="right">0</td>
</tr>

<tr height="21" style="height: 15.6pt;">
<td class="xl66" height="21" style="height: 15.6pt;">18</td>
<td class="xl65">Etter kampen var matlysten min høyere enn den var
før</td>
<td align="right">1</td>
</tr>

<tr height="21" style="height: 15.6pt;">
<td class="xl66" height="21" style="height: 15.6pt;"></td>
<td class="xl65">Matlysten min er mye høyere nå</td>
<td align="right">2</td>
</tr>

<tr height="21" style="height: 15.6pt;">
<td class="xl66" height="21" style="height: 15.6pt;"></td>
<td class="xl65">Jeg er sulten hele tiden, for tiden</td>
<td align="right">3</td>
</tr>

<tr height="21" style="height: 15.6pt;">
<td class="xl66" height="21" style="height: 15.6pt;"></td>
<td class="xl65">Matlysten min er ikke høyere enn ellers</td>
<td align="right">0</td>
</tr>

<tr height="21" style="height: 15.6pt;">
<td class="xl66" height="21" style="height: 15.6pt;">19</td>
<td class="xl65">Jeg har lagt på meg mer enn 2 kg.</td>
<td align="right">1</td>
</tr>

<tr height="21" style="height: 15.6pt;">
<td class="xl66" height="21" style="height: 15.6pt;"></td>
<td class="xl65">Jeg har lagt på meg mer enn <span></span>4
kg.</td>
<td align="right">2</td>
</tr>

<tr height="21" style="height: 15.6pt;">
<td class="xl66" height="21" style="height: 15.6pt;"></td>
<td class="xl65">Jeg har lagt på meg mer enn 6 kg.</td>
<td align="right">3</td>
</tr>

<tr height="21" style="height: 15.6pt;">
<td class="xl66" height="21" style="height: 15.6pt;"></td>
<td class="xl65">Jeg har ikke gått opp i vekt i den senere tid</td>
<td align="right">0</td>
</tr>

<tr height="21" style="height: 15.6pt;">
<td class="xl66" height="21" style="height: 15.6pt;">20</td>
<td class="xl65">På kampen var jeg bekymret for skader, urolig
mage, eller forstoppelse</td>
<td align="right">1</td>
</tr>

<tr height="21" style="height: 15.6pt;">
<td class="xl66" height="21" style="height: 15.6pt;"></td>
<td class="xl65">Jeg er meget bekymret for skader, og på kamp er
det vanskelig å tenke på noe annet</td>
<td align="right">2</td>
</tr>

<tr height="21" style="height: 15.6pt;">
<td class="xl66" height="21" style="height: 15.6pt;"></td>
<td class="xl65">Jeg er så bekymret for skader, at jeg på kamp ikke
klarer å tenke på noe annet</td>
<td align="right">3</td>
</tr>

<tr height="21" style="height: 15.6pt;">
<td class="xl66" height="21" style="height: 15.6pt;"></td>
<td class="xl65">Jeg er ikke mer bekymret for skader enn
vanlig</td>
<td align="right">0</td>
</tr>

<tr height="21" style="height: 15.6pt;">
<td class="xl66" height="21" style="height: 15.6pt;">21</td>
<td class="xl65">Etter kampen var jeg mindre interessert i sex enn
jeg var før</td>
<td align="right">1</td>
</tr>

<tr height="21" style="height: 15.6pt;">
<td class="xl66" height="21" style="height: 15.6pt;"></td>
<td class="xl65">Jeg er mye mindre interessert i sex etter kamp
nå</td>
<td align="right">2</td>
</tr>

<tr height="21" style="height: 15.6pt;">
<td class="xl66" height="21" style="height: 15.6pt;"></td>
<td class="xl65">Jeg har helt mistet interessen for sex etter
kamp</td>
<td align="right">3</td>
</tr>

<tr height="21" style="height: 15.6pt;">
<td class="xl66" height="21" style="height: 15.6pt;"></td>
<td class="xl65">Jeg har ikke merket noen forandring i mine
seksuelle interesser i det siste</td>
<td align="right">0</td>
</tr>
</tbody>
</table>

<p>&nbsp;</p>

<table border="0" cellspacing="0" cellpadding="0"
style="width: 6px; height: 64px;">
<tbody>
<tr height="21" style="height: 15.6pt;">
<td>
<p>&nbsp;</p>

<p>&nbsp;</p>
</td>
</tr>

<tr height="21" style="height: 15.6pt;">
<td height="21" style="height: 15.6pt;"></td>
<td class="xl63"></td>
<td align="right">
<p>&nbsp;</p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>&nbsp;</p>
</td>
</tr>
</tbody>
</table>

<div
style="position: absolute; left: -10000px; top: 0px; width: 1px; height: 1px; overflow: hidden;"
 id="_mcePaste">
<p class="MsoNormal">M40: Vollen - Frisk Asker 4-4</p>

<p class="MsoNormal">&nbsp;</p>

<p class="MsoNormal">Da har alle våre tre lag sesongstartet, og
alle spillere på FAO som har vært i aksjon, sitter alle nå og
depper:</p>

<p class="MsoNormal">Har jeg virkelig blitt så dårlig?</p>

<p class="MsoNormal">&nbsp;</p>

<p class="MsoNormal">Vi vil grave oss ned, siden sesongstarten ikke
ble sånn som vi selv hadde hauset den opp.</p>

<p class="MsoNormal">&nbsp;</p>

<p class="MsoNormal">Men før vi tar frem spaden, la oss høre på hva
Mads er flink til å minne oss på: Vi har jo faktisk ikke trent
sammen på veldig lenge. Mange har ikke trent i det hele tatt. Da er
det lurt av oss å akseptere at sånn er faktisk situasjonen, og så
tar vi det derfra. Ekstra treningsøkter slår graveøkter.</p>

<p class="MsoNormal">&nbsp;</p>

<p class="MsoNormal">La oss rekke hverandre hendene, og bruke vårt
uslåelige knep for å snu dårlige trender; vi lager en fest.</p>

<p class="MsoNormal">&nbsp;</p>

<p class="MsoNormal">Og mens vi venter på sommerfesten, kan vi
spørre en medspiller om det går bra med ham.</p>

<p class="MsoNormal">&nbsp;</p>

<p class="MsoNormal">Og hvis du selv blir spurt, så kan det være
greit å kunne svare helt presist.</p>

<p class="MsoNormal"><em style="mso-bidi-font-style:normal">Becks
Depresjonstest</em>:</p>

<p class="MsoNormal"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"></em></strong></p>

<p class="MsoNormal"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;">0 - 9 <em
style="mso-bidi-font-style: normal;">normal, <strong
style="mso-bidi-font-weight: normal;">10 - 15 mildt deprimert,
<strong style="mso-bidi-font-weight: normal;">16 - 19 moderat
deprimert, <strong style="mso-bidi-font-weight: normal;">20 - 29
moderat /alvorlig depresjon, <strong
style="mso-bidi-font-weight: normal;">30+ alvorlig
depresjon</strong></strong></strong></strong></em></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></p>

<p class="MsoNormal"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"></em></strong></em></strong></em></strong></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></p>

<p
style="margin-left: 18.0pt; text-indent: -18.0pt; mso-list: l0 level1 lfo1; tab-stops: list 18.0pt;"
 class="MsoNormal"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;">1. Jeg er lei meg eller føler
meg trist
1</strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></p>

<p style="margin-left:18.0pt" class="MsoNormal"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;">Jeg er lei meg eller trist
hele tiden og klarer ikke å komme ut av denne tilstanden
2</strong></em></strong></em></strong></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></p>

<p style="margin-left:18.0pt" class="MsoNormal"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;">Jeg er så trist eller
ulykkelig at jeg ikke holder det ut
3</strong></strong></em></strong></em></strong></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></p>

<p style="margin-left:18.0pt" class="MsoNormal"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;">Jeg føler meg ikke trist.
0</strong></strong></strong></em></strong></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></p>

<p style="margin-left:18.0pt" class="MsoNormal"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"></strong></strong></strong></strong></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></p>

<p class="MsoNormal"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"></strong></strong></strong></strong></strong></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></p>

<p class="MsoNormal"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"></strong></strong></strong></strong></strong></strong></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></p>

<p
style="margin-left: 18.0pt; text-indent: -18.0pt; mso-list: l0 level1 lfo1; tab-stops: list 18.0pt;"
 class="MsoNormal"><em style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;">2. Jeg er ikke særlig
pessimistisk eller motløs overfor fremtiden
0</strong></strong></strong></strong></strong></strong></strong></strong></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></p>

<p style="margin-left:18.0pt" class="MsoNormal"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;">Jeg føler meg motløs overfor
fremtiden
1</strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></p>

<p style="margin-left:18.0pt" class="MsoNormal"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;">Jeg føler at jeg ikke har noe
å se fram til
2</strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></p>

<p style="margin-left:18.0pt" class="MsoNormal"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;">Jeg føler at fremtiden er
håpløs og at forholdene ikke kan bedre seg
3</strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></p>

<p class="MsoNormal"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></p>

<p class="MsoNormal"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></p>

<p
style="margin-left: 18.0pt; text-indent: -18.0pt; mso-list: l0 level1 lfo1; tab-stops: list 18.0pt;"
 class="MsoNormal"><em style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;">3. Jeg føler meg ikke som et
mislykket menneske
0</strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></p>

<p style="margin-left:18.0pt" class="MsoNormal"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;">Jeg føler at jeg har
mislykkes mer enn andre mennesker
1</strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></p>

<p style="margin-left:18.0pt" class="MsoNormal"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;">Når jeg ser tilbake på livet
mitt, ser jeg ikke annet enn mislykkethet
2</strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></p>

<p style="margin-left:18.0pt" class="MsoNormal"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;">Jeg føler at jeg har
mislykkes fullstendig som menneske
3</strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></p>

<p class="MsoNormal"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></p>

<p class="MsoNormal"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></p>

<p
style="margin-left: 18.0pt; text-indent: -18.0pt; mso-list: l0 level1 lfo1; tab-stops: list 18.0pt;"
 class="MsoNormal"><em style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;">4. Jeg får like mye
tilfredstillelse ut av ting som før
0</strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></p>

<p style="margin-left:18.0pt" class="MsoNormal"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;">Jeg nyter ikke ting på samme
måte som før
1</strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></p>

<p style="margin-left:18.0pt" class="MsoNormal"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;">Jeg får ikke ordentlig
tilfredstillelse ut av noe lenger
2</strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></p>

<p style="margin-left:18.0pt" class="MsoNormal"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;">Jeg er misfornøyd eller
kjeder meg med alt
3</strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></p>

<p class="MsoNormal"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></p>

<p class="MsoNormal"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></p>

<p
style="margin-left: 18.0pt; text-indent: -18.0pt; mso-list: l0 level1 lfo1; tab-stops: list 18.0pt;"
 class="MsoNormal"><em style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;">5. Jeg føler meg ikke særlig
skyldbetynget
0</strong></strong></strong></strong></strong></strong></strong></strong></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></p>

<p style="margin-left:18.0pt" class="MsoNormal"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;">Jeg føler meg skyldbetynget
en stor del av tiden
1</strong></strong></strong></strong></strong></strong></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></p>

<p style="margin-left:18.0pt" class="MsoNormal"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;"><strong
style="mso-bidi-font-weight: normal;">Jeg føler meg temmelig
skyldbetynget mesteparten av tiden
2</strong></strong></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></p>

<p style="margin-left:18.0pt" class="MsoNormal"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;">Jeg føler meg skyldbetynget
hele tiden
3</strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></p>

<p class="MsoNormal"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"></strong></em></strong></em></strong></em></strong></em></strong></em></strong></em></p>

<p class="MsoNormal"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"></strong></em></strong></em></strong></em></p>

<em style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;"><strong
style="mso-bidi-font-weight: normal;"><em
style="mso-bidi-font-style: normal;">6. Jeg har ikke følelsen av å
bli straffet 0 Jeg føler at jeg kan bli straffet 1 Jeg forventer å
bli straffet 2 Jeg føler at jeg blir straffet 3 7. Jeg føler meg
ikke skuffet over meg selv 0 Jeg er skuffet over meg selv 1 Jeg
avskyr meg selv 2 Jeg hater meg selv 3 8. Jeg føler ikke at jeg er
noe dårligere enn andre 0 Jeg kritiserer meg selv for mine
svakheter eller feilgrep 1 Jeg bebreider meg selv hele tiden for
mine feil eller mangler 2 Jeg gir meg selv skylden for alt galt som
skjer 3 9. Jeg har ikke tanker om å ta livet mitt 0 Jeg har tanker
om å ta livet mitt, men jeg vil ikke omsette dem i handling 1 Jeg
ønsker å ta livet mitt 2 Jeg ville ta livet mitt om jeg fikk
sjansen til det 3 10. Jeg gråter ikke mer enn vanlig 0 Jeg gråter
mer nå enn jeg gjorde før 1 Jeg gråter hele tiden nå 2 Jeg pleide å
kunne gråte, men nå kan jeg ikke gråte selv om jeg gjerne ville 3
11. Jeg er ikke mer irritert nå enn ellers 0 Jeg blir lettere
ergerlig eller irritert enn før 1 Jeg føler meg irritert hele tiden
nå 2 Jeg blir ikke irritert i det hele tatt over ting som pleide å
irritere meg 3 12. Jeg har ikke mistet interessen for andre
mennesker 0 Jeg er mindre interessert i andre mennesker enn jeg
pleide å være 1 Jeg har mistet det meste av min interesse for andre
mennesker 2 Jeg har mistet all min interesse for andre mennesker 3
13. Jeg tar avgjørelser omtrent like lett som jeg alltid har gjort
0 Jeg forsøker å utsette det å ta avgjørelser mer enn tidligere 1
Jeg har større vanskeligheter med å ta avgjørelser enn før 2 Jeg
klarer ikke å ta avgjørelser i det hele tatt lenger 3 14. Jeg føler
ikke at jeg ser dårligere ut enn jeg pleide å gjøre 0 Jeg er
bekymret for at jeg ser gammel eller lite tiltrekkende ut 1 Jeg
føler at det er varige forandringer i mitt utseende som får meg til
å se lite tiltrekkende ut 2 Jeg tror jeg ser stygg ut 3 &nbsp; 15.
Jeg kan arbeide omtrent like godt som før 0 Det kreves en ekstra
anstrengelse for å ta fatt på noe 1 Jeg må presse meg selv meget
hardt for å gjøre noe 2 Jeg klarer ikke å gjøre noe arbeid i det
hele tatt 3 16. Jeg sover like godt som ellers 0 Jeg sover ikke så
godt som før 1 Jeg våkner 1-2 timer tidligere enn ellers og har
vanskelig for å sovne igjen 2 Jeg våkner flere timer tidligere enn
jeg pleide og får ikke sove igjen 3 17. Jeg blir ikke fortere trett
enn ellers 0 Jeg blir fortere trett enn før 1 Nesten alt jeg gjør,
blir jeg trett av 2 Jeg er for trett til å gjøre noe som helst 3
18. Matlysten min er ikke dårligere enn ellers 0 Matlysten min er
ikke så god som den var før 1 Matlysten min er mye dårligere nå 2
Jeg har ikke matlyst i det hele tatt lenger 3 19. Jeg har ikke gått
ned meget i vekst, om i det hele tatt noe, i den senere tid 0 Jeg
har tatt av mer enn 2 kg. 1 Jeg har tatt av mer enn 4 kg. 2 Jeg har
tatt av mer enn 6 kg. 3 20. Jeg er ikke mer bekymret for helsen min
enn vanlig 0 Jeg er bekymret for psykiske plager som verking og
smerter, urolig mage, eller forstoppelse 1 Jeg er meget bekymret
over fysiske plager og det er vanskelig å tenke på noe annet 2 Jeg
er så bekymret over mine fysiske plager, at jeg ikke klarer å tenke
på noe annet 3 21. Jeg har ikke merket noen forandring i mine
seksuelle interesser i det siste 0 Jeg er mindre interessert i sex
enn jeg var før 1 Jeg er mye mindre interessert i sex nå 2 Jeg har
helt mistet interessen for sex
3</em></strong></em></strong></em></div>



<div class="addthis_toolbox addthis_default_style">
<a href="http://www.addthis.com/bookmark.php?v=250&amp;username=xa-4be09cd0025b8da5" class="addthis_button_compact">Share</a>
<span class="addthis_separator">|</span>
<a class="addthis_button_facebook"></a>
<a class="addthis_button_myspace"></a>
<a class="addthis_button_google"></a>
<a class="addthis_button_twitter"></a>
</div>
<script type="text/javascript" src="http://s7.addthis.com/js/250/addthis_widget.js#username=xa-4be09cd0025b8da5"></script>
<!-- AddThis Button END -->

<hr>
<h2>Kommentarer:</h2>
	<div class="newsitem"><i><b>13.05.16 10:12 - <a href="mailto:">Turbo</a></b></i><p>Ikke spør!</p></div><div class="newsitem"><i><b>18.05.16 10:23 - <a href="mailto:">Mads</a></b></i><p>Takk som spør!</p></div>
<!--
<p>
<b>Kommentering er midlertidig steng pga SPAM!</b>
</p>
-->
<form method="post" action="m40-vollen---frisk-asker-4-4.aspx" id="aspnetForm">
<div>
<input type="hidden" name="__EVENTTARGET" id="__EVENTTARGET" value="" />
<input type="hidden" name="__EVENTARGUMENT" id="__EVENTARGUMENT" value="" />
<input type="hidden" name="__VIEWSTATE" id="__VIEWSTATE" value="/wEPDwUENTM4MQ9kFgJmD2QWAmYPZBYCZg9kFgJmD2QWAgIPD2QWAgIFD2QWAgIBD2QWAmYPZBYCAgIPZBYCAgEPFgIeBFRleHQFF0RpbiBrb21tZW50YXIgZXIgcG9zdGV0ZGTP3+kahhm7HkFLDJ1eDASlO9mxvA==" />
</div>

<script type="text/javascript">
//<![CDATA[
var theForm = document.forms['aspnetForm'];
if (!theForm) {
    theForm = document.aspnetForm;
}
function __doPostBack(eventTarget, eventArgument) {
    if (!theForm.onsubmit || (theForm.onsubmit() != false)) {
        theForm.__EVENTTARGET.value = eventTarget;
        theForm.__EVENTARGUMENT.value = eventArgument;
        theForm.submit();
    }
}
//]]>
</script>


<script src="/WebResource.axd?d=RhJRe7vAQjxLvd0VTiPlJ3ItrtWKNnlC5ndUOdQ1oQE84Jw0mmyu8t9423FKr6Sh25O1JfgygCRLDXncXNuX2rijfWY1&amp;t=635737087099672665" type="text/javascript"></script>


<script type="text/javascript">
//<![CDATA[
function insertLink(element) {var theLink = prompt('Enter URL for link here:','http://');insertTag(element, 'a', ' href="' + theLink + '"')}
            function insertTag(element, tag, param) {
            start = '<' + tag + param + '>';
            eind = '</' + tag + '>';
             /* element = document.getElementById(element); */
              if (document.selection) {
                element.focus();
                sel = document.selection.createRange();
                sel.text = start + sel.text + eind;
              } else if (element.selectionStart || element.selectionStart == '0') {
                element.focus();
                var startPos = element.selectionStart;
                var endPos = element.selectionEnd;
                element.value = element.value.substring(0, startPos) + start + element.value.substring(startPos, endPos) + eind + element.value.substring(endPos, element.value.length);
              } else {
                element.value += start + eind;
              }
            }
            //]]>
</script>

<h2>Post en kommentar:</h2>
<div id="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_PanelInput">
	
	<div id="umbracoAutoForm">
	
  <fieldset>
			<p><label for="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_navn">Navn:</label><input name="ctl00$ctl00$ctl00$ContentPlaceHolderDefault$MainContentPlaceHolder$AutoForm_7$navn" type="text" id="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_navn" class="umbEditorTextField" /></p><p><label for="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_epost">Epost:</label><input name="ctl00$ctl00$ctl00$ContentPlaceHolderDefault$MainContentPlaceHolder$AutoForm_7$epost" type="text" id="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_epost" class="umbEditorTextField" /></p><p><label for="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_kommentar">Kommentar:</label><table border="0" cellspacing="0" cellpadding="0"><tr><td>
	<p align="right" style="margin: 0px; padding:0px"><a href="javascript:insertLink(document.getElementById('ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_kommentar'))"><img src="/umbraco_client/simpleEditor/images/link.gif" border="0" align="right" /></a><a href="javascript:insertTag(document.getElementById('ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_kommentar'), 'em', '')"><img src="/umbraco_client/simpleEditor/images/italic.gif" border="0" style="margin-left: 3px; margin-right: 3px;" align="right" /></a> <a href="javascript:insertTag(document.getElementById('ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_kommentar'), 'strong', '')"><img src="/umbraco_client/simpleEditor/images/bold.gif" border="0" align="right" /></a><br/></p>
	<textarea name="ctl00$ctl00$ctl00$ContentPlaceHolderDefault$MainContentPlaceHolder$AutoForm_7$kommentar" rows="8" cols="20" id="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_kommentar" class="umbEditorTextField"></textarea></td></tr></table>
	</p><p><label for="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_captcha">Captcha:</label><input name="ctl00$ctl00$ctl00$ContentPlaceHolderDefault$MainContentPlaceHolder$AutoForm_7$captcha" type="text" id="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_captcha" class="umbEditorNumberField" /><br/><span class="umbracoAutoFormRowDescription">Hva er elleve pluss åtte?<br/></span></p>
		<p><input type="submit" name="ctl00$ctl00$ctl00$ContentPlaceHolderDefault$MainContentPlaceHolder$AutoForm_7$Button1" value="Post kommentar" onclick="javascript:WebForm_DoPostBackWithOptions(new WebForm_PostBackOptions(&quot;ctl00$ctl00$ctl00$ContentPlaceHolderDefault$MainContentPlaceHolder$AutoForm_7$Button1&quot;, &quot;&quot;, true, &quot;&quot;, &quot;&quot;, false, false))" id="ctl00_ctl00_ctl00_ContentPlaceHolderDefault_MainContentPlaceHolder_AutoForm_7_Button1" class="umbracoAutoFormButton" /></p>
	</fieldset>		
	</div>

</div>

		

<div>

	<input type="hidden" name="__VIEWSTATEGENERATOR" id="__VIEWSTATEGENERATOR" value="CA0B0334" />
</div></form>

<a class="readmore" href="/arkiv/2021/frisk-asker---covid-19-19-.aspx">Frisk Asker - Covid 19-19 </a> - 17.03.2021 8:41<br /><a class="readmore" href="/arkiv/2016/faos-sommerkrim.aspx">FAOs sommerkrim</a> - 29.04.2020 12:32<br /><a class="readmore" href="/arkiv/2019/fao-med-kupp-paa-overgangsmarkedet!.aspx">FAO med kupp på overgangsmarkedet!</a> - 30.07.2019 19:24<br /><a class="readmore" href="/arkiv/2019/dag-ansatt-som-fast-lagleder-paa-frisk-asker-m33.aspx">Dag ansatt som fast lagleder på Frisk Asker M33</a> - 29.07.2019 12:28<br /><a class="readmore" href="/arkiv/2019/askermesterskapet-i-oldboysfotball.aspx">Askermesterskapet i oldboysfotball</a> - 07.05.2019 16:49<br /><a class="readmore" href="/arkiv/2019/frisk-asker-oldgirls!.aspx">Frisk Asker OldGIRLS!</a> - 05.04.2019 14:14<br /><a class="readmore" href="/arkiv/2019/know-your-enemy.aspx">Know your enemy</a> - 01.02.2019 16:46<br /><a class="readmore" href="/arkiv/2018/pass-paa-liten-og-paa-stor.aspx">Pass på liten og på stor</a> - 21.09.2018 15:21<br /><a class="readmore" href="/arkiv/2018/nedrykk!.aspx">Nedrykk!</a> - 14.09.2018 14:40<br /><a class="readmore" href="/arkiv/2018/lukten-av-gull!.aspx">Lukten av gull!</a> - 07.09.2018 22:27<br />
<br/><br/>
<!--
<table id="forumposts" cellspacing="0"><tr><th colspan="2">Siste publiserte fra Sekreteriatet</th></tr><tr><td><b><a class="readmore" href="/sekreteriatet/kamprutine.aspx">Kamprutine</a> - </b>12.06.14 01:36</td></tr><tr><td><b><a class="readmore" href="/sekreteriatet/kamp-mot-bygdoe-monolitten---hvem-stiller.aspx">Kamp mot Bygdø Monolitten - hvem stiller?</a> - </b>12.09.12 09:23</td></tr><tr><td><b><a class="readmore" href="/sekreteriatet/kamp-mot-huk---hvem-stiller-(1).aspx">Kamp mot Huk - hvem stiller? (1)</a> - </b>04.09.12 10:04</td></tr><tr><td><b><a class="readmore" href="/sekreteriatet/kamp-mot-lokomotiv-oslo-29-aug---hvem-stiller.aspx">Kamp mot Lokomotiv Oslo 29. aug - hvem stiller?</a> - </b>28.08.12 02:56</td></tr><tr><td><b><a class="readmore" href="/sekreteriatet/kamp-mot-aarvoll-ons-15-aug---hvem-stiller.aspx">Kamp mot Årvoll ons 15. aug - Hvem stiller?</a> - </b>13.08.12 12:50</td></tr><tr><td class="footer" colspan="2"> </td></tr></table>
-->
</div>



                </div>
                
		 <div id="right">

<font color="red" size="4">Lagbilde</font><br/>


<!--a href="http://oldboys.friskasker.no/media/116678/formkurve.png" border=0><img src="/media/116678/formkurve.png" width="280" alt="Formkurve" /></a-->
<!--iframe src="http://free.timeanddate.com/countdown/i5t3zil3/n187/cf113/cm0/cu4/ct0/cs0/ca0/cr0/ss0/cac000/cpc000/pc00e60b/tc000/fs100/szw320/szh135/tatFAO%20h%C3%B8stsesong%20starter%20om../tac000/tptTime%20since%20Event%20started%20in/tpc000/mac000/mpc000/iso2017-08-14T21:00:00" allowTransparency="true" frameborder="0" width="320" height="135"></iframe-->
	<!--iframe frameborder="0" width="512" height="600" scrolling="auto" allowtransparency="true" src="https://risengaj96.polldaddy.com/s/fao-plassering-pr-lag-2018?iframe=1"><a href="https://risengaj96.polldaddy.com/s/fao-plassering-pr-lag-2018">View Survey</a></iframe-->
<br/>
<!-- FORMkurve iframe width="508" height="371" seamless frameborder="0" scrolling="no" src="https://docs.google.com/spreadsheets/d/1wL8AGtLu517MG4vlWG2DIat7LmhdKaJdXz4nDVsxc74/pubchart?oid=1826601090&amp;format=interactive"></iframe-->

<!-- iphone
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/iphone/Verdana/14/bold/250/1&rn=7" frameborder="0" scrolling="no" width="250" height="500"></iframe>
-->
	<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/37/63bb9297b8d7bc96cb3231c7abee57d5&colours=FF8C00/000000/FFF/3/iphone/Verdana/14/bold/280/1&rn=83" frameborder="0" scrolling="no" width="280" height="500"></iframe>
<!--
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/activities&bits=25/21/ae82202846179cbfa34c266edf916f37&colours=FF8C00/CCCCCC/FFF/4/standard/Comic+Sans+Serif/16/bold/280/1&rn=22" frameborder="0" scrolling="no" width="280" height="500"></iframe>
<iframe src="http://no-fotball.s2s.net/export_content.php?team_id=11225&system=no_no/5212/2/one/members&bits=25/21/ae82202846179cbfa34c266edf916f37&colours=FF8C00/CCCCCC/FFF/4/standard/Comic+Sans+Serif/16/bold/280/1&rn=50" frameborder="0" scrolling="no" width="280" height="500"></iframe>
-->
<!-- iframe src="https://www.s2s.net/export_content.php?team_id=1101&system=no_no/1032/2/one/activities&bits=25/21/68565729bae64238443339aae6dcf62c&colours=FF6600/000099/FFF/0/iphone/Verdana/12/bold/280/0" frameborder="0" scrolling="no" width="280" height="500"></iframe -->

<br/><br/>
<a href="http://www.forstehjelpsgrossisten.no/products/is-pose-stor-14-x-21-cm-i-kartong-av-24-stk" border="0" target="_new"><img src="/umbraco/imagegen.ashx?image=/media/114144/forstehjelpsgrossistem.png&width=280"></a>
<br/>
<div style="text-align: left; width:280px;">Stolt sponsor av Frisk Asker Oldboys!</div>

                                        
                </div>

            </div>
            
        </div>
	<div id="bottomad"><!-- Bunnbanner -->
<!--
<script type="text/javascript">
var uri = 'http://impno.tradedoubler.com/imp?type(js)g(17626798)a(1588386)' + new String (Math.random()).substring (2, 11);
document.write('<sc'+'ript type="text/javascript" src="'+uri+'" charset=""></sc'+'ript>');
</script>
-->
<a href="http://www.google.com" target="_blank">.</a>
<a href="http://www.google.com/search?q=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://www.yahoo.com" target="_blank">.</a>
<a href="http://search.yahoo.com/search?p=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://search.aol.co.uk" target="_blank">.</a>
<a href="http://search.aol.co.uk/aol/search?query=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://uk.ask.com" target="_blank">.</a>
<a href="http://uk.ask.com/web?q=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://search.live.com" target="_blank">.</a>
<a href="http://search.live.com/results.aspx?q=frisk+asker+oldboys" target="_blank">.</a>
<a href="http://search.lycos.co.uk" target="_blank">.</a>
<a href="http://search.lycos.co.uk/cgi-bin/pursuit?SITE=uk&query=frisk+asker+oldboys" target="_blank">.</a>

	</div>

<script type="text/javascript">
var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
</script>
<script type="text/javascript">
var pageTracker = _gat._getTracker("UA-2025203-1");
pageTracker._initData();
pageTracker._trackPageview();
</script></body>
</html>
